PRAGMA foreign_keys = ON;

-- Cloudflare D1 / SQLite shared catalogue schema. No demo inventory is seeded.
CREATE TABLE IF NOT EXISTS brands (
  id TEXT PRIMARY KEY NOT NULL, slug TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
  blurb_en TEXT NOT NULL DEFAULT '', blurb_fa TEXT NOT NULL DEFAULT '',
  sort INTEGER NOT NULL DEFAULT 0, is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY NOT NULL, slug TEXT NOT NULL UNIQUE,
  name_en TEXT NOT NULL, name_fa TEXT NOT NULL, sort INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY NOT NULL, slug TEXT NOT NULL UNIQUE, name TEXT NOT NULL,
  brand_id TEXT REFERENCES brands(id) ON DELETE SET NULL,
  category_id TEXT REFERENCES categories(id) ON DELETE SET NULL,
  price REAL NOT NULL DEFAULT 0 CHECK(price >= 0), image_url TEXT,
  desc_en TEXT NOT NULL DEFAULT '', desc_fa TEXT NOT NULL DEFAULT '',
  published INTEGER NOT NULL DEFAULT 0 CHECK(published IN (0,1)),
  is_new INTEGER NOT NULL DEFAULT 0 CHECK(is_new IN (0,1)),
  gender TEXT CHECK(gender IS NULL OR gender IN ('women','men','unisex')),
  concentration TEXT CHECK(concentration IS NULL OR concentration IN ('parfum','edp','edt','edc','extrait')),
  seasons_json TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(seasons_json)),
  notes_json TEXT NOT NULL DEFAULT '{}' CHECK(json_valid(notes_json)),
  occasions_json TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(occasions_json)),
  scent_character_json TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(scent_character_json)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS product_volumes (
  id TEXT PRIMARY KEY NOT NULL, product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  ml REAL NOT NULL CHECK(ml > 0), price REAL NOT NULL CHECK(price >= 0),
  stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0), sku TEXT UNIQUE,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  UNIQUE(product_id, ml)
);
CREATE TABLE IF NOT EXISTS product_categories (
  product_id TEXT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  category_id TEXT NOT NULL REFERENCES categories(id) ON DELETE CASCADE,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  PRIMARY KEY(product_id, category_id)
);
-- Server-only auth. Never expose these tables in public API responses.
CREATE TABLE IF NOT EXISTS admin_users (
  id TEXT PRIMARY KEY NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'admin' CHECK(role='admin'),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS admin_sessions (
  id TEXT PRIMARY KEY NOT NULL, user_id TEXT NOT NULL REFERENCES admin_users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE, expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_seen_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS admin_audit_log (
  id TEXT PRIMARY KEY NOT NULL, user_id TEXT REFERENCES admin_users(id) ON DELETE SET NULL,
  action TEXT NOT NULL, entity_type TEXT NOT NULL, entity_id TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS products_public_listing_idx ON products(published, created_at DESC);
CREATE INDEX IF NOT EXISTS products_brand_idx ON products(brand_id);
CREATE INDEX IF NOT EXISTS products_category_idx ON products(category_id);
CREATE INDEX IF NOT EXISTS volumes_product_active_idx ON product_volumes(product_id, is_active);
CREATE INDEX IF NOT EXISTS product_categories_category_idx ON product_categories(category_id);
CREATE INDEX IF NOT EXISTS sessions_user_expiry_idx ON admin_sessions(user_id, expires_at);
CREATE INDEX IF NOT EXISTS sessions_expiry_idx ON admin_sessions(expires_at);
CREATE INDEX IF NOT EXISTS audit_created_idx ON admin_audit_log(created_at DESC);

-- Persistent throttling for admin login/setup attempts.
CREATE TABLE IF NOT EXISTS admin_rate_limits (
  rate_key TEXT PRIMARY KEY NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts >= 0),
  window_started_at INTEGER NOT NULL,
  blocked_until INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS admin_rate_limits_blocked_idx ON admin_rate_limits(blocked_until);
