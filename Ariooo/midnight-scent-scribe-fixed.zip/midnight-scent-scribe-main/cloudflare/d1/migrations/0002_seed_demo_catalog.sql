-- Migration 0002: Seed Initial Demo Catalog Data for Scent Scribe
-- Target Database: scent_scribe_db
-- Status: Demonstrational seed data. Uses INSERT OR IGNORE to prevent overwriting existing data.
-- This file is source-only until explicitly applied to a D1 database.

PRAGMA foreign_keys = ON;

-- 1. BRANDS (6 Boutique Houses)
INSERT OR IGNORE INTO brands (id, slug, name, blurb_en, blurb_fa, sort, is_active) VALUES
('b-tom-ford', 'tom-ford', 'Tom Ford', 'Private Blend and Signature collections of modern luxury.', 'مجموعه‌های پرایوت بلند و سیگنیچر از عطرهای لوکس مدرن.', 1, 1),
('b-dior', 'dior', 'Dior', 'French haute parfumerie spanning timeless classics and bold moderns.', 'عطرسازی فاخر فرانسوی از کلاسیک‌های ماندگار تا رایحه‌های جسورانهٔ معاصر.', 2, 1),
('b-chanel', 'chanel', 'Chanel', 'Legendary French house defined by Gabrielle Chanel''s visionary elegance.', 'خانهٔ افسانه‌ای عطر و مد فرانسه با وقار و اصالت جاودانه.', 3, 1),
('b-ysl', 'ysl', 'Yves Saint Laurent', 'Parisian couture spirit rendered in daring oriental and floral notes.', 'روح کوتور پاریسی در قالب نت‌های شرقی و گلی ساختارشکن.', 4, 1),
('b-replica', 'replica', 'Maison Margiela Replica', 'Memory-evoking fragrance atmospheres bottled in apothecary glass.', 'رایحه‌های خاطره‌انگیز که لحظات زیسته را بازآفرینی می‌کنند.', 5, 1),
('b-guerlain', 'guerlain', 'Guerlain', 'Historic Parisian perfumer crafting legendary essences since 1828.', 'عطرساز تاریخی پاریس با میراثی نزدیک به دو قرن.', 6, 1);

-- 2. CATEGORIES (5 Fragrance Families)
INSERT OR IGNORE INTO categories (id, slug, name_en, name_fa, sort) VALUES
('cat-woody', 'woody', 'Woody & Earthy', 'چوبی و خاکی', 1),
('cat-amber', 'amber', 'Amber & Warm', 'کهربایی و گرم', 2),
('cat-floral', 'floral', 'Floral & Delicate', 'گلی و ظریف', 3),
('cat-fresh', 'fresh', 'Fresh & Citrus', 'خنک و مرکباتی', 4),
('cat-oriental', 'oriental', 'Spicy & Oriental', 'ادویه‌ای و شرقی', 5);

-- 3. PRODUCTS (12 Fragrances)
INSERT OR IGNORE INTO products (
  id, slug, name, brand_id, category_id, price, image_url,
  desc_en, desc_fa, published, is_new, gender, concentration,
  seasons_json, notes_json, occasions_json, scent_character_json
) VALUES
('p-oud-wood', 'oud-wood', 'Oud Wood', 'b-tom-ford', 'cat-woody', 195.0, 'asset:nocturne',
 'Rare oud wood, rosewood and sandalwood warmed by cardamom and Sichuan pepper.',
 'چوب عود، رزوود و صندل با گرمای هل و فلفل سیچوان؛ رایحه‌ای چوبی و مرموز.',
 1, 0, 'unisex', 'edp',
 '["fall","winter"]',
 '{"top":"Rosewood, Cardamom","heart":"Oud, Sichuan Pepper","base":"Sandalwood, Vetiver, Tonka Bean"}',
 '["evening","formal"]',
 '["mysterious","woody","opulent"]'),

('p-tobacco-vanille', 'tobacco-vanille', 'Tobacco Vanille', 'b-tom-ford', 'cat-amber', 215.0, 'asset:amber',
 'Tobacco leaf, creamy vanilla, tonka bean and cocoa create an opulent warm signature.',
 'برگ تنباکو، وانیل خامه‌ای، تونکا و کاکائو؛ ترکیبی گرم و مجلل.',
 1, 0, 'unisex', 'edp',
 '["fall","winter"]',
 '{"top":"Tobacco Leaf, Spicy Notes","heart":"Tonka Bean, Vanilla, Cacao","base":"Dry Fruit Accord, Rich Woods"}',
 '["evening","winter-gathering"]',
 '["warm","spicy","indulgent"]'),

('p-lost-cherry', 'lost-cherry', 'Lost Cherry', 'b-tom-ford', 'cat-amber', 245.0, 'asset:solstice',
 'Black cherry, bitter almond, Turkish rose and tonka in a playful, decadent composition.',
 'گیلاس سیاه، بادام تلخ، رز ترکی و تونکا؛ ترکیبی میوه‌ای، جسور و اغواگر.',
 1, 1, 'unisex', 'edp',
 '["fall","winter","spring"]',
 '{"top":"Black Cherry, Cherry Liqueur, Bitter Almond","heart":"Turkish Rose, Jasmine Sambac","base":"Peru Balsam, Tonka, Sandalwood"}',
 '["date-night","statement"]',
 '["sweet","sensual","bold"]'),

('p-sauvage', 'sauvage', 'Sauvage', 'b-dior', 'cat-fresh', 135.0, 'asset:riviere',
 'Calabrian bergamot and ambroxan create a radically fresh, energetic signature.',
 'ترنج کالابریایی و آمبروکسان؛ رایحه‌ای تازه، پرانرژی و مدرن.',
 1, 0, 'men', 'edp',
 '["spring","summer","fall"]',
 '{"top":"Calabrian Bergamot","heart":"Sichuan Pepper, Lavender, Star Anise","base":"Ambroxan, Vanilla"}',
 '["signature","daily","versatile"]',
 '["fresh","radiant","crisp"]'),

('p-miss-dior', 'miss-dior', 'Miss Dior', 'b-dior', 'cat-floral', 145.0, 'asset:floral',
 'Grasse rose, peony and iris illuminated by soft musk.',
 'رز گراس، گل صدتومانی و زنبق با هاله‌ای از مشک لطیف.',
 1, 0, 'women', 'edp',
 '["spring","summer"]',
 '{"top":"Peony, Iris","heart":"Grasse Rose","base":"Vanilla, Musk, Sandalwood"}',
 '["daytime","brunch","celebration"]',
 '["romantic","delicate","floral"]'),

('p-dior-homme-intense', 'dior-homme-intense', 'Dior Homme Intense', 'b-dior', 'cat-woody', 155.0, 'asset:nocturne',
 'Sophisticated iris balanced with ambrette and Virginia cedarwood.',
 'زنبق اشرافی در کنار آمبرت و چوب سدر ویرجینیا؛ ظریف و رسمی.',
 1, 0, 'men', 'edp',
 '["fall","winter"]',
 '{"top":"Tuscan Iris, Lavender","heart":"Ambrette Seeds, Pear Accord","base":"Virginia Cedar, Vetiver"}',
 '["black-tie","evening"]',
 '["powdery","sophisticated","warm"]'),

('p-bleu-de-chanel', 'bleu-de-chanel', 'Bleu de Chanel', 'b-chanel', 'cat-woody', 148.0, 'asset:nocturne',
 'An aromatic-woody composition with a confident, refined trail.',
 'ساختاری آروماتیک و چوبی با ردبویی متمایز، مطمئن و شیک.',
 1, 0, 'men', 'edp',
 '["spring","summer","fall","winter"]',
 '{"top":"Grapefruit, Lemon, Mint","heart":"Ginger, Nutmeg, Jasmine","base":"Incense, Vetiver, Cedar, Sandalwood"}',
 '["office","signature","evening"]',
 '["clean","charismatic","timeless"]'),

('p-no-5', 'no-5', 'N°5 Eau de Parfum', 'b-chanel', 'cat-floral', 160.0, 'asset:lumiere',
 'An abstract floral bouquet made extraordinary by the use of aldehydes.',
 'دسته‌گلی انتزاعی از آلدئیدها، یلانگ‌یلانگ، رز و یاس؛ نمادی جاودانه.',
 1, 0, 'women', 'edp',
 '["fall","winter","spring"]',
 '{"top":"Aldehydes, Ylang-Ylang, Neroli, Bergamot","heart":"Iris, Jasmine, Rose","base":"Sandalwood, Vanilla, Oakmoss"}',
 '["milestone","signature","formal"]',
 '["classic","powdery","legendary"]'),

('p-libre', 'libre', 'Libre', 'b-ysl', 'cat-floral', 140.0, 'asset:floral',
 'French lavender meets Moroccan orange blossom in a daring floral signature.',
 'اسطوخودوس فرانسوی در کنار شکوفه پرتقال مراکشی؛ جسور و آزاد.',
 1, 0, 'women', 'edp',
 '["spring","fall","winter"]',
 '{"top":"Mandarin, Petitgrain, Blackcurrant","heart":"Lavender, Jasmine, Orange Blossom","base":"Vanilla, Cedarwood, Musk"}',
 '["statement","evening","workplace"]',
 '["vibrant","daring","sensual"]'),

('p-black-opium', 'black-opium', 'Black Opium', 'b-ysl', 'cat-amber', 138.0, 'asset:spicy',
 'Black coffee and white flowers wrapped in sensual vanilla and patchouli.',
 'قهوه سیاه و گل‌های سفید در کنار وانیل و پچولی؛ شبانه و اغواگر.',
 1, 0, 'women', 'edp',
 '["fall","winter"]',
 '{"top":"Pear, Mandarin, Pink Pepper","heart":"Orange Blossom, Jasmine, Licorice","base":"Coffee, Vanilla, Cedarwood, Patchouli"}',
 '["nightlife","concert","party"]',
 '["gourmand","electrifying","addictive"]'),

('p-jazz-club', 'jazz-club', 'Jazz Club', 'b-replica', 'cat-amber', 160.0, 'asset:nocturne',
 'Rum, pink pepper, tobacco leaf and vanilla evoke an intimate jazz club.',
 'رام، فلفل صورتی، برگ تنباکو و وانیل؛ یادآور فضای یک کلوب جاز صمیمی.',
 1, 0, 'unisex', 'edt',
 '["fall","winter"]',
 '{"top":"Pink Pepper, Neroli, Lemon","heart":"Rum, Clary Sage, Vetiver","base":"Tobacco Leaf, Vanilla, Styrax"}',
 '["intimate","evening","autumn-walk"]',
 '["boozy","smoky","comforting"]'),

('p-shalimar', 'shalimar', 'Shalimar', 'b-guerlain', 'cat-amber', 150.0, 'asset:lumiere',
 'Bergamot, iris, jasmine, incense and vanilla in a legendary oriental composition.',
 'ترنج، زنبق، یاس، کندر و وانیل در ترکیبی شرقی و افسانه‌ای.',
 1, 0, 'women', 'edp',
 '["fall","winter"]',
 '{"top":"Bergamot, Lemon, Mandarin","heart":"Iris, Patchouli, Jasmine, Rose","base":"Vanilla, Incense, Tonka, Leather"}',
 '["heritage","formal","evening"]',
 '["oriental","regal","enveloping"]');

-- 4. PRODUCT VOLUMES (24 Bottle Variants)
INSERT OR IGNORE INTO product_volumes (id, product_id, ml, price, stock, sku, is_active) VALUES
('v-oud-wood-50', 'p-oud-wood', 50, 195.0, 12, 'DEMO-TF-OW-50', 1),
('v-oud-wood-100', 'p-oud-wood', 100, 285.0, 8, 'DEMO-TF-OW-100', 1),
('v-tobacco-vanille-50', 'p-tobacco-vanille', 50, 215.0, 15, 'DEMO-TF-TV-50', 1),
('v-tobacco-vanille-100', 'p-tobacco-vanille', 100, 310.0, 6, 'DEMO-TF-TV-100', 1),
('v-lost-cherry-50', 'p-lost-cherry', 50, 245.0, 9, 'DEMO-TF-LC-50', 1),
('v-lost-cherry-100', 'p-lost-cherry', 100, 365.0, 4, 'DEMO-TF-LC-100', 1),
('v-sauvage-60', 'p-sauvage', 60, 135.0, 24, 'DEMO-DR-SV-60', 1),
('v-sauvage-100', 'p-sauvage', 100, 175.0, 18, 'DEMO-DR-SV-100', 1),
('v-miss-dior-50', 'p-miss-dior', 50, 145.0, 16, 'DEMO-DR-MD-50', 1),
('v-miss-dior-100', 'p-miss-dior', 100, 185.0, 10, 'DEMO-DR-MD-100', 1),
('v-dior-homme-intense-50', 'p-dior-homme-intense', 50, 155.0, 14, 'DEMO-DR-DHI-50', 1),
('v-dior-homme-intense-100', 'p-dior-homme-intense', 100, 195.0, 7, 'DEMO-DR-DHI-100', 1),
('v-bleu-de-chanel-50', 'p-bleu-de-chanel', 50, 148.0, 20, 'DEMO-CH-BDC-50', 1),
('v-bleu-de-chanel-100', 'p-bleu-de-chanel', 100, 188.0, 15, 'DEMO-CH-BDC-100', 1),
('v-no-5-50', 'p-no-5', 50, 160.0, 11, 'DEMO-CH-N5-50', 1),
('v-no-5-100', 'p-no-5', 100, 210.0, 5, 'DEMO-CH-N5-100', 1),
('v-libre-50', 'p-libre', 50, 140.0, 22, 'DEMO-YS-LB-50', 1),
('v-libre-90', 'p-libre', 90, 180.0, 12, 'DEMO-YS-LB-90', 1),
('v-black-opium-50', 'p-black-opium', 50, 138.0, 19, 'DEMO-YS-BO-50', 1),
('v-black-opium-90', 'p-black-opium', 90, 178.0, 11, 'DEMO-YS-BO-90', 1),
('v-jazz-club-30', 'p-jazz-club', 30, 85.0, 14, 'DEMO-MM-JC-30', 1),
('v-jazz-club-100', 'p-jazz-club', 100, 160.0, 8, 'DEMO-MM-JC-100', 1),
('v-shalimar-50', 'p-shalimar', 50, 150.0, 10, 'DEMO-GL-SH-50', 1),
('v-shalimar-90', 'p-shalimar', 90, 190.0, 6, 'DEMO-GL-SH-90', 1);

-- 5. PRODUCT CATEGORIES (22 links; primary and secondary scent families)
INSERT OR IGNORE INTO product_categories (product_id, category_id) VALUES
('p-oud-wood', 'cat-woody'),
('p-oud-wood', 'cat-oriental'),
('p-tobacco-vanille', 'cat-amber'),
('p-tobacco-vanille', 'cat-oriental'),
('p-lost-cherry', 'cat-amber'),
('p-lost-cherry', 'cat-oriental'),
('p-sauvage', 'cat-fresh'),
('p-sauvage', 'cat-woody'),
('p-miss-dior', 'cat-floral'),
('p-dior-homme-intense', 'cat-woody'),
('p-dior-homme-intense', 'cat-floral'),
('p-bleu-de-chanel', 'cat-woody'),
('p-bleu-de-chanel', 'cat-fresh'),
('p-no-5', 'cat-floral'),
('p-libre', 'cat-floral'),
('p-libre', 'cat-amber'),
('p-black-opium', 'cat-amber'),
('p-black-opium', 'cat-oriental'),
('p-jazz-club', 'cat-amber'),
('p-jazz-club', 'cat-woody'),
('p-shalimar', 'cat-amber'),
('p-shalimar', 'cat-oriental');
