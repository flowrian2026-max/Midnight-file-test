PRAGMA foreign_keys = ON;

-- Store operations modules. Additive migration only: preserve all existing catalogue/admin rows.
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY NOT NULL,
  order_number TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','confirmed','processing','shipped','completed','cancelled','refunded')),
  payment_status TEXT NOT NULL DEFAULT 'unpaid' CHECK(payment_status IN ('unpaid','paid','failed','refunded')),
  customer_name TEXT NOT NULL,
  customer_email TEXT NOT NULL DEFAULT '',
  customer_phone TEXT NOT NULL DEFAULT '',
  shipping_address TEXT NOT NULL DEFAULT '',
  shipping_city TEXT NOT NULL DEFAULT '',
  shipping_postcode TEXT NOT NULL DEFAULT '',
  customer_note TEXT NOT NULL DEFAULT '',
  subtotal REAL NOT NULL DEFAULT 0 CHECK(subtotal >= 0),
  discount_total REAL NOT NULL DEFAULT 0 CHECK(discount_total >= 0),
  shipping_total REAL NOT NULL DEFAULT 0 CHECK(shipping_total >= 0),
  total REAL NOT NULL DEFAULT 0 CHECK(total >= 0),
  currency TEXT NOT NULL DEFAULT 'EUR',
  promotion_code TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE TABLE IF NOT EXISTS order_items (
  id TEXT PRIMARY KEY NOT NULL,
  order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id TEXT,
  volume_id TEXT,
  product_name TEXT NOT NULL,
  brand_name TEXT NOT NULL DEFAULT '',
  size_ml REAL NOT NULL DEFAULT 0 CHECK(size_ml >= 0),
  sku TEXT,
  unit_price REAL NOT NULL CHECK(unit_price >= 0),
  quantity INTEGER NOT NULL CHECK(quantity > 0),
  line_total REAL NOT NULL CHECK(line_total >= 0)
);
CREATE INDEX IF NOT EXISTS orders_created_idx ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS orders_status_created_idx ON orders(status, created_at DESC);
CREATE INDEX IF NOT EXISTS order_items_order_idx ON order_items(order_id);

CREATE TABLE IF NOT EXISTS promotions (
  id TEXT PRIMARY KEY NOT NULL,
  code TEXT NOT NULL UNIQUE COLLATE NOCASE,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  discount_type TEXT NOT NULL CHECK(discount_type IN ('percent','fixed')),
  discount_value REAL NOT NULL CHECK(discount_value > 0),
  minimum_order REAL NOT NULL DEFAULT 0 CHECK(minimum_order >= 0),
  usage_limit INTEGER CHECK(usage_limit IS NULL OR usage_limit >= 0),
  usage_count INTEGER NOT NULL DEFAULT 0 CHECK(usage_count >= 0),
  starts_at TEXT,
  ends_at TEXT,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS promotions_active_idx ON promotions(is_active, starts_at, ends_at);

CREATE TABLE IF NOT EXISTS homepage_sections (
  id TEXT PRIMARY KEY NOT NULL,
  section_key TEXT NOT NULL UNIQUE,
  section_type TEXT NOT NULL DEFAULT 'editorial',
  title_en TEXT NOT NULL DEFAULT '',
  title_fa TEXT NOT NULL DEFAULT '',
  body_en TEXT NOT NULL DEFAULT '',
  body_fa TEXT NOT NULL DEFAULT '',
  image_url TEXT,
  link_url TEXT,
  product_ids_json TEXT NOT NULL DEFAULT '[]' CHECK(json_valid(product_ids_json)),
  sort INTEGER NOT NULL DEFAULT 0,
  is_visible INTEGER NOT NULL DEFAULT 1 CHECK(is_visible IN (0,1)),
  starts_at TEXT,
  ends_at TEXT,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS homepage_sections_order_idx ON homepage_sections(is_visible, sort);

CREATE TABLE IF NOT EXISTS media_assets (
  id TEXT PRIMARY KEY NOT NULL,
  title TEXT NOT NULL DEFAULT '',
  asset_url TEXT NOT NULL,
  alt_en TEXT NOT NULL DEFAULT '',
  alt_fa TEXT NOT NULL DEFAULT '',
  media_type TEXT NOT NULL DEFAULT 'image' CHECK(media_type IN ('image','video','document')),
  mime_type TEXT NOT NULL DEFAULT '',
  byte_size INTEGER NOT NULL DEFAULT 0 CHECK(byte_size >= 0),
  width INTEGER,
  height INTEGER,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS media_assets_created_idx ON media_assets(created_at DESC);
