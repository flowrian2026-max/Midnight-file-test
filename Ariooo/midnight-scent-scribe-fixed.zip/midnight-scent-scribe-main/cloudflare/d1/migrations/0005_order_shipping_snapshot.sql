PRAGMA foreign_keys = ON;

-- Preserve the shipping choice on each order even if a delivery method is later edited or removed.
ALTER TABLE orders ADD COLUMN shipping_method_id TEXT;
ALTER TABLE orders ADD COLUMN shipping_method_name TEXT;
ALTER TABLE orders ADD COLUMN shipping_method_name_fa TEXT;
ALTER TABLE orders ADD COLUMN shipping_zone TEXT;
ALTER TABLE orders ADD COLUMN shipping_eta_min_days INTEGER;
ALTER TABLE orders ADD COLUMN shipping_eta_max_days INTEGER;
CREATE INDEX IF NOT EXISTS orders_shipping_method_idx ON orders(shipping_method_id);
