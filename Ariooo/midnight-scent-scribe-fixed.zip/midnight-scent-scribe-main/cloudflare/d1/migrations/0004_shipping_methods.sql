PRAGMA foreign_keys = ON;

-- Configurable shipping methods. Checkout can consume these rules in a later integration.
CREATE TABLE IF NOT EXISTS shipping_methods (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  name_fa TEXT NOT NULL DEFAULT '',
  zone TEXT NOT NULL DEFAULT 'Domestic',
  price REAL NOT NULL DEFAULT 0 CHECK(price >= 0),
  free_shipping_threshold REAL CHECK(free_shipping_threshold IS NULL OR free_shipping_threshold >= 0),
  estimated_min_days INTEGER NOT NULL DEFAULT 2 CHECK(estimated_min_days >= 0 AND estimated_min_days <= 60),
  estimated_max_days INTEGER NOT NULL DEFAULT 5 CHECK(estimated_max_days >= estimated_min_days AND estimated_max_days <= 60),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  sort INTEGER NOT NULL DEFAULT 0 CHECK(sort >= 0),
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS shipping_methods_active_order_idx ON shipping_methods(is_active, sort, zone);
