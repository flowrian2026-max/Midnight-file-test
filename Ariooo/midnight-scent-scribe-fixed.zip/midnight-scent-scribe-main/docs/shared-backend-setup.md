# Scent Scribe — Shared backend activation checklist

> **Superseded on 2026-10-27:** the current production admin path is Cloudflare D1, not Supabase. Do not follow this older Supabase activation checklist for the current app, and never run its PostgreSQL migrations against D1. Use [cloudflare-d1-backend.md](cloudflare-d1-backend.md) for the current schema, API and setup steps. This file is retained only as historical context for the abandoned Supabase approach.


Reviewed: 2026-10-25

## Current state

The project has a browser-only catalogue by default. Do not enable the remote data switch until a real database is provisioned, the migrations have been applied in order and an administrator account has been assigned explicitly.

The Lovable project database status was checked on 2026-10-25 and reported **disabled**. No database was provisioned, and no SQL migration has been executed against a hosted database. Migrations 0001–0003 are staged in the repository only.

## Repository changes staged

- `0001_secure_admin_bootstrap.sql` removes the unsafe “first signup becomes admin” trigger and stops browser-authenticated users from writing role assignments.
- `0002_shared_catalogue_admin.sql` adds brands, product bottle-size/stock rows, multi-category links and row-level security policies.
- `0003_admin_write_functions.sql` adds administrator-only, transaction-scoped RPCs to save a product with its bottle sizes/categories, and to save/rename a brand.
- `src/lib/remote-catalog.ts` reads shared brands/categories/products/stock and calls the protected save RPCs.
- `src/lib/catalog.ts` supports the optional remote adapter. Existing local demo behaviour remains the default.
- `/demo-editor` uses the shared save RPCs and checks the server-confirmed admin role only when remote mode is enabled. The browser-only merchandising controls are hidden in remote mode, because they are not yet backed by shared settings.

## Activate only after database is available

1. Provision/confirm the project's Supabase-compatible database through the intended account and verify the actual billing/usage terms first. The current database is disabled; this guide does not provision it.
2. Apply migrations in order: `0000_store_catalog_admin`, `0001_secure_admin_bootstrap`, `0002_shared_catalogue_admin`, `0003_admin_write_functions`. Review their SQL before applying to any database with important data.
3. In the auth provider, disable public sign-up. The login page has no public sign-up UI, but the server/provider setting must also be verified.
4. Invite or create the intended owner account through the provider's trusted admin interface. Use the provider's SQL editor to find that exact user's UUID and verify the result before assigning the role:
   ```sql
   select id, email from auth.users where lower(email) = lower('<verified owner email>');
   ```
   Then, substituting the UUID you personally verified:
   ```sql
   insert into public.user_roles (user_id, role)
   values ('<verified-owner-uuid>', 'admin')
   on conflict (user_id, role) do nothing;
   ```
   Never expose a service-role key in browser code. Do not assign the role based on signup order.
5. Import/review the actual product catalogue and real bottle sizes/prices/stock. The four old database seed rows are placeholders. Migration 0002 unpublishes `lumiere`, `nocturne`, `riviere` and `solstice` in the shared database so they do not leak into the public storefront before review. The TypeScript demo catalogue still contains illustrative photos/prices/stock; do not treat any of it as verified commercial inventory.
6. Configure `VITE_USE_REMOTE_CATALOG=true` in the app's build environment only after tables, policies, owner role and catalogue records have been verified. Keep the value unset/false before then. The usual public Supabase URL and publishable key are sufficient for browser reads; no service-role key is required by `remote-catalog.ts`.
7. Test as anonymous, signed-in non-admin and verified admin accounts:
   - anonymous users can read published products/active brands/categories;
   - anonymous users cannot write any catalog/role data;
   - non-admin authenticated users cannot write any catalog/role data;
   - admin can create/edit a product, edit bottle sizes, price, stock, publication and categories, and create/rename brands;
   - reload from another browser/device shows the same updates;
   - unpublished products and inactive brands are not publicly visible.
8. Do not enable payment, order fulfillment, discount logic or newsletter claims as part of this milestone; those systems have not been implemented.

## Known limitations after the repository work

- Database provisioning and migration execution are outstanding.
- The four placeholder database products have no real brand or bottle-size assignments. The shared catalogue must be reviewed/imported before switching the feature flag on.
- Shared product/brand/category create and edit are the write flows in this milestone. Product deletion, stock movement/order audit logs, shared homepage merchandising, order management and discounts still need dedicated backend work.
- Cart and wishlist are still browser-local. The catalogue adapter can load shared product records, but there is no persistent customer cart, checkout/order creation, payment or fulfillment workflow. Treat the storefront as a demo until those are built and tested.
- Product edits preserve database bottle-size IDs for unchanged sizes, so edits to price/stock/copy do not unnecessarily invalidate saved cart references.
- Public product reads require a published product with an active assigned brand; administrators can still inspect unpublished or unassigned records.
- Build/test verification is outstanding for the latest commits; do not report the branch as passing until CI or an equivalent build/test run confirms it.
- The live published site was not modified/published by this task.
