# Scent Scribe — Implementation Status & Audit

Last reviewed: 2026-10-23  
Working branch: `feat/luxury-scroll-motion`  
Pull request: [#1 — Add luxury floating navigation and scroll reveals](https://github.com/flowrian2026-max/midnight-scent-scribe/pull/1)

## Product direction

Scent Scribe is a luxury **multi-brand fragrance-store demo**, not a single-brand perfume house. The visual identity stays in midnight navy, dark plum, dusty lavender/periwinkle and cream. Do not replace this palette with ARIXEN's black-and-antique-gold identity. The sample catalogue includes Tom Ford, Dior, Chanel, Yves Saint Laurent, Maison Margiela and Guerlain; Tom Ford is included but should not dominate the homepage.

## Confirmed in the current code

- Home page, store catalogue, brand listings and individual fragrance pages are wired to the built-in demo catalogue.
- The shop supports search, brand/category/gender/season/price/stock filters and sorting.
- Product variants include bottle volume, price and stock values; the demo cart validates quantities against the local stock values.
- Cart and wishlist persist in the current browser using local storage.
- The site has English and Persian UI strings, a mobile navigation menu, and a keyboard skip link that moves focus to the main content.
- The home hero video exists at `public/scent-hero.mp4` (about 3 MB); a poster image is configured.
- The homepage has five distinct scent-family image assets and three editorial story-image assets.
- Mobile navigation includes Escape/backdrop dismissal and now locks background-page scrolling while open; its panel can scroll on short screens.
- The local editor can edit demo brands and products in the current browser and restore the defaults. Brand slug changes update linked demo products; duplicate slugs are rejected rather than overwriting another brand.
- Reset/status helpers tolerate browser storage being blocked, while keeping demo data available in memory.
- The local editor now reports whether browser storage actually persisted a change; when storage is unavailable it warns that edits are session-only rather than claiming they were saved.
- A visible demo notice explains that the catalogue is demonstration content.
- Newsletter submission is not connected to an email service; the UI explicitly says no email was sent or saved.

## Important limits — do not describe these as production features

- **No shared production database is connected to the demo catalogue.** Catalogue edits made from `/demo-editor` are stored in that browser only; they are not shared with other visitors or devices.
- The `/admin` route checks Supabase authentication and the `has_role` admin RPC, but this is only an access-status page in the current code. It does not provide a database-backed product-management system.
- **No real checkout or payment processing is connected.** The cart is for demonstration only.
- Newsletter subscriptions are not persisted or delivered.
- Brand/product photos, prices and stock values are sample content, not verified live inventory or brand-authorized product data.
- No production order management, shipping fulfilment, discount engine or multi-user admin persistence should be claimed as complete.

## Current branch work

The scroll-motion work adds a fixed, compacting navigation, mobile-menu presentation and section reveal animation. In commit `b7decfc`, the homepage motion handling was hardened:

1. Hero video autoplay is disabled when the browser requests reduced motion, and its preload is set to `none` while disabled.
2. Sections are revealed immediately when reduced motion is preferred.
3. If `IntersectionObserver` is unavailable, sections are revealed immediately instead of remaining hidden.
4. While the mobile menu is open, background scrolling is locked and the menu panel is bounded to the viewport height so its links remain reachable.
5. The local demo editor now updates product-to-brand references on a brand slug rename; tests were added for renames, duplicate-slug collisions and storage-blocked reset behavior.

This is code-level work and still needs a browser visual pass for layout, contrast, menu behavior, motion, and image crop.

## Validation status

- A previous GitHub Actions run built the production bundle successfully before the latest motion fix.
- An earlier lint step reported repository-wide Prettier formatting violations (882 findings) and caused tests to be skipped in that run. The workflow was adjusted so that formatting debt does not prevent the test step from running.
- Later push-triggered Actions entries have returned no job details from the available GitHub endpoint. **The latest code has not yet been confirmed by a successful build-and-test run; do not claim CI passes.**
- Existing automated tests cover route matching, catalogue filtering/sorting, cart normalization, demo catalogue integrity, safe brand slug edits, and storage-blocked save/reset handling. They do not replace a full visual/browser review.

## Next checkpoints

1. Get a reliable build-and-test result for the current branch.
2. Do a visual review of desktop and mobile layouts, including English/Persian direction, sticky header, reduced-motion behavior, category cards, product-image repetition, and the hero video.
3. Fix only the issues confirmed by that review; preserve the Scent Scribe palette and multi-brand positioning.
4. Keep checkout, stock, newsletter and admin clearly labelled as demo-only until a real shared backend is deliberately designed and tested.
5. The product grid still reuses a small set of generic demo images across multiple fragrances. Review the visual assets before considering the catalogue visually final; do not mislabel these placeholder assets as official product photography.
6. For any future backend, prefer a no-paid-API-first design with replaceable adapters and explicit security rules; never put database service keys or provider secrets in browser code.


## Shared administration backend — 2026-10-27

### Implemented in repository

- Added the independent Cloudflare D1/SQLite schema at `cloudflare/d1/migrations/0001_catalog_and_admin.sql`: brands, categories, products, product volumes/stock, product-category links, admin users, hashed sessions, audit log and rate-limit storage. No real prices or stock are seeded.
- Added Worker API routes in `src/lib/d1-worker-api.ts`: health/schema check, public catalogue reads, first-admin setup, login/session/logout, private product read/save, and brand/category read/save.
- Passwords are stored as PBKDF2-SHA-256 hashes, random sessions store only SHA-256 token hashes, cookies are HttpOnly/Secure/SameSite=Strict with expiry, and auth/mutation requests require same-origin checks. Login/setup attempts are throttled; admin writes use prepared statements and D1 batches.
- Replaced the admin sign-in, route guard and dashboard role checks with D1 sessions. Added a one-time first-admin setup form on `/auth`, protected by a server-only `ADMIN_SETUP_TOKEN` and the empty-admin-table condition.
- The catalogue adapter and editor now speak to D1 in production. Public catalogue calls fall back to illustrative demo records only when the D1 API is unavailable; the production editor does not treat browser-local storage as shared administration.
- GitHub Actions production build, lint and tests passed for the D1 API, admin UI/bootstrap and schema-health changes (latest code-validation run: [5432eef](https://github.com/flowrian2026-max/midnight-scent-scribe/actions/runs/40413252542)). This validates source/build, not a live database.

### Not yet live / important boundary

- `wrangler.jsonc` still has **no actual D1 binding**, because the real database name and ID are not available in the repository. The Worker has not been verified against a provisioned D1 database.
- The schema has not been applied to a real database; the first admin account has not been created; brand/product rows have not been imported. Therefore shared editing, persistence across devices and production admin login are **not yet verified**.
- D1 endpoints intentionally use the new SQLite schema. Do not apply the existing PostgreSQL `drizzle/migrations` files to D1.
- Orders, shipping, discounts as transactional rules and payments are not implemented as live backend workflows. Unpublishing a product hides it from the public catalogue; a dedicated delete/archive UI is still a later task.

### Exact next steps

1. Inspect the existing Cloudflare D1 database and copy its exact account ID, database name and database ID. Reuse the intended database; do not create another one just to make the IDs match.
2. Add the GitHub Actions repository secret `CLOUDFLARE_API_TOKEN` with Cloudflare Account D1 Edit permission, then run **Actions → Apply D1 schema and configure Worker binding** with the confirmed IDs. The workflow applies the numbered migration, verifies all nine required tables, and adds the binding to `wrangler.jsonc` on `main`; no table-by-table console work is needed.
3. Let the connected Worker build/deployment finish and check `/api/d1/health` for `{"ok":true,"database":"D1","schema":"ready"}`.
4. Set `ADMIN_SETUP_TOKEN` as a Cloudflare Worker secret (32+ random characters). Open `/auth`, choose **Initial setup (first admin only)**, create the admin, verify sign-in, then rotate/remove the setup secret.
5. Test login/logout and anonymous-write rejection, create a brand and category, save a product with bottle volumes/stock, reload from another device and confirm public visibility only after publishing.

**Portability boundary:** D1 is the current prototype. The code still contains D1-specific SQL; migrating to MySQL/MariaDB later requires a persistence adapter and a separately tested migration dialect, not just changing a database ID. See the existing [ARIXEN Studio roadmap](arixen-studio-roadmap.md) for the shared-core portability rule.

Keep the project in this state until those live tests pass. Do not call the backend connected, production-ready or complete before then.


## Cinematic underwater hero follow-up — 2026-10-28

- The existing homepage hero was confirmed in `src/components/site/scroll-editorial.tsx`: it already uses `/scent-hero.mp4` with a PNG bottle artwork moved by scroll/pointer transforms.
- Added `src/components/site/perfume-bottle-3d.css` and replaced the flat hero artwork layer with a lightweight, dependency-free CSS 3D perfume bottle. The glass shell, side depth, cap, neck, tinted liquid and front label are separate layers; the liquid color is controlled by `bottleLiquidColor` in `scroll-editorial.tsx`. Bottle rotation follows scroll progress and pointer movement. The original PNG remains as a CSS-support fallback.
- Kept the existing hero video path `/scent-hero.mp4`; the newer Dola clip has **not** yet replaced the asset in the repository. Current local optimized copy: `scent-scribe-underwater-hero.mp4` (H.264, 1248×704, ~3.1 MB, ~12 s).
- The updated code was committed directly to `main` because the connected Lovable workspace reported that it is out of credits. GitHub did not return a build/test workflow run for these commits, so do not mark the change as build-verified or visually approved yet. Next: inspect the live preview on desktop/mobile, confirm the new CSS 3D proportions, run build/tests, and then replace `public/scent-hero.mp4` with the H.264 Dola clip.

## Store operations backend — 2026-10-29

- Added additive migration `cloudflare/d1/migrations/0002_store_operations.sql` for `orders`, `order_items`, `promotions`, `homepage_sections`, and `media_assets`. It does not delete or reset the existing catalogue/admin tables.
- Added authenticated, same-origin-protected D1 management endpoints for listing/updating order status and CRUD for promotion records, homepage section records, and media metadata.
- Added the protected `/operations` admin route and links from the existing admin overview.
- Important boundaries until the migration is applied and verified: the new modules will report that their tables are not ready; storefront checkout does not yet create order records; promotion codes are not yet applied to checkout totals; homepage sections are stored but the homepage renderer is not yet reading them; Media currently stores HTTPS URLs/metadata, not binary uploads. Object storage (e.g. R2) and storefront integrations remain separate steps.
- No live D1 migration was run from this code-editing session, and no production rows were changed. After applying migration 0002, verify the Worker health endpoint and exercise each module before claiming production readiness.
