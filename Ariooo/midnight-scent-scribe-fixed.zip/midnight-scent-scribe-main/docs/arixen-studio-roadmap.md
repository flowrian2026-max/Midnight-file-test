# ARIXEN Studio — Reusable Capability Roadmap

## Core principle
Build the strongest practical no-paid-API version first. Design optional provider integrations as replaceable adapters so a customer can connect a paid/external API later without rewriting the core product. Never make a demo appear to have capabilities that are not implemented.

## AI access and future-readiness strategy
Current access, sanctions, payment restrictions, and high AI service prices can limit what is practical today, especially for users and customers in Iran. These are constraints to design around, not reasons to abandon AI capabilities entirely.

- **Build for today:** prefer genuinely free tools, open-source software, local models, and non-AI logic wherever they meet the requirement.
- **Prepare for tomorrow:** design clear provider interfaces/adapters so a suitable AI model or service can be connected later without rebuilding the site.
- **Avoid forced dependency:** core site functionality must remain useful when no AI provider is configured, unavailable, unaffordable, or inaccessible.
- **Make paid AI an intentional option:** assess whether a feature delivers measurable value to the customer before adding recurring API costs; account for usage, latency, privacy, reliability and support.
- **Keep options open:** periodically revisit model quality, pricing, free tiers, local models, provider access and legal/commercial terms as conditions change.
- **Be transparent:** document what works today, what is only prepared for future integration, and what remains untested. Never imply that a future integration already exists.
- **Protect credentials and data:** keep provider keys server-side, minimize sensitive data sent to external services, and provide a safe fallback when providers fail.

Long-term principle: **Design for today's constraints without closing the door on tomorrow's capabilities.** We are not rejecting AI; we are avoiding unnecessary dependence on paid or inaccessible services.

## Free-first research policy
Do not assume a capability requires payment just because the first familiar service charges for it. Before deciding, research the available options broadly and document the evidence.

For every capability we want to add:
1. **Search for genuinely free options:** distinguish permanently free features from trials, temporary promotions and free credits.
2. **Check open-source and self-hosted tools:** include local execution and community projects, not only hosted SaaS products.
3. **Check free tiers carefully:** record usage limits, account requirements, hardware needs, commercial-use terms, data/privacy implications and any hidden costs.
4. **Look for combinations:** multiple free tools or a simpler implementation may meet the requirement without a paid API.
5. **Compare implementation paths:** browser-only, local/self-hosted, free hosted service, and optional paid provider where relevant.
6. **Keep a replaceable architecture:** build a useful no-paid-API baseline first and make external providers optional adapters where practical.
7. **Record confidence honestly:** mark a solution as verified, tested, promising but untested, limited, or not found. “Not found yet” must not be presented as “does not exist.”
8. **Re-check before rejecting:** when a feature is important, revisit the research as tools, pricing and free tiers change.

For each researched option, document:
- What it actually does and what it does not do.
- Whether it is free permanently, limited-free, trial-only, or paid.
- Limits, hardware and setup requirements.
- Privacy, security, licensing and commercial-use restrictions.
- How it could integrate with our React/admin architecture.
- Whether it was tested in the real project and what the result was.

Never sacrifice security, user privacy, reliability or essential quality just to label something free. Never claim that a free option exists or works until its current terms and actual behavior have been checked.

## Capability modules

### 1. Scent Scribe / ecommerce
- Reusable admin patterns for product catalogue, brands, variants/volumes, inventory, promotions, homepage banners and homepage sections.
- Homepage sections must be independently renderable and configurable (visibility, permitted ordering, content, schedule where supported).
- Removing or reordering a section must not leave artificial gaps or break neighboring backgrounds/layouts.
- Preview changes before publishing; keep draft/published state separate where feasible.
- Keep promotion visibility separate from the actual product discount and pricing rules.
- Current Scent Scribe note (2026-10-27): D1 schema, server-side admin setup/login/session, audit/throttling, and authenticated brand/category/product save endpoints are implemented in code. The admin UI targets these endpoints. Production D1 was verified ready on 2026-10-27: `GET /api/d1/health` returned `{"ok":true,"database":"D1","schema":"ready"}` after fixing the Worker runtime environment handoff in `src/server.ts`. Next validation sequence: `/api/d1/catalog`, one-time initial admin setup using the Worker secret `ADMIN_SETUP_TOKEN`, login/session, then brand/category/product CRUD. The storefront may still use illustrative demo data when remote-catalog configuration or catalog readiness requires the fallback. Do not reuse the D1 binding or tenant data across clients without an explicit per-site isolation plan.

### 2. Real-estate virtual tour (no AI)
- Build a browser-based tour from supplied 360-degree panoramas or other suitable media.
- Features to evaluate: room hotspots, room-to-room navigation, zoom, fullscreen, floor-plan navigation, mobile touch controls, captions and accessibility.
- No generative AI is required. The quality depends on the source photography/panoramas and how the tour is authored.
- Optional future adapters: hosted tour services or other external providers. Keep core tour data and navigation independent of a particular provider.

### 3. Clothing virtual try-on / fitting
- Scope includes multiple approaches, not a single technique:
  - No-API baseline: curated product imagery, model photos, layered 2D garment previews or a simple 3D/avatar experience where suitable assets exist.
  - Advanced optional provider adapters: external virtual try-on services, only when a customer supplies credentials and accepts provider costs/terms.
- Important limitation: convincing photo-realistic garment transfer onto a real person's photo is not generally achievable with simple front-end code alone. Do not promise equivalent quality from a no-API baseline.
- Assess each method for garment types, body/pose support, image requirements, realism, privacy, performance, commercial licensing and operating cost.
- Provider keys must never be exposed in client-side code; proxy through a secure server-side integration when an API is used.

## Reusable implementation workflow
1. Audit current project and mark each feature as implemented, partial, demo-only or not implemented.
2. Research free-first options using the policy above; do not infer that a paid product is the only route.
3. Define the no-API baseline and its limitations.
4. Implement and test in one real project.
5. Document the design decisions, component boundaries, data model, test cases, failures and fixes.
6. Extract only stable reusable pieces into the studio library.
7. Add optional provider adapters behind a clear interface and configuration switch.
8. Verify mobile, keyboard/accessibility, reduced motion, empty/error states and performance before calling the feature complete.

## Studio guardrails
- Keep each client's visual identity distinct; shared components are not shared templates.
- No paid API or cloud dependency by default.
- Never put secrets in the frontend or commit environment files/secrets.
- Do not claim a feature works until tested in the actual application.
- Prefer portable, documented data formats and avoid unnecessary vendor lock-in.


## Shared admin and portable database architecture — 2026-10-27

- Build **one reusable admin/core layer** for ARIXEN, with separate niche-specific storefront themes (perfume, real estate, salon, jewelry, fashion and others). A theme changes its screens and permitted features; it should not require hand-building a new database schema each time.
- Each customer site must have its **own isolated database/configuration by default**. Never reuse one customer's inventory, admin sessions, orders or credentials for another customer.
- Database setup and upgrades must be **versioned, repeatable migrations** executed by provisioning/deployment automation. Do not ask the owner to paste SQL or create tables manually. First installation and later upgrades should use the same migration mechanism.
- **Current prototype:** Scent Scribe uses Cloudflare D1/SQLite. The new GitHub Actions workflow applies its numbered migration to the specifically selected D1 database, checks the complete required schema, and writes that verified binding to `wrangler.jsonc`. The GitHub Actions migration workflow has successfully applied and verified the schema for the selected D1 database; do not repeat provisioning unless diagnostics show a new schema or binding problem.
- **Portability goal:** keep frontend/admin contracts and business rules stable while database-specific access and migration dialects are replaceable. MySQL/MariaDB is a later target for common cPanel hosting; PostgreSQL can be an optional target when a client's hosting supports it.
- **Honest implementation boundary:** the existing `src/lib/d1-worker-api.ts` still contains D1-specific SQL and calls. It cannot move to MySQL just by changing a connection string. Before claiming cross-database portability, refactor the persistence boundary behind a documented repository/adapter interface and create/test a migration set for each supported database. Until then, D1 is the working prototype, not a universal multi-database backend.
- For every client handoff, plan a verified export/import path for catalogue and content data, per-client secrets, a backup and a migration check. Never treat schema portability alone as proof that the data and sessions have been moved safely.


## Visual design research bookmarks — 2026-10-27

Shared by the studio owner as a research shortlist. These are **reference sources to evaluate**, not a claim that every site has been fully audited or that every asset is free/licensed for commercial use. Before adopting a technique or asset, inspect the live page, verify pricing/licensing, note performance/accessibility, and implement a project-specific version rather than copying a design wholesale.

### Motion, interaction and scroll
- https://motionin.design — motion-design inspiration and references.
- https://scrolltide.co — scroll-driven interaction ideas; prioritize purposeful transitions over decorative scroll gimmicks.
- https://60fps.design — mobile UI animation references; assess smoothness and reduced-motion behavior.
- https://grainient.supply — gradient/background motion references; keep effects subtle and performant.
- https://landdding.com — visual design techniques and inspiration.

### Site galleries and landing-page inspiration
- https://land-book.com — curated website/landing-page references.
- https://godly.website — creative, experimental websites; inspect interaction and mobile behavior before borrowing a pattern.
- https://supahero.io — landing-page inspiration.
- https://cta.gallery — CTA/button patterns; evaluate hierarchy, clarity and accessibility.
- https://footer.design — footer layout and information architecture ideas.

### UI assets, templates and design systems
- https://modulify.ai/templates — website template references; check output/editability, terms and whether a template is actually suitable for the target stack.
- https://wonderlist.design — Figma design references.
- https://iconly.design — icon resources; verify license, formats and visual consistency.
- https://backgrounds.supply — background resources; verify license and asset weight.

### How ARIXEN should use this shortlist
1. Capture the exact useful pattern (not just a screenshot): trigger, timing, layout behavior, mobile variant and fallback.
2. Prefer real CSS/JS interaction and semantic components over a static imitation when feasible.
3. Keep motion lightweight for weak devices; honor `prefers-reduced-motion`, avoid scroll hijacking and test touch screens.
4. Preserve each brand's palette and identity. For Scent Scribe use midnight navy/plum/periwinkle/lavender, not ARIXEN's black-and-gold identity.
5. Before adding a library or asset, confirm license, dependencies, bundle cost, and whether a simpler custom implementation is safer.
6. Promote a pattern into the reusable studio library only after it is implemented and tested in a real project.


## Visual reference review — 2026-10-27

The following review checks each of the 14 visual-design bookmarks against its currently accessible public homepage/content. It is a **reference-source audit**, not a full browser QA of every example or a mobile/performance benchmark. Pricing, availability, content and licensing can change; re-check before adopting an asset or purchasing access.

### A. Motion, interaction and scroll

1. **Scrolltide — https://www.scrolltide.co/**
   - Most directly aligned with ARIXEN's interactive-web goal. Its current library advertises 130 website/hero templates (6 labelled free), 66 components, 55 shaders, 20 page sections and 14 UI screens. Examples include scroll-scrubbed film/frame sequences, cursor-reactive objects, layered portal zooms, focus/spotlight reveals, fan/deck/carousel cards, 3D product presentation and GPU-animated backgrounds.
   - The educational Academy also describes real build workflows and troubleshooting, including the need to stage complex effects instead of treating a giant prompt as guaranteed.
   - Commercial/client use is included in its license, but templates/prompts themselves may not be resold. Most library content is paid; 3D items are excluded from Monthly and included with Yearly/Lifetime. This is a useful learning/reference source, not a default free asset source.
   - **ARIXEN application:** pick one signature technique per page, define start/end states, fallback and mobile behavior, then build and test it in stages. For Scent Scribe, prioritize restrained hero film/scroll reveal, product spotlight and refined card motion; do not add a gratuitous fruit-splitting physics effect. For real estate, a controlled portal/room-transition or panorama tour could fit. Low-powered devices need a lighter fallback.
   - Source evidence: homepage, template library, Academy and terms pages linked above.

2. **60fps — https://60fps.design/**
   - Large inspiration archive for UI/app motion. The current homepage exposes 2,125 shots, 494 apps, 93 app sites, 83 motion examples, 32 snippets and pattern/type filters including 3D, carousel, loading, empty state, tabs, toast, tooltip and video.
   - **ARIXEN application:** primarily micro-interactions and interface states, not the whole art direction: filter selection, add-to-cart confirmation, product-gallery transitions, menu states, loading skeletons, empty cart and validation feedback. Recreate the behavior using CSS/JS/accessible controls; do not assume a gallery screenshot is production code.

3. **Motion — https://motionin.design/**
   - Curated interactive sections grouped around portfolio, hero, interactive, product showcase and immersive experiences; includes a mixture of free and paid entries. Examples include physics-like carousels, cursor-responsive surfaces and liquid/variable typography.
   - **ARIXEN application:** study individual motion mechanisms and their triggers. Use only those that serve the content; continuously running cursor/physics effects and heavy scripts should be avoided on the primary commerce path. Verify the exact component's code, dependencies and license before reusing it.

4. **Grainient — https://grainient.supply/**
   - Gradient, textured-gradient, animated-gradient/video and AI-background collections, plus a shader tool and a Freebies area. It is mainly a visual/asset source rather than a general web-UX gallery; some access is paid.
   - **ARIXEN application:** use as a mood/reference board for restrained atmospheric gradients and texture. Prefer CSS gradients or small optimized assets for the baseline. Before using downloadable assets commercially, check the individual license and file weight; avoid making large looping backgrounds mandatory on mobile.

### B. Website discovery and hero/layout inspiration

5. **Landdding — https://landdding.com/**
   - Curated website/landing-page gallery updated daily, with category and platform browsing; current page advertises roughly 2.6k designs, 1.7k designers, 40 categories and 5 platforms.
   - **ARIXEN application:** search by business niche (fragrance/beauty/fashion/real estate/agency), then by layout or visual style. Record what the page does, not just a screenshot: hierarchy, navigation, content rhythm, mobile adaptation and the CTA.

6. **Land-book — https://land-book.com/**
   - Curated inspiration library with separate Websites, Sections, Mobile, Motion, OG Images and Headlines views. Filters include 3D animation, background video, big type, cards, dark colors, parallax, typography and platforms. Its Basic tier is free but limited; the current page lists the supporter tier at $6/month for broader access.
   - **ARIXEN application:** especially useful for comparing desktop/mobile versions and isolated sections. Search by both industry and technique; do not let a popular gallery style erase each client's identity.

7. **Godly — https://godly.website/**
   - The old URL currently redirects to **Recent** rather than serving the former standalone site. Recent describes itself as a curated feed for exceptional design, websites and digital products and says it now takes the place of Godly with a broader feed.
   - **ARIXEN application:** update the bookmark to https://recent.design/ and use it as a discovery feed. Do not depend on old walkthroughs or instructions that assume the original Godly interface is unchanged.

8. **Supahero — https://supahero.io/**
   - The current page says Supahero is now part of Screensdesign and describes a curated collection of website hero sections.
   - **ARIXEN application:** useful for studying hero composition, headline/product placement and CTA hierarchy, not as a standalone site builder. Current destination: https://screensdesign.com/. Verify that an example still opens and represents the original linked work.

### C. Conversion details and page endings

9. **CTA.gallery — https://www.cta.gallery/**
   - Focused reference gallery with categories such as buttons, call-to-buy, downloads, forms, modals/pop-ups, navigation, newsletters and pricing/subscription.
   - **ARIXEN application:** improve the hierarchy and wording of shop actions, consultation forms, booking actions, newsletter signup and checkout preview. Every CTA must have a clear outcome, keyboard focus, mobile touch target and feedback state; avoid copying visual treatments that reduce contrast.

10. **Footer.design — https://www.footer.design/**
   - Curated footer gallery with categories including typographic, small type, illustrative, grid, flat, animated, cards, dark, bright, large type and bold.
   - **ARIXEN application:** build the footer as a deliberate final navigation layer: category/brand routes for ecommerce; services/process/contact for agencies; areas/property search for real estate. Avoid adding animation merely because the reference library offers it.

### D. Templates, UI assets and design systems

11. **Modulify templates — https://modulify.ai/templates**
   - Currently presents “free templates, ready to clone”; examples are previewed and cloned into a Modulify dashboard.
   - **ARIXEN application:** useful to inspect possible page structures and accelerate low-risk experiments. Before investing time, verify account/access limits, exportability, resulting source-code ownership, supported frameworks, dependencies and production deployment path. Do not assume a clone is automatically portable to the ARIXEN stack or safe for client handoff.

12. **Wonderlist — https://wonderlist.design/**
   - Current homepage advertises 127 premium website designs and 1,137 unique pages, with Figma-oriented design material and a Pro offer. It says designs include PNG/SVG formats and that fonts used are included; it separately claims icons/logos/mockups used in its designs are free to use, but that claim must be checked against the applicable terms for each asset.
   - **ARIXEN application:** a paid reference library for layout/page-structure studies if it ever fits the budget. No purchase is needed for now; recreate ideas independently and avoid assuming every included asset/font is commercially cleared for every use.

13. **Iconly — https://iconly.design/**
   - The currently accessible page is primarily a browsable collection of app, game and web-product icons/brand marks, rather than a complete generic website UI kit.
   - **ARIXEN application:** useful for observing how product brands present app icons and identity systems. It is not a priority source for general UI icons. For production interfaces, choose a consistent icon family with a verified license rather than mixing styles or downloading trademarked company marks casually.

14. **Backgrounds Supply — https://www.backgrounds.supply/**
   - Current homepage describes 1,273 4K-ready gradient wallpapers, AI backgrounds and animated videos across 29 collections, with a one-time purchase/lifetime-access proposition and included commercial license; it also exposes a Freebies section. This is an asset library, not a layout/interaction reference.
   - **ARIXEN application:** browse free items first and use only a small number of purposeful backgrounds. Paid purchase is not required for the current projects. Verify the current license and optimize any chosen video/texture for dimensions, compression and mobile performance.

### Shared lessons from all 14

- **Most relevant sources for signature motion:** Scrolltide first; Motion and 60fps for individual interactions; Grainient/Backgrounds Supply for atmosphere only.
- **Most relevant sources for layout research:** Landdding, Land-book, Recent (formerly Godly) and the Supahero archive now within Screensdesign.
- **Most relevant sources for conversion polish:** CTA.gallery and Footer.design.
- **Most relevant sources to treat as asset/template marketplaces rather than inspiration galleries:** Modulify, Wonderlist, Iconly, Grainient and Backgrounds Supply.
- **Free-first rule:** start with the public gallery/free items and custom CSS/JS. Do not purchase premium templates, fonts, icons or backgrounds merely to imitate a screenshot.
- **Extraction template for every selected example:** niche + URL; screenshot/section; user action that triggers it; motion/transition; implementation approach; reduced-motion/mobile fallback; dependencies and bundle impact; accessibility risks; asset license; actual test result.
- **Do not blindly clone:** record the mechanism and design principle, then create a client-specific implementation with original copy, palette, imagery and layout.
- **Verification boundary:** public landing pages and linked library descriptions were checked on 2026-10-27. Individual components have not all been downloaded or implemented; no claim is made that every pattern was tested on real devices or is free for commercial reuse.


## Inspiration-source directory update — MotionSites AI (2026-10-27)

**New source added; existing 14-site directory is preserved.**

- **MotionSites AI:** https://motionsites.ai/
- **Feather Atlas example supplied by the user:** https://motionsites.ai/?prompt=feathers-atlas
- **Use across every ARIXEN niche:** motion-heavy hero sections, 3D interactions, product showcases, editorial transitions, backgrounds, and reusable page sections—not only perfume websites.
- **Research method:** inspect each public preview and any linked source. Record what is actually visible separately from implementation hypotheses. If the exact prompt is paid/gated, never claim to have found it; write an original reverse-engineered prompt from the preview instead.
- **Free-first:** do not buy prompts or memberships without explicit approval. Learn the interaction pattern, then make an original implementation using the client's own assets, content and art direction.
- **For every new source/example:** append it to this directory and update `docs/arixen-motion-library.md` with the individual technique, URL, niche fit, implementation hypothesis, responsive/reduced-motion fallback, performance/accessibility risks and tested status. Do not replace the existing source list.


## Inspiration-source directory update — TOONHUB carousel brief (2026-10-27)

**Source / example name:** TOONHUB — layered character-figurine carousel  
**Reference material:** implementation brief supplied by the user in this conversation. The brief specifies four remote PNG assets hosted on a Figma site, coordinated background colors, oversized “3D SHAPE” typography, and role-based image positioning. No separate public source-page URL was supplied, so this entry records the supplied example/spec rather than claiming the site was independently inspected.

**Technique to reuse across niches:** CSS-based 2.5D layered carousel. One image is enlarged in the foreground; previous/next images sit to the sides and a fourth item recedes behind. Position, scale, blur, opacity, z-index, and the page background transition together over 650 ms. Oversized display type creates depth behind the subject. This effect does not require real 3D models or WebGL.

**Potential adaptations:** portfolio/agency projects, fashion campaign looks, real-estate project previews, beauty editorial imagery, jewelry collections, and perfume bottles. For Scent Scribe, adapt the technique to its midnight navy/plum/periwinkle palette rather than copying TOONHUB's coral/green/pink/blue colors. For ARIXEN itself, use its own black/antique-gold/stone visual identity only where appropriate.

**Practical guardrails:** preload assets; handle failed remote images; test touch targets and text overlap on mobile; respect reduced-motion settings; guard against repeated navigation during transitions; use original/authorized imagery; keep the focal image crisp and ensure the background and text maintain contrast. Avoid claiming that a CSS image carousel is a real 3D viewer.

**Status:** pattern/spec documented from the user's detailed brief. The supplied image URLs and exact layout have not been independently tested. Existing source directory entries are preserved; this is an appended entry.


## Incident / reusable fix — Cloudflare Workers D1 binding appeared missing (2026-10-27)

**Project:** Scent Scribe / `midnight-scent-scribe`  
**Production Worker:** `https://midnight-scent-scribe.flowrian-2026.workers.dev/`  
**Database:** `scent_scribe_db` (binding name: `DB`)  
**Status:** resolved; `GET /api/d1/health` returned `{"ok":true,"database":"D1","schema":"ready"}`.

### Symptoms
- The production health endpoint repeatedly returned `D1_NOT_CONFIGURED`.
- Its diagnostic showed `envType: "undefined"`, `hasDBProperty: false`, and `bindingNames: []`.
- The D1 database and required tables already existed, and `wrangler.jsonc` already contained the correct `d1_databases` entry. Recreating the database or repeatedly toggling the dashboard binding was not the right next step.

### Root cause
The custom `src/server.ts` wrapper passed its `env` argument into `handleD1Api`, assuming the framework would always supply the Cloudflare Worker environment as the second argument. In this TanStack Start/Nitro runtime path, that argument was `undefined`; consequently, the API reported a missing binding even though the Worker had a configured D1 binding. This was an environment-access / server-entry integration issue, not evidence that the D1 database or schema was absent.

### Fix recorded in source
Commit: `dcde44f2537d36819adf12f491163c502af6affa`  
File: `src/server.ts`

The wrapper now calls `resolveWorkerEnv(env)`: if a passed environment object contains `DB`, it uses that object; otherwise it attempts to obtain the Worker runtime environment through the guarded `cloudflare:workers` import, then passes the resolved environment to both `handleD1Api` and the TanStack server handler. The dynamic import is guarded so non-Cloudflare/local development can still run.

### Verification / future troubleshooting order
1. Test `/api/d1/health` first. Success is `{"ok":true,"database":"D1","schema":"ready"}`.
2. If it returns `D1_NOT_CONFIGURED`, inspect `diagnostic.envType` before touching D1 settings. If it is `undefined` and binding names are empty, investigate the Worker entry/runtime environment handoff and the deployed build/version first.
3. Only if the environment object exists but `DB` is absent, check the active Production Worker's binding and the deployed `wrangler.jsonc` configuration. Do not recreate the database or repeat the same dashboard clicks without new evidence.
4. Confirm that the latest commit was actually built and deployed to the active Worker before retesting. A GitHub commit or a successful D1 migration alone does not prove that the active Worker version contains the fix.
5. After health is ready, test `/api/d1/catalog`, then complete the one-time admin setup (requires the Worker secret `ADMIN_SETUP_TOKEN`), then test login/session and product/category/brand CRUD.

### Reusable lesson for all ARIXEN Cloudflare projects
A D1 binding being present in `wrangler.jsonc` and the database tables existing are separate from the runtime code actually receiving the Worker environment. When diagnostics say the entire `env` is undefined, debug the framework/Worker entry contract before changing database schemas or bindings. Preserve this distinction in future troubleshooting notes.


## Scent Scribe visual refinement checkpoint — 2026-10-27

- Applied an additional CSS-only art-direction pass in `src/scent-motion.css` (commit `63be50a7ba3308ebb5ef7a3cf5521e04543fdf1e`).
- Reused the shared motion-library principles: lightweight 2.5D depth, outlined editorial typography, a restrained orbital bottle frame, atmospheric light, and refined hover feedback for the product and journal cards.
- Kept Scent Scribe's midnight navy / plum / periwinkle / lavender identity. Corrected the scrolled-header border to periwinkle so the Scent Scribe storefront does not drift into ARIXEN's separate gold palette.
- No 3D/WebGL library, paid API, new dependency, route, catalog behavior, or D1/admin logic was changed.
- Status boundary: code is committed; GitHub validation was still running at the time of this note. The visual result has not yet been checked on physical devices or confirmed in the production Worker. After deployment, check the homepage at 375px, tablet, and desktop widths; confirm reduced-motion behavior, scroll chapters, quick category links, product-card links, and absence of console/layout errors.
