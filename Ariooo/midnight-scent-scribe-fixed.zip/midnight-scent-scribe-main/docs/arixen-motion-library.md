# ARIXEN Shared Motion Library — Reference Studies
Updated: 2026-10-27

This is a cross-niche library for all ARIXEN projects, not just Scent Scribe. Reuse the mechanism and adapt the art direction to each client; never force one palette or visual style across every site.

## Evidence boundary
References:
- https://recent.design/i/66s1tbe-five-into-one
- https://recent.design/i/bky6wkw-infinite-scroll-3d-concept

The public Recent pages were fetched, but the individual item endpoints exposed poster images and little/no explanatory text or playable implementation details. The notes below are independent implementation hypotheses based on the titles/concepts, not claims about the original code. Do not mark either effect “observed/tested” until the actual playback is reviewed.

## Technique 01 — Five Into One
**Concept:** Five separate visual elements resolve into one coherent hero composition.

**Good fits:** creative/agency studio, fashion campaign, architecture and property showcase, portfolio case study, product launch. For perfume, use editorial image fragments or mood imagery; avoid making ingredients fly away from the bottle.

**Prompt seed:**
> Create an original, premium, responsive hero interaction inspired by five visual elements resolving into one composition. Start with five distinct image panels arranged around a central focal point. On page entry or one intentional scroll threshold, each panel glides along a separate curved path with subtle perspective and staggered timing, then aligns into one coherent editorial composition. Make the movement deliberate and cinematic, not explosive or chaotic. Preserve headline legibility and keep the primary CTA usable throughout. Prefer CSS transforms and opacity; use an existing animation library only if already installed. Include a static reduced-motion version and a mobile layout with fewer layers.

**Implementation direction:** CSS transforms + opacity for the first prototype; use a single trigger and finite sequence. GSAP can be considered if already in the project. Do not add WebGL just to animate flat panels.

**Quality checks:** no scroll locking; text and CTA remain accessible; respect `prefers-reduced-motion`; disable decorative layers on low-power devices; verify image crops and mobile composition.

**Status:** concept/prompt recorded; not implemented or device-tested.

## Technique 02 — Infinite Scroll 3D Concept
**Concept hypothesis:** A continuous-feeling 3D gallery where cards sit in a shallow perspective corridor or ring and respond to scroll. Create continuity by recycling a finite set of cards, not by generating infinite DOM nodes. The exact source movement is not verified.

**Good fits:** agency portfolio, fashion/editorial lookbook, architecture projects, creative studio landing page, selected-property showcase. Avoid placing it across the core ecommerce buying flow if it hides prices, filters, or product actions.

**Prompt seed:**
> Build a responsive 3D scrolling gallery using a finite reusable set of content cards arranged in a perspective corridor. Scroll advances the card track smoothly; cards scale and shift in depth according to position with restrained parallax. Reposition cards at the ends to create continuity without endlessly duplicating content. Keep native scrolling and accessible navigation; do not hijack wheel or touch input. On mobile or when reduced motion is requested, replace the 3D corridor with a horizontal snap carousel or editorial card stack. Start with lightweight CSS perspective/transforms; use Three.js only if genuine 3D geometry or camera control is required. Lazy-load images and pause off-screen effects.

**Implementation choices:** CSS 3D transforms for lightweight scenes; GSAP ScrollTrigger if already present; Three.js only when actual 3D geometry/materials justify its cost.

**Risks to test:** mobile scroll jank, focus order vs visual order, layout shifts during image loading, motion sensitivity, keyboard access, reduced-motion fallback, low-end GPU performance.

**Status:** concept/prompt recorded; exact source mechanism unverified; not implemented or device-tested.

## Shared extraction template for future references
For every selected example record: title + URL; evidence available (playback, poster, description, code); trigger; movement sequence; likely implementation; suitable niches; mobile/reduced-motion fallback; dependencies/bundle impact; accessibility risks; asset licensing; and actual test result.

**Rule:** if a page exposes only a title/poster, never pretend to have inspected its exact animation or source code. Derive an independent prototype hypothesis, then verify it against playback before calling it observed or tested. Keep this library shared across all ARIXEN site types and tag relevant niches rather than tying techniques to the current perfume demo.


## Reference prompt study — Feather Atlas interactive 3D field guide (2026-10-27)

**Input:** user-supplied detailed prompt for a single-file `index.html` experience named “Feather Atlas,” with Hoopoe and Kingfisher models, Three.js, responsive layouts, detailed interactions, and CDN-hosted assets.

### Why this prompt is valuable
This is a specification, not merely a mood prompt. It defines:
1. **Output contract:** one standalone HTML file, inline CSS and one module script, no build step or local assets.
2. **Asset contract:** explicit remote PNG/GLB URLs and explicit no-video/no-download constraints.
3. **Design system:** day/dusk CSS tokens, typography, spacing, icons, focus states and transition easing.
4. **Responsive layout:** desktop/tablet/phone geometry, including phone-specific bottom-sheet behavior.
5. **3D scene:** renderer, camera, environment, lighting, model normalization, framing and asynchronous preload.
6. **Interaction model:** drag/inertia, wheel/pinch zoom, keyboard, turn queue, home reset, close-up toggle, focus mode and lighting.
7. **Motion choreography:** exact durations, easing curves, directional transitions, staggered detail swaps and idle behavior.
8. **Accessibility/performance:** semantic tabs, ARIA states, reduced-motion fallback, touch controls, no scroll hijacking and short-viewport handling.

### Reusable ARIXEN interaction-specification template
- **Deliverable and constraints:** exact file(s), framework/no-build requirement, permitted dependencies, asset policy, and exclusions.
- **Content/data:** actual entities, fields, variants and default selection.
- **Visual system:** project-specific palette, typography, spacing, surfaces, icons and motion language.
- **Layout:** desktop/tablet/mobile geometry and breakpoint-specific behavior.
- **Scene/asset pipeline:** exact URLs, model normalization, loading/error/fallback states, lazy loading and preload priorities.
- **Camera/composition:** framing target, focal point, bounds, resize behavior and scene/panel layering.
- **Interactions:** pointer/touch/keyboard input, state changes, bounds, reset behavior and focus management.
- **Animation timeline:** trigger, duration, easing, direction, choreography, overlap and interruption behavior.
- **Accessibility:** semantic controls, ARIA states, keyboard operation, focus ring, reduced motion and usable fallback.
- **Performance:** mobile/low-power fallback, capped pixel ratio, asset weight, lazy loading, avoid unnecessary render loops and handle WebGL failure.
- **Acceptance checklist:** tests at 375px/tablet/desktop; model failure; keyboard-only; reduced motion; resize; zoom bounds; no horizontal overflow; no console errors.

### Adaptation by niche
- **Luxury real estate:** optimized property GLB only when worthwhile; hotspots and 360 tours may be more useful than free spinning.
- **Fashion/jewelry:** product rotation, material/light presets and close-up inspection; avoid excessive bloom.
- **Perfume:** bottle rotation and close-up material details; retain Scent Scribe’s navy/plum/lavender palette, not ARIXEN gold. Avoid fake ingredient-flying effects.
- **Agency/portfolio:** same rigor for a 3D project stage, usually with fewer controls and no product-detail panel.
- **Beauty salon:** before/after or editorial gallery interactions may be more useful than full 3D.

### Caveats
- The specified CDN assets have not been fetched, licensed, or tested in this review.
- A single HTML file can still depend on remote CDN availability and CORS; standalone here means no build/local assets, not offline/self-contained.
- Three.js and its loaders add payload and complexity. Load only necessary decoders and handle failures. Test full-hero canvas layering against the phone bottom sheet.
- Respect both viewport requirements with `height:100vh; height:100dvh`.
- Keep the full specification for projects that need it; remove irrelevant controls from simpler client sites.

**Status:** analyzed as a reusable prompt/specification pattern; no Feather Atlas page generated or device-tested in this step.


## Source library — MotionSites AI

- **Main site:** https://motionsites.ai/
- **User’s Feather Atlas reference:** https://motionsites.ai/?prompt=feathers-atlas
- **What it is:** a prompt-first library for motion-heavy website sections and experiences. Browse previews to study visual direction and interaction patterns; some prompt-copy/custom prompt offerings are paid, so do not assume every prompt or asset is free. Public descriptions say prompts are intended for AI builders such as Lovable, Cursor and Claude. (Reference checked 2026-10-27.)
- **How ARIXEN should use it:** treat it as a recurring research source across *all* niches, not as a one-off Feather Atlas reference. When the user shares a new MotionSites example, add the URL, name, niche, observed motion pattern, likely implementation options, responsive/reduced-motion fallback, performance/accessibility risks and status to this library.
- **Research workflow:** inspect the example page and its preview/source links where accessible; distinguish what was directly observed from a hypothesis. If the full prompt is gated, do not claim to have retrieved it—reverse-engineer a fresh prompt from the visible behavior instead.
- **Free-first rule:** use public previews and the user's own supplied prompt/reference. Do not purchase membership or a private prompt without explicit approval. Avoid copying proprietary text/assets wholesale; extract the interaction principle and create an original ARIXEN implementation.
- **Best value:** high-density, concrete prompt specifications can provide a checklist for layout, motion timing, assets, responsiveness and interactions. Still simplify to the actual client brief and available hardware/credits.

**Ongoing maintenance rule:** whenever a new inspiration site is found, update both the source directory in `docs/arixen-studio-roadmap.md` and the relevant technique notes in this file; preserve the existing 14-site list and append new sources rather than replacing it.


## Technique 03 — TOONHUB-style layered character carousel

**Reference/spec supplied by user (2026-10-27):** React + TypeScript + Vite + Tailwind; four character PNGs; giant “3D SHAPE” ghost typography; active item enlarged in the center; left/right/back items smaller and blurred; background color changes with active item; 650 ms synchronized transitions. The supplied spec includes exact image URLs and colors, but assets have not been fetched or tested here.

**Core mechanism:** a *2.5D layered carousel* made from ordinary transparent images, CSS positioning, scale, blur, opacity and z-index—not a true 3D model or WebGL scene. Four items take derived roles from the active index: center, left, right and back. Each navigation action rotates those roles while the background follows the active item. A large, low-complexity typography layer provides visual depth behind the images.

**Why it matters:** convincing dimensional hierarchy can be achieved with a few image layers and carefully coordinated transitions, without Three.js, a build-heavy 3D stack, or 3D assets. This can be faster and cheaper to build than a real 3D product viewer.

**Best fits across ARIXEN:**
- **Agency/portfolio:** featured project in front, adjacent projects receding into the background.
- **Fashion/editorial:** campaign look or model image as the focal card; use licensed, brand-appropriate imagery.
- **Real estate:** featured property render with smaller surrounding project thumbnails; avoid implying an actual 3D tour.
- **Perfume:** hero bottle image centered with related fragrances behind it; preserve Scent Scribe navy/plum/lavender art direction instead of copying the sample's coral/green/pink/blue palette.
- **Beauty/jewelry:** one hero editorial/product image, with secondary looks/items softly receding.

**Prompt seed (original, reusable):**
> Build a responsive full-viewport 2.5D image carousel for [brand/niche] with [3–5] transparent or cleanly cropped images. Keep one active image large and centered, place the previous and next items smaller to the sides, and a fourth/farthest item behind. Use CSS scale, position, blur, opacity and stacking order to imply depth; do not use WebGL or claim the images are real 3D models. Coordinate the active image, background color and all item roles through one state value. Animate transitions together with a restrained easing curve, prevent repeated clicks from corrupting state, preload all images, and provide graceful handling for failed images. Add oversized low-contrast display typography behind the subject. Design explicit mobile positions so controls and copy remain readable at 375px. Respect reduced-motion preferences, keyboard access, focus visibility and contrast. Use the client's own palette, imagery and content; do not copy the reference brand's art direction.

**Implementation notes / checks:**
- Use stable item keys and derive roles from active index; do not create four unrelated state variables.
- A 650 ms animation lock is simple, but test rapid clicks and unmount cleanup to avoid stale timers.
- Preload image assets, but show a fallback if a remote CDN fails; remote URLs may be subject to CORS/hotlinking and availability.
- Use `prefers-reduced-motion` to shorten/disable transitions.
- Keep controls above the grain layer; verify z-index and pointer events.
- Blur can soften edges but can also reduce legibility; make the active subject crisp.
- On mobile, preserve adequate touch target size and prevent the bottom text/buttons from covering the character.
- The sample uses `fontWeight: 900` with Anton, but the supplied Google Fonts link may only load the font's default available weight; check the actual font response and avoid relying on a nonexistent weight.
- If using Tailwind, make sure dynamic styles such as per-item colors are assigned through inline styles/CSS variables rather than class names Tailwind cannot detect.

**Status:** specification/pattern recorded from the user's supplied brief; no implementation or real-device testing performed.


## Technique 04 — Scent Scribe cinematic depth and product-card refinement

**Implementation record (2026-10-27):** applied to `src/scent-motion.css` in `flowrian2026-max/midnight-scent-scribe`, commit `63be50a7ba3308ebb5ef7a3cf5521e04543fdf1e`.

- **Hero depth:** outlined low-contrast display type, a thin elliptical orbit behind the bottle, a soft periwinkle/plum light field, and a subtle ground glow. The bottle remains intact; no ingredients are made to fly away.
- **Motion trigger:** the existing scroll-driven three-chapter hero remains in place. CSS supplies only ambient movement and optical depth; it does not hijack scrolling or add an animation framework.
- **Commerce cards:** strengthen the hairline frame, use a single controlled highlight, and improve focus/hover feedback for the curated product and journal tiles.
- **Shared navigation:** the scrolled header outline now uses Scent Scribe periwinkle rather than a warm gold-like border.
- **Niche/palette:** perfume ecommerce; `#0A1123`, `#1F1823`, `#0C080D`, `#8387C3`, `#7A6284`. Do not reuse these colors for ARIXEN's own black/antique-gold identity.
- **Responsive/accessibility fallback:** motion is reduced under `prefers-reduced-motion`; the orbit and atmosphere are gentler on mobile. Validate hero chapters, card focus, scroll and layout at 375px, tablet, and desktop widths.
- **Dependencies/performance:** CSS only, no WebGL, Three.js, paid service, or added dependency.
- **Status:** committed, but the new pass was not yet verified on a real device or in the live Worker when recorded. Treat as implemented-but-unverified until visual QA passes.

**Reusable lesson:** apply one clear depth mechanism and one clear motion cue to a page, keep the commerce controls readable, and record actual validation separately from visual intent.
