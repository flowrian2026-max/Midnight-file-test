# Cloudflare D1 backend — Scent Scribe

## Current status

The code now routes production administrator sign-in and catalogue management through the Cloudflare Worker D1 API. The API and UI are committed to `main`; this does **not** mean a live database exists yet. The Worker still needs a real D1 database binding and the schema migration applied. Until that happens, the public storefront falls back to clearly illustrative demo catalogue data, and admin sign-in stays unavailable.

## D1 is a separate SQLite schema

D1 uses SQLite. The legacy files in `drizzle/migrations` are PostgreSQL migrations and must not be run against D1. The independent D1 schema is `cloudflare/d1/migrations/0001_catalog_and_admin.sql`. It creates the catalogue, volume/stock, administrator/session/audit and login-throttling tables; it does not seed fake inventory or prices.

## Provision the real database and apply the schema

The whole schema is versioned in `cloudflare/d1/migrations/0001_catalog_and_admin.sql`. Do not paste it from a phone into the SQL console and do not create the remaining tables one by one. The repository now has a GitHub Actions workflow that applies migrations with Wrangler and configures the Worker binding on `main`.

1. In Cloudflare, open **Storage & databases → D1 SQL Database** and inspect the existing databases. Reuse the database already bound to the `midnight-scent-scribe` Worker if it is the intended one. Copy its exact **database name** and **database ID**; also copy the Cloudflare **account ID**. Do not delete or overwrite a database to resolve a mismatch.
2. In GitHub, open this repository's **Settings → Secrets and variables → Actions → New repository secret**. Add a secret named `CLOUDFLARE_API_TOKEN`. Create its value in Cloudflare with the minimum account permission needed to edit D1 (`Account → D1 → Edit`). Never commit the token or send it in chat.
3. Open the repository's **Actions** tab, select **Apply D1 schema and configure Worker binding**, and choose **Run workflow**. Enter the account ID, exact database name and database ID from step 1, then tick the confirmation that this is the intended live database. The workflow shows pending migrations, applies them to the remote database, checks the required tables, adds the same `DB` binding to `wrangler.jsonc`, and commits that binding to `main`. It refuses to switch an existing `DB` binding to a different database. The existing manually created `brands` table is safe: the migration uses `CREATE TABLE IF NOT EXISTS`.
4. Let the build/deployment connected to `main` finish. Then open `https://<your-worker-domain>/api/d1/health`; success should return `{"ok":true,"database":"D1","schema":"ready"}`. If it reports a missing binding or schema, do not create tables manually; inspect the GitHub Actions run log first.
5. Set a strong, random, one-time `ADMIN_SETUP_TOKEN` as a Cloudflare Worker secret (32+ characters). Generate it privately; do not put it in Git or send it in chat. Once the binding and schema are deployed, open `/auth` and choose **Initial setup (first admin only)**. Create the admin with a valid email and password of at least 12 characters. The endpoint refuses setup if an administrator already exists. Verify login, then remove or rotate the setup secret in Cloudflare.

The workflow requires the repository Actions secret in step 2 but does not require a local Node/npm/VS Code setup. Re-running it will not recreate tables that already exist; Wrangler tracks which numbered migrations have been applied.

## Implemented API paths

- `GET /api/d1/health`: checks the D1 query path.
- `GET /api/d1/catalog`: public active brands, categories and published products, with active bottle sizes and stock.
- `POST /api/d1/admin/setup`: guarded first-administrator bootstrap.
- `POST /api/d1/admin/login`, `GET /api/d1/admin/session`, `POST /api/d1/admin/logout`: password verification, HttpOnly/Secure/SameSite session cookie, 12-hour expiry and server-side revocation.
- `GET|POST /api/d1/admin/products`: private catalogue read and create/update of products, categories assigned to products, bottle sizes and stock. Setting `published=false` hides a product from the public catalogue.
- `GET|POST /api/d1/admin/brands` and `GET|POST /api/d1/admin/categories`: private reference reads and create/update operations.

Admin passwords use PBKDF2-SHA-256. Only SHA-256 hashes of random session tokens are stored. Admin mutations validate request fields, use prepared statements and D1 batch operations, create audit entries, and require both a valid admin session and a same-origin request. Login/setup attempts are throttled using D1 storage. The browser never receives the database binding or setup secret.

## Still required before calling this production-ready

- Provision the real D1 database, set its binding and apply the migration.
- Create the first admin privately, then verify login, logout, expired-session rejection and rejected anonymous writes against the live Worker.
- Populate verified brand/category/product records. The D1 database starts empty on purpose.
- Test product creation/editing and persistence from another device; verify that unpublished products remain private and published products appear in the storefront.
- Configure a real order system before claiming order management is available. Payment processing is intentionally not enabled.

The CI workflow validates production builds and runs lint/tests after pushes to `main`; passing CI does not substitute for deploying and testing the real D1 binding. Current demo images, product names, prices and stock values are illustrative only.
