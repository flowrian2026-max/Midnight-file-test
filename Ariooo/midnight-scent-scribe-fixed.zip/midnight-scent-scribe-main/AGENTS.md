<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Storefront architecture
- Isolate homepage scroll storytelling in ScrollEditorial with compositor CSS variables, passive requestAnimationFrame updates and a static reduced-motion layout; this keeps shopping and shared navigation independent of motion.
- Use the existing TanStack routes, shared shell and bilingual context; this preserves the established storefront.
- All demo product views and local editing use the same catalog store and React Query keys; never mix local reads with remote writes.
- Keep cart normalization in a pure helper and use it for restored and updated entries; variant stock and published status must be enforced consistently.
- The demo editor is public, browser-only and separate from authenticated administration; local storage never grants privileges.
- Authenticated administration stays read-only until its actual server catalog and authorization are verified; retain the existing provider configuration.
