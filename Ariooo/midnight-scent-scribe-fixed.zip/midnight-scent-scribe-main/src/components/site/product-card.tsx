import { Link } from "@tanstack/react-router";
import { Heart } from "lucide-react";
import { useLanguage } from "./language";
import { resolveImg } from "@/lib/catalog";
import { minPrice, totalStock, type DemoProduct } from "@/lib/demo-catalog";
import { useCommerce } from "@/lib/commerce";
import { Button } from '@/components/ui/button';

function scentMood(p: DemoProduct): "fruity" | "floral" | "citrus" | "amber" | "spicy" | "woody" | "aromatic" {
  const characters = new Set((p.scent_character ?? []).map((item) => item.toLowerCase()));
  const notes = [p.name, p.notes?.top, p.notes?.heart, p.notes?.base].filter(Boolean).join(" ").toLowerCase();
  if (characters.has("fruity") || /\b(cherry|cherries|berry|berries|strawberry|raspberry|plum|peach)\b/.test(notes)) return "fruity";
  if (characters.has("citrus") || /\b(citrus|bergamot|grapefruit|lemon|mandarin|orange)\b/.test(notes)) return "citrus";
  if (characters.has("floral") || /\b(floral|rose|jasmine|peony|iris|flower|blossom)\b/.test(notes)) return "floral";
  if (characters.has("gourmand") || characters.has("amber") || /\b(amber|vanilla|tonka|cocoa|chocolate|caramel)\b/.test(notes)) return "amber";
  if (characters.has("spicy") || /\b(spice|spicy|pepper|saffron|cardamom|cinnamon|clove)\b/.test(notes)) return "spicy";
  if (characters.has("woody") || /\b(wood|woody|oud|cedar|sandalwood|vetiver|patchouli)\b/.test(notes)) return "woody";
  return "aromatic";
}

export function ProductCard({ p, brandName }: { p: DemoProduct; brandName?: string | undefined }) {
  const { fa, t } = useLanguage();
  const { toggleWishlist, inWishlist } = useCommerce();
  const stock = totalStock(p);
  const wished = inWishlist(p.id);
  const handleCardPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.pointerType !== "mouse" || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width;
    const y = (event.clientY - rect.top) / rect.height;
    event.currentTarget.style.setProperty("--card-tilt-x", `${((0.5 - y) * 4).toFixed(2)}deg`);
    event.currentTarget.style.setProperty("--card-tilt-y", `${((x - 0.5) * 5).toFixed(2)}deg`);
    event.currentTarget.style.setProperty("--card-glint-x", `${(x * 100).toFixed(1)}%`);
    event.currentTarget.style.setProperty("--card-glint-y", `${(y * 100).toFixed(1)}%`);
  };
  const resetCardPointer = (event: React.PointerEvent<HTMLDivElement>) => {
    event.currentTarget.style.setProperty("--card-tilt-x", "0deg");
    event.currentTarget.style.setProperty("--card-tilt-y", "0deg");
    event.currentTarget.style.setProperty("--card-glint-x", "50%");
    event.currentTarget.style.setProperty("--card-glint-y", "50%");
  };

  return (
    <div
      onPointerMove={handleCardPointerMove}
      onPointerLeave={resetCardPointer}
      className={`ss-product-card ss-product-card--${scentMood(p)} group relative border border-transparent bg-card text-card-foreground transition duration-500 hover:-translate-y-1`}
    >
      <Button variant="ghost" size="icon"
        type="button"
        onClick={() => toggleWishlist(p.id)}
        aria-label={wished ? t.removeFromWishlist : t.addToWishlist}
        aria-pressed={wished}
        className="absolute end-3 top-3 z-10 bg-background/70 p-2 backdrop-blur transition hover:opacity-80"
      >
        <Heart className={`h-4 w-4 ${wished ? "fill-primary text-primary" : ""}`} />
      </Button>
      <Link to="/fragrance/$slug" params={{ slug: p.slug }} className="block">
        <div className="ss-product-card__media relative overflow-hidden">
          <img src={resolveImg(p.image_url)} alt={p.name} loading="lazy" className="ss-product-card__image aspect-[4/5] w-full object-cover" />
          {p.is_new && <span className="eyebrow absolute start-3 top-3 bg-primary px-2 py-1 text-primary-foreground">{t.newTag}</span>}
          {stock === 0 && (
            <span className="eyebrow absolute bottom-0 start-0 end-0 bg-background/80 px-3 py-2 text-center backdrop-blur">{t.outOfStock}</span>
          )}
        </div>
        <div className="p-4">
          <p className="eyebrow text-muted-foreground">{brandName ?? p.brand_slug.replace(/-/g, " ")}</p>
          <h2 className="mt-1 break-words text-2xl" dir="ltr">{p.name}</h2>
          <p dir="ltr" className="mt-1 text-sm">{p.volumes.length ? t.price(minPrice(p)) : (fa ? "قیمت ثبت نشده" : "Price not set")}</p>
          <p dir="ltr" className="mt-1 text-xs text-muted-foreground">{p.volumes.length ? `${p.volumes.map(v => v.ml).join(' / ')} ml · ${stock ? t.inStock : t.outOfStock}` : (fa ? "حجم و موجودی تنظیم نشده" : "Sizes and stock not configured")}</p>
        </div>
      </Link>
    </div>
  );
}
