import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, ArrowUpRight } from "lucide-react";
import { resolveImg } from "@/lib/catalog";
import type { DemoBrand, DemoProduct } from "@/lib/demo-catalog";
import { useLanguage } from "./language";
import "./fragrance-shelf.css";

const preferredSlugs = [
  "bleu-de-chanel",
  "dior-homme-intense",
  "libre",
  "jazz-club",
  "tobacco-vanille",
  "lost-cherry",
  "chance-eau-tendre",
  "shalimar",
  "black-opium",
];

type Props = {
  products: DemoProduct[];
  brands: DemoBrand[];
  isLoading?: boolean;
};

export function FragranceShelfHero({ products, brands, isLoading = false }: Props) {
  const { fa } = useLanguage();
  const navigate = useNavigate();
  const [activeIndex, setActiveIndex] = useState(0);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [mobile, setMobile] = useState(false);

  const featured = useMemo(() => {
    const bySlug = new Map(products.filter((product) => product.published).map((product) => [product.slug, product]));
    const ordered: DemoProduct[] = [];
    const used = new Set<string>();

    preferredSlugs.forEach((slug) => {
      const product = bySlug.get(slug);
      if (product && !used.has(product.id)) {
        ordered.push(product);
        used.add(product.id);
      }
    });

    products.forEach((product) => {
      if (product.published && !used.has(product.id)) {
        ordered.push(product);
        used.add(product.id);
      }
    });

    return ordered.slice(0, 9);
  }, [products]);

  useEffect(() => {
    const query = window.matchMedia("(max-width: 767px)");
    const sync = () => setMobile(query.matches);
    sync();
    query.addEventListener("change", sync);
    return () => query.removeEventListener("change", sync);
  }, []);

  useEffect(() => {
    if (activeIndex >= featured.length) {
      setActiveIndex(0);
      setSelectedId(null);
    }
  }, [activeIndex, featured.length]);

  const move = (direction: number) => {
    if (featured.length < 2) return;
    setActiveIndex((current) => (current + direction + featured.length) % featured.length);
    setSelectedId(null);
  };

  const openOrSelect = (product: DemoProduct, index: number) => {
    if (selectedId === product.id) {
      void navigate({
        to: "/fragrance/$slug",
        params: { slug: product.slug },
      });
      return;
    }

    setActiveIndex(index);
    setSelectedId(product.id);
  };

  const activeProduct = featured[activeIndex];
  const activeBrand = brands.find((brand) => brand.slug === activeProduct?.brand_slug);
  const activeSizes = activeProduct?.volumes.map((volume) => volume.ml).join(" / ");

  return (
    <section
      className="ss-fragrance-shelf"
      aria-label={fa ? "ویترین گردان عطرها" : "Rotating fragrance shelf"}
      onKeyDown={(event) => {
        if (event.key === "ArrowLeft") {
          event.preventDefault();
          move(-1);
        } else if (event.key === "ArrowRight") {
          event.preventDefault();
          move(1);
        }
      }}
    >
      <div className="ss-shelf-video" aria-hidden="true">
        <video
          className="ss-shelf-video__media"
          src="https://raw.githubusercontent.com/flowrian2026-max/Midnight-file-test/main/Ariooo/sakhre%20poshte%20hero.mp4"
          autoPlay
          muted
          loop
          playsInline
          preload="metadata"
          poster="/scent-hero-v2.mp4"
        />
        <span className="ss-shelf-video__shade" />
      </div>

      <div className="ss-shelf-ambient" aria-hidden="true">
        <span className="ss-shelf-ambient__light ss-shelf-ambient__light--one" />
        <span className="ss-shelf-ambient__light ss-shelf-ambient__light--two" />
        <span className="ss-shelf-ambient__horizon" />
      </div>

      <div className="ss-shelf-heading">
        <p className="ss-shelf-kicker">THE FRAGRANCE EDIT / 2026</p>
        <h1>
          {fa ? <>رایحه‌ی <em>امضای تو.</em></> : <>Find your <em>signature.</em></>}
        </h1>
        <p>
          {fa
            ? "از میان خانه‌های عطر جهان، رایحه‌ی خودت را کشف کن."
            : "A considered selection from the world's most distinctive fragrance houses."}
        </p>
      </div>

      <div className="ss-home-marquee" aria-label={fa ? "جهان رایحه‌ها" : "A world of fragrance"}>
        <div className="ss-home-marquee__track" aria-hidden="true">
          {[0, 1].map((copy) => <div className="ss-home-marquee__group" key={copy}>
            <span>{fa ? "هنر رایحه" : "THE ART OF SCENT"}</span><i>✳</i>
            <span>{fa ? "خاطره در هر قطره" : "MEMORY IN EVERY DROP"}</span><i>✳</i>
            <span>{fa ? "امضای شخصی تو" : "YOUR SIGNATURE, YOUR STORY"}</span><i>✳</i>
            <span>{fa ? "فراتر از یک عطر" : "BEYOND A FRAGRANCE"}</span><i>✳</i>
          </div>)}
        </div>
      </div>

      <div className="ss-display-stand" aria-hidden="true">
        <span className="ss-display-stand__back" />
        <span className="ss-display-stand__tier ss-display-stand__tier--upper" />
        <span className="ss-display-stand__tier ss-display-stand__tier--lower" />
        <span className="ss-display-stand__foot" />
      </div>

      <div className="ss-shelf-stage" aria-label={fa ? "برای انتخاب عطر روی بطری بزن" : "Select a fragrance bottle"}>
        <div className="ss-shelf-track">
          {featured.map((product, index) => {
            const length = featured.length;
            let offset = index - activeIndex;
            if (offset > length / 2) offset -= length;
            if (offset < -length / 2) offset += length;

            const distance = Math.abs(offset);
            const visible = distance <= (mobile ? 2 : 3);
            if (!visible) return null;

            const step = mobile ? 28 : 17;
            const x = offset * step;
            const z = distance === 0 ? (selectedId === product.id ? 190 : 95) : distance * -74;
            const y = distance * (mobile ? 5 : 9);
            const rotate = offset * -15;
            const scale = distance === 0
              ? (selectedId === product.id ? 1.11 : 1.02)
              : Math.max(mobile ? 0.62 : 0.68, 1 - distance * 0.12);
            const opacity = distance === 0 ? 1 : Math.max(0.24, 1 - distance * 0.27);
            const style = {
              transform:
                "translate3d(calc(-50% + " + x + "vw), calc(-50% + " + y + "px), " +
                z + "px) rotateY(" + rotate + "deg) scale(" + scale + ")",
              opacity,
              zIndex: 30 - distance,
            } as CSSProperties;
            const brand = brands.find((item) => item.slug === product.brand_slug);
            const isSelected = selectedId === product.id;
            const isActive = index === activeIndex;

            return (
              <button
                key={product.id}
                type="button"
                className="ss-shelf-card"
                style={style}
                data-distance={distance}
                data-active={isActive}
                data-selected={isSelected}
                aria-pressed={isSelected}
                aria-label={
                  (fa ? "عطر " : "Select ") +
                  product.name +
                  (isSelected
                    ? (fa ? "؛ برای دیدن مشخصات دوباره لمس کن" : "; tap again to view details")
                    : (fa ? "؛ برای انتخاب لمس کن" : "; tap once to bring it forward"))
                }
                onClick={() => openOrSelect(product, index)}
              >
                <span className="ss-shelf-card__image">
                  <img src={resolveImg(product.image_url)} alt="" loading={distance > 1 ? "lazy" : "eager"} />
                  <span className="ss-shelf-card__edge" aria-hidden="true" />
                  <span className="ss-shelf-card__index">0{index + 1}</span>
                  {isSelected && <span className="ss-shelf-card__selected">{fa ? "انتخاب‌شده" : "SELECTED"}</span>}
                </span>
                <span className="ss-shelf-card__identity">
                  <span>{brand?.name ?? product.brand_slug.replace(/-/g, " ")}</span>
                  <strong dir="ltr">{product.name}</strong>
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="ss-shelf-footer">
        <button
          type="button"
          className="ss-shelf-arrow"
          aria-label={fa ? "عطر قبلی" : "Previous fragrance"}
          onClick={() => move(-1)}
          disabled={featured.length < 2}
        >
          <ChevronLeft size={19} />
        </button>

        <div className="ss-shelf-caption" aria-live="polite">
          {isLoading && featured.length === 0 ? (
            <p>{fa ? "در حال آماده‌سازی ویترین…" : "Preparing the fragrance shelf…"}</p>
          ) : activeProduct ? (
            <>
              <span className="ss-shelf-caption__brand">{activeBrand?.name ?? activeProduct.brand_slug.replace(/-/g, " ")}</span>
              <strong dir="ltr">{activeProduct.name}</strong>
              <span className="ss-shelf-caption__details">
                {(activeProduct.concentration ?? "Eau de parfum").toUpperCase()}
                {activeSizes ? "  /  " + activeSizes + " ML" : ""}
              </span>
              <p>
                {selectedId === activeProduct.id
                  ? (fa ? "دوباره روی بطری بزن تا مشخصات همین عطر باز شود." : "Tap the same bottle again to open its full story.")
                  : (fa ? "یک‌بار لمس کن تا بطری جلو بیاید؛ دوباره لمس کن تا مشخصاتش را ببینی." : "Tap a bottle to bring it forward. Tap it again for the full details.")}
              </p>
            </>
          ) : (
            <p>{fa ? "هنوز عطری برای نمایش آماده نیست." : "The collection is being prepared."}</p>
          )}
        </div>

        <button
          type="button"
          className="ss-shelf-arrow"
          aria-label={fa ? "عطر بعدی" : "Next fragrance"}
          onClick={() => move(1)}
          disabled={featured.length < 2}
        >
          <ChevronRight size={19} />
        </button>
      </div>

      <Link className="ss-shelf-all" to="/shop">
        {fa ? "مشاهده‌ی همه‌ی عطرها" : "Explore the full collection"}
        <ArrowUpRight size={14} />
      </Link>
    </section>
  );
}
