import { Link } from '@tanstack/react-router';
import { useState } from 'react';
import { ArrowRight, Search } from 'lucide-react';
import { useLanguage } from './language';
import { families, products, stories, images } from '@/content/site';
import { familySlugs, productSlugs, storySlugs } from '@/content/navigation';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { brandsQuery, productsQuery } from '@/lib/catalog';
import { filterProducts, sortProducts } from '@/lib/demo-catalog';
import { ProductCard } from './product-card';

export function pageHead(title: string, description: string) {
 return {meta: [{title: `${title} — Scent Scribe`},{name:'description',content:description},{property:'og:title',content:`${title} — Scent Scribe`},{property:'og:description',content:description},{property:'og:type',content:'website'},{name:'twitter:card',content:'summary_large_image'}]};
}
export function PageIntro({title, text}: {title: string; text: string}) { const {fa} = useLanguage(); return <div className="mb-10 max-w-3xl"><Link to="/" className="eyebrow text-muted-foreground hover:underline">{fa ? 'خانه' : 'Home'}</Link><h1 className="mt-6 break-words text-4xl md:text-6xl">{title}</h1><p className="mt-5 max-w-2xl text-base leading-8 text-muted-foreground">{text}</p></div>; }
export function ProductGrid() {
 const {t} = useLanguage();
 const products = useQuery(productsQuery);
 const brands = useQuery(brandsQuery);
 return <>
  <p className="mb-6 text-sm text-muted-foreground">{t.demoNotice}</p>
  {products.isLoading ? <p className="py-12 text-center text-muted-foreground">…</p> : products.isError ? <p className="py-12 text-center text-muted-foreground">{t.loadError}</p> : (
   <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
    {sortProducts(products.data ?? [], "newest").filter(p => p.published).map(p => (
     <ProductCard key={p.id} p={p} brandName={brands.data?.find(brand => brand.slug === p.brand_slug)?.name}/>
    ))}
   </div>
  )}
 </>;
}
export function ShopPage() {const {fa} = useLanguage(); return <section className="mx-auto max-w-7xl px-5 py-12 md:px-6 md:py-16"><PageIntro title={fa ? 'همهٔ عطرها' : 'All Fragrances'} text={fa ? 'مجموعهٔ سنت اسکرایب؛ هر عطر را باز کنید و از نزدیک ببینید.' : 'The Scent Scribe collection. Explore each fragrance in detail.'}/><ProductGrid/></section>;}
export function FamiliesPage() {const {t,fa} = useLanguage(); return <section className="mx-auto max-w-7xl px-5 py-12 md:px-6 md:py-16"><PageIntro title={t.famTitle} text={fa ? 'از گل‌های لطیف تا چوب‌های عمیق؛ با دنیای خانواده‌های رایحه آشنا شوید.' : 'From delicate florals to deep woods, explore the language of scent.'}/><div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">{families.map((f,i) => <Link key={f.name} to="/scent-family/$slug" params={{slug:familySlugs[i] ?? 'floral'}}><img src={f.img} alt={t.families[i]?.[0] ?? f.name} className="aspect-[5/4] w-full object-cover"/><h2 className="mt-4 text-3xl">{t.families[i]?.[0]}</h2><p className="mt-2 text-muted-foreground">{t.families[i]?.[1]}</p></Link>)}</div></section>;}
const familyDescriptions = [
 ['Floral fragrances evoke petals, bouquets and gardens. Rose, jasmine and violet are familiar references. They can feel airy and fresh or rich and enveloping.', 'رایحه‌های گلی یادآور گلبرگ‌ها، دسته‌گل‌ها و باغ‌ها هستند. رز، یاس و بنفشه از نمونه‌های آشنا هستند. این خانواده می‌تواند سبک و تازه یا غنی و فراگیر باشد.'],
 ['Amber fragrances draw on warm, resinous impressions. Vanilla, balsamic accords and soft spices often shape this family. The effect can be plush, intimate and lingering.', 'رایحه‌های کهربایی فضایی گرم و رزینی دارند. وانیل، آکوردهای بالزامیک و ادویه‌های ملایم اغلب در این خانواده دیده می‌شوند و حسی نرم، صمیمی و ماندگار می‌سازند.'],
 ['Woody fragrances recall cedar, sandalwood and vetiver. Their character ranges from dry and clean to smoky and earthy. They give a composition structure and depth.', 'رایحه‌های چوبی یادآور سدر، چوب صندل و وتیور هستند. از خشک و شفاف تا دودی و خاکی تغییر می‌کنند و به ترکیب عطر عمق و ساختار می‌دهند.'],
 ['Spicy fragrances borrow the energy of pepper, cardamom and cinnamon. Fresh spices can sparkle; warmer spices create a rounded, enveloping impression.', 'رایحه‌های تند از انرژی فلفل، هل و دارچین الهام می‌گیرند. ادویه‌های تازه حس درخشان‌تری دارند و ادویه‌های گرم فضایی نرم و فراگیر ایجاد می‌کنند.'],
 ['Citrus fragrances recall lemon, bergamot and mandarin peel. Often bright at the opening, they can be paired with flowers, herbs or woods for greater depth.', 'رایحه‌های مرکباتی یادآور پوست لیمو، ترنج و نارنگی هستند. شروعی روشن دارند و در کنار گل‌ها، گیاهان یا چوب‌ها عمق بیشتری پیدا می‌کنند.'],
];
export function FamilyPage({ slug }: { slug: string }) {
 const { t, fa } = useLanguage();
 const i = familySlugs.findIndex((item) => item === slug);
 const family = families[i];
 const catalogue = useQuery(productsQuery);
 const brands = useQuery(brandsQuery);
 if (!family) return <Missing/>;

 const familyProducts = sortProducts(filterProducts(catalogue.data ?? [], { cat: slug }), "newest");
 const familyTitle = t.families[i]?.[0] ?? family.name;

 return (
  <section className="mx-auto max-w-7xl px-5 py-12 md:px-6 md:py-16">
   <PageIntro title={familyTitle} text={t.families[i]?.[1] ?? family.desc}/>
   <div className="grid items-start gap-10 md:grid-cols-2">
    <img src={family.img} alt={familyTitle} className="aspect-[5/4] w-full object-cover"/>
    <div>
     <h2 className="text-3xl">{fa ? 'شخصیت رایحه' : 'Scent character'}</h2>
     <p className="mt-6 leading-8 text-muted-foreground">{familyDescriptions[i]?.[fa ? 1 : 0]}</p>
     <p className="mt-6 leading-8">{fa ? 'یک عطر ممکن است به چند خانواده نزدیک باشد؛ روی پوست خودتان امتحان کنید و بعد از تغییر نُت‌های آغازین دوباره آن را بسنجید.' : 'A fragrance may overlap several families. Try it on your own skin and revisit it after the opening notes settle.'}</p>
     <Button asChild className="mt-8"><Link to="/shop" search={{ cat: slug }}>{fa ? 'دیدن عطرهای این خانواده' : 'Shop this family'}<ArrowRight className="rtl:rotate-180"/></Link></Button>
    </div>
   </div>

   <section className="mt-20 border-t border-border/70 pt-12" aria-labelledby="family-products-heading">
    <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
     <div>
      <p className="eyebrow text-muted-foreground">{fa ? 'انتخاب‌هایی از خانوادهٔ رایحه' : 'SCENT FAMILY EDIT'}</p>
      <h2 id="family-products-heading" className="mt-2 text-3xl md:text-4xl">{fa ? `عطرهای ${familyTitle}` : `${familyTitle} fragrances`}</h2>
     </div>
     {catalogue.data && <p className="text-sm text-muted-foreground">{t.results(familyProducts.length)}</p>}
    </div>
    {catalogue.isLoading ? <p className="py-12 text-center text-muted-foreground">…</p>
     : catalogue.isError ? <p className="py-12 text-center text-muted-foreground">{t.loadError}</p>
     : familyProducts.length ? (
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
       {familyProducts.map((product) => (
        <ProductCard
         key={product.id}
         p={product}
         brandName={brands.data?.find((brand) => brand.slug === product.brand_slug)?.name}
        />
       ))}
      </div>
     ) : (
      <p className="border-y py-12 text-muted-foreground">{fa ? 'فعلاً عطری با این خانواده ثبت نشده است.' : 'No published fragrances are currently assigned to this family.'}</p>
     )}
    <Button asChild variant="outline" className="mt-8"><Link to="/shop" search={{ cat: slug }}>{fa ? 'مشاهده در فروشگاه' : 'View in shop'}</Link></Button>
   </section>
  </section>
 );
}
export function ProductPage({slug}: {slug:string}) {const {fa,t} = useLanguage(); const p = products[productSlugs.findIndex(s => s === slug)]; if (!p) return <Missing/>; return <section className="mx-auto max-w-7xl px-5 py-12 md:px-6"><div className="grid gap-10 md:grid-cols-2"><img src={p.img} alt={`Scent Scribe ${p.name}`} className="mx-auto aspect-[4/5] w-full max-w-lg object-cover"/><div className="py-6"><Link to="/shop" className="eyebrow">{fa ? 'همهٔ عطرها' : 'All Fragrances'}</Link><h1 dir="ltr" className="mt-8 break-words text-5xl md:text-6xl">{p.name}</h1><p className="mt-5">{t.edp}</p><p dir="ltr" className="mt-4 text-2xl">{t.price(p.price)}</p><div className="mt-8 border-y py-6 leading-8"><p>{fa ? 'تصویر و قیمت فعلی مجموعهٔ سنت اسکرایب در این صفحه نمایش داده شده است. حجم، ترکیبات دقیق و موجودی این عطر هنوز تأیید نشده‌اند.' : 'This page shows the current Scent Scribe collection image and price. Bottle size, exact composition and stock availability have not yet been confirmed.'}</p></div><h2 className="mt-8 text-3xl">{fa ? 'نگهداری از عطر' : 'Caring for your fragrance'}</h2><p className="mt-4 leading-8 text-muted-foreground">{fa ? 'عطر را دور از نور مستقیم و گرمای زیاد نگه دارید. پس از استفاده، درِ بطری را ببندید و از تماس با چشم‌ها خودداری کنید.' : 'Keep fragrance away from direct sunlight and excessive heat. Close the bottle after use and avoid contact with eyes.'}</p><Button asChild variant="outline" className="mt-8"><Link to="/contact">{fa ? 'اطلاعات خرید و موجودی' : 'Purchase & availability information'}</Link></Button></div></div></section>;}
const articles = [
 {en:['A Fragrant Summer on the Amalfi Coast','Travel','Along the coast, scent belongs as much to the landscape as to a bottle: citrus peel, warm stone and air from the sea.','A citrus fragrance can echo that brightness without trying to reproduce a place literally. Bergamot and lemon suggest freshness, while woods can lend a quieter finish.','When choosing a scent for warmer days, try a little first. Heat changes how quickly a fragrance unfolds, and the same perfume can feel different outdoors.'],fa:['تابستانی معطر در ساحل آمالفی','سفر','در کنار ساحل، رایحه به اندازهٔ یک بطری عطر به منظره تعلق دارد: پوست مرکبات، سنگ گرم و هوای دریا.','یک عطر مرکباتی می‌تواند آن روشنایی را بازتاب دهد، بدون آنکه یک مکان را عیناً بازسازی کند. ترنج و لیمو تازگی می‌آورند و چوب‌ها پایانی آرام‌تر می‌سازند.','برای روزهای گرم، ابتدا مقدار کمی از عطر را امتحان کنید. گرما سرعت بازشدن رایحه را تغییر می‌دهد و همان عطر در فضای باز ممکن است متفاوت احساس شود.']},
 {en:['The Ritual of Scent','Wellness','A daily fragrance ritual can be a small pause: choosing, applying and noticing how the scent develops.','Try fragrance on clean skin and let it dry naturally rather than rubbing the application points together. Give the opening time to settle before deciding how it feels.','There is no single correct scent for every day. Your surroundings, comfort and preference matter more than a rigid rule about when to wear a perfume.'],fa:['آیین رایحه','آرامش','آیین روزانهٔ عطر می‌تواند مکثی کوچک باشد: انتخاب‌کردن، استفاده‌کردن و توجه به تغییر رایحه.','عطر را روی پوست تمیز امتحان کنید و اجازه دهید طبیعی خشک شود؛ محل استفاده را به هم نمالید. قبل از قضاوت، به نُت‌های آغازین فرصت بدهید آرام بگیرند.','برای همهٔ روزها یک رایحهٔ درست وجود ندارد. محیط، راحتی و سلیقهٔ شما از قواعد سخت دربارهٔ زمان استفاده از عطر مهم‌ترند.']},
 {en:['The Power of a Memory','Inspiration','A familiar smell can bring a person or a place to mind before we have found the words to describe it.','The scent itself is only part of that experience. Context matters: a garden after rain, a favourite room, or a fragrance worn during an important moment.','Keep a small scent journal. Record what you notice first, how the fragrance changes and what it reminds you of. Over time, these impressions can reveal your own preferences.'],fa:['قدرت یک خاطره','الهام','یک بوی آشنا می‌تواند پیش از آنکه واژه‌ای برای توصیفش پیدا کنیم، فرد یا مکانی را به یادمان بیاورد.','خود رایحه فقط بخشی از تجربه است. زمینه هم اهمیت دارد: باغی بعد از باران، اتاقی محبوب یا عطری که در لحظه‌ای مهم استفاده شده است.','دفتر کوچکی برای رایحه‌ها داشته باشید. برداشت نخست، تغییر عطر و چیزی را که به یادتان می‌آورد بنویسید. این یادداشت‌ها به مرور سلیقهٔ شخصی شما را روشن‌تر می‌کنند.']},
];
export function JournalPage() {const {fa,t} = useLanguage(); return <section className="mx-auto max-w-7xl px-5 py-12 md:px-6"><PageIntro title={t.jTitle} text={t.jSub}/><div className="grid gap-10 md:grid-cols-3">{stories.map((s,i) => <Link key={s.title} to="/stories/$slug" params={{slug:storySlugs[i] ?? 'amalfi-coast'}}><img src={s.img} alt={t.stories[i]?.[0]} className="aspect-[3/2] w-full object-cover"/><p className="eyebrow mt-5 text-muted-foreground">{t.stories[i]?.[1]}</p><h2 className="mt-3 text-3xl leading-snug">{t.stories[i]?.[0]}</h2><p className="mt-4 leading-7 text-muted-foreground">{articles[i]?.[fa ? 'fa' : 'en'][2]}</p></Link>)}</div></section>;}
export function ArticlePage({ slug }: { slug: string }) {
 const { fa } = useLanguage();
 const i = storySlugs.findIndex((item) => item === slug);
 const story = stories[i];
 const text = articles[i]?.[fa ? 'fa' : 'en'];
 if (!story || !text) return <Missing />;
 const related = stories
  .map((item, index) => ({ item, index, copy: articles[index]?.[fa ? 'fa' : 'en'] }))
  .filter((item) => item.index !== i && item.copy);

 return (
  <article dir={fa ? 'rtl' : 'ltr'} className="bg-background">
   <section className="relative isolate overflow-hidden border-b border-foreground/10">
    <img src={story.img} alt="" className="absolute inset-0 -z-20 h-full w-full object-cover opacity-60" />
    <div className="absolute inset-0 -z-10 bg-gradient-to-t from-background via-background/75 to-background/15" />
    <div className="mx-auto flex min-h-[58svh] max-w-7xl flex-col justify-end px-5 pb-12 pt-28 md:min-h-[68svh] md:px-6 md:pb-16">
     <Link to="/journal" className="eyebrow mb-8 inline-flex w-fit items-center gap-2 text-muted-foreground hover:text-foreground">
      <ArrowRight className={`h-3.5 w-3.5 ${fa ? 'rotate-180' : ''}`} />
      {fa ? 'بازگشت به مجلهٔ رایحه' : 'BACK TO THE SCENT JOURNAL'}
     </Link>
     <p className="eyebrow mb-5 text-primary">{text[1]}</p>
     <h1 className="max-w-4xl text-4xl leading-[1.04] md:text-7xl">{text[0]}</h1>
     <p className="mt-6 max-w-2xl text-lg leading-8 text-foreground/80 md:text-xl">{text[2]}</p>
    </div>
   </section>

   <div className="mx-auto grid max-w-7xl gap-12 px-5 py-12 md:grid-cols-[minmax(0,1fr)_20rem] md:px-6 md:py-16">
    <div className="mx-auto w-full max-w-3xl">
     <div className="space-y-7 text-base leading-9 text-muted-foreground md:text-lg">
      {text.slice(3).map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
     </div>
     <section className="mt-12 border-y border-foreground/15 py-8 md:py-10">
      <p className="eyebrow mb-3 text-primary">{fa ? 'لحظهٔ کشف' : 'YOUR NEXT DISCOVERY'}</p>
      <h2 className="text-3xl leading-tight md:text-4xl">{fa ? 'رایحه‌ای پیدا کن که داستان تو را تعریف کند.' : 'Find a fragrance that tells your story.'}</h2>
      <p className="mt-4 max-w-xl leading-7 text-muted-foreground">{fa ? 'در مجموعهٔ چندبرندی ما میان رایحه‌های گوناگون بگرد و برای کشف انتخاب بعدی‌ات وقت بگذار.' : 'Explore a multi-brand collection and take your time finding the scent that feels like you.'}</p>
      <Link to="/shop" className="eyebrow mt-6 inline-flex items-center gap-3 bg-primary px-5 py-4 text-primary-foreground transition hover:opacity-85">
       {fa ? 'کشف عطرها' : 'EXPLORE FRAGRANCES'} <ArrowRight className={`h-4 w-4 ${fa ? 'rotate-180' : ''}`} />
      </Link>
     </section>
    </div>

    <aside className="md:border-s md:border-foreground/10 md:ps-8">
     <p className="eyebrow mb-6 text-primary">{fa ? 'داستان‌های بیشتر' : 'CONTINUE READING'}</p>
     <div className="grid gap-7 sm:grid-cols-2 md:grid-cols-1">
      {related.map(({ item, index, copy }) => (
       <Link key={storySlugs[index] ?? item.title} to="/stories/$slug" params={{ slug: storySlugs[index] ?? 'amalfi-coast' }} className="group">
        <div className="overflow-hidden">
         <img src={item.img} alt="" loading="lazy" className="aspect-[5/3] w-full object-cover transition duration-700 group-hover:scale-[1.03]" />
        </div>
        <p className="eyebrow mt-4 text-muted-foreground">{copy?.[1]}</p>
        <h3 className="mt-2 text-xl leading-snug transition group-hover:text-primary">{copy?.[0]}</h3>
        <span className="mt-3 inline-flex items-center gap-2 text-sm text-muted-foreground">{fa ? 'ادامهٔ مطلب' : 'Read story'} <ArrowRight className={`h-3.5 w-3.5 ${fa ? 'rotate-180' : ''}`} /></span>
       </Link>
      ))}
     </div>
    </aside>
   </div>
  </article>
 );
}
const info = {
 'our-story': {en:['Our Story','An independent multi-brand fragrance boutique built around scent as a personal expression.','Fragrance beyond time','Scent Scribe brings its collection, scent families and journal together around one question: what makes a fragrance meaningful to you? A familiar note can feel intimate; an unexpected combination can invite discovery.','Finding your own signature','Explore without rushing. Notice the first impression, then return to the scent as it settles. The fragrance you enjoy wearing matters more than the label attached to it.'],fa:['داستان ما','بوتیک مستقل چندبرندی عطر با نگاهی به رایحه به‌عنوان بیان شخصی.','عطری فراتر از زمان','سنت اسکرایب مجموعه، خانواده‌های رایحه و مجله‌اش را حول یک پرسش کنار هم قرار می‌دهد: چه چیزی یک عطر را برای شما معنادار می‌کند؟ نُتی آشنا می‌تواند صمیمی باشد و ترکیبی غیرمنتظره شما را به کشف دعوت کند.','امضای شخصی شما','بدون عجله کشف کنید. به برداشت نخست توجه کنید و بعد از آرام‌شدن رایحه دوباره به آن برگردید. لذتی که از استفادهٔ عطر می‌برید از برچسب آن مهم‌تر است.']},
 sustainability:{en:['Sustainability','A closer look at thoughtful choices in perfumery.','Use thoughtfully','Store your fragrance carefully so it retains its character. Choose a scent you will genuinely use rather than collecting bottles you do not enjoy.','Packaging and sourcing','Environmental claims should be supported by clear evidence. Verified information about Scent Scribe’s sourcing, packaging and certifications has not yet been provided; no certification or environmental guarantee is claimed here.'],fa:['پایداری','نگاهی نزدیک‌تر به انتخاب‌های آگاهانه در دنیای عطر.','استفادهٔ آگاهانه','عطر را درست نگهداری کنید تا کیفیت رایحه حفظ شود. رایحه‌ای انتخاب کنید که واقعاً استفاده می‌کنید، نه بطری‌هایی که از آن‌ها لذت نمی‌برید.','بسته‌بندی و تأمین مواد','ادعاهای محیط‌زیستی باید پشتوانهٔ روشن داشته باشند. اطلاعات تأییدشدهٔ تأمین مواد، بسته‌بندی و گواهی‌های سنت اسکرایب هنوز ارائه نشده‌اند؛ این صفحه ادعای گواهی یا تضمین محیط‌زیستی ندارد.']},
 ingredients:{en:['Ingredients','Understanding the building blocks of a fragrance.','Natural and crafted materials','Perfumery uses botanical extracts and carefully crafted aroma materials. Both contribute to a scent’s character; “natural” alone does not determine safety or quality.','Top, heart and base','Top notes shape the opening, heart notes develop as the fragrance unfolds, and base notes form its lasting impression. Exact ingredients and allergen information must be checked on each product’s verified label; those labels have not yet been supplied for this collection.'],fa:['مواد اولیه','آشنایی با اجزای سازندهٔ یک رایحه.','مواد طبیعی و ساخته‌شده','عطرسازی از عصاره‌های گیاهی و مواد معطر ساخته‌شده استفاده می‌کند. هر دو در شخصیت رایحه نقش دارند؛ طبیعی‌بودن به‌تنهایی معیار ایمنی یا کیفیت نیست.','نُت آغازین، میانی و پایه','نُت‌های آغازین برداشت اول را می‌سازند، نُت‌های میانی در ادامه باز می‌شوند و نُت‌های پایه اثر ماندگار را شکل می‌دهند. ترکیبات دقیق و اطلاعات حساسیت‌زا باید از برچسب تأییدشدهٔ هر محصول خوانده شوند؛ این برچسب‌ها هنوز برای مجموعه ارائه نشده‌اند.']},
 'shipping-returns':{en:['Shipping & Returns','Order details to check before purchasing a fragrance.','Shipping information','Delivery regions, shipping fees and dispatch estimates have not yet been confirmed. Before placing an order, check the delivery address, available shipping method and final cost.','Returns and product condition','Return deadlines, opened-bottle eligibility and refund terms have not yet been confirmed. Keep the packaging and purchase record, and review the store’s final return policy before purchasing. Online checkout is not currently available.'],fa:['ارسال و مرجوعی','اطلاعاتی که پیش از خرید عطر باید بررسی کنید.','اطلاعات ارسال','محدودهٔ ارسال، هزینه و زمان آماده‌سازی هنوز تأیید نشده‌اند. پیش از سفارش، نشانی مقصد، روش ارسال و مبلغ نهایی را بررسی کنید.','مرجوعی و وضعیت محصول','مهلت مرجوعی، امکان بازگرداندن بطری بازشده و شرایط بازپرداخت هنوز تأیید نشده‌اند. بسته‌بندی و رسید خرید را نگه دارید و پیش از خرید، شرایط نهایی فروشگاه را بخوانید. پرداخت آنلاین در حال حاضر فعال نیست.']},
 contact:{en:['Contact Us','Questions about the collection, availability or gifting.','Contact information','A verified email address, phone number and store address have not yet been provided. No message form is offered until a real receiving channel is connected.','Before you enquire','Have the fragrance name and your question ready. For purchase enquiries, include the bottle size you are looking for and your delivery destination. For an existing order, keep your order reference available; never share full payment-card details.'],fa:['تماس با ما','پرسش دربارهٔ مجموعه، موجودی یا انتخاب هدیه.','راه‌های ارتباطی','ایمیل، شمارهٔ تلفن و نشانی تأییدشدهٔ فروشگاه هنوز ارائه نشده‌اند. تا اتصال یک راه واقعی دریافت پیام، فرم ارسال پیام نمایش داده نمی‌شود.','پیش از تماس','نام عطر و پرسش خود را آماده کنید. برای پرسش خرید، حجم موردنظر و مقصد ارسال را مشخص کنید. برای سفارش قبلی، شمارهٔ سفارش را داشته باشید؛ اطلاعات کامل کارت بانکی را ارسال نکنید.']},
} as const;
export function InfoPage({kind}: {kind:keyof typeof info}) {const {fa} = useLanguage(); const text = info[kind][fa ? 'fa' : 'en']; return <section className="mx-auto max-w-7xl px-5 py-12 md:px-6"><PageIntro title={text[0]} text={text[1]}/><div className="grid items-start gap-10 md:grid-cols-[1fr_1.2fr]"><img src={kind === 'ingredients' ? images.flower : images.hero} alt={fa ? 'سنت اسکرایب' : 'Scent Scribe'} className="aspect-[4/3] w-full object-cover"/><div className="space-y-10">{[2,4].map(i => <div key={i}><h2 className="text-3xl">{text[i]}</h2><p className="mt-4 leading-8 text-muted-foreground">{text[i+1]}</p></div>)}<Button asChild variant="outline"><Link to="/shop">{fa ? 'دیدن عطرها' : 'Explore fragrances'}</Link></Button></div></div></section>;}
export function DiscoveryPage() {const {fa} = useLanguage(); return <section className="mx-auto max-w-7xl px-5 py-12 md:px-6"><PageIntro title={fa ? 'ست‌های آشنایی' : 'Discovery Sets'} text={fa ? 'پیش از انتخاب بطری کامل، سلیقهٔ خودتان را بشناسید.' : 'Get to know your preferences before choosing a full bottle.'}/><div className="mb-12 grid gap-8 border-y py-8 md:grid-cols-3">{(fa ? [['۱. یک خانواده انتخاب کنید','از خانواده‌ای شروع کنید که به سلیقه‌تان نزدیک‌تر است؛ گلی، چوبی، کهربایی، تند یا مرکباتی.'],['۲. روی پوست امتحان کنید','هر بار تعداد کمی رایحه را امتحان کنید و میان آن‌ها فاصله بگذارید.'],['۳. دوباره بسنجید','برداشت اولیه و رایحهٔ چند ساعت بعد را یادداشت کنید تا انتخاب روشن‌تری داشته باشید.']] : [['1. Choose a family','Start with floral, woody, amber, spicy or citrus impressions that appeal to you.'],['2. Try on skin','Try a small number of scents at a time and leave space between applications.'],['3. Revisit the scent','Note both the first impression and the scent a few hours later.']]).map(([h,p]) => <div key={h}><h2 className="text-2xl">{h}</h2><p className="mt-4 leading-8 text-muted-foreground">{p}</p></div>)}</div><p className="mb-8 leading-8">{fa ? 'ست قابل‌خرید، تعداد نمونه‌ها، حجم و قیمت هنوز برای فروشگاه تعریف نشده‌اند. عطرهای مجموعه را در ادامه می‌توانید بررسی کنید.' : 'A purchasable set, sample count, sizes and pricing have not yet been defined. Explore the individual collection fragrances below.'}</p><ProductGrid/></section>;}
export function GiftPage() {const {fa} = useLanguage(); return <section className="mx-auto max-w-7xl px-5 py-12 md:px-6"><PageIntro title={fa ? 'کارت هدیه' : 'Gift Cards'} text={fa ? 'فضایی برای انتخاب رایحه‌ای که به سلیقهٔ خودشان نزدیک است.' : 'Leave room for a fragrance that feels personal to them.'}/><div className="mb-12 max-w-3xl space-y-8"><div><h2 className="text-3xl">{fa ? 'هدیه‌ای با حق انتخاب' : 'A gift with room to choose'}</h2><p className="mt-4 leading-8 text-muted-foreground">{fa ? 'اگر رایحهٔ محبوب گیرنده را نمی‌دانید، حق انتخاب می‌تواند از حدس‌زدن بهتر باشد. از خانوادهٔ موردعلاقه و عطری که معمولاً استفاده می‌کند شروع کنید.' : 'When you do not know someone’s favourite fragrance, choice can be better than guessing. Start with the scent family they enjoy and what they already wear.'}</p></div><div className="border-y py-6"><h2 className="text-2xl">{fa ? 'وضعیت کارت هدیه' : 'Gift card availability'}</h2><p className="mt-4 leading-8">{fa ? 'صدور و خرید کارت هدیه هنوز فعال نشده است. مبلغ، اعتبار و شرایط استفاده تأیید نشده‌اند؛ این صفحه کارت یا کد غیرواقعی صادر نمی‌کند.' : 'Gift card purchase and issuance are not yet available. Amounts, validity and redemption terms are unconfirmed; this page does not issue pretend cards or codes.'}</p></div><h2 className="text-3xl">{fa ? 'عطرهای مجموعه برای بررسی' : 'Explore the collection for gifting'}</h2></div><ProductGrid/></section>;}
const faq = [
 ['How do I choose a fragrance?','Try it on your skin and revisit it after the opening settles. Scent-family guides can help you identify the impressions you enjoy.','چطور عطر انتخاب کنم؟','روی پوست خود امتحان کنید و پس از آرام‌شدن نُت‌های آغازین دوباره بسنجید. راهنمای خانواده‌های رایحه به شناخت سلیقه کمک می‌کند.'],
 ['What are top, heart and base notes?','They describe a fragrance’s evolution: the first impression, the developing centre and the longer-lasting finish.','نُت آغازین، میانی و پایه یعنی چه؟','این نام‌ها مراحل تغییر عطر هستند: برداشت نخست، بخش میانی که باز می‌شود و پایان ماندگارتر.'],
 ['Can I buy online now?','Online checkout is not connected. Stock, bottle sizes and final purchase information still need confirmation.','الان می‌توانم آنلاین خرید کنم؟','پرداخت آنلاین متصل نیست. موجودی، حجم بطری‌ها و اطلاعات نهایی خرید هنوز نیاز به تأیید دارند.'],
 ['Are discovery sets and gift cards available?','Not yet. Their dedicated pages explain how to explore scents and choose gifts; no set or gift card is currently offered for purchase.','ست آشنایی و کارت هدیه موجود است؟','هنوز نه. صفحه‌های اختصاصی دربارهٔ شناخت رایحه و انتخاب هدیه هستند؛ فعلاً ست یا کارت هدیه‌ای برای خرید عرضه نشده است.'],
 ['Where can I find shipping and return terms?','Visit Shipping & Returns for the current status. Delivery fees, regions, timelines and return conditions are not yet confirmed.','شرایط ارسال و مرجوعی را کجا ببینم؟','وضعیت فعلی در صفحهٔ ارسال و مرجوعی است. هزینه، محدوده، زمان ارسال و شرایط مرجوعی هنوز تأیید نشده‌اند.'],
];
export function FaqPage() {const {fa} = useLanguage(); const [search,setSearch] = useState(''); const rows = faq.filter(row => row[fa ? 2 : 0]?.toLowerCase().includes(search.toLowerCase()) || row[fa ? 3 : 1]?.toLowerCase().includes(search.toLowerCase())); return <section className="mx-auto max-w-4xl px-5 py-12 md:px-6"><PageIntro title={fa ? 'سؤالات متداول' : 'Frequently Asked Questions'} text={fa ? 'پاسخ به پرسش‌های رایج دربارهٔ رایحه و فروشگاه.' : 'Answers to common questions about fragrance and the store.'}/><label className="mb-8 flex items-center gap-3 border px-4"><Search className="h-4 w-4 shrink-0"/><input aria-label={fa ? 'جست‌وجوی پرسش‌ها' : 'Search questions'} value={search} onChange={e=>setSearch(e.target.value)} placeholder={fa ? 'جست‌وجوی پرسش‌ها' : 'Search questions'} className="min-w-0 flex-1 bg-transparent py-4 outline-none"/></label>{rows.map(row => <details key={row[0]} className="border-b py-5"><summary className="cursor-pointer text-lg leading-8">{row[fa ? 2 : 0]}</summary><p className="mt-4 leading-8 text-muted-foreground">{row[fa ? 3 : 1]}</p></details>)}{rows.length === 0 && <p>{fa ? 'پرسشی پیدا نشد.' : 'No questions found.'}</p>}<Button asChild variant="outline" className="mt-8"><Link to="/contact">{fa ? 'تماس با ما' : 'Contact us'}</Link></Button></section>;}
function Missing() {const {fa} = useLanguage(); return <section className="mx-auto max-w-4xl px-5 py-16"><h1 className="text-4xl">{fa ? 'این مورد پیدا نشد' : 'Item not found'}</h1><Link to="/shop" className="mt-8 inline-block underline">{fa ? 'بازگشت به فروشگاه' : 'Back to shop'}</Link></section>;}
