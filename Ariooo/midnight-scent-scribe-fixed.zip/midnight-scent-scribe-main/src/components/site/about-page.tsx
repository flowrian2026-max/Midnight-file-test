import { Link } from '@tanstack/react-router';
import { ArrowRight } from 'lucide-react';
import { useLanguage } from '@/components/site/language';
import { images, families } from '@/content/site';

export function AboutPage() {
  const { fa } = useLanguage();
  const copy = fa ? {
    eyebrow: 'داستان سنت اسکرایب',
    title: 'هر رایحه، داستانی برای گفتن دارد.',
    intro: 'سنت اسکرایب یک بوتیک چندبرندی عطر است؛ جایی برای کشف رایحه‌هایی که با خاطره، حال‌وهوا و شخصیت شما پیوند می‌خورند.',
    philosophy: 'ما به عطر فقط به چشم یک محصول نگاه نمی‌کنیم. رایحه می‌تواند یک لحظه را ثبت کند، خاطره‌ای را زنده کند یا راهی تازه برای بیان خودمان باشد.',
    section: 'از کنجکاوی شروع کن',
    sectionText: 'از میان خانه‌های عطر، خانواده‌های بویایی و داستان‌های الهام‌گرفته از رایحه حرکت کن. لازم نیست از قبل عطر مورد علاقه‌ات را بدانی؛ کشف‌کردن بخشی از تجربه است.',
    values: [['انتخاب آگاهانه', 'به نُت‌ها فرصت بده و عطر را روی پوست خودت تجربه کن.'], ['چندین خانهٔ عطر', 'برندهای گوناگون را کنار هم ببین و فقط به یک نام محدود نمان.'], ['داستان پشت رایحه', 'در مجله دربارهٔ نُت‌ها، خاطره‌ها و آیین‌های شخصی بیشتر بخوان.']],
    cta: 'کشف عطرها', journal: 'خواندن مجله'
  } : {
    eyebrow: 'THE STORY OF SCENT SCRIBE',
    title: 'Every fragrance has a story to tell.',
    intro: 'Scent Scribe is a multi-brand fragrance boutique for discovering scents that connect with memory, mood and personal expression.',
    philosophy: 'We see fragrance as more than a product. A scent can hold a moment, bring a memory back to life, or offer a new way to express who we are.',
    section: 'Begin with curiosity',
    sectionText: 'Move between fragrance houses, scent families and stories inspired by the world of perfumery. You do not need to know your signature scent yet; discovery is part of the experience.',
    values: [['Thoughtful discovery', 'Give each note time to unfold and experience fragrance on your own skin.'], ['Many fragrance houses', 'Explore different brands side by side rather than limiting yourself to one name.'], ['Stories behind scent', 'Read about notes, memories and personal rituals in our journal.']],
    cta: 'Explore fragrances', journal: 'Read the journal'
  };
  return <main className="bg-background">
    <section className="relative isolate overflow-hidden border-b border-foreground/10">
      <img src={images.darkFlowers} alt="" className="absolute inset-0 -z-20 h-full w-full object-cover opacity-45" />
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-background via-background/90 to-background/35" />
      <div className="mx-auto grid min-h-[68svh] max-w-7xl items-end gap-12 px-5 pb-16 pt-32 md:grid-cols-[1.2fr_.8fr] md:items-center md:px-6 md:py-24">
        <div>
          <p className="eyebrow mb-5 text-primary">{copy.eyebrow}</p>
          <h1 className="max-w-3xl text-5xl leading-[1.04] md:text-7xl">{copy.title}</h1>
          <p className="mt-7 max-w-2xl text-base leading-8 text-muted-foreground md:text-lg">{copy.intro}</p>
          <div className="mt-9 flex flex-wrap gap-4">
            <Link to="/shop" className="eyebrow inline-flex items-center gap-3 bg-primary px-6 py-4 text-primary-foreground">{copy.cta}<ArrowRight className="h-4 w-4 rtl:rotate-180"/></Link>
            <Link to="/journal" className="eyebrow inline-flex items-center gap-3 border border-foreground/20 px-6 py-4">{copy.journal}<ArrowRight className="h-4 w-4 rtl:rotate-180"/></Link>
          </div>
        </div>
        <div className="relative mx-auto w-full max-w-md">
          <div className="absolute -inset-5 border border-primary/30" />
          <img src={images.flower} alt="" className="relative aspect-[4/5] w-full object-cover" />
          <p className="absolute bottom-4 start-4 bg-background/85 px-3 py-2 font-serif text-lg italic">SCENT / MEMORY / MATTER</p>
        </div>
      </div>
    </section>
    <section className="mx-auto grid max-w-7xl gap-8 px-5 py-16 md:grid-cols-[.7fr_1.3fr] md:px-6 md:py-24">
      <p className="eyebrow text-primary">{fa ? 'نگاه ما' : 'OUR POINT OF VIEW'}</p>
      <div><h2 className="max-w-3xl text-3xl leading-snug md:text-5xl">{copy.philosophy}</h2><div className="mt-8 h-px w-20 bg-primary"/></div>
    </section>
    <section className="border-y border-foreground/10 bg-plum-black">
      <div className="mx-auto max-w-7xl px-5 py-16 md:px-6 md:py-20">
        <div className="max-w-2xl"><p className="eyebrow mb-4 text-primary">{fa ? 'راهنمای کشف' : 'A GUIDE TO DISCOVERY'}</p><h2 className="text-4xl md:text-5xl">{copy.section}</h2><p className="mt-5 leading-8 text-muted-foreground">{copy.sectionText}</p></div>
        <div className="mt-12 grid gap-px border border-foreground/10 bg-foreground/10 md:grid-cols-3">
          {copy.values.map(([title, text], i) => <article key={title} className="bg-plum-black p-7 md:p-9"><span className="eyebrow text-primary">0{i+1}</span><h3 className="mt-6 text-2xl">{title}</h3><p className="mt-4 leading-7 text-muted-foreground">{text}</p></article>)}
        </div>
      </div>
    </section>
    <section className="mx-auto max-w-7xl px-5 py-16 md:px-6 md:py-20">
      <div className="flex flex-wrap items-end justify-between gap-5"><div><p className="eyebrow mb-3 text-primary">{fa ? 'جهان رایحه‌ها' : 'THE WORLD OF SCENT'}</p><h2 className="text-4xl md:text-5xl">{fa ? 'از کجا شروع می‌کنی؟' : 'Where will you begin?'}</h2></div><Link to="/scent-families" className="eyebrow inline-flex items-center gap-2 border-b border-current pb-2">{fa ? 'همهٔ خانواده‌ها' : 'All scent families'}<ArrowRight className="h-3 w-3 rtl:rotate-180"/></Link></div>
      <div className="mt-9 grid grid-cols-2 gap-4 md:grid-cols-5">{families.map((f) => <Link key={f.name} to="/scent-families" className="group"><div className="overflow-hidden"><img src={f.img} alt={f.name} className="aspect-[4/5] w-full object-cover transition-transform duration-700 group-hover:scale-105"/></div><h3 className="mt-3 font-serif text-xl">{f.name}</h3><p className="mt-1 text-sm text-muted-foreground">{f.desc}</p></Link>)}</div>
    </section>
  </main>;
}
