import { useEffect, useRef, useState, type CSSProperties } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "./language";
import { images, products } from "@/content/site";
import bottle from "@/assets/editorial-bottle.png";
import "./perfume-bottle-3d.css";
import "./scent-entry-polish.css";
import type { BottleGL } from "./bottle-gl";

const chapters = ["The encounter", "The composition", "The fragrance edit"];
const chaptersFa = ["اولین دیدار", "ترکیب رایحه", "منتخب عطرها"];

function AnimatedLetters({ text, startDelay }: { text: string; startDelay: number }) {
  return (
    <span className="ss-editorial-letter-line" aria-hidden="true">
      {Array.from(text).map((character, index) => (
        <span
          key={`${character}-${index}`}
          className="ss-editorial-letter"
          style={{ "--ss-letter-delay": `${startDelay + index * 30}ms` } as CSSProperties}
        >
          {character === " " ? "\u00a0" : character}
        </span>
      ))}
    </span>
  );
}

// Motion writes only compositor variables; React changes only at chapter boundaries.
export function ScrollEditorial() {
  const { fa, t } = useLanguage();
  const scene = useRef<HTMLElement>(null);
  const [chapter, setChapter] = useState(0);
  const [bottleIndex, setBottleIndex] = useState(0);
  const [reduced, setReduced] = useState(false);
  const [glReady, setGlReady] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fogRef = useRef<HTMLCanvasElement>(null);
  const [fogCleared, setFogCleared] = useState(false);
  const [entryVisible, setEntryVisible] = useState(true);
  const [entryReleased, setEntryReleased] = useState(false);
  const [selectedIngredients, setSelectedIngredients] = useState<string[]>([]);
  const glRef = useRef<BottleGL | null>(null);

  useEffect(() => {
    const node = scene.current;
    if (!node) return;
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    const update = () => {
      frame = 0;
      if (preference.matches) return;
      const range = Math.max(1, node.offsetHeight - window.innerHeight);
      const progress = Math.max(0, Math.min(1, -node.getBoundingClientRect().top / range));
      const beat = progress < 0.3 ? 0 : progress < 0.67 ? 1 : 2;
      const nextBottle = Math.min(products.length - 1, Math.floor(progress * products.length));
      setBottleIndex((previous) => previous === nextBottle ? previous : nextBottle);
      node.style.setProperty("--journey", String(progress));
      // Keep the perfume present from the first frame: the living ocean is the motion,
      // while the bottle only drifts gently with the scene instead of rotating into view.
      node.style.setProperty("--bottle-enter", "1");
      node.style.setProperty("--bottle-turn", "-12deg");
      glRef.current?.wake();
      const bottleFrame = node.querySelector<HTMLElement>(".ss-editorial-bottle-frame");
      if (bottleFrame) {
        const mobile = window.matchMedia("(max-width: 767px)").matches;
        const wave = Math.sin(progress * Math.PI * 2);
        const driftX = -progress * (mobile ? 3 : 8);
        const lift = wave * (mobile ? 1.5 : 3);
        const scale = 0.99 + Math.sin(progress * Math.PI) * 0.01;
        bottleFrame.style.visibility = "visible";
        bottleFrame.style.transform = "translate3d(" + driftX.toFixed(1) + "px, " + lift.toFixed(1) + "px, 0) scale(" + scale.toFixed(3) + ")";
      }
      setChapter((previous) => previous === beat ? previous : beat);
    };
    const schedule = () => { if (!frame) frame = requestAnimationFrame(update); };
    const syncPreference = () => { setReduced(preference.matches); schedule(); };
    syncPreference();
    preference.addEventListener("change", syncPreference);
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule);
    return () => {
      cancelAnimationFrame(frame);
      preference.removeEventListener("change", syncPreference);
      window.removeEventListener("scroll", schedule);
      window.removeEventListener("resize", schedule);
    };
  }, []);

  // Interactive fogged-glass reveal. A single lightweight canvas sits above the artwork;
  // pointer/touch movement erases soft circles without blocking links or scroll.
  useEffect(() => {
    const canvas = fogRef.current;
    const node = scene.current;
    if (!canvas || !node || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const context = canvas.getContext("2d", { alpha: true });
    if (!context) return;
    let width = 0;
    let height = 0;
    const clearedCells = new Set<number>();
    const gridCols = 12;
    const gridRows = 8;
    let entryDismissedByWipe = false;

    const paintFog = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      width = Math.max(1, rect.width);
      height = Math.max(1, rect.height);
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      context.setTransform(dpr, 0, 0, dpr, 0, 0);
      context.globalCompositeOperation = "source-over";
      context.clearRect(0, 0, width, height);
      clearedCells.clear();
      entryDismissedByWipe = false;
      context.fillStyle = "rgba(191, 197, 222, 0.38)";
      context.fillRect(0, 0, width, height);

      const haze = context.createLinearGradient(0, 0, width, height);
      haze.addColorStop(0, "rgba(232, 235, 255, 0.48)");
      haze.addColorStop(0.42, "rgba(151, 153, 188, 0.34)");
      haze.addColorStop(1, "rgba(31, 24, 45, 0.42)");
      context.fillStyle = haze;
      context.fillRect(0, 0, width, height);

      // Fine crystalline seams make the wipe layer read as frosted glass, not a flat tint.
      context.lineWidth = 1;
      context.strokeStyle = "rgba(235, 238, 255, 0.22)";
      for (let i = 0; i < 14; i += 1) {
        const x = width * ((i * 31) % 100) / 100;
        const y = height * ((i * 47) % 100) / 100;
        context.beginPath();
        context.moveTo(x, y);
        context.lineTo(x + width * (i % 2 ? 0.08 : -0.06), y + height * 0.11);
        context.stroke();
      }

      for (let i = 0; i < 9; i += 1) {
        const x = width * (0.08 + ((i * 37) % 83) / 100);
        const y = height * (0.08 + ((i * 29) % 78) / 100);
        const radius = Math.min(width, height) * (0.12 + (i % 3) * 0.045);
        const cloud = context.createRadialGradient(x, y, 0, x, y, radius);
        cloud.addColorStop(0, "rgba(221, 223, 241, 0.13)");
        cloud.addColorStop(1, "rgba(221, 223, 241, 0)");
        context.fillStyle = cloud;
        context.fillRect(x - radius, y - radius, radius * 2, radius * 2);
      }
    };

    paintFog();
    const observer = new ResizeObserver(paintFog);
    observer.observe(canvas);
    return () => observer.disconnect();
  }, []);

  const eraseFog = (clientX: number, clientY: number) => {
    const canvas = fogRef.current;
    const context = canvas?.getContext("2d");
    if (!canvas || !context || reduced) return;
    const rect = canvas.getBoundingClientRect();
    const x = clientX - rect.left;
    const y = clientY - rect.top;
    if (x < 0 || y < 0 || x > rect.width || y > rect.height) return;

    const mobile = window.matchMedia("(max-width: 767px)").matches;
    const radius = mobile ? 62 : 86;
    for (let row = 0; row < gridRows; row += 1) {
      for (let col = 0; col < gridCols; col += 1) {
        const cellX = (col + 0.5) * rect.width / gridCols;
        const cellY = (row + 0.5) * rect.height / gridRows;
        if (Math.hypot(cellX - x, cellY - y) < radius * 1.45) {
          clearedCells.add(row * gridCols + col);
        }
      }
    }
    context.save();
    context.globalCompositeOperation = "destination-out";
    const gradient = context.createRadialGradient(x, y, radius * 0.12, x, y, radius);
    gradient.addColorStop(0, "rgba(0, 0, 0, 0.96)");
    gradient.addColorStop(0.58, "rgba(0, 0, 0, 0.74)");
    gradient.addColorStop(1, "rgba(0, 0, 0, 0)");
    context.fillStyle = gradient;
    context.beginPath();
    context.arc(x, y, radius, 0, Math.PI * 2);
    context.fill();
    context.restore();
    if (!fogCleared) setFogCleared(true);
    // Once enough of the glass has been wiped away, let the page underneath take over.
    if (!entryDismissedByWipe && clearedCells.size >= Math.ceil(gridCols * gridRows * 0.28)) {
      entryDismissedByWipe = true;
      releaseEntry();
    }
  };

  // Load the 3D bottle after first paint, never for reduced-motion or data-saver visitors.
  useEffect(() => {
    const canvas = canvasRef.current;
    const node = scene.current;
    if (!canvas || !node) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const connection = (navigator as Navigator & { connection?: { saveData?: boolean } }).connection;
    if (connection?.saveData) return;
    let cancelled = false;
    const timer = window.setTimeout(() => {
      import("./bottle-gl")
        .then(({ createBottleGL }) => createBottleGL(canvas, node, bottleModelUrl, () => { glRef.current = null; setGlReady(false); }))
        .then((created) => {
          if (cancelled) { created.destroy(); return; }
          glRef.current = created;
          setGlReady(true);
          created.wake();
        })
        .catch(() => { /* WebGL or the model is unavailable: the CSS bottle stays */ });
    }, 1800);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
      glRef.current?.destroy();
      glRef.current = null;
    };
  }, []);

  const chooseIngredient = (ingredient: string) => {
    if (selectedIngredients.includes(ingredient) || entryReleased) return;
    const next = [...selectedIngredients, ingredient];
    setSelectedIngredients(next);
    if (next.length === 5) window.setTimeout(releaseEntry, 950);
  };

  const releaseEntry = () => {
    if (entryReleased) return;
    setEntryReleased(true);
    window.setTimeout(() => setEntryVisible(false), 1050);
  };

  useEffect(() => {
    if (!entryVisible) return;
    const clearOnScroll = () => {
      if (window.scrollY > 36) {
        setEntryReleased(true);
        setEntryVisible(false);
      }
    };
    window.addEventListener("scroll", clearOnScroll, { passive: true });
    return () => window.removeEventListener("scroll", clearOnScroll);
  }, [entryVisible]);

  const goToChapter = (index: number) => {
    const node = scene.current;
    if (!node) return;
    if (reduced) {
      node.querySelectorAll("article")[index]?.scrollIntoView({ block: "start" });
      return;
    }
    const progress = [0, 0.44, 0.82][index] ?? 0;
    window.scrollTo({ top: window.scrollY + node.getBoundingClientRect().top + progress * (node.offsetHeight - window.innerHeight), behavior: "smooth" });
  };

  const handlePointerMove = (event: React.PointerEvent<HTMLElement>) => {
    eraseFog(event.clientX, event.clientY);
    if (reduced || event.pointerType === "touch") return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    const node = scene.current;
    if (!node) return;
    node.style.setProperty("--pointer-x", x.toFixed(3));
    node.style.setProperty("--pointer-y", y.toFixed(3));
    node.style.setProperty("--parallax-x", (-x * 22).toFixed(1) + "px");
    node.style.setProperty("--parallax-y", (-y * 14).toFixed(1) + "px");
    node.style.setProperty("--pointer-rotate-y", (x * 10).toFixed(2) + "deg");
    node.style.setProperty("--pointer-rotate-x", (y * -7).toFixed(2) + "deg");
    node.style.setProperty("--bottle-pointer-rotate-y", (x * 7).toFixed(2) + "deg");
    node.style.setProperty("--bottle-pointer-rotate-x", (y * -4).toFixed(2) + "deg");
  };
  const resetPointer = () => {
    const node = scene.current;
    if (!node) return;
    node.style.setProperty("--pointer-x", "0");
    node.style.setProperty("--pointer-y", "0");
    node.style.setProperty("--parallax-x", "0px");
    node.style.setProperty("--parallax-y", "0px");
    node.style.setProperty("--pointer-rotate-y", "0deg");
    node.style.setProperty("--pointer-rotate-x", "0deg");
    node.style.setProperty("--bottle-pointer-rotate-y", "0deg");
    node.style.setProperty("--bottle-pointer-rotate-x", "0deg");
  };

  return (
    <section ref={scene} onPointerMove={handlePointerMove} onPointerLeave={resetPointer} className="ss-editorial-scene" data-chapter={chapter} data-static={reduced} data-gl={glReady} data-bottle-index={bottleIndex} aria-label={fa ? "سفر در دنیای رایحه" : "A journey through fragrance"}>
      {entryVisible && <div className={`ss-scent-entry ss-scent-entry--alchemy ${entryReleased ? "is-released" : ""}`}>
        <div className="ss-scent-entry__grain" aria-hidden="true" />
        <p className="ss-scent-entry__eyebrow">{fa ? "آیین ساخت رایحه · SCENT SCRIBE" : "THE SCENT SCRIBE RITUAL"}</p>
        <p className="ss-scent-entry__instruction">{fa ? "مواد را لمس کن؛ رایحه را بساز." : "TOUCH THE NOTES. CREATE YOUR SCENT."}</p>
        <div className="ss-alchemy-stage">
          <div className="ss-alchemy-orbit ss-alchemy-orbit--outer" aria-hidden="true" />
          <div className="ss-alchemy-orbit ss-alchemy-orbit--inner" aria-hidden="true" />
          <div className="ss-alchemy-bottle" aria-label={fa ? "بطری عطر در حال ساخته‌شدن" : "Perfume bottle being composed"}>
            <span className="ss-alchemy-liquid" style={{ "--liquid-level": `${Math.min(100, selectedIngredients.length * 20)}%` } as CSSProperties} />
            <img src={bottle} alt="" />
            <span className="ss-alchemy-bottle-glint" aria-hidden="true" />
          </div>
          {[
            { id: "petal", en: "PETAL", fa: "گلبرگ", x: "clamp(-220px, -22vw, -84px)", y: "clamp(-96px, -10vh, -52px)" },
            { id: "citrus", en: "CITRUS", fa: "مرکبات", x: "clamp(84px, 22vw, 220px)", y: "clamp(-96px, -10vh, -52px)" },
            { id: "jasmine", en: "JASMINE", fa: "یاس", x: "clamp(-260px, -26vw, -105px)", y: "clamp(-6px, 3vh, 22px)" },
            { id: "woods", en: "WOODS", fa: "چوب", x: "clamp(105px, 26vw, 260px)", y: "clamp(-6px, 3vh, 22px)" },
            { id: "musk", en: "MUSK", fa: "مشک", x: "0px", y: "clamp(90px, 15vh, 135px)" },
          ].map((item) => {
            const selected = selectedIngredients.includes(item.id);
            return <button
              key={item.id}
              type="button"
              className={`ss-alchemy-note ${selected ? "is-selected" : ""}`}
              style={{ "--note-x": item.x, "--note-y": item.y } as CSSProperties}
              onClick={() => chooseIngredient(item.id)}
              disabled={selected || entryReleased}
              aria-pressed={selected}
              aria-label={fa ? `افزودن نت ${item.fa}` : `Add ${item.en.toLowerCase()} note`}
            >
              <span>{fa ? item.fa : item.en}</span>
              <i aria-hidden="true" />
            </button>;
          })}
        </div>
        <div className="ss-alchemy-progress" aria-live="polite">
          <span>{fa ? "ترکیب رایحه" : "COMPOSING YOUR FRAGRANCE"}</span>
          <span>{selectedIngredients.length.toString().padStart(2, "0")} / 05</span>
          <span className="ss-alchemy-progress__track"><i style={{ width: `${selectedIngredients.length * 20}%` }} /></span>
        </div>
        <h2>{selectedIngredients.length === 5 ? (fa ? "رایحه کامل شد." : "A SCENT IS BORN.") : (fa ? "رایحه را بساز." : "Compose your scent.")}</h2>
        <p className="ss-scent-entry__sub">{selectedIngredients.length === 5 ? (fa ? "در حال ورود به دنیای عطر…" : "ENTERING THE WORLD OF SCENT…") : (fa ? "هر پنج نت را انتخاب کن تا بطری کامل شود." : "Choose all five notes to complete the bottle.")}</p>
        <button type="button" className="ss-scent-entry__skip" onClick={releaseEntry}>{fa ? "رد کردن و ورود" : "SKIP INTRO"}</button>
      </div>}
      <div className="ss-editorial-stage">
        <div className="ss-editorial-world" aria-hidden="true">
          <video className="ss-editorial-landscape" src="/scent-hero-v2.mp4" poster={images.hero} muted playsInline autoPlay={!reduced} loop preload={reduced ? "none" : "metadata"} ref={(video) => { if (video && reduced) video.pause(); }} />
          <div className="ss-editorial-veil" />
          <span className="ss-editorial-type">{chapter === 1 ? "ESSENCE" : "SCENT"}</span>
          <div className="ss-editorial-atmosphere" />
          <div className="ss-editorial-bottle-frame">
            <div className="ss-scroll-bottle-carousel" aria-label={fa ? "بطری‌ها؛ با اسکرول بچرخان" : "Scroll to rotate the fragrance bottles"}>
              {products.map((product, index) => {
                const rawOffset = (index - bottleIndex + products.length) % products.length;
                const position = rawOffset > products.length / 2 ? rawOffset - products.length : rawOffset;
                return (
                  <img
                    key={product.name}
                    className="ss-scroll-bottle"
                    data-position={position}
                    src={product.img}
                    alt={product.name}
                    draggable={false}
                    style={{ "--bottle-slot": position } as CSSProperties}
                  />
                );
              })}
            </div>
            <div className="ss-scroll-bottle-caption" aria-live="polite">
              <span>{fa ? "منتخب عطرها" : "THE FRAGRANCE EDIT"}</span>
              <strong>{products[bottleIndex]?.name}</strong>
              <small>0{bottleIndex + 1} / 0{products.length}</small>
            </div>
            <img className="ss-editorial-bottle ss-editorial-bottle--fallback" src={bottle} alt="" width="300" height="563" />
            <span className="ss-editorial-specular" />
          </div>
        </div>

        <canvas ref={fogRef} className="ss-editorial-fog" aria-hidden="true" />
        <div className={`ss-editorial-fog-hint ${fogCleared ? "is-cleared" : ""}`} aria-hidden="true">
          <span className="ss-editorial-fog-hint__dot" />
          {fa ? "با انگشت یا نشانگر، مه را پاک کن" : "WIPE TO REVEAL"}
        </div>

        <div className="ss-editorial-heading"><span>{fa ? "بوتیک مستقل عطر" : "INDEPENDENT FRAGRANCE BOUTIQUE"}</span><span dir="ltr">SCENT SCRIBE / VOL. 01</span></div>
        <div className="ss-editorial-chapters">
          <article className="ss-editorial-chapter" data-active={chapter === 0} inert={!reduced && chapter !== 0} aria-hidden={!reduced && chapter !== 0}>
            <p className="ss-editorial-kicker">01 / {fa ? "هنر انتخاب رایحه" : "THE ART OF FINDING YOUR SCENT"}</p>
            <h1 dir="ltr" aria-label="Scent Scribe."><AnimatedLetters text="Scent" startDelay={200} /><br /><em><AnimatedLetters text="Scribe." startDelay={380} /></em></h1>
            <p className="ss-editorial-description">{t.heroTitle.join(" ")}<br />{t.heroSub}</p>
            <Button asChild variant="outline" className="ss-editorial-link"><Link to="/shop">{t.discover}<ArrowUpRight className="h-4 w-4 rtl:-rotate-90" /></Link></Button>
          </article>
          <article className="ss-editorial-chapter" data-active={chapter === 1} inert={!reduced && chapter !== 1} aria-hidden={!reduced && chapter !== 1}>
            <p className="ss-editorial-kicker">02 / {fa ? "لایه‌های رایحه" : "THE COMPOSITION"}</p>
            <h2>{fa ? "از اولین نُت،" : "From the first note,"}<br /><em>{fa ? "تا آخرین خاطره." : "to the last memory."}</em></h2>
            <p className="ss-editorial-description">{fa ? "کهربای گرم. گلبرگ‌های لطیف. عمق چوب‌ها. خانواده‌های رایحه را کشف کن و انتخاب خودت را پیدا کن." : "Golden amber. Soft petals. The depth of woods. Explore the fragrance families and find what moves you."}</p>
            <ul className="ss-editorial-notes">{[0, 1, 2].map((i) => <li key={i}><span>0{i + 1}</span>{t.families[i]?.[0]}</li>)}</ul>
            <Button asChild variant="outline" className="ss-editorial-link"><Link to="/scent-families">{t.famTitle}<ArrowUpRight className="h-4 w-4" /></Link></Button>
            <p className="ss-editorial-caption">{fa ? "تصویر هنری نمایشی؛ نه تصویر رسمی محصولات برندها." : "Illustrative campaign bottle. Not official brand photography."}</p>
          </article>
          <article className="ss-editorial-chapter" data-active={chapter === 2} inert={!reduced && chapter !== 2} aria-hidden={!reduced && chapter !== 2}>
            <p className="ss-editorial-kicker">03 / {fa ? "منتخب خانه‌های عطر" : "THE FRAGRANCE EDIT"}</p>
            <h2 dir={fa ? "rtl" : "ltr"}>{fa ? "نگاهی به" : "A study in"}<br /><em>{fa ? "تام فورد." : "Tom Ford."}</em></h2>
            <p className="ss-editorial-description">{fa ? "انتخابی از مجموعهٔ نمایشی تام فورد؛ در کنار دیور، شنل، ایو سن لوران و دیگر خانه‌های عطر." : "Discover our Tom Ford demonstration edit, alongside Dior, Chanel, Yves Saint Laurent and more fragrance houses."}</p>
            <Button asChild variant="outline" className="ss-editorial-link"><Link to="/brand/$slug" params={{ slug: "tom-ford" }}>{fa ? "منتخب تام فورد" : "The Tom Ford edit"}<ArrowUpRight className="h-4 w-4" /></Link></Button>
            <p className="ss-editorial-caption">{fa ? "تصویر هنری نمایشی؛ نه تصویر رسمی محصولات برندها." : "Demonstration campaign artwork. Not official brand photography."}</p>
          </article>
        </div>

        <nav className="ss-editorial-index" aria-label={fa ? "فصل‌های رایحه" : "Fragrance chapters"}>
          {chapters.map((label, i) => <Button key={label} variant="ghost" onClick={() => goToChapter(i)} aria-current={chapter === i ? "step" : undefined} className="ss-editorial-index-link"><span>0{i + 1}</span><span>{fa ? chaptersFa[i] : label}</span><i /></Button>)}
          <Button asChild variant="ghost" className="ss-editorial-index-shop"><Link to="/shop">{fa ? "فروشگاه" : "Shop the boutique"}<ArrowUpRight className="h-4 w-4" /></Link></Button>
        </nav>
        <span className="ss-editorial-scroll" aria-hidden="true"><ArrowDown className="h-4 w-4" />{fa ? "دنیای رایحه" : "A WORLD OF SCENT"}</span>
      </div>
    </section>
  );
}
