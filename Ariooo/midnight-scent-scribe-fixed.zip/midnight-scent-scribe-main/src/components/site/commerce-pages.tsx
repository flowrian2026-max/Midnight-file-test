import { useEffect, useState, type FormEvent } from 'react';
import { Link } from '@tanstack/react-router';
import { useQuery } from '@tanstack/react-query';
import { ArrowUpRight, Check, Copy, Loader2, Minus, Plus, Send, ShoppingBag, Trash2 } from 'lucide-react';
import { useLanguage } from './language';
import { PageIntro } from './pages';
import { ProductCard } from './product-card';
import { DemoNotice } from './store';
import { useCommerce } from '@/lib/commerce';
import { brandsQuery, productsQuery, resolveImg } from '@/lib/catalog';
import { recommendCartProducts } from '@/lib/cart-recommendations';
import { isRemoteCatalogEnabled } from '@/lib/remote-catalog';
import { Button } from '@/components/ui/button';

const wrap = 'mx-auto max-w-7xl px-5 py-12 md:px-6 md:py-16';

type ShippingMethodOption = {
  id: string; name: string; name_fa: string; zone: string; price: number;
  free_shipping_threshold: number | null; estimated_min_days: number; estimated_max_days: number;
};
export function BrandListing({ slug }: { slug: string }) {
  const { fa, t } = useLanguage();
  const brands = useQuery(brandsQuery);
  const products = useQuery(productsQuery);
  const brand = brands.data?.find((item) => item.slug === slug);
  const list = products.data?.filter((product) => product.published && product.brand_slug === slug) ?? [];
  const featured = list.find((product) => product.is_new) ?? list[0];
  const title = brand?.name ?? slug.replace(/-/g, " ");
  const description = brand ? (fa ? brand.blurbFa : brand.blurbEn) : (
    fa ? "عطرهای منتخب این برند را در مجموعهٔ سنت اسکرایب کشف کنید." : "Discover selected fragrances from this house in the Scent Scribe collection."
  );

  return (
    <section className={wrap}>
      {products.isLoading ? (
        <div className="py-24 text-center text-muted-foreground">…</div>
      ) : products.isError ? (
        <p className="py-20 text-center text-muted-foreground">{t.loadError}</p>
      ) : (
        <>
          <section className="ss-brand-hero relative isolate mb-14 grid overflow-hidden border border-primary/20 bg-card/30 md:min-h-[440px] md:grid-cols-[1fr_.92fr]">
            <div className="relative z-10 flex flex-col items-start justify-center p-6 sm:p-10 lg:p-14">
              <Link to="/shop" className="eyebrow text-muted-foreground transition hover:text-foreground">
                {fa ? "همهٔ عطرها" : "ALL FRAGRANCES"}
              </Link>
              <p className="eyebrow mt-8 text-primary">{fa ? "خانهٔ عطرسازی" : "THE PERFUMERY HOUSE"}</p>
              <h1 className="mt-4 break-words font-serif text-5xl leading-[1.05] sm:text-6xl lg:text-7xl" dir="ltr">{title}</h1>
              <p className="mt-6 max-w-xl text-sm leading-8 text-muted-foreground sm:text-base">{description}</p>
              <div className="mt-7 flex flex-wrap items-center gap-x-5 gap-y-2 border-y border-border/70 py-4 text-xs text-muted-foreground">
                <span>{fa ? "تعداد عطرهای مجموعه" : "FRAGRANCES IN THE EDIT"}</span>
                <strong className="text-foreground" dir="ltr">{list.length}</strong>
                <span>{fa ? "مجموعهٔ چندبرندی" : "MULTI-BRAND COLLECTION"}</span>
              </div>
              <Button asChild className="mt-8 h-auto rounded-none px-5 py-3">
                <Link to="/shop" search={{ brand: slug }}>
                  {fa ? "کشف عطرهای این برند" : "Explore this house"}
                  <ArrowUpRight className="ms-2 h-4 w-4" />
                </Link>
              </Button>
            </div>

            {featured ? (
              <Link
                to="/fragrance/$slug"
                params={{ slug: featured.slug }}
                className="ss-brand-hero__feature group relative block min-h-[320px] overflow-hidden border-t border-border/70 md:min-h-[440px] md:border-s md:border-border/70 md:border-t-0"
                aria-label={fa ? `مشاهدهٔ ${featured.name}` : `Explore ${featured.name}`}
              >
                <img
                  src={resolveImg(featured.image_url)}
                  alt={featured.name}
                  className="absolute inset-0 h-full w-full object-cover transition duration-700 group-hover:scale-[1.035]"
                  loading="eager"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/15 to-background/5" />
                <div className="absolute inset-x-0 bottom-0 p-6 sm:p-9">
                  <p className="eyebrow text-primary">{fa ? "رایحهٔ منتخب" : "THE HOUSE EDIT"}</p>
                  <h2 dir="ltr" className="mt-3 break-words font-serif text-3xl sm:text-4xl">{featured.name}</h2>
                  <p className="mt-3 inline-flex items-center gap-2 text-xs text-foreground/80">
                    {fa ? "مشاهدهٔ عطر" : "Discover fragrance"} <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" />
                  </p>
                </div>
              </Link>
            ) : (
              <div className="flex min-h-[280px] items-center justify-center border-t border-border/70 bg-muted/20 md:border-s md:border-t-0">
                <span className="font-serif text-8xl text-primary/30">S.</span>
              </div>
            )}
          </section>

          <DemoNotice />
          <div className="mb-7 mt-12 flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow text-muted-foreground">{fa ? "مجموعهٔ برند" : "THE COLLECTION"}</p>
              <h2 className="mt-3 font-serif text-3xl sm:text-4xl">{fa ? `عطرهای ${title}` : `${title} fragrances`}</h2>
            </div>
            <p className="text-sm text-muted-foreground">{t.results(list.length)}</p>
          </div>

          {list.length > 0 ? (
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              {list.map((product) => <ProductCard key={product.id} p={product} brandName={brand?.name ?? title} />)}
            </div>
          ) : (
            <p className="border-y py-12 text-muted-foreground">{t.brandEmpty}</p>
          )}
          <Button asChild variant="outline" className="mt-8 rounded-none">
            <Link to="/shop">{t.continueShopping}</Link>
          </Button>
        </>
      )}
    </section>
  );
}
export function WishlistPage() {
  const {fa,t} = useLanguage(); const {wishlist} = useCommerce(); const products = useQuery(productsQuery); const brands = useQuery(brandsQuery);
  const list = products.data?.filter(p => p.published && wishlist.includes(p.id)) ?? [];
  return <section className={wrap}><PageIntro title={t.wishlist} text=""/><DemoNotice/>{list.length ? <div className="grid grid-cols-2 gap-4 md:grid-cols-4">{list.map(p => <ProductCard key={p.id} p={p} brandName={brands.data?.find(brand => brand.slug === p.brand_slug)?.name}/>)}</div> : <p className="py-12 text-muted-foreground">{fa ? 'هنوز عطری ذخیره نکرده‌اید.' : 'No saved fragrances yet.'}</p>}<Button asChild variant="outline" className="mt-8"><Link to="/shop">{t.continueShopping}</Link></Button></section>;
}
export function CartPage() {
  const { t, fa } = useLanguage();
  const { items, subtotal, setQty, removeFromCart, clearCart } = useCommerce();
  const products = useQuery(productsQuery);
  const brands = useQuery(brandsQuery);
  const [copyState, setCopyState] = useState<"idle" | "copied" | "unavailable">("idle");
  const [requestDetails, setRequestDetails] = useState({
    customer_name: "", customer_email: "", customer_phone: "",
    shipping_address: "", shipping_city: "", shipping_postcode: "", customer_note: "", promotion_code: "", shipping_method_id: "",
  });
  const [requestState, setRequestState] = useState<{ status: "idle" | "submitting" | "success" | "error"; message: string; orderNumber?: string; discountTotal?: number; shippingTotal?: number; total?: number; shippingMethod?: { name: string; name_fa: string; zone: string; estimated_min_days: number; estimated_max_days: number } | null }>({ status: "idle", message: "" });
  const remoteMode = isRemoteCatalogEnabled();
  const [shippingMethods, setShippingMethods] = useState<ShippingMethodOption[]>([]);
  const [shippingLoadError, setShippingLoadError] = useState(false);
  const [shippingLoading, setShippingLoading] = useState(false);
  const itemCount = items.reduce((count, item) => count + item.qty, 0);

  useEffect(() => {
    if (!remoteMode) return;
    let current = true;
    setShippingLoading(true);
    fetch("/api/d1/shipping/methods", { cache: "no-store", credentials: "same-origin" })
      .then(async (response) => {
        const body = await response.json().catch(() => ({})) as { ok?: boolean; items?: ShippingMethodOption[] };
        if (!response.ok || !body.ok) throw new Error("Shipping methods are not available.");
        if (current) {
          const methods = body.items ?? [];
          setShippingMethods(methods);
          setRequestDetails((previous) => ({ ...previous, shipping_method_id: previous.shipping_method_id || methods[0]?.id || "" }));
        }
      })
      .catch(() => { if (current) setShippingLoadError(true); })
      .finally(() => { if (current) setShippingLoading(false); });
    return () => { current = false; };
  }, [remoteMode]);

  const copySelection = async () => {
    const lines = [
      "SCENT SCRIBE — " + (fa ? "فهرست انتخاب‌ها" : "SELECTION SUMMARY"),
      ...items.map((item) => {
        const brandName = brands.data?.find((brand) => brand.slug === item.product.brand_slug)?.name
          ?? item.product.brand_slug.replace(/-/g, " ");
        return brandName + " — " + item.product.name + " | " + item.volume.ml + " ml × " + item.qty
          + " | " + t.price(item.lineTotal);
      }),
      (fa ? "جمع جزء: " : "Subtotal: ") + t.price(subtotal),
      fa ? "هزینه‌ی ارسال و پرداخت در این نسخه تأیید/فعال نیست." : "Shipping is not included. Online payment is not enabled in this demo.",
    ];

    try {
      if (!navigator.clipboard?.writeText) throw new Error("Clipboard API unavailable");
      await navigator.clipboard.writeText(lines.join("\n"));
      setCopyState("copied");
    } catch {
      setCopyState("unavailable");
    }
  };

  const submitOrderRequest = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!items.length || requestState.status === "submitting") return;
    setRequestState({ status: "submitting", message: "" });
    try {
      const response = await fetch("/api/d1/checkout/request", {
        method: "POST",
        credentials: "same-origin",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          ...requestDetails,
          items: items.map((item) => ({
            product_id: item.productId,
            volume_id: item.volumeId,
            quantity: item.qty,
          })),
        }),
      });
      const body = await response.json().catch(() => ({})) as { ok?: boolean; order_number?: string; message?: string; code?: string; discount_total?: number; shipping_total?: number; total?: number; shipping_method?: { name: string; name_fa: string; zone: string; estimated_min_days: number; estimated_max_days: number } | null };
      if (!response.ok || !body.ok || !body.order_number) {
        throw new Error(body.message ?? (body.code === "STOCK_CHANGED"
          ? (fa ? "موجودی تغییر کرده؛ سبد را تازه کن." : "Stock changed. Refresh your cart and try again.")
          : (fa ? "ثبت درخواست انجام نشد؛ دوباره تلاش کن." : "We could not submit the request. Please try again.")));
      }
      setRequestState({
        status: "success",
        orderNumber: body.order_number,
        discountTotal: Number(body.discount_total ?? 0),
        shippingTotal: Number(body.shipping_total ?? 0),
        shippingMethod: body.shipping_method ?? null,
        total: Number(body.total ?? 0),
        message: body.shipping_method
          ? (fa ? "درخواستت ثبت شد. موجودی نهایی بررسی می‌شود؛ روش و هزینه ارسال انتخاب‌شده در سفارش ذخیره شده است. پرداختی انجام نشده." : "Your request is recorded. Stock still needs confirmation; the selected delivery method and fee are saved. No payment was taken.")
          : (fa ? "درخواستت ثبت شد. موجودی و هزینه ارسال بعداً هماهنگ می‌شوند؛ پرداختی انجام نشده است." : "Your request is recorded. Stock and shipping will be confirmed separately; no payment was taken."),
      });
      clearCart();
    } catch (error) {
      setRequestState({
        status: "error",
        message: error instanceof Error ? error.message : (fa ? "خطای ارتباط با سرور." : "Could not reach the order service."),
      });
    }
  };

  const suggestions = recommendCartProducts(
    products.data ?? [],
    items.map((item) => item.product),
    4,
  );

  return (
    <section className={`${wrap} ss-cart-page`}>
      <PageIntro
        title={t.cartTitle}
        text={fa ? "انتخاب‌هایت را مرور کن و رایحه‌های تازه‌ای برای کشف پیدا کن." : "Review your selection and discover a few more fragrances."}
      />
      <DemoNotice />

      {requestState.status === "success" && <div role="status" aria-live="polite" className="mb-8 border border-emerald-400/30 bg-emerald-400/[.06] p-5 sm:p-6">
        <p className="eyebrow text-emerald-200">{fa ? "درخواست دریافت شد" : "REQUEST RECEIVED"}</p>
        <p className="mt-2 font-serif text-2xl text-foreground">{fa ? "شماره پیگیری" : "Reference"}: <span dir="ltr" className="font-sans text-lg">{requestState.orderNumber}</span></p>
        <p className="mt-2 text-sm leading-7 text-muted-foreground">{requestState.message}</p>
        {Number(requestState.discountTotal ?? 0) > 0 && <p className="mt-3 text-sm text-[#b7b9eb]">{fa ? "تخفیف اعمال‌شده: " : "Discount applied: "}<strong dir="ltr">{t.price(requestState.discountTotal ?? 0)}</strong></p>}
        {requestState.shippingMethod && <p className="mt-1 text-sm text-muted-foreground">{fa ? "روش ارسال: " : "Shipping: "}{fa ? requestState.shippingMethod.name_fa || requestState.shippingMethod.name : requestState.shippingMethod.name} · {requestState.shippingTotal === 0 ? (fa ? "رایگان" : "Free") : t.price(requestState.shippingTotal ?? 0)} · {requestState.shippingMethod.estimated_min_days}–{requestState.shippingMethod.estimated_max_days} {fa ? "روز" : "days"}</p>}
        {!requestState.shippingMethod && <p className="mt-1 text-xs text-muted-foreground">{fa ? "هزینه ارسال بعداً هماهنگ می‌شود." : "Shipping cost will be confirmed separately."}</p>}
        {requestState.total !== undefined && <p className="mt-1 text-sm text-foreground">{fa ? "جمع نهایی درخواست: " : "Request total: "}<strong dir="ltr">{t.price(requestState.total)}</strong></p>}
      </div>}

      {items.length > 0 ? (
        <div className="grid gap-10 lg:grid-cols-[minmax(0,1.8fr)_minmax(270px,.8fr)]">
          <ul className="divide-y border-y">
            {items.map((item) => (
              <li key={`${item.productId}-${item.volumeId}`} className="ss-cart-line flex gap-4 py-6 sm:gap-6">
                <Link to="/fragrance/$slug" params={{ slug: item.product.slug }} className="group block h-32 w-24 shrink-0 overflow-hidden bg-muted sm:h-40 sm:w-32">
                  <img
                    src={resolveImg(item.product.image_url)}
                    alt={item.product.name}
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                </Link>
                <div className="min-w-0 flex-1">
                  <p className="eyebrow text-muted-foreground">{brands.data?.find((brand) => brand.slug === item.product.brand_slug)?.name ?? item.product.brand_slug.replace(/-/g, " ")}</p>
                  <Link to="/fragrance/$slug" params={{ slug: item.product.slug }}>
                    <h2 dir="ltr" className="mt-1 break-words text-xl sm:text-2xl">{item.product.name}</h2>
                  </Link>
                  <p dir="ltr" className="my-2 text-sm text-muted-foreground">{item.volume.ml} ml · {t.price(item.volume.price)}</p>
                  <div className="flex flex-wrap items-center gap-2">
                    <Button
                      size="icon"
                      variant="outline"
                      aria-label={`${fa ? "کاهش تعداد" : "Decrease quantity"} ${item.product.name}`}
                      onClick={() => setQty(item.productId, item.volumeId, item.qty - 1)}
                    ><Minus className="h-4 w-4" /></Button>
                    <span className="w-8 text-center tabular-nums" aria-label={t.qty}>{item.qty}</span>
                    <Button
                      size="icon"
                      variant="outline"
                      disabled={item.qty >= item.volume.stock}
                      aria-label={`${fa ? "افزایش تعداد" : "Increase quantity"} ${item.product.name}`}
                      onClick={() => setQty(item.productId, item.volumeId, item.qty + 1)}
                    ><Plus className="h-4 w-4" /></Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-muted-foreground hover:text-destructive"
                      aria-label={`${t.remove} ${item.product.name}`}
                      onClick={() => removeFromCart(item.productId, item.volumeId)}
                    ><Trash2 className="me-1 h-4 w-4" />{t.remove}</Button>
                  </div>
                </div>
                <p className="shrink-0 text-sm sm:text-base" dir="ltr">{t.price(item.lineTotal)}</p>
              </li>
            ))}
          </ul>

          <aside className="ss-cart-summary h-fit border border-primary/25 bg-card/40 p-5 sm:p-7 lg:sticky lg:top-28">
            <div className="ss-cart-summary__heading">
              <div>
                <p className="eyebrow text-muted-foreground">{fa ? "انتخاب‌های تو" : "YOUR SELECTION"}</p>
                <p className="ss-cart-summary__count">{fa ? `${itemCount} عدد در ${items.length} ردیف` : `${itemCount} items · ${items.length} selections`}</p>
              </div>
              <span className="ss-cart-summary__mark" aria-hidden="true">S.</span>
            </div>
            <div className="mt-6 flex items-center justify-between gap-4 text-lg">
              <span>{t.subtotal}</span>
              <strong dir="ltr" aria-live="polite" className="text-xl">{t.price(subtotal)}</strong>
            </div>
            <div className="my-5 border-t border-border/70" />
            <p className="text-sm leading-7 text-muted-foreground">
              {fa
                ? "انتخاب‌هایت را مرور کن، در صورت وجود روش ارسال را انتخاب کن و درخواست سفارش بفرست. پرداختی در این مرحله انجام نمی‌شود."
                : "Review your selection, choose a delivery method if available, and send an order request. No online payment is taken."}
            </p>
            <Button type="button" variant="outline" onClick={() => void copySelection()} className="ss-cart-summary__copy mt-6 w-full rounded-none">
              {copyState === "copied" ? <Check className="me-2 h-4 w-4" /> : <Copy className="me-2 h-4 w-4" />}
              {copyState === "copied"
                ? (fa ? "فهرست کپی شد" : "Selection copied")
                : (fa ? "کپی فهرست انتخاب‌ها" : "Copy selection")}
            </Button>
            <p className="ss-cart-summary__feedback mt-3 min-h-5 text-xs text-muted-foreground" role="status" aria-live="polite">
              {copyState === "copied"
                ? (fa ? "فهرست کپی شد؛ هنوز هیچ سفارشی ثبت نشده است." : "Copied. No order has been placed.")
                : copyState === "unavailable"
                  ? (fa ? "کپی خودکار در این مرورگر در دسترس نیست." : "Clipboard access is unavailable in this browser.")
                  : t.demoCheckout}
            </p>
            {remoteMode ? <form dir={fa ? "rtl" : "ltr"} onSubmit={(event) => void submitOrderRequest(event)} className="mt-7 space-y-3 border-t border-border/70 pt-6">
              <div className="mb-4">
                <p className="eyebrow text-primary">{fa ? "ثبت درخواست سفارش" : "ORDER REQUEST"}</p>
                <h3 className="mt-2 font-serif text-2xl">{fa ? "اطلاعات تحویل" : "Delivery details"}</h3>
                <p className="mt-2 text-xs leading-6 text-muted-foreground">{fa ? "این مرحله پرداخت ندارد؛ درخواست برای بررسی موجودی و هماهنگی ارسال ثبت می‌شود." : "No payment is taken here. Your request is sent for stock and delivery confirmation."}</p>
              </div>
              <label className="block"><span className="mb-1.5 block text-xs text-muted-foreground">{fa ? "نام و نام خانوادگی" : "Full name"} *</span>
                <input required maxLength={120} autoComplete="name" value={requestDetails.customer_name} onChange={(event) => setRequestDetails({ ...requestDetails, customer_name: event.target.value })} className="w-full border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary" />
              </label>
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="block"><span className="mb-1.5 block text-xs text-muted-foreground">{fa ? "شماره تماس" : "Phone"} *</span>
                  <input required minLength={6} maxLength={40} autoComplete="tel" type="tel" value={requestDetails.customer_phone} onChange={(event) => setRequestDetails({ ...requestDetails, customer_phone: event.target.value })} className="w-full border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary" />
                </label>
                <label className="block"><span className="mb-1.5 block text-xs text-muted-foreground">{fa ? "ایمیل (اختیاری)" : "Email (optional)"}</span>
                  <input maxLength={254} autoComplete="email" type="email" value={requestDetails.customer_email} onChange={(event) => setRequestDetails({ ...requestDetails, customer_email: event.target.value })} className="w-full border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary" />
                </label>
              </div>
              <label className="block"><span className="mb-1.5 block text-xs text-muted-foreground">{fa ? "کد تخفیف (اختیاری)" : "Discount code (optional)"}</span>
                <input maxLength={64} autoCapitalize="characters" value={requestDetails.promotion_code} onChange={(event) => setRequestDetails({ ...requestDetails, promotion_code: event.target.value.toUpperCase() })} placeholder={fa ? "مثلاً WELCOME10" : "e.g. WELCOME10"} className="w-full border border-input bg-background px-3 py-2.5 text-sm uppercase tracking-[.12em] outline-none focus:border-primary" />
              </label>
              {shippingLoading ? <p className="rounded-xl border border-border/70 bg-muted/30 p-3 text-xs text-muted-foreground">{fa ? "در حال دریافت روش‌های ارسال…" : "Loading delivery methods…"}</p> : shippingMethods.length > 0 ? <label className="block"><span className="mb-1.5 block text-xs text-muted-foreground">{fa ? "روش ارسال" : "Delivery method"} *</span>
                <select required value={requestDetails.shipping_method_id} onChange={(event) => setRequestDetails({ ...requestDetails, shipping_method_id: event.target.value })} className="w-full border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary">
                  {shippingMethods.map((method) => <option key={method.id} value={method.id}>{fa ? method.name_fa || method.name : method.name} · {method.zone} · {method.price === 0 ? (fa ? "رایگان" : "Free") : t.price(method.price)} · {method.estimated_min_days}–{method.estimated_max_days} {fa ? "روز" : "days"}</option>)}
                </select>
                <span className="mt-1.5 block text-[11px] text-muted-foreground">{fa ? "اگر مبلغ کالاها پس از تخفیف به حد ارسال رایگان برسد، هزینه ارسال صفر می‌شود." : "Free shipping applies when the discounted items total reaches the method threshold."}</span>
              </label> : <p className="rounded-xl border border-border/70 bg-muted/30 p-3 text-xs leading-6 text-muted-foreground">{shippingLoadError ? (fa ? "روش ارسال آنلاین در دسترس نیست؛ هزینه ارسال پس از بررسی هماهنگ می‌شود." : "Shipping methods are not available yet; delivery cost will be confirmed separately.") : (fa ? "هزینه ارسال پس از بررسی درخواست هماهنگ می‌شود." : "Shipping cost will be confirmed after the request is reviewed.")}</p>}
              <label className="block"><span className="mb-1.5 block text-xs text-muted-foreground">{fa ? "نشانی کامل" : "Full address"} *</span>
                <textarea required maxLength={1000} rows={3} autoComplete="street-address" value={requestDetails.shipping_address} onChange={(event) => setRequestDetails({ ...requestDetails, shipping_address: event.target.value })} className="w-full resize-y border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary" />
              </label>
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="block"><span className="mb-1.5 block text-xs text-muted-foreground">{fa ? "شهر" : "City"} *</span>
                  <input required maxLength={120} autoComplete="address-level2" value={requestDetails.shipping_city} onChange={(event) => setRequestDetails({ ...requestDetails, shipping_city: event.target.value })} className="w-full border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary" />
                </label>
                <label className="block"><span className="mb-1.5 block text-xs text-muted-foreground">{fa ? "کد پستی" : "Postal code"}</span>
                  <input maxLength={40} autoComplete="postal-code" value={requestDetails.shipping_postcode} onChange={(event) => setRequestDetails({ ...requestDetails, shipping_postcode: event.target.value })} className="w-full border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary" />
                </label>
              </div>
              <label className="block"><span className="mb-1.5 block text-xs text-muted-foreground">{fa ? "یادداشت (اختیاری)" : "Note (optional)"}</span>
                <textarea maxLength={1000} rows={2} value={requestDetails.customer_note} onChange={(event) => setRequestDetails({ ...requestDetails, customer_note: event.target.value })} className="w-full resize-y border border-input bg-background px-3 py-2.5 text-sm outline-none focus:border-primary" />
              </label>
              {requestState.status === "error" && <p role="alert" className="border border-destructive/30 bg-destructive/5 p-3 text-xs leading-6 text-destructive">{requestState.message}</p>}
              <Button type="submit" disabled={requestState.status === "submitting" || shippingLoading} className="w-full rounded-none bg-primary py-3 text-primary-foreground">
                {requestState.status === "submitting" ? <Loader2 className="me-2 h-4 w-4 animate-spin" /> : <Send className="me-2 h-4 w-4" />}
                {requestState.status === "submitting" ? (fa ? "در حال ثبت…" : "Submitting…") : (fa ? "ثبت درخواست سفارش" : "Send order request")}
              </Button>
            </form> : <p className="mt-6 border-t border-border/70 pt-5 text-xs leading-6 text-muted-foreground">{fa ? "برای ثبت درخواست سفارش، نسخه متصل به دیتابیس لازم است. فعلاً می‌توانی فهرست انتخاب‌ها را کپی کنی." : "Order requests require the shared D1 catalogue. You can still copy your selection summary in this local preview."}</p>}
            <Button asChild variant="ghost" className="mt-3 w-full rounded-none">
              <Link to="/shop">{t.continueShopping}</Link>
            </Button>
          </aside>
        </div>
      ) : (
        <div className="border-y border-border/70 py-14 text-center sm:py-20">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-primary/30 text-primary">
            <ShoppingBag className="h-6 w-6" />
          </div>
          <h2 className="mt-6 font-serif text-3xl">{t.cartEmpty}</h2>
          <p className="mx-auto mt-3 max-w-md leading-7 text-muted-foreground">
            {fa ? "از نت‌های چوبی تا رایحه‌های گلی، عطر بعدی‌ات را کشف کن." : "From deep woods to delicate florals, find your next signature scent."}
          </p>
          <Button asChild className="mt-7 rounded-none px-6">
            <Link to="/shop">{t.continueShopping}</Link>
          </Button>
        </div>
      )}

      {suggestions.length > 0 && (
        <section className="mt-20 border-t border-border/70 pt-12">
          <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow text-muted-foreground">{fa ? "ادامهٔ کشف رایحه‌ها" : "THE SCENT JOURNEY"}</p>
              <h2 className="mt-2 font-serif text-3xl sm:text-4xl">{fa ? "شاید این‌ها را هم دوست داشته باشی" : "A few more to discover"}</h2>
            </div>
            <Link to="/shop" className="eyebrow border-b border-primary/50 pb-1 hover:border-primary">
              {fa ? "دیدن همهٔ عطرها" : "VIEW ALL FRAGRANCES"}
            </Link>
          </div>
          {products.isLoading ? <p className="py-8 text-muted-foreground">…</p> : products.isError ? null : (
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              {suggestions.map((product) => (
                <ProductCard
                  key={product.id}
                  p={product}
                  brandName={brands.data?.find((brand) => brand.slug === product.brand_slug)?.name}
                />
              ))}
            </div>
          )}
        </section>
      )}
    </section>
  );
}
