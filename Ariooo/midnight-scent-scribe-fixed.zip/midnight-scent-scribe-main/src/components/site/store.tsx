import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { Heart, Minus, Plus, ShoppingBag } from "lucide-react";
import { useLanguage } from "./language";
import { PageIntro } from "./pages";
import { ProductCard } from "./product-card";
import { brandsQuery, categoriesQuery, productsQuery, resolveImg } from "@/lib/catalog";
import { JournalPage, ArticlePage } from './pages';
import { filterProducts, minPrice, sortProducts, totalStock, type DemoProduct, type SortKey } from "@/lib/demo-catalog";
import { useCommerce } from "@/lib/commerce";
import { Button } from "@/components/ui/button";

const wrap = "mx-auto max-w-7xl px-5 py-12 md:px-6 md:py-16";
function Loading() { return <p className="py-16 text-center text-muted-foreground">…</p>; }
function Empty({ text }: { text: string }) { return <p className="py-16 text-center text-muted-foreground">{text}</p>; }
export function DemoNotice() {
  const { t } = useLanguage();
  return <p className="mb-8 border border-primary/30 bg-muted px-4 py-3 text-sm text-muted-foreground">{t.demoNotice}</p>;
}

export interface ShopFilters {
  q?: string | undefined;
  brand?: string | undefined;
  cat?: string | undefined;
  min?: string | undefined;
  max?: string | undefined;
  stock?: string | undefined;
  sort?: string | undefined;
  gender?: string | undefined;
  season?: string | undefined;
}

const inputCls = "w-full border border-input bg-background/50 px-3 py-2 text-sm text-foreground outline-none transition placeholder:text-muted-foreground focus:border-primary focus:ring-1 focus:ring-primary/40";

export function StoreShop({ filters, onChange }: { filters: ShopFilters; onChange: (next: ShopFilters) => void }) {
  const { fa, t } = useLanguage();
  const cats = useQuery(categoriesQuery);
  const brands = useQuery(brandsQuery);
  const prods = useQuery(productsQuery);
  const [q, setQ] = useState(filters.q ?? "");
  useEffect(() => {setQ(filters.q ?? '');},[filters.q]);

  const list = useMemo(() => {
    const f = {
      q: filters.q,
      brand: filters.brand,
      cat: filters.cat,
      min: filters.min ? Number(filters.min) : undefined,
      max: filters.max ? Number(filters.max) : undefined,
      inStock: filters.stock === "1",
      gender: filters.gender,
      season: filters.season,
    };
    const sort = (["newest", "price-asc", "price-desc", "name"].includes(filters.sort ?? "") ? filters.sort : "newest") as SortKey;
    return sortProducts(filterProducts(prods.data ?? [], f), sort);
  }, [prods.data, filters]);

  const chip = (active: boolean) => `eyebrow shrink-0 border px-4 py-2 ${active ? "border-primary bg-primary text-primary-foreground" : "hover:border-primary/60 hover:bg-muted"}`;
  const set = (patch: ShopFilters) => onChange({ ...filters, ...patch });
  const hasFilters = !!(filters.q || filters.brand || filters.cat || filters.min || filters.max || filters.stock || filters.gender || filters.season || (filters.sort && filters.sort !== "newest"));

  return (
    <section className={`${wrap} ss-shop-page`}>
      <div className="ss-shop-page__intro"><PageIntro title={fa ? "فروشگاه" : "Shop"} text={fa ? "عطرها را جست‌وجو، فیلتر و مرتب کنید." : "Search, filter and sort the fragrances."} />
      <DemoNotice /></div>

      <form
        role="search"
        onSubmit={(e) => { e.preventDefault(); set({ q: q.trim() || undefined }); }}
        className="ss-shop-page__search mb-6 flex gap-2"
      >
        <input
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={t.search}
          aria-label={t.search}
          className={`${inputCls} min-w-0 flex-1`}
        />
        <Button type="submit" className="eyebrow h-auto px-5 py-2">{fa ? "جست‌وجو" : "Search"}</Button>
      </form>

      <div className="ss-shop-page__audience mb-4 flex gap-2 overflow-x-auto border-y py-4">
        {([{value:"",label:t.allGenders},{value:"women",label:t.women},{value:"men",label:t.men},{value:"unisex",label:t.unisex}] as const).map(item => (
          <Button key={item.value || "all"} variant="outline" type="button" className={chip((filters.gender ?? "") === item.value)} onClick={() => set({ gender: item.value || undefined })}>{item.label}</Button>
        ))}
      </div>

      <details className="ss-shop-page__category-menu mb-8">
        <summary>
          <span className="ss-shop-page__category-menu-label">{fa ? "دسته‌بندی رایحه‌ها" : "EXPLORE BY SCENT FAMILY"}</span>
          <span className="ss-shop-page__category-menu-current">
            {filters.cat ? (cats.data ?? []).find((category) => category.slug === filters.cat)?.[fa ? "name_fa" : "name_en"] ?? t.allCategories : t.allCategories}
          </span>
          <span className="ss-shop-page__category-menu-icon" aria-hidden="true">＋</span>
        </summary>
        <div className="ss-shop-page__categories flex gap-2 overflow-x-auto pb-2">
          <Button variant="outline" type="button" className={chip(!filters.cat)} onClick={() => set({ cat: undefined })}>{t.allCategories}</Button>
          {(cats.data ?? []).map((c) => (
            <Button variant="outline" key={c.id} type="button" className={chip(filters.cat === c.slug)} onClick={() => set({ cat: filters.cat === c.slug ? undefined : c.slug })}>
              {fa ? c.name_fa : c.name_en}
            </Button>
          ))}
        </div>
      </details>

      <div className="ss-shop-page__filters mb-8 grid gap-3 border-y py-5 sm:grid-cols-2 lg:grid-cols-6">
        <label className="flex flex-col gap-1 text-xs text-muted-foreground">
          <span>{t.seasonLabel}</span>
          <select className={inputCls} value={filters.season ?? ""} onChange={(e) => set({ season: e.target.value || undefined })}>
            <option value="">{t.allSeasons}</option>
            <option value="spring">{t.spring}</option>
            <option value="summer">{t.summer}</option>
            <option value="autumn">{t.autumn}</option>
            <option value="winter">{t.winter}</option>
          </select>
        </label>
        <label className="flex flex-col gap-1 text-xs text-muted-foreground">
          <span>{t.brand}</span>
          <select className={inputCls} value={filters.brand ?? ""} onChange={(e) => set({ brand: e.target.value || undefined })}>
            <option value="">{t.allBrands}</option>
            {(brands.data ?? []).map((b) => <option key={b.slug} value={b.slug}>{b.name}</option>)}
          </select>
        </label>
        <label className="flex flex-col gap-1 text-xs text-muted-foreground">
          <span>{t.sortLabel}</span>
          <select className={inputCls} value={filters.sort ?? "newest"} onChange={(e) => set({ sort: e.target.value })}>
            <option value="newest">{t.sortNewest}</option>
            <option value="price-asc">{t.sortPriceAsc}</option>
            <option value="price-desc">{t.sortPriceDesc}</option>
            <option value="name">{t.sortName}</option>
          </select>
        </label>
        <label className="flex flex-col gap-1 text-xs text-muted-foreground">
          <span>{t.minPrice}</span>
          <input type="number" min={0} dir="ltr" className={inputCls} value={filters.min ?? ""} onChange={(e) => set({ min: e.target.value || undefined })} />
        </label>
        <label className="flex flex-col gap-1 text-xs text-muted-foreground">
          <span>{t.maxPrice}</span>
          <input type="number" min={0} dir="ltr" className={inputCls} value={filters.max ?? ""} onChange={(e) => set({ max: e.target.value || undefined })} />
        </label>
        <div className="flex items-end gap-3">
          <label className="flex items-center gap-2 pb-2 text-sm">
            <input type="checkbox" checked={filters.stock === "1"} onChange={(e) => set({ stock: e.target.checked ? "1" : undefined })} />
            {t.inStockOnly}
          </label>
          {hasFilters && <Button type="button" variant="ghost" className="eyebrow h-auto px-2 pb-2" onClick={() => { setQ(""); onChange({}); }}>{t.resetFilters}</Button>}
        </div>
      </div>

      <p className="ss-shop-page__results mb-6 text-sm text-muted-foreground" aria-live="polite">{t.results(list.length)}</p>
      {prods.isLoading ? <Loading /> : prods.isError ? <Empty text={t.loadError} /> : list.length === 0 ? <Empty text={t.shopEmpty} /> : (
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {list.map((p) => <ProductCard key={p.id} p={p} brandName={brands.data?.find((brand) => brand.slug === p.brand_slug)?.name} />)}
        </div>
      )}
    </section>
  );
}

export function StoreProduct({ slug }: { slug: string }) {
  const { fa, t } = useLanguage();
  const prods = useQuery(productsQuery);
  const brands = useQuery(brandsQuery);
  const { addToCart, toggleWishlist, inWishlist } = useCommerce();
  const [volumeId, setVolumeId] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [justAdded, setJustAdded] = useState(false);
  const [notesRevealed, setNotesRevealed] = useState(false);

  useEffect(() => {
    if (!notesRevealed) return;
    const startY = window.scrollY;
    const clearOnScroll = () => {
      if (window.scrollY - startY > 110) setNotesRevealed(false);
    };
    window.addEventListener("scroll", clearOnScroll, { passive: true });
    return () => window.removeEventListener("scroll", clearOnScroll);
  }, [notesRevealed]);

  if (prods.isLoading) return <Loading />;
  const p = prods.data?.find((x) => x.slug === slug);
  if (prods.isError) return <Empty text={t.loadError} />;
  if (!p || !p.published) return <Empty text={t.notFound} />;
  const volume = p.volumes.find((v) => v.id === volumeId) ?? p.volumes.find((v) => v.stock > 0) ?? p.volumes[0];
  const brand = brands.data?.find((b) => b.slug === p.brand_slug);
  const related = (prods.data ?? [])
    .filter((candidate) => candidate.published && candidate.id !== p.id && (
      candidate.brand_slug === p.brand_slug ||
      candidate.category_id === p.category_id ||
      (p.scent_character ?? []).some((character) => (candidate.scent_character ?? []).includes(character))
    ))
    .sort((a, b) => Number(b.brand_slug === p.brand_slug) - Number(a.brand_slug === p.brand_slug))
    .slice(0, 4);
  const desc = fa ? p.desc_fa : p.desc_en;
  const wished = inWishlist(p.id);
  const hasConfiguredVolumes = p.volumes.length > 0;
  const out = !volume || volume.stock === 0;

  return (
    <section className={`${wrap} ss-product-page`}>
      <DemoNotice />
      <div className="ss-product-page__layout grid gap-10 md:grid-cols-2">
        <div className="ss-product-page__visual">
          <div className="ss-product-page__image-frame">
            <span className="ss-product-page__image-kicker">{fa ? "هنر عطرسازی" : "THE ART OF PERFUMERY"}</span>
            {p.notes && (p.notes.top || p.notes.heart || p.notes.base) ? (
              <button type="button" className={`ss-product-page__image-trigger ${notesRevealed ? "is-broken" : ""} ${(p.scent_character ?? []).map((character) => `ss-product-page__image-trigger--${character}`).join(" ")}`} onClick={() => setNotesRevealed((value) => !value)} aria-label={fa ? "آشکار کردن ترکیبات عطر" : "Reveal this fragrance’s ingredients"} aria-pressed={notesRevealed}>
                <img src={resolveImg(p.image_url)} alt={p.name} className="ss-product-page__image mx-auto aspect-[4/5] w-full max-w-lg object-cover" />
                <span className="ss-product-page__image-invitation">{notesRevealed ? (fa ? "ترکیبات آشکار شدند" : "SCENT RELEASED") : (fa ? "برای آزادکردن رایحه لمس کن" : "TAP TO RELEASE THE SCENT")} <span aria-hidden="true">↗</span></span>
                <span className="ss-product-page__shard ss-product-page__shard--one" aria-hidden="true" />
                <span className="ss-product-page__shard ss-product-page__shard--two" aria-hidden="true" />
                <span className="ss-product-page__shard ss-product-page__shard--three" aria-hidden="true" />
              </button>
            ) : <img src={resolveImg(p.image_url)} alt={p.name} className="ss-product-page__image mx-auto aspect-[4/5] w-full max-w-lg object-cover" />}
            <span className="ss-product-page__image-caption">{brand?.name ?? p.brand_slug.replace(/-/g, " ")} · {fa ? "کشف رایحه" : "SCENT DISCOVERY"}</span>
          </div>
        </div>
        <div className="py-6">
          <Link to="/brand/$slug" params={{ slug: p.brand_slug }} className="eyebrow hover:underline">{brand?.name ?? p.brand_slug.replace(/-/g, " ")}</Link>
          <h1 dir="ltr" className="mt-8 break-words text-5xl md:text-6xl">{p.name}</h1>
          <p dir="ltr" className="mt-4 text-2xl" aria-live="polite">{volume ? t.price(volume.price) : (fa ? "قیمت ثبت نشده" : "Price not set")}</p>

          <div className="mt-8">
            <p className="eyebrow mb-3">{t.selectVolume}</p>
            {hasConfiguredVolumes ? <div className="flex flex-wrap gap-2">
              {p.volumes.map((v) => (
                <Button variant="outline"
                  key={v.id}
                  type="button"
                  onClick={() => { setVolumeId(v.id); setQuantity(1); }}
                  aria-pressed={v.id === volume?.id}
                  className={`border px-4 py-2 text-sm transition ${v.id === volume?.id ? "border-primary bg-primary text-primary-foreground" : "hover:border-primary/60"} ${v.stock === 0 ? "opacity-50" : ""}`}
                >
                  <span dir="ltr">{v.ml} ml</span>
                  <span className="mx-2 opacity-40">·</span>
                  <span dir="ltr">{t.price(v.price)}</span>
                </Button>
              ))}
            </div> : <p className="text-sm text-muted-foreground">{fa ? "حجم و موجودی این محصول هنوز تنظیم نشده است." : "Bottle sizes and stock have not been configured for this product."}</p>}
            {hasConfiguredVolumes && <p className={`mt-3 text-sm ${out ? "text-destructive" : "text-muted-foreground"}`} aria-live="polite">
              {out ? t.outOfStock : volume && volume.stock <= 3 ? t.lowStock(volume.stock) : t.inStock}
            </p>}
          </div>

          <div className="ss-product-page__purchase-actions mt-6 flex flex-wrap items-center gap-3">
            <div className="ss-quantity-control inline-flex items-center border border-primary/35" aria-label={fa ? "تعداد" : "Quantity"}>
              <Button variant="ghost" type="button" size="icon" className="h-11 w-10 rounded-none" aria-label={fa ? "کم کردن تعداد" : "Decrease quantity"} disabled={out || quantity <= 1} onClick={() => setQuantity(current => Math.max(1, current - 1))}>
                <Minus className="h-4 w-4" />
              </Button>
              <span className="min-w-9 text-center text-sm tabular-nums" aria-live="polite">{quantity}</span>
              <Button variant="ghost" type="button" size="icon" className="h-11 w-10 rounded-none" aria-label={fa ? "زیاد کردن تعداد" : "Increase quantity"} disabled={out || quantity >= (volume?.stock ?? 0)} onClick={() => setQuantity(current => Math.min(volume?.stock ?? 1, current + 1))}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            <Button
              className="eyebrow h-auto inline-flex items-center gap-2 px-6 py-3"
              disabled={out || quantity > (volume?.stock ?? 0)}
              onClick={() => { if (volume && quantity <= volume.stock) { addToCart(p.id, volume.id, quantity); setJustAdded(true); setTimeout(() => setJustAdded(false), 2000); } }}
            >
              <ShoppingBag className="h-4 w-4" />{justAdded ? t.added : t.addToCart}
            </Button>
            <Button
              variant="outline"
              className="eyebrow h-auto inline-flex items-center gap-2 px-6 py-3"
              aria-pressed={wished}
              onClick={() => toggleWishlist(p.id)}
            >
              <Heart className={`h-4 w-4 ${wished ? "fill-primary text-primary" : ""}`} />
              {wished ? t.removeFromWishlist : t.addToWishlist}
            </Button>
          </div>

          {desc && <div className="mt-8 space-y-4 border-y py-6 leading-8">{desc.split(/\n\s*\n/).map((x) => <p key={x}>{x}</p>)}</div>}

          {p.notes && (p.notes.top || p.notes.heart || p.notes.base) && (
            <section className={`ss-scent-anatomy mt-10 ${notesRevealed ? "is-revealed" : ""}`} aria-labelledby="fragrance-notes-heading">
              <div className="ss-scent-anatomy__intro">
                <p className="eyebrow text-primary">{fa ? "آناتومی رایحه" : "THE ANATOMY OF SCENT"}</p>
                <h2 id="fragrance-notes-heading">{fa ? "داخل این رایحه چه می‌گذرد؟" : "What lives inside this scent?"}</h2>
                <p>{fa ? "ترکیبات واقعی همین عطر را کشف کن." : "Reveal the composition behind this exact fragrance."}</p>
              </div>
              <button
                type="button"
                className="ss-scent-anatomy__trigger"
                aria-expanded={notesRevealed}
                onClick={() => setNotesRevealed((value) => !value)}
              >
                <span className="ss-scent-anatomy__bottle" aria-hidden="true">✳</span>
                <span>{notesRevealed ? (fa ? "جمع‌کردن ترکیبات" : "CLEAR THE NOTES") : (fa ? "ترکیبات را آشکار کن" : "REVEAL THE NOTES")}</span>
                <span aria-hidden="true">{notesRevealed ? "−" : "↗"}</span>
              </button>
              <div className="ss-scent-anatomy__layers">
                {[
                  { key: "top", label: fa ? "نُت‌های آغازین" : "TOP NOTES", value: p.notes.top, number: "01" },
                  { key: "heart", label: fa ? "نُت‌های میانی" : "HEART NOTES", value: p.notes.heart, number: "02" },
                  { key: "base", label: fa ? "نُت‌های پایه" : "BASE NOTES", value: p.notes.base, number: "03" },
                ].filter((note) => note.value).map((note) => (
                  <div key={note.key} className="ss-scent-anatomy__layer">
                    <span className="ss-scent-anatomy__number">{note.number}</span>
                    <div className="ss-scent-anatomy__content">
                      <p className="eyebrow">{note.label}</p>
                      <div className="ss-scent-anatomy__ingredients">
                        {note.value!.split(/[,،;؛·]+/).map((ingredient) => ingredient.trim()).filter(Boolean).map((ingredient, index) => (
                          <span key={ingredient + index} style={{ "--ingredient-index": index } as React.CSSProperties}>{ingredient}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <p className="ss-scent-anatomy__footnote">{fa ? "نمایش بر اساس اطلاعات ثبت‌شده برای همین محصول است." : "Rendered from this product’s saved fragrance notes."}</p>
            </section>
          )}
          <p className="mt-6 text-sm text-muted-foreground">{t.demoNotice}</p>
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-20 border-t border-border/70 pt-12">
          <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="eyebrow text-muted-foreground">{fa ? "ادامهٔ کشف رایحه‌ها" : "THE SCENT JOURNEY"}</p>
              <h2 className="mt-2 text-3xl md:text-4xl">{fa ? "شاید این‌ها را هم دوست داشته باشید" : "You may also like"}</h2>
            </div>
            <Link to="/shop" className="eyebrow border-b border-primary/50 pb-1 hover:border-primary">{t.continueShopping}</Link>
          </div>
          <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
            {related.map((item) => (
              <ProductCard
                key={item.id}
                p={item}
                brandName={brands.data?.find((itemBrand) => itemBrand.slug === item.brand_slug)?.name}
              />
            ))}
          </div>
        </section>
      )}
    </section>
  );
}

// Preserve the existing journal imagery and bilingual editorial content.
export const StoreJournal = JournalPage;
export const StoreArticle = ArticlePage;
