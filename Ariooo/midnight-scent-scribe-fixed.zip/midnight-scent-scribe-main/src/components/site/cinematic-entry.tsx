import { useCallback, useEffect, useRef, useState } from "react";
import "./cinematic-entry-interaction.css";

const VIDEO_SRC = "https://raw.githubusercontent.com/flowrian2026-max/Midnight-file-test/main/Entrance.mp4";
const REQUIRED_TAPS = 5;
const IDLE_END = 1.25;
const TAP_STOPS = [2.0, 2.75, 3.5, 4.4];

type EntranceMode = "loading" | "idle" | "play" | "hold" | "end" | "error";

export function CinematicEntry() {
  const rootRef = useRef<HTMLElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const snapshotRef = useRef<HTMLCanvasElement>(null);
  const modeRef = useRef<EntranceMode>("loading");
  const hitsRef = useRef(0);
  const stopAtRef = useRef(0);
  const holdFromRef = useRef(0);
  const readyRef = useRef(false);
  const [mode, setMode] = useState<EntranceMode>("loading");
  const [hits, setHits] = useState(0);
  const [shake, setShake] = useState(false);
  const [flash, setFlash] = useState(false);
  const [ctaVisible, setCtaVisible] = useState(false);
  const [veilVisible, setVeilVisible] = useState(false);
  const [visible, setVisible] = useState(true);
  const [fit, setFit] = useState(false);
  const [videoFailed, setVideoFailed] = useState(false);

  const changeMode = useCallback((next: EntranceMode) => {
    modeRef.current = next;
    setMode(next);
  }, []);

  const captureFrame = useCallback(() => {
    const video = videoRef.current;
    const canvas = snapshotRef.current;
    const context = canvas?.getContext("2d");
    if (!video || !canvas || !context || video.readyState < 2) return;
    try {
      context.drawImage(video, 0, 0, canvas.width, canvas.height);
      canvas.style.transition = "none";
      canvas.style.opacity = "1";
      requestAnimationFrame(() => requestAnimationFrame(() => {
        canvas.style.transition = "opacity .4s";
        canvas.style.opacity = "0";
      }));
    } catch {
      // The video remains fully functional if the browser blocks canvas snapshots.
    }
  }, []);

  const tapBottle = useCallback(() => {
    const video = videoRef.current;
    if (!video || !readyRef.current || modeRef.current === "end" || modeRef.current === "error" || hitsRef.current >= REQUIRED_TAPS) return;

    const nextHits = hitsRef.current + 1;
    hitsRef.current = nextHits;
    setHits(nextHits);

    setShake(false);
    requestAnimationFrame(() => setShake(true));
    setFlash(true);
    window.setTimeout(() => setFlash(false), 90);
    window.setTimeout(() => setShake(false), 320);

    if (modeRef.current === "idle") {
      captureFrame();
      video.currentTime = IDLE_END - 0.05;
    }

    video.muted = false;
    video.playbackRate = 1;
    stopAtRef.current = nextHits >= REQUIRED_TAPS ? Number.POSITIVE_INFINITY : TAP_STOPS[nextHits - 1];
    changeMode("play");
    void video.play().catch(() => {
      // Some mobile browsers require the first tap to unlock audible playback.
      video.muted = true;
      void video.play().catch(() => setVideoFailed(true));
    });
  }, [captureFrame, changeMode]);

  const enterStore = useCallback(() => {
    if (hitsRef.current < REQUIRED_TAPS || veilVisible) return;
    setVeilVisible(true);
    videoRef.current?.pause();
    window.setTimeout(() => setVisible(false), 1250);
  }, [veilVisible]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    let fallbackTimer = 0;
    let ctaTimer = 0;
    let frameId = 0;

    const startPlayback = () => {
      if (readyRef.current) return;
      readyRef.current = true;
      window.clearTimeout(fallbackTimer);
      video.pause();
      video.currentTime = 0;
      video.muted = true;
      changeMode("idle");
    };

    const onCanPlay = () => {
      if (!readyRef.current && !fallbackTimer) {
        fallbackTimer = window.setTimeout(startPlayback, 7000);
      }
    };
    const onCanPlayThrough = () => startPlayback();
    const onError = () => {
      setVideoFailed(true);
      changeMode("error");
    };
    const onEnded = () => {
      changeMode("end");
      ctaTimer = window.setTimeout(() => setCtaVisible(true), 700);
    };

    video.addEventListener("canplay", onCanPlay, { once: true });
    video.addEventListener("canplaythrough", onCanPlayThrough, { once: true });
    video.addEventListener("error", onError);
    video.addEventListener("ended", onEnded);
    video.src = VIDEO_SRC;
    video.load();

    const tick = () => {
      const currentMode = modeRef.current;
      if (currentMode === "play" && video.currentTime >= stopAtRef.current) {
        holdFromRef.current = video.currentTime;
        video.playbackRate = 0.25;
        changeMode("hold");
      } else if (currentMode === "hold" && video.currentTime >= holdFromRef.current + 0.4) {
        captureFrame();
        video.currentTime = holdFromRef.current;
        void video.play().catch(() => undefined);
      }

      if (hitsRef.current >= REQUIRED_TAPS && video.currentTime > 8.2) {
        setCtaVisible(true);
      }
      if (hitsRef.current >= REQUIRED_TAPS && video.currentTime > 9 && video.playbackRate > 0.5) {
        video.playbackRate = 0.5;
      }
      if (hitsRef.current >= REQUIRED_TAPS && video.currentTime >= 9.9) {
        captureFrame();
        video.currentTime = 8.2;
        void video.play().catch(() => undefined);
      }
      frameId = requestAnimationFrame(tick);
    };
    frameId = requestAnimationFrame(tick);

    return () => {
      window.clearTimeout(fallbackTimer);
      window.clearTimeout(ctaTimer);
      cancelAnimationFrame(frameId);
      video.pause();
      video.removeEventListener("canplay", onCanPlay);
      video.removeEventListener("canplaythrough", onCanPlayThrough);
      video.removeEventListener("error", onError);
      video.removeEventListener("ended", onEnded);
    };
  }, [captureFrame, changeMode]);

  useEffect(() => {
    const updateFit = () => setFit(window.innerWidth / Math.max(window.innerHeight, 1) < 1.2);
    updateFit();
    window.addEventListener("resize", updateFit);
    return () => window.removeEventListener("resize", updateFit);
  }, []);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.code === "Space" || event.code === "Enter") {
        if (modeRef.current === "loading" || modeRef.current === "error") return;
        event.preventDefault();
        tapBottle();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [tapBottle]);

  if (!visible) return null;

  return (
    <section
      ref={rootRef}
      className={`ss-entrance${fit ? " is-fit" : ""}`}
      aria-label="Scent Scribe interactive entrance"
      onPointerDown={(event) => {
        if ((event.target as HTMLElement).closest(".ss-entrance__cta")) return;
        tapBottle();
      }}
    >
      <div className={`ss-entrance__stage${mode === "idle" || mode === "hold" ? " is-holding" : ""}${shake ? " is-shaking" : ""}`}>
        <video
          ref={videoRef}
          className="ss-entrance__video"
          muted
          playsInline
          preload="auto"
          aria-hidden="true"
        />
        <canvas ref={snapshotRef} className="ss-entrance__snapshot" width={1280} height={720} aria-hidden="true" />
      </div>

      <div className="ss-entrance__vignette" aria-hidden="true" />
      <div className={`ss-entrance__flash${flash ? " is-on" : ""}`} aria-hidden="true" />

      <div className={`ss-entrance__hint${mode === "loading" || mode === "error" ? " is-waiting" : ""}${hits >= REQUIRED_TAPS ? " is-hidden" : ""}`}>
        <strong>TAP THE BOTTLE</strong>
        <div className="ss-entrance__dots" aria-label={`${hits} of ${REQUIRED_TAPS} taps`}>
          {Array.from({ length: REQUIRED_TAPS }, (_, index) => (
            <span key={index} className={index < hits ? "is-active" : ""} />
          ))}
        </div>
      </div>

      <button
        type="button"
        className={`ss-entrance__cta${ctaVisible ? " is-visible" : ""}`}
        onPointerDown={(event) => event.stopPropagation()}
        onClick={enterStore}
      >
        ENTER
      </button>

      <div className={`ss-entrance__loader${mode !== "loading" && mode !== "error" ? " is-hidden" : ""}${videoFailed ? " is-error" : ""}`}>
        <div>{videoFailed ? "VIDEO FAILED TO LOAD" : "LOADING"}<i /></div>
      </div>
      <div className={`ss-entrance__veil${veilVisible ? " is-visible" : ""}`} aria-hidden="true" />
    </section>
  );
}
