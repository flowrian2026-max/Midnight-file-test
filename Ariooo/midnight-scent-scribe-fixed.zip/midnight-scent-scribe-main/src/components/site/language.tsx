import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { dict, type Lang } from '@/content/i18n';
const LanguageContext = createContext<{lang: Lang; setLang: (lang: Lang) => void}>({lang: 'en', setLang: () => {}});
export function LanguageProvider({children}: {children: ReactNode}) {
  const [lang, setLang] = useState<Lang>('en');
  const [ready, setReady] = useState(false);
  useEffect(() => { const saved = localStorage.getItem('lang'); if (saved === 'fa' || saved === 'en') setLang(saved); setReady(true); }, []);
  useEffect(() => { if (!ready) return; localStorage.setItem('lang', lang); document.documentElement.lang = lang; document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr'; }, [lang, ready]);
  return <LanguageContext.Provider value={{lang, setLang}}>{children}</LanguageContext.Provider>;
}
export function useLanguage() { const value = useContext(LanguageContext); return {...value, fa: value.lang === 'fa', t: dict[value.lang]}; }
