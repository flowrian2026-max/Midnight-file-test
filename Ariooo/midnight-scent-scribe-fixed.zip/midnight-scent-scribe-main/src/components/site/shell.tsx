import { Link, useLocation, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { Menu, X, Heart, ShoppingBag, ArrowUpRight, Search, ChevronDown } from "lucide-react";
import { useCommerce } from "@/lib/commerce";
import { Button } from "@/components/ui/button";
import { useLanguage } from "./language";
import { navPaths, footerPaths } from "@/content/navigation";
import { useQuery } from "@tanstack/react-query";
import { brandsQuery, categoriesQuery } from "@/lib/catalog";

export function SiteShell({ children }: { children: ReactNode }) {
  const { fa, t, setLang } = useLanguage();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);
  const [activeMenu, setActiveMenu] = useState<"categories" | "brands" | null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [mobileAccordion, setMobileAccordion] = useState<"categories" | "brands" | null>(null);
  const lastY = useRef(0);
  const headerRef = useRef<HTMLElement>(null);
  const navigate = useNavigate();
  const categories = useQuery(categoriesQuery);
  const brands = useQuery(brandsQuery);
  const location = useLocation();
  const [introActive, setIntroActive] = useState(location.pathname === "/");
  const { count, wishlist } = useCommerce();

  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 32);
      if (y < 90) {
        setHidden(false);
      } else if (Math.abs(y - lastY.current) > 7) {
        setHidden(y > lastY.current);
      }
      lastY.current = y;
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (location.pathname !== "/") { setIntroActive(false); return; }
    setIntroActive(true);
    const frame = document.querySelector<HTMLIFrameElement>(`iframe[src="/scent-smoke/"]`);
    const onIntroComplete = (event: MessageEvent) => {
      if (event.source !== frame?.contentWindow || event.origin !== window.location.origin) return;
      if (event.data?.type === "scent-smoke:intro-complete") setIntroActive(false);
    };
    window.addEventListener("message", onIntroComplete);
    return () => window.removeEventListener("message", onIntroComplete);
  }, [location.pathname]);
  useEffect(() => {
    setOpen(false);
    setActiveMenu(null);
    setSearchOpen(false);
    setMobileAccordion(null);
  }, [location.pathname]);

  useEffect(() => {
    if (!activeMenu && !searchOpen) return;
    const onPointerDown = (event: PointerEvent) => {
      if (!headerRef.current?.contains(event.target as Node)) {
        setActiveMenu(null);
        setSearchOpen(false);
      }
    };
    document.addEventListener("pointerdown", onPointerDown);
    return () => document.removeEventListener("pointerdown", onPointerDown);
  }, [activeMenu, searchOpen]);

  useEffect(() => {
    if (!open && !activeMenu && !searchOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setOpen(false);
        setActiveMenu(null);
        setSearchOpen(false);
        setMobileAccordion(null);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open, activeMenu, searchOpen]);

  // Keep the fixed header and its open mobile navigation on screen while the menu is active.
  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previousOverflow;
    };
  }, [open]);

  const homeAtTop = location.pathname === "/" && !scrolled;

  return (
    <div dir={fa ? "rtl" : "ltr"} className={`min-h-screen ${fa ? "lang-fa" : ""}`}>
      <a href="#main-content" className="site-skip-link">
        {fa ? "رفتن به محتوای اصلی" : "Skip to main content"}
      </a>
      <header
        ref={headerRef}
        className={`site-header ${introActive ? "hidden" : ""} ${location.pathname !== "/" ? "site-header--inner-page" : ""}
          ${scrolled ? "site-header--scrolled" : ""}
          ${hidden ? "site-header--hidden" : ""}
          ${homeAtTop ? "site-header--hero" : ""} z-40`}
        style={introActive ? { display: "none" } : undefined}
      >
        <div className="site-header__inner mx-auto flex max-w-7xl items-center justify-between gap-3 px-5 py-4 md:px-6 md:py-5">
          <Link
            to="/"
            className="site-header__brand shrink-0 text-center leading-none"
            dir="ltr"
            aria-label="Scent Scribe — Home"
          >
            <span className="site-header__wordmark font-serif text-lg sm:text-2xl">SCENT SCRIBE</span>
            <span className="eyebrow mt-1 block text-[0.5rem]">{t.house}</span>
          </Link>

          <nav aria-label={fa ? "منوی اصلی" : "Main navigation"} className="site-header__links hidden items-center gap-4 lg:flex xl:gap-6">
            <Link
              to="/shop"
              activeProps={{ className: "eyebrow site-nav-link site-nav-link--active" }}
              inactiveProps={{ className: "eyebrow site-nav-link" }}
            >
              {t.nav[0]}
            </Link>

            <div className="site-nav-dropdown">
              <button
                type="button"
                className={`eyebrow site-nav-link site-nav-trigger ${activeMenu === "categories" ? "site-nav-trigger--active" : ""}`}
                aria-haspopup="true"
                aria-expanded={activeMenu === "categories"}
                aria-controls="desktop-categories-menu"
                onClick={() => {
                  setActiveMenu((value) => value === "categories" ? null : "categories");
                  setSearchOpen(false);
                }}
              >
                <span>{fa ? "دسته‌بندی‌ها" : "Categories"}</span>
                <ChevronDown className={`h-3.5 w-3.5 transition-transform ${activeMenu === "categories" ? "rotate-180" : ""}`} />
              </button>
              {activeMenu === "categories" && (
                <div id="desktop-categories-menu" className="site-mega-menu site-mega-menu--categories" role="group" aria-label={fa ? "دسته‌بندی عطرها" : "Fragrance categories"}>
                  <div className="site-mega-menu__intro">
                    <p className="eyebrow text-primary">{fa ? "پیدا کردن عطر، به روش تو" : "FIND YOUR WAY TO SCENT"}</p>
                    <p>{fa ? "می‌توانی بر اساس مخاطب عطر انتخاب کنی یا از خانوادهٔ رایحه‌ها شروع کنی." : "Shop by who it is for, or begin with the fragrance family."}</p>
                  </div>
                  <div className="site-mega-menu__items">
                    <p className="col-span-full eyebrow border-b border-foreground/10 pb-2 text-muted-foreground">{fa ? "خرید بر اساس مخاطب" : "SHOP BY WHO"}</p>
                    <Link to="/shop" search={{ gender: "women" }} className="site-mega-menu__link" onClick={() => setActiveMenu(null)}>{fa ? "عطرهای زنانه" : "For her"}</Link>
                    <Link to="/shop" search={{ gender: "men" }} className="site-mega-menu__link" onClick={() => setActiveMenu(null)}>{fa ? "عطرهای مردانه" : "For him"}</Link>
                    <Link to="/shop" search={{ gender: "unisex" }} className="site-mega-menu__link" onClick={() => setActiveMenu(null)}>{fa ? "عطرهای یونیسکس" : "Unisex"}</Link>
                    <p className="col-span-full eyebrow mt-2 border-b border-foreground/10 pb-2 text-muted-foreground">{fa ? "کشف بر اساس رایحه" : "DISCOVER BY SCENT"}</p>
                    <Link to="/scent-families" className="site-mega-menu__link site-mega-menu__link--all" onClick={() => setActiveMenu(null)}>
                      <span>{fa ? "همهٔ خانواده‌های بویایی" : "All fragrance families"}</span><ArrowUpRight className="h-4 w-4" />
                    </Link>
                    {(categories.data ?? []).map((category) => (
                      <Link key={category.slug} to="/shop" search={{ cat: category.slug }} className="site-mega-menu__link" onClick={() => setActiveMenu(null)}>
                        <span>{fa ? category.name_fa : category.name_en}</span><ArrowUpRight className="h-4 w-4" />
                      </Link>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="site-nav-dropdown">
              <button
                type="button"
                className={`eyebrow site-nav-link site-nav-trigger ${activeMenu === "brands" ? "site-nav-trigger--active" : ""}`}
                aria-haspopup="true"
                aria-expanded={activeMenu === "brands"}
                aria-controls="desktop-brands-menu"
                onClick={() => {
                  setActiveMenu((value) => value === "brands" ? null : "brands");
                  setSearchOpen(false);
                }}
              >
                <span>{fa ? "برندها" : "Brands"}</span>
                <ChevronDown className={`h-3.5 w-3.5 transition-transform ${activeMenu === "brands" ? "rotate-180" : ""}`} />
              </button>
              {activeMenu === "brands" && (
                <div id="desktop-brands-menu" className="site-mega-menu site-mega-menu--brands" role="group" aria-label={fa ? "برندهای عطر" : "Fragrance brands"}>
                  <div className="site-mega-menu__intro">
                    <p className="eyebrow text-primary">{fa ? "خانه‌های عطر" : "FRAGRANCE HOUSES"}</p>
                    <p>{fa ? "مستقیماً از میان برندهای فروشگاه انتخاب کن." : "Explore the fragrance houses in our boutique."}</p>
                  </div>
                  <div className="site-mega-menu__items site-mega-menu__items--brands">
                    {(brands.data ?? []).map((brand) => (
                      <Link key={brand.slug} to="/brand/$slug" params={{ slug: brand.slug }} className="site-mega-menu__link" onClick={() => setActiveMenu(null)}>
                        <span>{brand.name}</span><ArrowUpRight className="h-4 w-4" />
                      </Link>
                    ))}
                  </div>
                  <Link to="/shop" className="site-mega-menu__all-brands" onClick={() => setActiveMenu(null)}>{fa ? "مشاهدهٔ همهٔ عطرها" : "Browse all fragrances"} <ArrowUpRight className="h-4 w-4" /></Link>
                </div>
              )}
            </div>

            {navPaths.slice(2).map((to, offset) => {
              const i = offset + 2;
              return (
                <Link
                  key={to}
                  to={to}
                  activeProps={{ className: "eyebrow site-nav-link site-nav-link--active" }}
                  inactiveProps={{ className: "eyebrow site-nav-link" }}
                >
                  {t.nav[i]}
                </Link>
              );
            })}
          </nav>

          <div className="site-header__actions flex shrink-0 items-center gap-1 sm:gap-2">
            <Button
              type="button"
              size="icon"
              variant="ghost"
              className={`site-icon-button ${searchOpen ? "site-icon-button--active" : ""}`}
              aria-label={fa ? "باز کردن جست‌وجوی عطرها" : "Open fragrance search"}
              title={fa ? "جست‌وجو" : "Search"}
              aria-expanded={searchOpen}
              aria-controls="site-search-panel"
              onClick={() => {
                setSearchOpen((value) => !value);
                setActiveMenu(null);
                setOpen(false);
              }}
            >
              <Search className="h-4 w-4" />
            </Button>
            <Button asChild size="icon" variant="ghost" className="site-icon-button">
              <Link to="/wishlist" aria-label={`${t.wishlist} (${wishlist.length})`} title={t.wishlist}>
                <Heart className="h-4 w-4" />
              </Link>
            </Button>
            <Button asChild size="icon" variant="ghost" className="site-icon-button">
              <Link to="/cart" className="relative" aria-label={`${t.cartTitle} (${count})`} title={t.cartTitle}>
                <ShoppingBag className="h-4 w-4" />
                {count > 0 && (
                  <span className="absolute -end-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] text-primary-foreground">
                    {count}
                  </span>
                )}
              </Link>
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="site-language-button"
              onClick={() => setLang(fa ? "en" : "fa")}
              aria-label={fa ? "Switch to English" : "تغییر زبان به فارسی"}
            >
              {fa ? "EN" : "فا"}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="site-icon-button lg:hidden"
              aria-label={open ? (fa ? "بستن منو" : "Close menu") : (fa ? "باز کردن منو" : "Open menu")}
              aria-expanded={open}
              aria-controls="mobile-site-navigation"
              onClick={() => { setOpen((value) => !value); setMobileAccordion(null); setActiveMenu(null); setSearchOpen(false); }}
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        <div className="site-mobile-quick-nav lg:hidden">
          <button
            type="button"
            className={`site-mobile-quick-nav__button ${activeMenu === "categories" ? "site-mobile-quick-nav__button--active" : ""}`}
            aria-expanded={activeMenu === "categories"}
            aria-controls="mobile-quick-categories"
            onClick={() => {
              setActiveMenu((value) => value === "categories" ? null : "categories");
              setSearchOpen(false);
              setOpen(false);
            }}
          >
            <span>{fa ? "دسته‌بندی‌ها" : "Categories"}</span>
            <ChevronDown className={`h-4 w-4 transition-transform ${activeMenu === "categories" ? "rotate-180" : ""}`} />
          </button>
          <button
            type="button"
            className={`site-mobile-quick-nav__button ${searchOpen ? "site-mobile-quick-nav__button--active" : ""}`}
            aria-expanded={searchOpen}
            aria-controls="site-search-panel"
            onClick={() => {
              setSearchOpen((value) => !value);
              setActiveMenu(null);
              setOpen(false);
            }}
          >
            <Search className="h-4 w-4" />
            <span>{fa ? "جست‌وجو" : "Search"}</span>
          </button>
          {activeMenu === "categories" && (
            <div id="mobile-quick-categories" className="site-mobile-quick-menu" role="group" aria-label={fa ? "دسته‌بندی عطرها" : "Fragrance categories"}>
              <p className="eyebrow site-mobile-quick-menu__kicker">{fa ? "خرید بر اساس مخاطب" : "SHOP BY WHO"}</p>
              <div className="site-mobile-quick-menu__grid">
                <Link to="/shop" search={{ gender: "women" }} className="site-mobile-quick-menu__link" onClick={() => setActiveMenu(null)}>{fa ? "عطرهای زنانه" : "For her"}</Link>
                <Link to="/shop" search={{ gender: "men" }} className="site-mobile-quick-menu__link" onClick={() => setActiveMenu(null)}>{fa ? "عطرهای مردانه" : "For him"}</Link>
                <Link to="/shop" search={{ gender: "unisex" }} className="site-mobile-quick-menu__link" onClick={() => setActiveMenu(null)}>{fa ? "عطرهای یونیسکس" : "Unisex"}</Link>
              </div>
              <p className="eyebrow site-mobile-quick-menu__kicker mt-5">{fa ? "کشف بر اساس رایحه" : "DISCOVER BY SCENT"}</p>
              <div className="site-mobile-quick-menu__grid">
                <Link to="/scent-families" className="site-mobile-quick-menu__link site-mobile-quick-menu__link--all" onClick={() => setActiveMenu(null)}>
                  {fa ? "همهٔ خانواده‌های بویایی" : "All fragrance families"}
                  <ArrowUpRight className="h-4 w-4" />
                </Link>
                {(categories.data ?? []).map((category) => (
                  <Link key={category.slug} to="/shop" search={{ cat: category.slug }} className="site-mobile-quick-menu__link" onClick={() => setActiveMenu(null)}>
                    {fa ? category.name_fa : category.name_en}
                    <ArrowUpRight className="h-4 w-4" />
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>

        {searchOpen && (
          <form
            id="site-search-panel"
            role="search"
            className="site-search-panel"
            onSubmit={(event: FormEvent<HTMLFormElement>) => {
              event.preventDefault();
              const q = searchQuery.trim();
              setSearchOpen(false);
              setOpen(false);
              void navigate({ to: "/shop", search: q ? { q } : {} });
            }}
          >
            <label className="sr-only" htmlFor="site-header-search">{t.search}</label>
            <input
              id="site-header-search"
              type="search"
              autoFocus
              value={searchQuery}
              onChange={(event) => setSearchQuery(event.target.value)}
              placeholder={fa ? "نام عطر، برند یا رایحه..." : "Search fragrance, brand or scent..."}
            />
            <Button type="submit" className="eyebrow h-auto shrink-0 px-5 py-3">{fa ? "جست‌وجو" : "Search"}</Button>
          </form>
        )}

        {open && (
          <>
            <button
              type="button"
              className="site-mobile-backdrop lg:hidden"
              aria-label={fa ? "بستن منو" : "Close navigation"}
              onClick={() => setOpen(false)}
            />
            <nav id="mobile-site-navigation" aria-label={fa ? "منوی موبایل" : "Mobile navigation"} className="site-mobile-menu lg:hidden">
              <p className="eyebrow site-mobile-kicker">{fa ? "کشف دنیای عطر" : "Discover the world of scent"}</p>
              <Link
                to="/shop"
                onClick={() => setOpen(false)}
                activeProps={{ className: "site-mobile-link site-mobile-link--active" }}
                inactiveProps={{ className: "site-mobile-link" }}
              >
                <span>{t.nav[0]}</span>
              </Link>

              <div className="site-mobile-accordion">
                <button type="button" className="site-mobile-link" aria-expanded={mobileAccordion === "categories"} onClick={() => setMobileAccordion((value) => value === "categories" ? null : "categories")}>
                  <span>{fa ? "دسته‌بندی‌ها" : "Categories"}</span><ChevronDown className={`h-4 w-4 transition-transform ${mobileAccordion === "categories" ? "rotate-180" : ""}`} />
                </button>
                {mobileAccordion === "categories" && (
                  <div className="site-mobile-submenu">
                    <Link to="/scent-families" onClick={() => setOpen(false)}>{fa ? "همهٔ خانواده‌های بویایی" : "All fragrance families"}</Link>
                    {(categories.data ?? []).map((category) => (
                      <Link key={category.slug} to="/shop" search={{ cat: category.slug }} onClick={() => setOpen(false)}>{fa ? category.name_fa : category.name_en}</Link>
                    ))}
                    <Link to="/shop" search={{ gender: "women" }} onClick={() => setOpen(false)}>{fa ? "زنانه" : "For her"}</Link>
                    <Link to="/shop" search={{ gender: "men" }} onClick={() => setOpen(false)}>{fa ? "مردانه" : "For him"}</Link>
                    <Link to="/shop" search={{ gender: "unisex" }} onClick={() => setOpen(false)}>{fa ? "یونیسکس" : "Unisex"}</Link>
                  </div>
                )}
              </div>

              <div className="site-mobile-accordion">
                <button type="button" className="site-mobile-link" aria-expanded={mobileAccordion === "brands"} onClick={() => setMobileAccordion((value) => value === "brands" ? null : "brands")}>
                  <span>{fa ? "برندها" : "Brands"}</span><ChevronDown className={`h-4 w-4 transition-transform ${mobileAccordion === "brands" ? "rotate-180" : ""}`} />
                </button>
                {mobileAccordion === "brands" && (
                  <div className="site-mobile-submenu site-mobile-submenu--brands">
                    {(brands.data ?? []).map((brand) => (
                      <Link key={brand.slug} to="/brand/$slug" params={{ slug: brand.slug }} onClick={() => setOpen(false)}>{brand.name}</Link>
                    ))}
                  </div>
                )}
              </div>

              {navPaths.slice(2).map((to, offset) => {
                const i = offset + 2;
                return (
                  <Link
                    key={to}
                    to={to}
                    onClick={() => setOpen(false)}
                    activeProps={{ className: "site-mobile-link site-mobile-link--active" }}
                    inactiveProps={{ className: "site-mobile-link" }}
                  >
                    <span>{t.nav[i]}</span>
                  </Link>
                );
              })}
              <div className="site-mobile-footnote">{fa ? "رایحه‌ای برای به‌یادماندن" : "A fragrance to be remembered"}</div>
            </nav>
          </>
        )}
      </header>

      <main id="main-content" tabIndex={-1}>{children}</main>

      <footer className="mx-auto max-w-7xl px-5 py-14 md:px-6">
        <div className="grid grid-cols-2 gap-8 md:grid-cols-[1.2fr_1fr_1fr_1fr]">
          <Link to="/" className="col-span-2 font-serif text-2xl md:col-span-1" dir="ltr">SCENT SCRIBE</Link>
          {t.footer.map(([heading, items], group) => (
            <div key={heading}>
              <p className="mb-4 text-sm text-muted-foreground">{heading}</p>
              <ul className="space-y-3 text-sm">
                {items.map((label, i) => {
                  const to = footerPaths[group]?.[i];
                  return to ? <li key={to}><Link to={to} className="footer-link">{label}</Link></li> : null;
                })}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-8 flex flex-wrap gap-6 text-sm">
          <Link to="/admin">{fa ? "مدیریت" : "Admin"}</Link>
          <Link to="/demo-editor">{fa ? "ویرایش نمونهٔ محلی" : "Local demo editor"}</Link>
        </div>
        <div className="mt-12 flex flex-col justify-between gap-3 border-t pt-6 text-xs text-muted-foreground md:flex-row">
          <p>© {new Date().getFullYear()} {t.rights}</p>
          <p className="font-serif text-sm italic">{t.tagline}</p>
        </div>
      </footer>
    </div>
  );
}
