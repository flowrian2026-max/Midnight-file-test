import "./lib/error-capture";
import { handleD1Api } from "./lib/d1-worker-api";

import { consumeLastCapturedError } from "./lib/error-capture";
import { renderErrorPage } from "./lib/error-page";

type ServerEntry = {
  fetch: (request: Request, env?: unknown, ctx?: unknown) => Promise<Response> | Response;
};

let serverEntryPromise: Promise<ServerEntry> | undefined;

async function getServerEntry(): Promise<ServerEntry> {
  if (!serverEntryPromise) {
    serverEntryPromise = import("@tanstack/react-start/server-entry").then(
      (m) => (m.default ?? m) as ServerEntry,
    );
  }
  return serverEntryPromise;
}

/**
 * TanStack Start's server-entry fetch can be called with only the Request,
 * even when the app is running inside a Cloudflare Worker. In that case the
 * second argument is undefined; recover bindings from Cloudflare's Worker
 * runtime instead of treating the D1 binding as unconfigured.
 */
async function resolveWorkerEnv(passedEnv: unknown): Promise<unknown> {
  if (passedEnv && (typeof passedEnv === "object" || typeof passedEnv === "function")) {
    if ("DB" in (passedEnv as object)) return passedEnv;
  }

  try {
    // This built-in module is available in Cloudflare Workers. The guarded
    // dynamic import keeps local/Lovable development working without it.
    const workerRuntime = await import("cloudflare:workers");
    if (workerRuntime?.env) return workerRuntime.env;
  } catch {
    // Expected outside the Cloudflare Workers runtime.
  }

  return passedEnv;
}

// h3 swallows in-handler throws into a normal 500 Response with body
// {"unhandled":true,"message":"HTTPError"} — try/catch alone never fires for those.
async function normalizeCatastrophicSsrResponse(response: Response): Promise<Response> {
  if (response.status < 500) return response;
  const contentType = response.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return response;

  const body = await response.clone().text();
  if (!isH3SwallowedErrorBody(body)) return response;

  console.error(consumeLastCapturedError() ?? new Error(`h3 swallowed SSR error: ${body}`));
  return new Response(renderErrorPage(), {
    status: 500,
    headers: { "content-type": "text/html; charset=utf-8" },
  });
}

function isH3SwallowedErrorBody(body: string): boolean {
  try {
    const payload = JSON.parse(body) as { unhandled?: unknown; message?: unknown };
    return payload.unhandled === true && payload.message === "HTTPError";
  } catch {
    return false;
  }
}

export default {
  async fetch(request: Request, env?: unknown, ctx?: unknown) {
    const runtimeEnv = await resolveWorkerEnv(env);
    const d1Response = await handleD1Api(request, runtimeEnv);
    if (d1Response) return d1Response;
    try {
      const handler = await getServerEntry();
      const response = await handler.fetch(request, runtimeEnv, ctx);
      return await normalizeCatastrophicSsrResponse(response);
    } catch (error) {
      console.error(error);
      return new Response(renderErrorPage(), {
        status: 500,
        headers: { "content-type": "text/html; charset=utf-8" },
      });
    }
  },
};
