export type AdminScalar = string | number | boolean | null;
export type AdminValue = AdminScalar | string[];
export type AdminRecord = { id: string } & Record<string, AdminValue>;
export type AdminFieldType = "text" | "email" | "url" | "number" | "textarea" | "select" | "multiselect" | "boolean" | "volumes";

export interface AdminFieldOption { value: string; label: string; labelFa?: string }
export interface AdminFieldConfig {
  name: string;
  label: string;
  labelFa?: string;
  type: AdminFieldType;
  required?: boolean;
  placeholder?: string;
  placeholderFa?: string;
  help?: string;
  helpFa?: string;
  defaultValue?: AdminValue;
  options?: AdminFieldOption[];
}
export interface AdminResourceConfig {
  key: string;
  label: string;
  labelFa?: string;
  singular: string;
  singularFa?: string;
  description?: string;
  descriptionFa?: string;
  icon?: "package" | "tags" | "folder" | "page" | "inbox" | "building" | "calendar";
  fields: AdminFieldConfig[];
  seed?: AdminRecord[];
}
export interface AdminAdapter {
  readonly kind: string;
  list(resourceKey: string): Promise<AdminRecord[]>;
  create(resourceKey: string, values: Record<string, AdminValue>): Promise<AdminRecord>;
  update(resourceKey: string, id: string, values: Record<string, AdminValue>): Promise<AdminRecord>;
  remove(resourceKey: string, id: string): Promise<void>;
}
export type AdminLocale = "en" | "fa";
export function adminLabel(value: { label: string; labelFa?: string }, locale: AdminLocale): string {
  return locale === "fa" && value.labelFa ? value.labelFa : value.label;
}
export function emptyAdminRecord(resource: AdminResourceConfig): Record<string, AdminValue> {
  return Object.fromEntries(resource.fields.map((field) => {
    if (field.defaultValue !== undefined) return [field.name, field.defaultValue];
    if (field.type === "boolean") return [field.name, false];
    if (field.type === "number") return [field.name, 0];
    if (field.type === "multiselect") return [field.name, []];
    if (field.type === "select") return [field.name, field.options?.[0]?.value ?? ""];
    return [field.name, ""];
  }));
}
