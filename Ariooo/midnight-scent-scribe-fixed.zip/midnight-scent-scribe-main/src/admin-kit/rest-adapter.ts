import type { AdminAdapter, AdminRecord, AdminValue } from "./types";

export interface RestAdminAdapterOptions {
  baseUrl: string;
  /** Map local module keys to REST collection endpoints, for example { products: "/products" }. */
  endpoints: Record<string, string>;
  /** Optional Bearer token. Prefer a server-side proxy for production secrets. */
  token?: string;
  headers?: Record<string, string>;
  fetcher?: typeof fetch;
}

/**
 * Adapter for conventional JSON REST APIs. It assumes GET collection, POST collection,
 * PUT collection/:id and DELETE collection/:id. WooCommerce, Shopify, WordPress and
 * custom systems may need a dedicated adapter/proxy for their auth or payload rules.
 */
export class RestAdminAdapter implements AdminAdapter {
  readonly kind = "JSON REST API";
  private readonly baseUrl: string;
  private readonly endpoints: Record<string, string>;
  private readonly token?: string;
  private readonly headers: Record<string, string>;
  private readonly fetcher: typeof fetch;

  constructor(options: RestAdminAdapterOptions) {
    this.baseUrl = options.baseUrl.replace(/\/+$/, "");
    this.endpoints = options.endpoints;
    this.token = options.token;
    this.headers = options.headers ?? {};
    this.fetcher = options.fetcher ?? fetch;
  }

  private endpoint(key: string, id?: string): string {
    const part = this.endpoints[key];
    if (!part) throw new Error("No REST endpoint configured for module: " + key);
    const url = this.baseUrl + "/" + part.replace(/^\/+/, "").replace(/\/+$/, "");
    return id ? url + "/" + encodeURIComponent(id) : url;
  }

  private async request<T>(url: string, init?: RequestInit): Promise<T> {
    const headers = new Headers({
      Accept: "application/json",
      "Content-Type": "application/json",
      ...this.headers,
    });
    if (this.token) headers.set("Authorization", "Bearer " + this.token);
    if (init?.headers) new Headers(init.headers).forEach((value, key) => headers.set(key, value));

    const response = await this.fetcher(url, { ...init, headers });
    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      throw new Error(
        "API request failed (" + response.status + ")" +
        (detail ? ": " + detail.slice(0, 240) : ""),
      );
    }

    // Many APIs answer DELETE with 204, or answer 200 with an empty body.
    if (response.status === 204) return undefined as T;
    const body = await response.text();
    if (!body.trim()) return undefined as T;

    try {
      return JSON.parse(body) as T;
    } catch {
      throw new Error("The API returned a successful response that was not valid JSON.");
    }
  }

  async list(key: string): Promise<AdminRecord[]> {
    const result = await this.request<unknown>(this.endpoint(key));
    const rows = Array.isArray(result)
      ? result
      : result && typeof result === "object" && Array.isArray((result as { data?: unknown }).data)
        ? (result as { data: unknown[] }).data
        : null;
    if (!rows) throw new Error("The API must return an array or an object with a data array.");
    return rows.map((item) => {
      if (!item || typeof item !== "object" || !("id" in item)) {
        throw new Error("Every API record must include an id.");
      }
      return item as AdminRecord;
    });
  }

  async create(key: string, values: Record<string, AdminValue>): Promise<AdminRecord> {
    const row = await this.request<AdminRecord>(this.endpoint(key), {
      method: "POST",
      body: JSON.stringify(values),
    });
    if (!row || row.id === undefined) {
      throw new Error("Create response must return the saved record, including id.");
    }
    return row;
  }

  async update(key: string, id: string, values: Record<string, AdminValue>): Promise<AdminRecord> {
    const row = await this.request<AdminRecord>(this.endpoint(key, id), {
      method: "PUT",
      body: JSON.stringify(values),
    });
    return row && row.id !== undefined ? row : ({ ...values, id } as AdminRecord);
  }

  async remove(key: string, id: string): Promise<void> {
    await this.request<unknown>(this.endpoint(key, id), { method: "DELETE" });
  }
}
