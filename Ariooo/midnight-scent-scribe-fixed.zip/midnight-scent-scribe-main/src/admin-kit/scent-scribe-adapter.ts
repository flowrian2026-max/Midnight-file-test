import type { AdminAdapter, AdminRecord, AdminValue } from "./types";
import type { DemoBrand, DemoCategory, DemoProduct, DemoVolume } from "@/lib/demo-catalog";
import { loadCatalog, saveCatalog, upsertDemoBrand, upsertDemoCategory, type DemoCatalog } from "@/lib/demo-store";

const makeId = () => typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : "ss-" + Date.now().toString(36);
const strings = (value: AdminValue | undefined): string[] => Array.isArray(value) ? value : typeof value === "string" && value ? [value] : [];
const string = (value: AdminValue | undefined, fallback = ""): string => value === undefined || value === null ? fallback : String(value);
const number = (value: AdminValue | undefined, fallback = 0): number => {
  const result = Number(value);
  return Number.isFinite(result) ? result : fallback;
};
const boolean = (value: AdminValue | undefined): boolean => value === true || value === "true";

function parseVolumes(value: AdminValue | undefined, existing: DemoVolume[] = []): DemoVolume[] {
  let parsed: unknown;
  try {
    parsed = typeof value === "string" && value.trim()
      ? JSON.parse(value)
      : existing.map(({ ml, price, stock }) => ({ ml, price, stock }));
  } catch {
    throw new Error("Bottle variants are not valid. Review the size, price and stock rows.");
  }
  if (!Array.isArray(parsed) || parsed.length === 0) throw new Error("Add at least one bottle size.");
  return parsed.map((item, index) => {
    if (!item || typeof item !== "object") throw new Error("Each bottle variant needs a size, price and stock value.");
    const row = item as Record<string, unknown>;
    const ml = Number(row.ml), price = Number(row.price), stock = Number(row.stock);
    if (!Number.isInteger(ml) || ml <= 0 || !Number.isFinite(price) || price < 0 || !Number.isInteger(stock) || stock < 0) {
      throw new Error("Bottle size must be a positive whole number; price and stock must be zero or more (stock must be whole).");
    }
    return { id: existing[index]?.id ?? makeId(), ml, price, stock };
  });
}

function productRecord(product: DemoProduct): AdminRecord {
  return {
    id: product.id, name: product.name, slug: product.slug, brand_slug: product.brand_slug,
    category_ids: product.category_ids ?? [product.category_id].filter(Boolean),
    image_url: product.image_url, desc_en: product.desc_en, desc_fa: product.desc_fa,
    gender: product.gender ?? "", concentration: product.concentration ?? "",
    top_note: product.notes?.top ?? "", heart_note: product.notes?.heart ?? "", base_note: product.notes?.base ?? "",
    seasons: product.seasons ?? [], occasions: product.occasions ?? [], scent_character: product.scent_character ?? [],
    volume_variants: JSON.stringify(product.volumes.map(({ ml, price, stock }) => ({ ml, price, stock }))),
    published: product.published, is_new: product.is_new,
  };
}
function brandRecord(brand: DemoBrand): AdminRecord {
  return { id: brand.slug, slug: brand.slug, name: brand.name, blurbEn: brand.blurbEn, blurbFa: brand.blurbFa };
}
function categoryRecord(category: DemoCategory): AdminRecord {
  return { id: category.id, slug: category.slug, name_en: category.name_en, name_fa: category.name_fa, sort: category.sort };
}
function persist(catalog: DemoCatalog): void {
  if (!saveCatalog(catalog)) throw new Error("Changes are in memory but browser storage could not save them.");
}

export class ScentScribeCatalogAdapter implements AdminAdapter {
  readonly kind = "Scent Scribe local catalogue adapter";
  async list(resourceKey: string): Promise<AdminRecord[]> {
    const catalog = loadCatalog();
    if (resourceKey === "products") return catalog.products.map(productRecord);
    if (resourceKey === "brands") return catalog.brands.map(brandRecord);
    if (resourceKey === "categories") return [...catalog.categories].sort((a,b) => a.sort - b.sort).map(categoryRecord);
    throw new Error("Unknown Scent Scribe module: " + resourceKey);
  }
  async create(resourceKey: string, record: Record<string, AdminValue>): Promise<AdminRecord> {
    const catalog = loadCatalog();
    if (resourceKey === "products") {
      const id = makeId();
      const categoryIds = strings(record.category_ids);
      const selectedCategories = catalog.categories.filter((category) => categoryIds.includes(category.id));
      const product: DemoProduct = {
        id, name: string(record.name).trim(), slug: string(record.slug).trim(), brand_slug: string(record.brand_slug),
        category_id: selectedCategories[0]?.id ?? "", category_ids: selectedCategories.map((category) => category.id),
        category_slugs: selectedCategories.map((category) => category.slug), image_url: string(record.image_url, "asset:lumiere"),
        desc_en: string(record.desc_en), desc_fa: string(record.desc_fa), published: boolean(record.published),
        is_new: boolean(record.is_new), gender: (string(record.gender) || undefined) as DemoProduct["gender"],
        concentration: (string(record.concentration) || undefined) as DemoProduct["concentration"],
        notes: {
          top: string(record.top_note).trim() || undefined,
          heart: string(record.heart_note).trim() || undefined,
          base: string(record.base_note).trim() || undefined,
        },
        seasons: strings(record.seasons), occasions: strings(record.occasions), scent_character: strings(record.scent_character),
        created_at: new Date().toISOString(),
        volumes: parseVolumes(record.volume_variants),
      };
      if (!product.name || !product.slug) throw new Error("Product name and slug are required.");
      if (catalog.products.some((item) => item.slug === product.slug)) throw new Error("A product already uses this slug.");
      if (!catalog.brands.some((brand) => brand.slug === product.brand_slug)) throw new Error("Choose an existing brand.");
      if (!selectedCategories.length) throw new Error("Choose at least one category.");
      persist({ ...catalog, products: [product, ...catalog.products] }); return productRecord(product);
    }
    if (resourceKey === "brands") {
      const brand: DemoBrand = { slug: string(record.slug).trim(), name: string(record.name).trim(), blurbEn: string(record.blurbEn), blurbFa: string(record.blurbFa) };
      if (!brand.name || !brand.slug) throw new Error("Brand name and slug are required.");
      const next = upsertDemoBrand(catalog, brand, null);
      if (!next) throw new Error("This brand slug is already in use.");
      persist(next); return brandRecord(brand);
    }
    if (resourceKey === "categories") {
      const category: DemoCategory = { id: makeId(), slug: string(record.slug).trim(), name_en: string(record.name_en).trim(), name_fa: string(record.name_fa).trim(), sort: Math.max(0, Math.trunc(number(record.sort, catalog.categories.length + 1))) };
      if (!category.name_en || !category.slug || !category.name_fa) throw new Error("English name, Persian name and slug are required.");
      const next = upsertDemoCategory(catalog, category, null);
      if (!next) throw new Error("This category slug is already in use.");
      persist(next); return categoryRecord(category);
    }
    throw new Error("Unknown Scent Scribe module: " + resourceKey);
  }
  async update(resourceKey: string, id: string, record: Record<string, AdminValue>): Promise<AdminRecord> {
    const catalog = loadCatalog();
    if (resourceKey === "products") {
      const current = catalog.products.find((product) => product.id === id);
      if (!current) throw new Error("Product not found. Refresh the list.");
      const categoryIds = strings(record.category_ids);
      const selectedCategories = catalog.categories.filter((category) => categoryIds.includes(category.id));
      const volumes = parseVolumes(record.volume_variants, current.volumes);
      const product: DemoProduct = {
        ...current, name: string(record.name).trim(), slug: string(record.slug).trim(), brand_slug: string(record.brand_slug),
        category_id: selectedCategories[0]?.id ?? "", category_ids: selectedCategories.map((category) => category.id),
        category_slugs: selectedCategories.map((category) => category.slug), image_url: string(record.image_url, current.image_url),
        desc_en: string(record.desc_en), desc_fa: string(record.desc_fa), published: boolean(record.published), is_new: boolean(record.is_new),
        gender: (string(record.gender) || undefined) as DemoProduct["gender"],
        concentration: (string(record.concentration) || undefined) as DemoProduct["concentration"],
        notes: {
          top: string(record.top_note).trim() || undefined,
          heart: string(record.heart_note).trim() || undefined,
          base: string(record.base_note).trim() || undefined,
        },
        seasons: strings(record.seasons), occasions: strings(record.occasions), scent_character: strings(record.scent_character),
        volumes,
      };
      if (!product.name || !product.slug) throw new Error("Product name and slug are required.");
      if (catalog.products.some((item) => item.id !== id && item.slug === product.slug)) throw new Error("A product already uses this slug.");
      if (!catalog.brands.some((brand) => brand.slug === product.brand_slug)) throw new Error("Choose an existing brand.");
      if (!selectedCategories.length) throw new Error("Choose at least one category.");
      persist({ ...catalog, products: catalog.products.map((item) => item.id === id ? product : item) }); return productRecord(product);
    }
    if (resourceKey === "brands") {
      const old = catalog.brands.find((brand) => brand.slug === id);
      if (!old) throw new Error("Brand not found. Refresh the list.");
      const brand: DemoBrand = { slug: string(record.slug).trim(), name: string(record.name).trim(), blurbEn: string(record.blurbEn), blurbFa: string(record.blurbFa) };
      if (!brand.name || !brand.slug) throw new Error("Brand name and slug are required.");
      const next = upsertDemoBrand(catalog, brand, id);
      if (!next) throw new Error("This brand slug is already in use.");
      persist(next); return brandRecord(brand);
    }
    if (resourceKey === "categories") {
      const old = catalog.categories.find((category) => category.id === id);
      if (!old) throw new Error("Category not found. Refresh the list.");
      const category: DemoCategory = { id: old.id, slug: string(record.slug).trim(), name_en: string(record.name_en).trim(), name_fa: string(record.name_fa).trim(), sort: Math.max(0, Math.trunc(number(record.sort, old.sort))) };
      if (!category.name_en || !category.slug || !category.name_fa) throw new Error("English name, Persian name and slug are required.");
      const next = upsertDemoCategory(catalog, category, old.slug);
      if (!next) throw new Error("This category slug is already in use.");
      persist(next); return categoryRecord(category);
    }
    throw new Error("Unknown Scent Scribe module: " + resourceKey);
  }
  async remove(resourceKey: string, id: string): Promise<void> {
    const catalog = loadCatalog();
    if (resourceKey === "products") {
      persist({ ...catalog, products: catalog.products.filter((product) => product.id !== id) }); return;
    }
    if (resourceKey === "brands") {
      if (catalog.products.some((product) => product.brand_slug === id)) throw new Error("This brand is used by products. Reassign those products before deleting the brand.");
      persist({ ...catalog, brands: catalog.brands.filter((brand) => brand.slug !== id) }); return;
    }
    if (resourceKey === "categories") {
      const category = catalog.categories.find((item) => item.id === id);
      if (!category) return;
      const products = catalog.products.map((product) => {
        const ids = (product.category_ids ?? [product.category_id].filter(Boolean)).filter((categoryId) => categoryId !== id);
        const slugs = (product.category_slugs ?? []).filter((slug) => slug !== category.slug);
        return { ...product, category_ids: ids, category_id: ids[0] ?? "", category_slugs: slugs };
      });
      persist({ ...catalog, products, categories: catalog.categories.filter((item) => item.id !== id) }); return;
    }
    throw new Error("Unknown Scent Scribe module: " + resourceKey);
  }
}
