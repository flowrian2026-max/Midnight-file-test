import type { AdminResourceConfig } from "./types";
import type { DemoCatalog } from "@/lib/demo-store";

export function scentScribeResources(catalog: DemoCatalog): AdminResourceConfig[] {
  const brandOptions = catalog.brands.map((brand) => ({ value: brand.slug, label: brand.name }));
  const categoryOptions = catalog.categories.map((category) => ({ value: category.id, label: category.name_en, labelFa: category.name_fa }));
  const seasonOptions = [
    { value: "spring", label: "Spring", labelFa: "بهار" },
    { value: "summer", label: "Summer", labelFa: "تابستان" },
    { value: "autumn", label: "Autumn", labelFa: "پاییز" },
    { value: "winter", label: "Winter", labelFa: "زمستان" },
  ];
  const occasionOptions = [
    { value: "daily", label: "Everyday", labelFa: "روزمره" },
    { value: "office", label: "Office", labelFa: "محل کار" },
    { value: "formal", label: "Formal", labelFa: "رسمی" },
    { value: "evening", label: "Evening", labelFa: "شبانه" },
    { value: "date night", label: "Date night", labelFa: "قرار" },
    { value: "casual", label: "Casual", labelFa: "غیررسمی" },
  ];
  const characterOptions = [
    { value: "floral", label: "Floral", labelFa: "گلی" },
    { value: "amber", label: "Amber", labelFa: "کهربایی" },
    { value: "woody", label: "Woody", labelFa: "چوبی" },
    { value: "spicy", label: "Spicy", labelFa: "ادویه‌ای" },
    { value: "citrus", label: "Citrus", labelFa: "مرکباتی" },
    { value: "fruity", label: "Fruity", labelFa: "میوه‌ای" },
    { value: "powdery", label: "Powdery", labelFa: "پودری" },
    { value: "aromatic", label: "Aromatic", labelFa: "آروماتیک" },
    { value: "gourmand", label: "Gourmand", labelFa: "خوراکی و شیرین" },
  ];
  return [
    {
      key: "products", label: "Products", labelFa: "محصولات", singular: "Product", singularFa: "محصول", icon: "package",
      description: "Catalogue, merchandising, pricing and stock levels.", descriptionFa: "کاتالوگ، اطلاعات محصول، قیمت و موجودی.",
      fields: [
        { name: "name", label: "Product name", labelFa: "نام محصول", type: "text", required: true },
        { name: "slug", label: "URL slug", labelFa: "نامک آدرس", type: "text", required: true, help: "Use lowercase letters, numbers and hyphens." },
        { name: "brand_slug", label: "Brand", labelFa: "برند", type: "select", required: true, options: brandOptions },
        { name: "category_ids", label: "Scent categories", labelFa: "دسته‌بندی رایحه", type: "multiselect", required: true, options: categoryOptions },
        { name: "image_url", label: "Image URL / asset key", labelFa: "آدرس تصویر", type: "text", required: true, defaultValue: "asset:lumiere", help: "Use a trusted https:// URL or a built-in key such as asset:lumiere." },
        { name: "gender", label: "Audience", labelFa: "مخاطب", type: "select", options: [{value:"",label:"Not specified",labelFa:"مشخص نشده"},{value:"women",label:"Women",labelFa:"زنانه"},{value:"men",label:"Men",labelFa:"مردانه"},{value:"unisex",label:"Unisex",labelFa:"یونیسکس"}] },
        { name: "concentration", label: "Concentration", labelFa: "غلظت", type: "select", options: [{value:"",label:"Not specified",labelFa:"مشخص نشده"},{value:"parfum",label:"Parfum"},{value:"extrait",label:"Extrait de Parfum"},{value:"edp",label:"Eau de Parfum"},{value:"edt",label:"Eau de Toilette"},{value:"edc",label:"Eau de Cologne"}] },
        { name: "top_note", label: "Top note", labelFa: "نُت آغازین", type: "text", help: "The first impression, e.g. bergamot or cherry.", helpFa: "برداشت نخست، مثل ترنج یا گیلاس." },
        { name: "heart_note", label: "Heart note", labelFa: "نُت میانی", type: "text", help: "The developing character, e.g. rose or jasmine.", helpFa: "شخصیت میانی رایحه، مثل رز یا یاس." },
        { name: "base_note", label: "Base note", labelFa: "نُت پایه", type: "text", help: "The lasting foundation, e.g. cedar or musk.", helpFa: "پایهٔ ماندگار، مثل سدر یا مشک." },
        { name: "seasons", label: "Best seasons", labelFa: "فصل‌های مناسب", type: "multiselect", options: seasonOptions },
        { name: "occasions", label: "Occasions", labelFa: "موقعیت استفاده", type: "multiselect", options: occasionOptions },
        { name: "scent_character", label: "Scent character", labelFa: "شخصیت رایحه", type: "multiselect", options: characterOptions },
        { name: "volume_variants", label: "Bottle sizes, prices & stock", labelFa: "حجم بطری، قیمت و موجودی", type: "volumes", required: true, defaultValue: '[{"ml":50,"price":0,"stock":0}]', help: "Add every size and edit its own price and stock.", helpFa: "تمام حجم‌ها را اضافه کن و قیمت و موجودی هرکدام را جداگانه تنظیم کن." },
        { name: "published", label: "Visible in store", labelFa: "نمایش در فروشگاه", type: "boolean", defaultValue: false },
        { name: "is_new", label: "Mark as new arrival", labelFa: "تازه‌وارد", type: "boolean", defaultValue: false },
        { name: "desc_en", label: "Description (English)", labelFa: "توضیحات انگلیسی", type: "textarea" },
        { name: "desc_fa", label: "توضیحات فارسی", labelFa: "توضیحات فارسی", type: "textarea" },
      ],
    },
    {
      key: "brands", label: "Brands", labelFa: "برندها", singular: "Brand", singularFa: "برند", icon: "tags",
      description: "Manage multi-brand house profiles and editorial descriptions.", descriptionFa: "مدیریت برندهای مختلف و توضیحات معرفی.",
      fields: [
        { name: "name", label: "Brand name", labelFa: "نام برند", type: "text", required: true },
        { name: "slug", label: "URL slug", labelFa: "نامک آدرس", type: "text", required: true },
        { name: "blurbEn", label: "Editorial description (EN)", labelFa: "توضیحات معرفی انگلیسی", type: "textarea" },
        { name: "blurbFa", label: "توضیحات معرفی فارسی", labelFa: "توضیحات معرفی فارسی", type: "textarea" },
      ],
    },
    {
      key: "categories", label: "Categories", labelFa: "دسته‌بندی‌ها", singular: "Category", singularFa: "دسته‌بندی", icon: "folder",
      description: "Control scent families and how they are ordered in the store.", descriptionFa: "مدیریت خانواده‌های بویایی و ترتیب نمایش.",
      fields: [
        { name: "name_en", label: "Category name (EN)", labelFa: "نام دسته‌بندی انگلیسی", type: "text", required: true },
        { name: "name_fa", label: "Category name (FA)", labelFa: "نام دسته‌بندی فارسی", type: "text", required: true },
        { name: "slug", label: "URL slug", labelFa: "نامک آدرس", type: "text", required: true },
        { name: "sort", label: "Display order", labelFa: "ترتیب نمایش", type: "number", required: true, defaultValue: 1 },
      ],
    },
  ];
}
