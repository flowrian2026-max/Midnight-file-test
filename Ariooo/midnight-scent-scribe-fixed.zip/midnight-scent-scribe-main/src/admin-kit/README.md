# Studio / Control — reusable admin kit

A reusable, schema-driven management-panel core intended for the ARIXEN website studio. The shell is intentionally separate from business records; each project supplies module schemas and a data adapter.

## Core modules

- `UniversalAdminWorkbench.tsx`: responsive luxury UI, search, record list, typed forms, CRUD, delete confirmations, bilingual field labels, CSV export and dashboard metrics.
- `types.ts`: `AdminResourceConfig`, `AdminFieldConfig` and the `AdminAdapter` contract.
- `local-storage-adapter.ts`: namespaced browser persistence for demos and prototypes only.
- `rest-adapter.ts`: conventional JSON REST adapter (GET collection, POST, PUT by ID, DELETE by ID).
- `business-presets.ts`: starting schemas for commerce, real estate, salon/appointments, agency/CRM and content pages.
- `scent-scribe-adapter.ts`: maps the reusable UI to Scent Scribe's existing product, brand and category catalogue, without creating a second detached copy of the store.

## Use a different business preset

Keep the selected preset at module scope, not inside the React component, so its identity stays stable:

```tsx
import { UniversalAdminWorkbench } from "@/admin-kit/UniversalAdminWorkbench";
import { businessAdminPresets } from "@/admin-kit/business-presets";

const realEstatePreset = businessAdminPresets.find((preset) => preset.key === "real-estate")!;

export function RealEstateAdminPreview() {
  return (
    <UniversalAdminWorkbench
      title="NOIR ESTATES"
      subtitle="Property listings, enquiries and viewing requests"
      namespace="noir-estates-preview"
      resourceConfigs={realEstatePreset.resources}
    />
  );
}
```

With `resourceConfigs` and no `adapter`, the workbench creates a separate `LocalStorageAdminAdapter` namespace. That makes an isolated preview without mixing records between client projects.

## Connect to a compatible API

```tsx
import { UniversalAdminWorkbench } from "@/admin-kit/UniversalAdminWorkbench";
import { RestAdminAdapter } from "@/admin-kit/rest-adapter";
import { businessAdminPresets } from "@/admin-kit/business-presets";

const preset = businessAdminPresets.find((item) => item.key === "real-estate")!;
const apiAdapter = new RestAdminAdapter({
  baseUrl: "https://your-api.example/api",
  endpoints: { properties: "/properties", inquiries: "/inquiries" },
  // Do not expose privileged production secrets in client-side code.
});

export function AdminPage() {
  return (
    <UniversalAdminWorkbench
      title="NOIR ESTATES"
      resourceConfigs={preset.resources}
      adapter={apiAdapter}
      namespace="noir-estates"
    />
  );
}
```

The REST adapter expects GET collection to return an array or `{ data: [] }`, POST collection to create a record, PUT `/:id` to update, and DELETE `/:id` to remove. Every saved record needs an `id`.

## Important boundaries

- Browser demo storage is local to one browser profile/device. It is not a shared database, user authentication, access control, or a backup.
- The included REST adapter is a starting point, not a claim that every platform has the same API. WordPress/WooCommerce, Shopify, Supabase and custom backends may need platform-specific adapters or a server-side proxy.
- Never place private API keys or privileged service-role tokens in a client bundle. Production admin pages need verified authentication/permissions on the server, input validation, durable database writes and appropriate logging.
- The current Scent Scribe workbench uses local demo storage unless a separately configured server data path is enabled. Prices and inventory are demo values; there is no connected checkout or shared live stock.
- The product volume editor accepts multiple bottle-size rows (ml, price, stock). Product images should use an existing `asset:<key>` or a trusted HTTPS URL.

## Studio workflow

1. Choose a business preset or define a project-specific array of `AdminResourceConfig` records.
2. Choose the storage adapter: local demo storage while designing, then a suitable API/database adapter for production.
3. Add fields and modules per business type; do not force property listings, product stock and salon appointments into one universal data model.
4. Test access control and persistence independently from the visual UI before describing the panel as production-ready.
