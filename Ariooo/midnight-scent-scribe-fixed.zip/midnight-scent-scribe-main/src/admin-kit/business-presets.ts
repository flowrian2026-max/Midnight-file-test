import type { AdminResourceConfig } from "./types";

/**
 * Starter module blueprints for future ARIXEN/studio client sites.
 * They are schemas only: each project chooses an adapter and backend separately.
 */
export interface BusinessAdminPreset {
  key: "store" | "real-estate" | "salon" | "agency" | "content";
  label: string;
  labelFa: string;
  description: string;
  descriptionFa: string;
  resources: AdminResourceConfig[];
}

const propertyResources: AdminResourceConfig[] = [
  {
    key: "properties", label: "Properties", labelFa: "ملک‌ها", singular: "Property", singularFa: "ملک", icon: "building",
    description: "Manage property listings, prices, availability and key details.", descriptionFa: "مدیریت فایل‌های ملکی، قیمت و مشخصات اصلی.",
    fields: [
      { name: "title", label: "Listing title", labelFa: "عنوان ملک", type: "text", required: true },
      { name: "slug", label: "URL slug", labelFa: "نامک آدرس", type: "text", required: true },
      { name: "listing_type", label: "Listing type", labelFa: "نوع آگهی", type: "select", required: true, options: [{value:"sale",label:"For sale",labelFa:"فروش"},{value:"rent",label:"For rent",labelFa:"اجاره"},{value:"short-stay",label:"Short stay",labelFa:"اقامت کوتاه"}] },
      { name: "property_type", label: "Property type", labelFa: "نوع ملک", type: "select", options: [{value:"apartment",label:"Apartment",labelFa:"آپارتمان"},{value:"house",label:"House",labelFa:"خانه"},{value:"villa",label:"Villa",labelFa:"ویلا"},{value:"commercial",label:"Commercial",labelFa:"تجاری"},{value:"land",label:"Land",labelFa:"زمین"}] },
      { name: "price", label: "Price", labelFa: "قیمت", type: "number", required: true },
      { name: "currency", label: "Currency", labelFa: "واحد پول", type: "select", defaultValue: "EUR", options: [{value:"EUR",label:"EUR"},{value:"USD",label:"USD"},{value:"GBP",label:"GBP"}] },
      { name: "city", label: "City / district", labelFa: "شهر / محله", type: "text", required: true },
      { name: "area_sqm", label: "Area (m²)", labelFa: "متراژ (متر مربع)", type: "number" },
      { name: "bedrooms", label: "Bedrooms", labelFa: "اتاق خواب", type: "number" },
      { name: "status", label: "Availability", labelFa: "وضعیت", type: "select", options: [{value:"available",label:"Available",labelFa:"موجود"},{value:"reserved",label:"Reserved",labelFa:"رزرو شده"},{value:"sold",label:"Sold",labelFa:"فروخته شد"},{value:"rented",label:"Rented",labelFa:"اجاره رفت"}] },
      { name: "hero_image", label: "Main image URL", labelFa: "آدرس تصویر اصلی", type: "url" },
      { name: "description", label: "Description", labelFa: "توضیحات", type: "textarea" },
      { name: "featured", label: "Featured listing", labelFa: "ملک ویژه", type: "boolean" },
    ],
  },
  {
    key: "inquiries", label: "Inquiries", labelFa: "درخواست‌ها", singular: "Inquiry", singularFa: "درخواست", icon: "inbox",
    description: "Track prospective buyers, viewing requests and follow-up.", descriptionFa: "پیگیری علاقه‌مندان خرید، بازدید و تماس بعدی.",
    fields: [
      { name: "name", label: "Contact name", labelFa: "نام مخاطب", type: "text", required: true },
      { name: "email", label: "Email", labelFa: "ایمیل", type: "email" },
      { name: "phone", label: "Phone", labelFa: "تلفن", type: "text" },
      { name: "property", label: "Property reference", labelFa: "ملک موردنظر", type: "text" },
      { name: "stage", label: "Lead stage", labelFa: "مرحله پیگیری", type: "select", options: [{value:"new",label:"New",labelFa:"جدید"},{value:"contacted",label:"Contacted",labelFa:"تماس گرفته شد"},{value:"viewing",label:"Viewing",labelFa:"بازدید"},{value:"closed",label:"Closed",labelFa:"بسته شد"}] },
      { name: "notes", label: "Internal notes", labelFa: "یادداشت داخلی", type: "textarea" },
    ],
  },
];

const salonResources: AdminResourceConfig[] = [
  {
    key: "services", label: "Services", labelFa: "خدمات", singular: "Service", singularFa: "خدمت", icon: "calendar",
    description: "Manage treatments, duration, pricing and visibility.", descriptionFa: "مدیریت خدمات، مدت‌زمان، قیمت و نمایش.",
    fields: [
      { name: "name", label: "Service name", labelFa: "نام خدمت", type: "text", required: true },
      { name: "category", label: "Category", labelFa: "دسته", type: "select", options: [{value:"hair",label:"Hair",labelFa:"مو"},{value:"skin",label:"Skin",labelFa:"پوست"},{value:"nails",label:"Nails",labelFa:"ناخن"},{value:"wellness",label:"Wellness",labelFa:"سلامت و آرامش"}] },
      { name: "duration_minutes", label: "Duration (minutes)", labelFa: "مدت (دقیقه)", type: "number", required: true },
      { name: "price", label: "Price", labelFa: "قیمت", type: "number", required: true },
      { name: "description", label: "Description", labelFa: "توضیحات", type: "textarea" },
      { name: "visible", label: "Visible for booking", labelFa: "قابل رزرو", type: "boolean" },
    ],
  },
  {
    key: "bookings", label: "Bookings", labelFa: "رزروها", singular: "Booking", singularFa: "رزرو", icon: "calendar",
    description: "Review appointment requests and booking status.", descriptionFa: "بررسی درخواست‌های وقت و وضعیت رزرو.",
    fields: [
      { name: "client_name", label: "Client name", labelFa: "نام مشتری", type: "text", required: true },
      { name: "email", label: "Email", labelFa: "ایمیل", type: "email" },
      { name: "service", label: "Requested service", labelFa: "خدمت درخواستی", type: "text", required: true },
      { name: "date", label: "Date", labelFa: "تاریخ", type: "text", required: true },
      { name: "time", label: "Time", labelFa: "ساعت", type: "text" },
      { name: "status", label: "Status", labelFa: "وضعیت", type: "select", options: [{value:"new",label:"New",labelFa:"جدید"},{value:"confirmed",label:"Confirmed",labelFa:"تأیید شده"},{value:"completed",label:"Completed",labelFa:"انجام شد"},{value:"cancelled",label:"Cancelled",labelFa:"لغو شده"}] },
      { name: "notes", label: "Notes", labelFa: "یادداشت", type: "textarea" },
    ],
  },
];

const agencyResources: AdminResourceConfig[] = [
  {
    key: "leads", label: "Leads", labelFa: "سرنخ‌ها", singular: "Lead", singularFa: "سرنخ", icon: "inbox",
    description: "Keep enquiries, opportunities and follow-up in one place.", descriptionFa: "مدیریت درخواست‌ها، فرصت‌ها و پیگیری‌ها.",
    fields: [
      { name: "name", label: "Contact name", labelFa: "نام مخاطب", type: "text", required: true },
      { name: "company", label: "Company", labelFa: "شرکت", type: "text" },
      { name: "email", label: "Work email", labelFa: "ایمیل کاری", type: "email", required: true },
      { name: "service", label: "Interested service", labelFa: "خدمت موردنظر", type: "text" },
      { name: "budget", label: "Estimated budget", labelFa: "بودجه تقریبی", type: "number" },
      { name: "stage", label: "Pipeline stage", labelFa: "مرحله فروش", type: "select", options: [{value:"new",label:"New",labelFa:"جدید"},{value:"discovery",label:"Discovery",labelFa:"شناخت نیاز"},{value:"proposal",label:"Proposal",labelFa:"پیشنهاد"},{value:"won",label:"Won",labelFa:"موفق"},{value:"lost",label:"Lost",labelFa:"ناموفق"}] },
      { name: "next_action", label: "Next action", labelFa: "اقدام بعدی", type: "text" },
      { name: "notes", label: "Notes", labelFa: "یادداشت", type: "textarea" },
    ],
  },
  {
    key: "projects", label: "Projects", labelFa: "پروژه‌ها", singular: "Project", singularFa: "پروژه", icon: "page",
    description: "Track client work, milestones and delivery status.", descriptionFa: "پیگیری کار مشتریان، مراحل و وضعیت تحویل.",
    fields: [
      { name: "name", label: "Project name", labelFa: "نام پروژه", type: "text", required: true },
      { name: "client", label: "Client", labelFa: "مشتری", type: "text" },
      { name: "stage", label: "Stage", labelFa: "مرحله", type: "select", options: [{value:"planning",label:"Planning",labelFa:"برنامه‌ریزی"},{value:"design",label:"Design",labelFa:"طراحی"},{value:"build",label:"Build",labelFa:"ساخت"},{value:"review",label:"Review",labelFa:"بازبینی"},{value:"delivered",label:"Delivered",labelFa:"تحویل‌شده"}] },
      { name: "due_date", label: "Due date", labelFa: "موعد تحویل", type: "text" },
      { name: "budget", label: "Contract value", labelFa: "ارزش قرارداد", type: "number" },
      { name: "notes", label: "Project notes", labelFa: "یادداشت پروژه", type: "textarea" },
    ],
  },
];

const contentResources: AdminResourceConfig[] = [
  {
    key: "pages", label: "Pages", labelFa: "صفحه‌ها", singular: "Page", singularFa: "صفحه", icon: "page",
    description: "Manage editorial pages and publication state.", descriptionFa: "مدیریت صفحات محتوایی و وضعیت انتشار.",
    fields: [
      { name: "title", label: "Page title", labelFa: "عنوان صفحه", type: "text", required: true },
      { name: "slug", label: "URL slug", labelFa: "نامک آدرس", type: "text", required: true },
      { name: "status", label: "Publication status", labelFa: "وضعیت انتشار", type: "select", options: [{value:"draft",label:"Draft",labelFa:"پیش‌نویس"},{value:"published",label:"Published",labelFa:"منتشرشده"}] },
      { name: "summary", label: "Summary", labelFa: "خلاصه", type: "textarea" },
      { name: "body", label: "Page content", labelFa: "محتوای صفحه", type: "textarea" },
    ],
  },
];

const commerceResources: AdminResourceConfig[] = [
  {
    key: "products", label: "Products", labelFa: "محصولات", singular: "Product", singularFa: "محصول", icon: "package",
    description: "Manage product information, price, inventory and visibility.", descriptionFa: "مدیریت اطلاعات محصول، قیمت، موجودی و انتشار.",
    fields: [
      { name: "name", label: "Product name", labelFa: "نام محصول", type: "text", required: true },
      { name: "slug", label: "URL slug", labelFa: "نامک آدرس", type: "text", required: true },
      { name: "brand", label: "Brand / maker", labelFa: "برند / سازنده", type: "text" },
      { name: "category", label: "Category", labelFa: "دسته‌بندی", type: "text" },
      { name: "image_url", label: "Image URL", labelFa: "آدرس تصویر", type: "url" },
      { name: "price", label: "Price", labelFa: "قیمت", type: "number", required: true },
      { name: "stock", label: "Stock quantity", labelFa: "تعداد موجودی", type: "number", required: true },
      { name: "description", label: "Description", labelFa: "توضیحات", type: "textarea" },
      { name: "published", label: "Published", labelFa: "منتشرشده", type: "boolean" },
    ],
  },
  {
    key: "brands", label: "Brands", labelFa: "برندها", singular: "Brand", singularFa: "برند", icon: "tags",
    fields: [
      { name: "name", label: "Brand name", labelFa: "نام برند", type: "text", required: true },
      { name: "slug", label: "URL slug", labelFa: "نامک آدرس", type: "text", required: true },
      { name: "description", label: "Description", labelFa: "توضیحات", type: "textarea" },
    ],
  },
  {
    key: "categories", label: "Categories", labelFa: "دسته‌بندی‌ها", singular: "Category", singularFa: "دسته‌بندی", icon: "folder",
    fields: [
      { name: "name", label: "Category name", labelFa: "نام دسته‌بندی", type: "text", required: true },
      { name: "slug", label: "URL slug", labelFa: "نامک آدرس", type: "text", required: true },
      { name: "description", label: "Description", labelFa: "توضیحات", type: "textarea" },
      { name: "published", label: "Published", labelFa: "منتشرشده", type: "boolean" },
    ],
  },
];

export const businessAdminPresets: BusinessAdminPreset[] = [
  { key: "store", label: "Commerce", labelFa: "فروشگاه", description: "Products, brands, collections and stock.", descriptionFa: "محصولات، برندها، دسته‌ها و موجودی.", resources: commerceResources },
  { key: "real-estate", label: "Real estate", labelFa: "املاک", description: "Listings, viewing requests and enquiry tracking.", descriptionFa: "فایل‌های ملکی، درخواست بازدید و پیگیری.", resources: propertyResources },
  { key: "salon", label: "Salon & bookings", labelFa: "سالن و رزرو", description: "Services, durations, prices and appointments.", descriptionFa: "خدمات، زمان، قیمت و قرارها.", resources: salonResources },
  { key: "agency", label: "Agency / studio", labelFa: "آژانس / استودیو", description: "Leads, project tracking and delivery stages.", descriptionFa: "سرنخ‌ها، پروژه‌ها و مراحل تحویل.", resources: agencyResources },
  { key: "content", label: "Content website", labelFa: "سایت محتوایی", description: "Pages, editorial content and publication status.", descriptionFa: "صفحات، محتوا و وضعیت انتشار.", resources: contentResources },
];
