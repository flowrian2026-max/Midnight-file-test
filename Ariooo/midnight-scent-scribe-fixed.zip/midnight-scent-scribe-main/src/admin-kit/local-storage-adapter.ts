import type { AdminAdapter, AdminRecord, AdminResourceConfig, AdminValue } from "./types";

type StoreShape = Record<string, AdminRecord[]>;
const clone = <T,>(value: T): T => JSON.parse(JSON.stringify(value)) as T;
const makeId = () => typeof crypto !== "undefined" && "randomUUID" in crypto
  ? crypto.randomUUID()
  : "local-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 9);

/** Demo adapter only: data stays in one browser/profile and is not secure or shared. */
export class LocalStorageAdminAdapter implements AdminAdapter {
  readonly kind = "Browser demo storage";
  private readonly storageKey: string;
  private readonly definitions: Map<string, AdminResourceConfig>;

  constructor(namespace: string, resources: AdminResourceConfig[]) {
    this.storageKey = "studio-admin-kit:v1:" + namespace;
    this.definitions = new Map(resources.map((resource) => [resource.key, resource]));
  }
  private seed(): StoreShape {
    return Object.fromEntries(Array.from(this.definitions, ([key, resource]) => [key, clone(resource.seed ?? [])]));
  }
  private read(): StoreShape {
    const fresh = this.seed();
    if (typeof window === "undefined") return fresh;
    try {
      const raw = window.localStorage.getItem(this.storageKey);
      if (!raw) return fresh;
      const parsed: unknown = JSON.parse(raw);
      if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return fresh;
      const result = parsed as Record<string, unknown>;
      for (const [key, resource] of this.definitions) if (!Array.isArray(result[key])) result[key] = clone(resource.seed ?? []);
      return result as StoreShape;
    } catch { return fresh; }
  }
  private write(data: StoreShape): void {
    if (typeof window === "undefined") throw new Error("Browser storage is not available.");
    try {
      window.localStorage.setItem(this.storageKey, JSON.stringify(data));
      window.dispatchEvent(new CustomEvent("studio-admin-kit:changed", { detail: { namespace: this.storageKey } }));
    } catch { throw new Error("The demo could not be saved. Check browser storage settings."); }
  }
  private ensure(key: string): void { if (!this.definitions.has(key)) throw new Error("Unknown admin module: " + key); }
  async list(key: string): Promise<AdminRecord[]> {
    this.ensure(key); return clone(this.read()[key] ?? []);
  }
  async create(key: string, values: Record<string, AdminValue>): Promise<AdminRecord> {
    this.ensure(key);
    const data = this.read();
    const row = { ...values, id: makeId() } as AdminRecord;
    data[key] = [...(data[key] ?? []), row];
    this.write(data); return clone(row);
  }
  async update(key: string, id: string, values: Record<string, AdminValue>): Promise<AdminRecord> {
    this.ensure(key);
    const data = this.read(); const rows = data[key] ?? [];
    if (!rows.some((row) => row.id === id)) throw new Error("This record no longer exists. Refresh and try again.");
    const updated = { ...values, id } as AdminRecord;
    data[key] = rows.map((row) => row.id === id ? updated : row);
    this.write(data); return clone(updated);
  }
  async remove(key: string, id: string): Promise<void> {
    this.ensure(key); const data = this.read(); data[key] = (data[key] ?? []).filter((row) => row.id !== id); this.write(data);
  }
}
