import { useEffect, useMemo, useRef, useState, type ChangeEvent } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Activity, ArrowDownToLine, ArrowLeft, ArrowUpRight, Boxes, Check, ChevronDown, CircleHelp,
  Command, FolderKanban, Gauge, Layers3, Menu, Package, Pencil, Plus, RefreshCw,
  Search, ShieldCheck, Tags, Trash2, Upload, Download, X, type LucideIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/components/site/language";
import { loadCatalog, saveCatalog, type DemoCatalog } from "@/lib/demo-store";
import { parseCatalogBackup, serializeCatalogBackup } from "@/lib/catalog-backup";
import { ScentScribeCatalogAdapter } from "./scent-scribe-adapter";
import { LocalStorageAdminAdapter } from "./local-storage-adapter";
import { scentScribeResources } from "./scent-scribe-resources";
import { businessAdminPresets } from "./business-presets";
import { adminLabel, emptyAdminRecord, type AdminAdapter, type AdminFieldConfig, type AdminRecord, type AdminResourceConfig, type AdminValue } from "./types";

const icons: Record<string, LucideIcon> = {
  products: Package, brands: Tags, categories: Layers3, package: Package, tags: Tags,
  folder: Layers3, page: FolderKanban, inbox: Activity, building: Boxes, calendar: Activity,
};
const shell = "border border-[#c8b99f]/15 bg-[#19151c]";
const control = "w-full min-w-0 border border-[#c8b99f]/20 bg-[#100f0e] px-3 py-3 text-sm text-[#f2ede4] outline-none transition placeholder:text-[#83786d] focus:border-[#c8b99f]/65 focus:ring-1 focus:ring-[#c8b99f]/15";
const fieldLabel = "mb-2 block text-[11px] uppercase tracking-[.15em] text-[#b5a998]";

function recordValues(row: AdminRecord, resource: AdminResourceConfig): Record<string, AdminValue> {
  return Object.fromEntries(resource.fields.map((field) => [field.name, row[field.name] ?? (field.type === "multiselect" ? [] : field.type === "boolean" ? false : "")]));
}
function makeSlug(value: string): string {
  return value.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
function displayValue(value: AdminValue | undefined): string {
  if (Array.isArray(value)) return value.length ? value.join(", ") : "—";
  if (typeof value === "boolean") return value ? "Yes" : "No";
  if (value === null || value === undefined || value === "") return "—";
  return String(value);
}
type BottleVariantDraft = { ml: number; price: number; stock: number };
function parseBottleVariants(value: AdminValue | undefined): BottleVariantDraft[] {
  try {
    const parsed = typeof value === "string" && value.trim() ? JSON.parse(value) as unknown : [];
    if (!Array.isArray(parsed)) return [];
    return parsed.map((item) => ({
      ml: Math.max(1, Number((item as Record<string, unknown>).ml) || 1),
      price: Math.max(0, Number((item as Record<string, unknown>).price) || 0),
      stock: Math.max(0, Math.trunc(Number((item as Record<string, unknown>).stock) || 0)),
    }));
  } catch { return []; }
}

export interface UniversalAdminWorkbenchProps {
  onExit?: () => void;
  title?: string;
  subtitle?: string;
  resourceConfigs?: AdminResourceConfig[];
  adapter?: AdminAdapter;
  namespace?: string;
  /** Keeps the studio template gallery independent from the Scent Scribe catalogue. */
  studioMode?: boolean;
}

/**
 * Reusable, schema-driven admin workspace.
 * Pass new resourceConfigs for a business-specific module set and an AdminAdapter
 * to bind it to local demo storage or an API. Define resourceConfigs outside the
 * rendering component so its identity remains stable.
 */
export function UniversalAdminWorkbench({
  onExit, title = "Scent Scribe", subtitle, resourceConfigs, adapter: suppliedAdapter, namespace = "client-site", studioMode = false,
}: UniversalAdminWorkbenchProps) {
  const { fa } = useLanguage();
  const queryClient = useQueryClient();
  const [previewPreset, setPreviewPreset] = useState<string | null>(null);
  const selectedPreviewPreset = businessAdminPresets.find((preset) => preset.key === previewPreset);
  const showTemplateGallery = studioMode && !resourceConfigs && !suppliedAdapter;
  const defaultAdapter = useMemo(
    () => selectedPreviewPreset
      ? new LocalStorageAdminAdapter(namespace + "-template-" + selectedPreviewPreset.key, selectedPreviewPreset.resources)
      : resourceConfigs ? new LocalStorageAdminAdapter(namespace, resourceConfigs)
      : studioMode ? new LocalStorageAdminAdapter(namespace + "-template-gallery", [])
      : new ScentScribeCatalogAdapter(),
    [resourceConfigs, namespace, selectedPreviewPreset, studioMode],
  );
  const adapter = previewPreset ? defaultAdapter : suppliedAdapter ?? defaultAdapter;
  const isLocalAdapter = adapter.kind.toLowerCase().includes("local") || adapter.kind.toLowerCase().includes("storage");
  const isScentScribe = !studioMode && !previewPreset && !resourceConfigs && !suppliedAdapter;
  const workspaceTitle = selectedPreviewPreset?.label ?? title;
  const [catalog, setCatalog] = useState<DemoCatalog>(() => loadCatalog());
  const [genericCounts, setGenericCounts] = useState<Record<string, number>>({});
  const [activeModule, setActiveModule] = useState<string>("overview");
  const [rows, setRows] = useState<AdminRecord[]>([]);
  const [query, setQuery] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<Record<string, AdminValue>>({});
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [mobileNav, setMobileNav] = useState(false);
  const backupInputRef = useRef<HTMLInputElement>(null);

  const generatedResources = useMemo(() => scentScribeResources(catalog), [catalog]);
  const resources = selectedPreviewPreset?.resources ?? resourceConfigs ?? (studioMode ? [] : generatedResources);
  const resource = resources.find((item) => item.key === activeModule);
  const pageTitle = activeModule === "overview"
    ? (fa ? "مرکز فرماندهی" : "Control room")
    : resource ? adminLabel({ label: resource.label, labelFa: resource.labelFa }, fa ? "fa" : "en") : "";
  const visibleRows = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase();
    if (!needle || !resource) return rows;
    return rows.filter((row) => resource.fields.some((field) => displayValue(row[field.name]).toLocaleLowerCase().includes(needle)));
  }, [query, resource, rows]);

  async function reload(moduleKey = activeModule) {
    if (isScentScribe) setCatalog(loadCatalog());
    setBusy(true);
    try {
      if (moduleKey === "overview") {
        const pairs = await Promise.all(resources.map(async (item) => [item.key, (await adapter.list(item.key)).length] as const));
        setGenericCounts(Object.fromEntries(pairs)); setRows([]);
      } else setRows(await adapter.list(moduleKey));
    } catch (error) { setNotice(error instanceof Error ? error.message : "Could not load the module."); }
    finally { setBusy(false); }
  }

  useEffect(() => {
    let current = true;
    if (isScentScribe) setCatalog(loadCatalog());
    const loadOverviewCounts = () => {
      Promise.all(resources.map(async (item) => {
        try { return [item.key, (await adapter.list(item.key)).length] as const; }
        catch { return [item.key, 0] as const; }
      })).then((pairs) => { if (current) setGenericCounts(Object.fromEntries(pairs)); });
    };
    if (activeModule === "overview") {
      setRows([]);
      loadOverviewCounts();
    } else {
      setBusy(true);
      adapter.list(activeModule).then((records) => { if (current) setRows(records); })
        .catch((error: unknown) => { if (current) setNotice(error instanceof Error ? error.message : "Could not load module."); })
        .finally(() => { if (current) setBusy(false); });
    }
    const changed = () => {
      if (!current) return;
      if (activeModule === "overview") loadOverviewCounts();
      else adapter.list(activeModule).then((records) => { if (current) setRows(records); }).catch(() => {});
      if (isScentScribe) setCatalog(loadCatalog());
    };
    window.addEventListener("ss:catalog", changed);
    window.addEventListener("studio-admin-kit:changed", changed);
    return () => {
      current = false;
      window.removeEventListener("ss:catalog", changed);
      window.removeEventListener("studio-admin-kit:changed", changed);
    };
  }, [activeModule, adapter, isScentScribe, resources]);

  function chooseModule(key: string) {
    setActiveModule(key); setEditingId(null); setForm({}); setQuery(""); setNotice(""); setMobileNav(false);
  }
  function openPreset(key: string) {
    setPreviewPreset(key);
    setActiveModule("overview");
    setEditingId(null); setForm({}); setQuery(""); setNotice(""); setMobileNav(false);
  }
  function returnToOriginalWorkspace() {
    setPreviewPreset(null);
    setActiveModule("overview");
    setEditingId(null); setForm({}); setQuery(""); setNotice(""); setMobileNav(false);
  }
  function startCreate() {
    if (!resource) return;
    const next = emptyAdminRecord(resource);
    if (isScentScribe && activeModule === "products") {
      next.slug = ""; next.name = "";
      next.brand_slug = catalog.brands[0]?.slug ?? "";
      next.category_ids = catalog.categories[0] ? [catalog.categories[0].id] : [];
      next.image_url = "asset:lumiere"; next.volume_variants = JSON.stringify([{ ml: 50, price: 0, stock: 0 }]);
    }
    setEditingId(null); setForm(next); setNotice("");
  }
  function startEdit(row: AdminRecord) {
    if (!resource) return;
    setEditingId(row.id); setForm(recordValues(row, resource)); setNotice("");
  }
  function changeField(field: AdminFieldConfig, value: AdminValue) {
    setForm((previous) => {
      const next = { ...previous, [field.name]: value };
      if (["name", "name_en", "title", "listing_title"].includes(field.name)) next.slug = makeSlug(String(value));
      return next;
    });
  }
  async function saveRecord() {
    if (!resource) return;
    const missing = resource.fields.find((field) => field.required && (
      form[field.name] === undefined || form[field.name] === null || form[field.name] === "" ||
      (Array.isArray(form[field.name]) && (form[field.name] as string[]).length === 0)
    ));
    if (missing) { setNotice((fa ? "این فیلد الزامی است: " : "Required field: ") + adminLabel({label: missing.label, labelFa: missing.labelFa}, fa ? "fa" : "en")); return; }
    if (resource.fields.some((field) => field.name === "slug")) {
      const slug = String(form.slug ?? "").trim();
      if (!/^[a-z0-9]+(-[a-z0-9]+)*$/.test(slug)) {
        setNotice(fa ? "نامک باید فقط شامل حروف کوچک انگلیسی، عدد و خط تیره باشد." : "Use a URL slug with lowercase letters, numbers and hyphens only.");
        return;
      }
      if (rows.some((row) => row.id !== editingId && String(row.slug ?? "") === slug)) {
        setNotice(fa ? "این نامک قبلاً استفاده شده است." : "That URL slug is already in use.");
        return;
      }
    }
    setBusy(true); setNotice("");
    try {
      if (editingId) await adapter.update(resource.key, editingId, form);
      else await adapter.create(resource.key, form);
      setCatalog(loadCatalog());
      setRows(await adapter.list(resource.key));
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["products"] }),
        queryClient.invalidateQueries({ queryKey: ["brands"] }),
        queryClient.invalidateQueries({ queryKey: ["categories"] }),
      ]);
      setEditingId(null); setForm({});
      setNotice(fa ? "تغییرات ذخیره شد." : "Changes saved.");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : (fa ? "ذخیره انجام نشد." : "Save failed."));
    } finally { setBusy(false); }
  }
  async function deleteRecord() {
    if (!resource || !editingId) return;
    const title = String(form.name ?? form.name_en ?? form.slug ?? "");
    if (!window.confirm(fa ? "«" + title + "» حذف شود؟ این کار قابل بازگشت نیست." : "Delete “" + title + "”? This cannot be undone.")) return;
    setBusy(true); setNotice("");
    try {
      await adapter.remove(resource.key, editingId);
      setCatalog(loadCatalog()); setRows(await adapter.list(resource.key)); setEditingId(null); setForm({});
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["products"] }),
        queryClient.invalidateQueries({ queryKey: ["brands"] }),
        queryClient.invalidateQueries({ queryKey: ["categories"] }),
      ]);
      setNotice(fa ? "مورد حذف شد." : "Record deleted.");
    } catch (error) { setNotice(error instanceof Error ? error.message : (fa ? "حذف انجام نشد." : "Delete failed.")); }
    finally { setBusy(false); }
  }
  async function exportCurrent() {
    let data: Array<Record<string, unknown>>;
    if (resource) data = rows;
    else if (isScentScribe) data = catalog.products.map((product) => ({
      id: product.id, name: product.name, slug: product.slug, brand_slug: product.brand_slug,
      published: product.published, price: product.volumes[0]?.price ?? 0, stock: product.volumes.reduce((sum, volume) => sum + volume.stock, 0),
    }));
    else data = (await Promise.all(resources.map(async (item) => (await adapter.list(item.key)).map((row) => ({ module: item.key, ...row }))))).flat();
    const keys = data.length ? Array.from(new Set(data.flatMap((row) => Object.keys(row)))) : ["id"];
    const csvCell = (value: unknown) => '"' + String(Array.isArray(value) ? value.join("; ") : value ?? "").replace(/"/g, '""') + '"';
    const csv = [keys.map(csvCell).join(","), ...data.map((row) => keys.map((key) => csvCell(row[key])).join(","))].join("\r\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob); const link = document.createElement("a");
    link.href = url; link.download = workspaceTitle.toLowerCase().replace(/[^a-z0-9]+/g, "-") + "-" + activeModule + ".csv"; link.click(); URL.revokeObjectURL(url);
  }

  function exportCatalogBackup() {
    if (!isScentScribe) return;
    const payload = serializeCatalogBackup(loadCatalog());
    const blob = new Blob([payload], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "scent-scribe-catalog-" + new Date().toISOString().slice(0, 10) + ".json";
    link.click();
    URL.revokeObjectURL(url);
    setNotice(fa ? "نسخهٔ پشتیبان JSON دانلود شد." : "JSON catalogue backup downloaded.");
  }

  async function importCatalogBackup(event: ChangeEvent<HTMLInputElement>) {
    const file = event.currentTarget.files?.[0];
    event.currentTarget.value = "";
    if (!file || !isScentScribe) return;
    if (file.size > 5 * 1024 * 1024) {
      setNotice(fa ? "حجم فایل پشتیبان باید کمتر از ۵ مگابایت باشد." : "Backup files must be smaller than 5 MB.");
      return;
    }

    setBusy(true);
    try {
      const next = parseCatalogBackup(JSON.parse(await file.text()) as unknown);
      const confirmed = window.confirm(fa
        ? "این فایل، کاتالوگ فعلی را با برندها، دسته‌ها و محصولات داخل نسخهٔ پشتیبان جایگزین می‌کند. ادامه می‌دهی؟"
        : "This will replace the current local catalogue with the brands, categories and products in this backup. Continue?");
      if (!confirmed) return;
      if (!saveCatalog(next)) {
        throw new Error(fa ? "مرورگر نتوانست فایل را ذخیره کند؛ فضای ذخیره‌سازی را بررسی کن." : "Browser storage could not persist the backup. Check available storage.");
      }
      setCatalog(loadCatalog());
      setEditingId(null);
      setForm({});
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ["products"] }),
        queryClient.invalidateQueries({ queryKey: ["brands"] }),
        queryClient.invalidateQueries({ queryKey: ["categories"] }),
      ]);
      if (activeModule !== "overview") setRows(await adapter.list(activeModule));
      setNotice(fa ? "کاتالوگ از نسخهٔ پشتیبان بازیابی شد." : "Catalogue backup restored successfully.");
    } catch (error) {
      setNotice(error instanceof Error ? error.message : (fa ? "بازیابی نسخهٔ پشتیبان انجام نشد." : "Could not restore the catalogue backup."));
    } finally {
      setBusy(false);
    }
  }

  const totalStock = catalog.products.reduce((sum, product) => sum + product.volumes.reduce((stock, volume) => stock + volume.stock, 0), 0);
  const published = catalog.products.filter((product) => product.published).length;
  const totalGenericRecords = Object.values(genericCounts).reduce((sum, count) => sum + count, 0);
  const nav = [
    { key: "overview", title: fa ? "نمای کلی" : "Overview", icon: Gauge },
    ...resources.map((item) => ({
      key: item.key,
      title: adminLabel({ label: item.label, labelFa: item.labelFa }, fa ? "fa" : "en"),
      icon: icons[item.icon ?? item.key] ?? FolderKanban,
      count: isScentScribe
        ? item.key === "products" ? catalog.products.length : item.key === "brands" ? catalog.brands.length : item.key === "categories" ? catalog.categories.length : 0
        : genericCounts[item.key] ?? 0,
    })),
  ];
  const dashboardMetrics = isScentScribe ? [
    { label: fa ? "کل محصولات" : "Total products", value: catalog.products.length, detail: fa ? "در کاتالوگ فعلی" : "In current catalogue", icon: Package },
    { label: fa ? "منتشرشده" : "Published", value: published, detail: fa ? "قابل نمایش در فروشگاه" : "Visible on the storefront", icon: Check },
    { label: fa ? "واحدهای موجود" : "Units in stock", value: totalStock, detail: fa ? "جمع موجودی نمایشی" : "Demo stock total", icon: Boxes },
    { label: fa ? "برند و دسته" : "Brands & categories", value: catalog.brands.length + catalog.categories.length, detail: catalog.brands.length + " brands · " + catalog.categories.length + " categories", icon: Layers3 },
  ] : [
    { label: fa ? "ماژول‌های فعال" : "Configured modules", value: resources.length, detail: fa ? "طبق الگوی این کسب‌وکار" : "Defined by this business preset", icon: Layers3 },
    { label: fa ? "کل رکوردها" : "Total records", value: totalGenericRecords, detail: fa ? "در فضای کاری فعلی" : "Across configured modules", icon: Boxes },
    { label: fa ? "ماژول‌های دارای داده" : "Modules with data", value: Object.values(genericCounts).filter((count) => count > 0).length, detail: fa ? "شامل رکوردهای ذخیره‌شده" : "Modules containing saved records", icon: Package },
    { label: fa ? "روش اتصال" : "Data adapter", value: 1, detail: adapter.kind, icon: Activity },
  ];
  const createTitle = resource ? (fa ? "ایجاد " + (resource.singularFa ?? resource.labelFa ?? resource.label) : "New " + resource.singular) : "";

  return <div dir={fa ? "rtl" : "ltr"} className="min-h-screen bg-[#11100f] text-[#f2ede4]">
    <div className="flex min-h-screen">
      <aside className={`fixed inset-y-0 z-40 w-[278px] border-r border-[#c8b99f]/15 bg-[#130f16] px-5 py-6 transition-transform lg:sticky lg:top-0 lg:flex lg:h-screen lg:translate-x-0 lg:flex-col ${mobileNav ? "translate-x-0" : fa ? "translate-x-full lg:translate-x-0" : "-translate-x-full"}`}>
        <div className="flex items-center justify-between gap-3 px-2">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center border border-[#c8b99f]/45 bg-[#c8b99f]/[.07] text-[#c8b99f]"><Command size={20} strokeWidth={1.3}/></div>
            <div><p className="font-serif text-xl tracking-[.08em]">STUDIO /</p><p className="mt-0.5 text-[9px] tracking-[.32em] text-[#c8b99f]">CONTROL</p></div>
          </div>
          <button className="p-2 text-[#a7a095] lg:hidden" onClick={() => setMobileNav(false)} aria-label="Close menu"><X size={18}/></button>
        </div>
        <div className="mx-2 mb-6 mt-8 border-t border-[#c8b99f]/15 pt-5">
          <p className="text-[10px] uppercase tracking-[.2em] text-[#857d72]">{fa ? "فضای کاری" : "WORKSPACE"}</p>
          <p className="mt-2 text-sm text-[#e8dfd0]">{workspaceTitle + (fa ? " / مدیریت" : " / Operations")}</p>
        </div>
        <nav className="space-y-1">
          {nav.map(({ key, title: navTitle, icon: Icon, count }) => <button key={key} onClick={() => chooseModule(key)} className={`group flex w-full items-center gap-3 border px-3 py-3 text-start transition ${activeModule === key ? "border-[#9a788e]/40 bg-[#49235f]/30 text-[#f2ede4]" : "border-transparent text-[#989187] hover:border-[#9a788e]/20 hover:bg-[#49235f]/[.12] hover:text-[#f2ede4]"}`}>
            <Icon size={17} strokeWidth={1.5} className={activeModule === key ? "text-[#c8b99f]" : "text-[#857d72]"}/><span className="flex-1 text-[13px]">{navTitle}</span>{count !== undefined && <span className="text-[10px] tabular-nums text-[#80776c]">{count}</span>}{activeModule === key && <span className="h-1.5 w-1.5 bg-[#c8b99f]"/>}
          </button>)}
        </nav>
        <div className="mt-8 border-t border-[#c8b99f]/15 pt-5">
          <p className="px-2 text-[10px] uppercase tracking-[.2em] text-[#857d72]">{fa ? "قابلیت توسعه" : "EXTENDABLE MODULES"}</p>
          <div className="mt-3 space-y-1 text-[12px] text-[#777067]">
            <div className="flex items-center gap-3 px-2 py-2"><FolderKanban size={15}/><span>{fa ? "صفحه‌ها و محتوا" : "Pages & content"}</span><span className="ms-auto text-[9px]">{fa ? "الگو" : "TEMPLATE"}</span></div>
            <div className="flex items-center gap-3 px-2 py-2"><Boxes size={15}/><span>{fa ? "سفارش‌ها / رزروها" : "Orders / bookings"}</span><span className="ms-auto text-[9px]">{fa ? "الگو" : "TEMPLATE"}</span></div>
            <div className="flex items-center gap-3 px-2 py-2"><Settings2 size={15}/><span>{fa ? "اتصالات و تنظیمات" : "Integrations"}</span><span className="ms-auto text-[9px]">{fa ? "آماده اتصال" : "ADAPTER"}</span></div>
          </div>
        </div>
        <div className="mt-auto border-t border-[#c8b99f]/15 pt-5">
          <div className="flex items-start gap-3 px-2"><ShieldCheck size={17} className="mt-0.5 shrink-0 text-[#c8b99f]"/><div><p className="text-xs text-[#d7cbbb]">{isLocalAdapter ? (fa ? "حالت نمایشی محلی" : "Local demo mode") : (fa ? "آداپتر دادهٔ اختصاصی" : "Custom data adapter")}</p><p className="mt-1 text-[11px] leading-5 text-[#81796e]">{isLocalAdapter ? (fa ? "بدون سرور مشترک یا دادهٔ مشتری" : "No shared server or customer data") : adapter.kind}</p></div></div>
        </div>
      </aside>
      {mobileNav && <button aria-label="Close navigation" onClick={() => setMobileNav(false)} className="fixed inset-0 z-30 bg-black/70 lg:hidden"/>}
      <main className="min-w-0 flex-1">
        <header className="sticky top-0 z-20 border-b border-[#c8b99f]/15 bg-[#11100f]/90 px-4 py-4 backdrop-blur-xl sm:px-7 lg:px-10">
          <div className="mx-auto flex max-w-[1500px] flex-wrap items-center justify-between gap-3">
            <div className="flex min-w-0 items-center gap-3">
              <button className="border border-[#c8b99f]/20 p-2 text-[#c8b99f] lg:hidden" aria-label="Open navigation" onClick={() => setMobileNav(true)}><Menu size={17}/></button>
              <div className="min-w-0"><p className="hidden text-[9px] uppercase tracking-[.24em] text-[#8d8375] sm:block">{workspaceTitle.toUpperCase()} / OPERATIONS</p><h1 className="truncate font-serif text-2xl sm:mt-1 sm:text-[30px]">{pageTitle}</h1></div>
            </div>
            <div className="flex shrink-0 items-center gap-2 sm:gap-3">
              <span className="flex items-center gap-2 border border-[#c8b99f]/20 px-2 py-2 text-[9px] tracking-[.1em] text-[#c8b99f] sm:px-3 sm:text-[10px]"><span className="h-1.5 w-1.5 rounded-full bg-[#c8b99f]"/>{isLocalAdapter ? (fa ? "محلی · دمو" : "LOCAL · DEMO") : (fa ? "آداپتر اختصاصی" : "CUSTOM ADAPTER")}</span>
              {selectedPreviewPreset && <button onClick={returnToOriginalWorkspace} className="flex items-center gap-1 text-[10px] text-[#c8b99f] transition hover:text-[#f2ede4] sm:gap-2 sm:text-[11px]"><ArrowLeft size={13}/>{fa ? "بازگشت به اصل" : "Back to site"}</button>}
              {onExit && !selectedPreviewPreset && <button onClick={onExit} className="flex items-center gap-1 text-[10px] text-[#a7a095] transition hover:text-[#f2ede4] sm:gap-2 sm:text-[11px]"><ArrowLeft size={13}/>{fa ? "ویرایشگر قبلی" : "Classic"}</button>}
            </div>
          </div>
        </header>
        <div className="mx-auto max-w-[1500px] px-4 py-7 sm:px-7 sm:py-9 lg:px-10 lg:py-10">
          <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
            <div><p className="mb-2 text-[10px] uppercase tracking-[.24em] text-[#c8b99f]">{activeModule === "overview" ? (fa ? "بررسی کلی · داشبورد" : "OVERVIEW / DASHBOARD") : (fa ? "ماژول مدیریت" : "MANAGEMENT MODULE")}</p><p className="max-w-2xl text-[13px] leading-6 text-[#9b9388]">{activeModule === "overview" ? (fa ? "محصولات، برندها و موجودی را از یک میز کار منظم مدیریت کن؛ ساختار پنل برای افزودن ماژول‌های سایت‌های دیگر طراحی شده است." : "A considered workspace for catalogue and stock, built around reusable modules for future sites.") : resource ? adminLabel({label: resource.description ?? resource.label, labelFa: resource.descriptionFa ?? resource.labelFa}, fa ? "fa" : "en") : ""}</p></div>
            <div className="flex flex-wrap gap-2">
              {isScentScribe && <input ref={backupInputRef} type="file" accept="application/json,.json" aria-label={fa ? "انتخاب فایل نسخهٔ پشتیبان" : "Select catalogue backup file"} className="sr-only" onChange={(event) => void importCatalogBackup(event)}/>}
              <Button variant="outline" onClick={() => void reload()} disabled={busy} className="h-10 rounded-none border-[#c8b99f]/25 bg-transparent text-[#d8cdbb] hover:bg-[#c8b99f]/[.07] hover:text-[#f2ede4]"><RefreshCw size={14} className={busy ? "me-2 animate-spin" : "me-2"}/>{fa ? "تازه‌سازی" : "Refresh"}</Button>
              {isScentScribe && <Button variant="outline" onClick={exportCatalogBackup} className="h-10 rounded-none border-[#c8b99f]/25 bg-transparent text-[#d8cdbb] hover:bg-[#c8b99f]/[.07] hover:text-[#f2ede4]"><Download size={14} className="me-2"/>{fa ? "پشتیبان JSON" : "Backup JSON"}</Button>}
              {isScentScribe && <Button variant="outline" disabled={busy} onClick={() => backupInputRef.current?.click()} className="h-10 rounded-none border-[#c8b99f]/25 bg-transparent text-[#d8cdbb] hover:bg-[#c8b99f]/[.07] hover:text-[#f2ede4]"><Upload size={14} className="me-2"/>{fa ? "بازیابی JSON" : "Restore JSON"}</Button>}
              <Button variant="outline" onClick={exportCurrent} disabled={busy} className="h-10 rounded-none border-[#c8b99f]/25 bg-transparent text-[#d8cdbb] hover:bg-[#c8b99f]/[.07] hover:text-[#f2ede4]"><ArrowDownToLine size={14} className="me-2"/>{fa ? "خروجی CSV" : "Export CSV"}</Button>
            </div>
          </div>

          {notice && <div role="status" className="mb-6 flex items-start gap-3 border border-[#c8b99f]/25 bg-[#c8b99f]/[.06] px-4 py-3 text-sm text-[#e2d5c1]"><Activity size={16} className="mt-0.5 shrink-0 text-[#c8b99f]"/><span className="flex-1">{notice}</span><button onClick={() => setNotice("")} aria-label="Dismiss notice"><X size={14}/></button></div>}

          {activeModule === "overview" ? <div className="space-y-8">
            <section className="relative overflow-hidden border border-[#c8b99f]/20 bg-[radial-gradient(ellipse_at_80%_0%,rgba(73,35,95,.42),transparent_40%),radial-gradient(ellipse_at_8%_100%,rgba(154,120,142,.10),transparent_45%),linear-gradient(120deg,#211b23,#141210_65%)] p-6 sm:p-9 lg:p-11">
              <div className="pointer-events-none absolute -right-20 -top-24 h-72 w-72 rounded-full border border-[#c8b99f]/10"/><div className="pointer-events-none absolute -right-10 -top-14 h-52 w-52 rounded-full border border-[#c8b99f]/10"/>
              <div className="relative max-w-2xl"><p className="text-[10px] uppercase tracking-[.28em] text-[#c8b99f]">{fa ? "فضای کار اختصاصی" : "YOUR PRIVATE WORKSPACE"}</p><h2 className="mt-4 max-w-xl font-serif text-4xl leading-[1.08] sm:text-5xl">{fa ? "هر جزئیات، در جای درست خود." : "Every detail. In its place."}</h2><p className="mt-4 max-w-lg text-sm leading-7 text-[#b6ada0]">{fa ? "از کاتالوگ تا موجودی، یک تجربهٔ مدیریتی آرام و دقیق؛ با امکان تبدیل به پنل اختصاصی کسب‌وکارهای دیگر." : "A calm, precise operating space for catalogue and inventory — designed to evolve into a tailored workspace for other businesses."}</p><button onClick={() => chooseModule(isScentScribe ? "products" : (resources[0]?.key ?? "overview"))} className="mt-7 inline-flex items-center gap-3 border border-[#c8b99f]/55 px-5 py-3 text-[11px] uppercase tracking-[.14em] text-[#efe3d0] transition hover:bg-[#c8b99f]/10">{fa ? (isScentScribe ? "مدیریت محصولات" : "باز کردن اولین ماژول") : (isScentScribe ? "Manage products" : "Open first module")}<ArrowUpRight size={15}/></button></div>
              <div className="absolute bottom-8 end-9 hidden font-serif text-[100px] leading-none text-[#c8b99f]/[.07] xl:block">S.</div>
            </section>
            <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              {dashboardMetrics.map(({label,value,detail,icon:Icon},i)=><article key={label} className={`${shell} p-5 sm:p-6`}><div className="flex items-center justify-between"><p className="text-[11px] text-[#a69d91]">{label}</p><Icon size={17} className="text-[#c8b99f]"/></div><p className="mt-5 font-serif text-4xl tabular-nums">{value.toLocaleString()}</p><p className="mt-2 min-h-4 text-[10px] tracking-wide text-[#80796f]">{detail}</p><div className="mt-5 h-px bg-[#c8b99f]/15"><div className="h-px w-1/3 bg-[#c8b99f]/65" style={{opacity: .95 - i * .12}}/></div></article>)}
            </section>
            <section><div className="mb-4 flex items-end justify-between gap-3"><div><p className="text-[10px] uppercase tracking-[.22em] text-[#c8b99f]">{fa ? "دسترسی سریع" : "QUICK ACCESS"}</p><h3 className="mt-2 font-serif text-2xl">{fa ? "ماژول‌های عملیاتی" : "Operational modules"}</h3></div><p className="hidden text-[11px] text-[#80796f] sm:block">{fa ? "برای باز کردن انتخاب کن" : "Select a module to open"}</p></div><div className="grid gap-3 md:grid-cols-3">
              {resources.map((item,index)=>{const Icon=icons[item.icon ?? item.key] ?? FolderKanban;const count=isScentScribe?(item.key==="products"?catalog.products.length:item.key==="brands"?catalog.brands.length:item.key==="categories"?catalog.categories.length:0):(genericCounts[item.key]??0);return <button key={item.key} onClick={()=>chooseModule(item.key)} className="group border border-[#c8b99f]/15 bg-[#19151c] p-5 text-start transition duration-300 hover:-translate-y-0.5 hover:border-[#9a788e]/45 hover:bg-[#211825] sm:p-6"><div className="flex items-start justify-between"><span className="flex h-10 w-10 items-center justify-center border border-[#c8b99f]/25 text-[#c8b99f]"><Icon size={18}/></span><span className="font-serif text-3xl text-[#d8cbb6]">{String(index+1).padStart(2,"0")}</span></div><div className="mt-7 flex items-end justify-between gap-3"><div><h4 className="text-sm tracking-wide">{adminLabel({label:item.label,labelFa:item.labelFa},fa?"fa":"en")}</h4><p className="mt-2 text-[11px] text-[#81796e]">{count} {fa?"مورد":"records"}</p></div><ArrowUpRight size={17} className="text-[#c8b99f] transition-transform group-hover:-translate-y-1 group-hover:translate-x-1"/></div></button>})}
            </div></section>
            {showTemplateGallery && <section>
              <div className="mb-4 flex flex-wrap items-end justify-between gap-3"><div><p className="text-[10px] uppercase tracking-[.22em] text-[#c8b99f]">{fa?"کتابخانه الگوهای استودیو":"STUDIO TEMPLATE LIBRARY"}</p><h3 className="mt-2 font-serif text-2xl">{fa?"یک هسته برای چند صنعت":"One admin core. Multiple industries."}</h3><p className="mt-2 max-w-2xl text-[12px] leading-6 text-[#8e8579]">{fa?"هر الگو فضای آزمایشی جدا دارد؛ می‌توانی فرم‌ها و ساختار دادهٔ هر نوع کسب‌وکار را پیش از اتصال به سرور امتحان کنی.":"Each blueprint opens an isolated demo workspace so its forms and data model can be reviewed before connecting a real backend."}</p></div><span className="border border-[#c8b99f]/20 px-3 py-2 text-[9px] uppercase tracking-[.18em] text-[#b9aa94]">5 BLUEPRINTS</span></div>
              <div className="grid gap-3 sm:grid-cols-2 2xl:grid-cols-5">
                {businessAdminPresets.map((preset,index)=>{const Icon=preset.key==="real-estate"?Boxes:preset.key==="salon"?Activity:preset.key==="agency"?FolderKanban:preset.key==="content"?Layers3:Package;return <button key={preset.key} onClick={()=>openPreset(preset.key)} className="group flex min-h-[196px] flex-col border border-[#c8b99f]/15 bg-[#19151c] p-4 text-start transition duration-300 hover:-translate-y-0.5 hover:border-[#9a788e]/45 hover:bg-[#211825] sm:p-5"><div className="flex items-start justify-between"><span className="flex h-9 w-9 items-center justify-center border border-[#c8b99f]/25 text-[#c8b99f]"><Icon size={17}/></span><span className="font-serif text-2xl text-[#c8b99f]/65">{String(index+1).padStart(2,"0")}</span></div><h4 className="mt-5 text-[13px] text-[#e9e0d4]">{fa?preset.labelFa:preset.label}</h4><p className="mt-2 flex-1 text-[10px] leading-5 text-[#898074]">{fa?preset.descriptionFa:preset.description}</p><div className="mt-4 flex items-center justify-between border-t border-[#c8b99f]/10 pt-3 text-[9px] uppercase tracking-[.1em] text-[#a79a87]"><span>{preset.resources.length} {fa?"ماژول":"modules"}</span><ArrowUpRight size={13} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5"/></div></button>})}
              </div>
            </section>}
            <section className="grid gap-4 xl:grid-cols-[1.1fr_.9fr]">
              <div className={shell + " p-5 sm:p-7"}><p className="text-[10px] uppercase tracking-[.2em] text-[#c8b99f]">{fa?"چیدمان پنل":"PANEL ARCHITECTURE"}</p><h3 className="mt-3 font-serif text-2xl">{fa?"یک هسته، چند نوع کسب‌وکار":"One core. Different businesses."}</h3><p className="mt-3 max-w-xl text-[13px] leading-6 text-[#9d9589]">{fa?"ماژول‌ها با تعریف فیلدها و آداپتر داده ساخته می‌شوند؛ بنابراین می‌توان برای املاک، رزرو سالن، آژانس، محصولات یا محتوای سایت فرم و جدول متناسب تعریف کرد." : "Modules are driven by field definitions and data adapters, so a property listing, salon booking, agency lead or product catalogue can use the same core with a different resource schema."}</p><div className="mt-5 flex flex-wrap gap-2">{["Field-driven forms","CRUD adapter","JSON REST","Browser demo"].map(tag=><span key={tag} className="border border-[#c8b99f]/20 px-3 py-2 text-[10px] tracking-wide text-[#c9bdab]">{tag}</span>)}</div></div>
              <div className={shell + " p-5 sm:p-7"}><div className="flex items-center gap-3"><ShieldCheck size={19} className="text-[#c8b99f]"/><h3 className="font-serif text-2xl">{fa?"وضعیت اتصال":"Connection status"}</h3></div><p className="mt-3 text-[13px] leading-6 text-[#9d9589]">{fa?"در این نمونه، داده‌ها با آداپتر انتخاب‌شده ذخیره می‌شوند. برای اتصال به سرور، تنظیمات مخصوص همان پروژه لازم است." : (subtitle ?? "This workspace uses the configured data adapter. Compatible REST APIs can plug in; other systems may need a dedicated connector.")}</p><div className="mt-5 flex items-center gap-3 border-t border-[#c8b99f]/15 pt-4"><span className="h-2 w-2 rounded-full bg-[#c8b99f]"/><div><p className="text-xs text-[#e2d7c6]">{fa?"آداپتر محلی فعال":"Local catalogue adapter active"}</p><p className="mt-1 text-[10px] text-[#80796f]">{fa?"بدون همگام‌سازی سرور":"No server synchronisation"}</p></div></div></div>
            </section>
          </div> : resource ? <div className="grid gap-5 xl:grid-cols-[minmax(300px,.85fr)_minmax(0,1.15fr)]">
            <section className={shell + " min-w-0"}>
              <div className="border-b border-[#c8b99f]/15 p-4 sm:p-5"><div className="flex items-center justify-between gap-3"><div><p className="text-[10px] uppercase tracking-[.18em] text-[#8b8276]">{fa?"کتابخانه":"LIBRARY"}</p><h2 className="mt-1 font-serif text-2xl">{pageTitle}</h2></div><span className="font-serif text-2xl text-[#c8b99f]">{rows.length.toString().padStart(2,"0")}</span></div><div className="mt-4 flex gap-2"><div className="relative min-w-0 flex-1"><Search size={15} className="absolute start-3 top-1/2 -translate-y-1/2 text-[#7f776b]"/><input className={control + " ps-9"} value={query} onChange={(event)=>setQuery(event.target.value)} placeholder={fa?"جست‌وجو در این ماژول...":"Search this module…"} /></div><Button aria-label="Create record" onClick={startCreate} className="h-11 w-11 shrink-0 rounded-none bg-[#c8b99f] p-0 text-[#11100f] hover:bg-[#e0d1b9]"><Plus size={17}/></Button></div></div>
              <div className="max-h-[72vh] overflow-y-auto">
                {busy && !rows.length ? <div className="p-8 text-sm text-[#91877b]">{fa?"در حال بارگذاری...":"Loading records…"}</div> : visibleRows.length ? visibleRows.map((row,index)=>{const title = String(row.name ?? row.name_en ?? row.slug ?? "Untitled");const subtitle = String(row.slug ?? row.brand_slug ?? "");const isPublished = row.published === true;const selected = editingId === row.id;return <button key={row.id} onClick={()=>startEdit(row)} className={`flex w-full items-center gap-3 border-b border-[#c8b99f]/10 px-4 py-4 text-start transition hover:bg-white/[.025] sm:px-5 ${selected?"bg-[#c8b99f]/[.07]":""}`}><span className={`flex h-9 w-9 shrink-0 items-center justify-center border text-[10px] ${selected?"border-[#c8b99f]/55 bg-[#c8b99f]/10 text-[#d9c7ac]":"border-[#c8b99f]/15 text-[#837a6e]"}`}>{String(index+1).padStart(2,"0")}</span><span className="min-w-0 flex-1"><span className="block truncate text-[13px] text-[#e8e0d4]">{title}</span><span className="mt-1 block truncate text-[10px] text-[#80786d]">{subtitle || (fa?"بدون نامک":"No slug")}</span></span>{row.published !== undefined && <span className={`shrink-0 border px-2 py-1 text-[9px] uppercase tracking-wide ${isPublished?"border-[#c8b99f]/30 text-[#c8b99f]":"border-white/10 text-[#81786d]"}`}>{isPublished?(fa?"منتشر":"Live"):(fa?"پیش‌نویس":"Draft")}</span>}<ChevronDown size={14} className={`shrink-0 -rotate-90 text-[#736b60] ${selected?"text-[#c8b99f]":""}`}/></button>}) : <div className="p-8 text-center"><Package size={24} className="mx-auto text-[#847b6e]"/><p className="mt-3 text-sm text-[#b5aa9b]">{fa?"موردی پیدا نشد":"No records found"}</p><p className="mt-1 text-[11px] text-[#736b60]">{fa?"جست‌وجو را تغییر بده یا مورد جدید بساز":"Change your search or create a new record."}</p><button onClick={startCreate} className="mt-4 text-[11px] text-[#c8b99f] underline underline-offset-4">{fa?"ایجاد مورد جدید":"Create a record"}</button></div>}
              </div>
              <div className="flex items-center justify-between border-t border-[#c8b99f]/15 px-4 py-3 text-[10px] text-[#80776c] sm:px-5"><span>{visibleRows.length} / {rows.length} {fa?"مورد":"records"}</span><span>{fa?"ذخیره محلی":"Local storage"}</span></div>
            </section>
            <section className={shell + " min-w-0"}>
              {resource && (Object.keys(form).length > 0 || editingId) ? <div>
                <div className="flex items-start justify-between gap-4 border-b border-[#c8b99f]/15 p-5 sm:p-7"><div><p className="text-[10px] uppercase tracking-[.18em] text-[#c8b99f]">{editingId?(fa?"ویرایش رکورد":"EDIT RECORD"):(fa?"رکورد جدید":"NEW RECORD")}</p><h2 className="mt-2 font-serif text-3xl">{editingId?String(form.name??form.name_en??form.slug??(fa?"ویرایش":"Edit")):createTitle}</h2><p className="mt-2 text-[11px] text-[#8d8477]">{fa?"فیلدهای الزامی با ساختار این ماژول مشخص شده‌اند.":"Fields and validation follow this module's schema."}</p></div><button aria-label="Close editor" onClick={()=>{setEditingId(null);setForm({});setNotice("");}} className="border border-[#c8b99f]/20 p-2 text-[#a7a095] transition hover:text-[#f2ede4]"><X size={16}/></button></div>
                <div className="grid gap-x-5 gap-y-5 p-5 sm:grid-cols-2 sm:p-7">
                  {resource.fields.map((field)=>{const full=field.type==="textarea"||field.type==="multiselect"||field.type==="volumes";return <div key={field.name} className={full?"sm:col-span-2":""}>
                    {field.type==="boolean" ? <label className="flex cursor-pointer items-center justify-between border border-[#c8b99f]/15 bg-[#11100f]/60 p-4"><span><span className="block text-[12px] text-[#e6ddcf]">{adminLabel({label:field.label,labelFa:field.labelFa},fa?"fa":"en")}</span>{(field.help||field.helpFa)&&<span className="mt-1 block text-[10px] leading-5 text-[#847b70]">{fa?field.helpFa??field.help:field.help}</span>}</span><input type="checkbox" checked={form[field.name]===true} onChange={(event)=>changeField(field,event.target.checked)} className="h-4 w-4 accent-[#c8b99f]"/></label>
                    : <><label className={fieldLabel}>{adminLabel({label:field.label,labelFa:field.labelFa},fa?"fa":"en")}{field.required&&<span className="ms-1 text-[#c8b99f]">*</span>}</label>
                    {field.type==="volumes" ? <div className="space-y-3">
                      {parseBottleVariants(form[field.name]).map((variant,index)=><div key={index} className="border border-[#c8b99f]/15 bg-[#11100f]/60 p-3 sm:p-4"><div className="mb-3 flex items-center justify-between"><span className="text-[10px] uppercase tracking-[.18em] text-[#c8b99f]">{fa?"حجم بطری":"BOTTLE SIZE"} · {String(index+1).padStart(2,"0")}</span><button type="button" aria-label={fa?"حذف حجم":"Remove bottle size"} disabled={parseBottleVariants(form[field.name]).length<=1} onClick={()=>{const current=parseBottleVariants(form[field.name]);changeField(field,JSON.stringify(current.filter((_,i)=>i!==index)));}} className="p-1 text-[#9a8d7c] transition hover:text-[#d9a59b] disabled:opacity-30"><Trash2 size={14}/></button></div><div className="grid grid-cols-3 gap-2"><label className="text-[10px] text-[#9e9487]">ML<input type="number" min="1" step="1" className={control+" mt-2 px-2"} value={variant.ml} onChange={(event)=>{const current=parseBottleVariants(form[field.name]);current[index]={...current[index],ml:Math.max(1,Number(event.target.value)||1)};changeField(field,JSON.stringify(current));}}/></label><label className="text-[10px] text-[#9e9487]">{fa?"قیمت":"PRICE"}<input type="number" min="0" step="0.01" className={control+" mt-2 px-2"} value={variant.price} onChange={(event)=>{const current=parseBottleVariants(form[field.name]);current[index]={...current[index],price:Math.max(0,Number(event.target.value)||0)};changeField(field,JSON.stringify(current));}}/></label><label className="text-[10px] text-[#9e9487]">{fa?"موجودی":"STOCK"}<input type="number" min="0" step="1" className={control+" mt-2 px-2"} value={variant.stock} onChange={(event)=>{const current=parseBottleVariants(form[field.name]);current[index]={...current[index],stock:Math.max(0,Math.trunc(Number(event.target.value)||0))};changeField(field,JSON.stringify(current));}}/></label></div></div>)}
                      <button type="button" onClick={()=>{const current=parseBottleVariants(form[field.name]);changeField(field,JSON.stringify([...current,{ml:100,price:0,stock:0}]));}} className="inline-flex items-center gap-2 border border-[#c8b99f]/35 px-3 py-2.5 text-[11px] text-[#d5c6b0] transition hover:bg-[#c8b99f]/[.07]"><Plus size={14}/>{fa?"افزودن حجم بطری":"Add bottle size"}</button>
                    </div>
                    : field.type==="textarea" ? <textarea rows={4} className={control+" resize-y leading-6"} value={String(form[field.name]??"")} required={field.required} placeholder={fa?field.placeholderFa??"":field.placeholder??""} onChange={(event)=>changeField(field,event.target.value)}/>
                    : field.type==="select" ? <div className="relative"><select className={control+" appearance-none pe-9"} value={String(form[field.name]??"")} required={field.required} onChange={(event)=>changeField(field,event.target.value)}>{!field.required&&<option value="">{fa?"انتخاب نشده":"Not specified"}</option>}{field.options?.map((option)=><option key={option.value} value={option.value}>{fa?option.labelFa??option.label:option.label}</option>)}</select><ChevronDown size={14} className="pointer-events-none absolute end-3 top-1/2 -translate-y-1/2 text-[#8d8376]"/></div>
                    : field.type==="multiselect" ? <div className="grid gap-2 border border-[#c8b99f]/15 bg-[#11100f]/55 p-3 sm:grid-cols-2">{field.options?.map((option)=>{const selected=(Array.isArray(form[field.name])?form[field.name] as string[]:[]).includes(option.value);return <label key={option.value} className={`flex cursor-pointer items-center gap-2 border p-3 text-[11px] transition ${selected?"border-[#c8b99f]/45 bg-[#c8b99f]/[.06] text-[#eee1cf]":"border-white/5 text-[#a59a8b] hover:border-[#c8b99f]/20"}`}><input type="checkbox" className="accent-[#c8b99f]" checked={selected} onChange={(event)=>{const current=Array.isArray(form[field.name])?form[field.name] as string[]:[];changeField(field,event.target.checked?[...current,option.value]:current.filter((v)=>v!==option.value));}}/>{fa?option.labelFa??option.label:option.label}</label>})}</div>
                    : <input type={field.type==="number"?"number":field.type==="email"?"email":field.type==="url"?"url":"text"} className={control} value={String(form[field.name]??"")} required={field.required} min={field.type==="number"?0:undefined} placeholder={fa?field.placeholderFa??"":field.placeholder??""} onChange={(event)=>changeField(field,field.type==="number"?(event.target.value===""?"":Number(event.target.value)):event.target.value)}/>}
                    {(field.help||field.helpFa)&&<p className="mt-2 text-[10px] leading-5 text-[#847b70]">{fa?field.helpFa??field.help:field.help}</p>}</>}
                  </div>})}
                </div>
                <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#c8b99f]/15 p-5 sm:px-7"><div>{editingId&&<Button variant="ghost" disabled={busy} onClick={()=>void deleteRecord()} className="rounded-none text-[#bd8e83] hover:bg-[#8b3f32]/10 hover:text-[#e3a99c]"><Trash2 size={14} className="me-2"/>{fa?"حذف":"Delete"}</Button>}</div><div className="flex gap-2"><Button variant="outline" disabled={busy} onClick={()=>{setEditingId(null);setForm({});}} className="rounded-none border-[#c8b99f]/25 bg-transparent text-[#c8b99f] hover:bg-[#c8b99f]/[.07]">{fa?"انصراف":"Cancel"}</Button><Button disabled={busy} onClick={()=>void saveRecord()} className="rounded-none bg-[#c8b99f] px-5 text-[#171411] hover:bg-[#e0d1b9]"><Check size={14} className="me-2"/>{busy?(fa?"در حال ذخیره...":"Saving…"):(fa?"ذخیرهٔ تغییرات":"Save changes")}</Button></div></div>
              </div> : <div className="flex min-h-[420px] flex-col items-center justify-center px-7 py-14 text-center"><div className="flex h-14 w-14 items-center justify-center border border-[#c8b99f]/25 text-[#c8b99f]"><Pencil size={19}/></div><h3 className="mt-5 font-serif text-2xl">{fa?"آمادهٔ ویرایش":"Ready when you are"}</h3><p className="mt-2 max-w-xs text-[12px] leading-6 text-[#8e8579]">{fa?"از فهرست سمت چپ یک مورد را انتخاب کن یا یک رکورد تازه بساز.":"Select a record from the library or create a new one to start editing."}</p><button onClick={startCreate} className="mt-5 inline-flex items-center gap-2 border border-[#c8b99f]/40 px-4 py-2.5 text-[11px] tracking-wide text-[#e0d3bf] transition hover:bg-[#c8b99f]/[.06]"><Plus size={14}/>{fa?"ایجاد مورد جدید":"Create new record"}</button></div>}
            </section>
          </div> : null}
          <footer className="mt-10 flex flex-col justify-between gap-3 border-t border-[#c8b99f]/15 pt-5 text-[10px] text-[#776f64] sm:flex-row sm:items-center"><span>STUDIO / CONTROL · MODULE-BASED ADMIN KIT</span><span className="inline-flex items-center gap-2"><CircleHelp size={12}/>{fa?"این پیش‌نمایش محلی است؛ اتصال سرور جداگانه پیکربندی می‌شود.":"Local preview only · production adapter configured separately."}</span></footer>
        </div>
      </main>
    </div>
  </div>;
}
