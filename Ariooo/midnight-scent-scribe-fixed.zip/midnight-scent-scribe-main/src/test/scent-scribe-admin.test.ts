import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { ScentScribeCatalogAdapter } from "@/admin-kit/scent-scribe-adapter";
import { loadCatalog, resetCatalog } from "@/lib/demo-store";

describe("Scent Scribe product editor metadata", () => {
  beforeEach(() => resetCatalog());
  afterEach(() => resetCatalog());

  it("loads and saves the note pyramid, seasons, occasions and scent character", async () => {
    const adapter = new ScentScribeCatalogAdapter();
    const catalog = loadCatalog();
    const current = catalog.products.find((product) => product.slug === "oud-wood");
    if (!current) throw new Error("Oud Wood fixture is missing");

    const record = (await adapter.list("products")).find((item) => item.id === current.id);
    expect(record?.top_note).toBe(current.notes?.top ?? "");
    expect(record?.seasons).toEqual(current.seasons ?? []);

    await adapter.update("products", current.id, {
      ...(record ?? {}),
      top_note: "saffron",
      heart_note: "iris",
      base_note: "amber",
      seasons: ["winter"],
      occasions: ["formal", "evening"],
      scent_character: ["amber", "woody"],
    });

    const updated = loadCatalog().products.find((product) => product.id === current.id);
    expect(updated?.notes?.top).toBe("saffron");
    expect(updated?.notes?.heart).toBe("iris");
    expect(updated?.notes?.base).toBe("amber");
    expect(updated?.seasons).toEqual(["winter"]);
    expect(updated?.occasions).toEqual(["formal", "evening"]);
    expect(updated?.scent_character).toEqual(["amber", "woody"]);
  });

  it("creates new fragrances with full merchandising metadata", async () => {
    const catalog = loadCatalog();
    const adapter = new ScentScribeCatalogAdapter();
    const brand = catalog.brands[0];
    const category = catalog.categories[0];
    if (!brand || !category) throw new Error("Demo brand/category fixtures are missing");

    await adapter.create("products", {
      name: "Test Fragrance",
      slug: "test-fragrance",
      brand_slug: brand.slug,
      category_ids: [category.id],
      image_url: "asset:lumiere",
      desc_en: "A test fragrance.",
      desc_fa: "یک عطر آزمایشی.",
      gender: "unisex",
      concentration: "edp",
      top_note: "bergamot",
      heart_note: "jasmine",
      base_note: "musk",
      seasons: ["spring"],
      occasions: ["daily"],
      scent_character: ["floral", "citrus"],
      volume_variants: JSON.stringify([{ ml: 50, price: 10, stock: 3 }]),
      published: true,
      is_new: true,
    });

    const created = loadCatalog().products.find((product) => product.slug === "test-fragrance");
    expect(created?.notes?.top).toBe("bergamot");
    expect(created?.notes?.heart).toBe("jasmine");
    expect(created?.notes?.base).toBe("musk");
    expect(created?.seasons).toEqual(["spring"]);
    expect(created?.occasions).toEqual(["daily"]);
    expect(created?.scent_character).toEqual(["floral", "citrus"]);
  });
});
