import { describe, expect, it } from "vitest";
import { demoProducts } from "@/lib/demo-catalog";
import { recommendCartProducts } from "@/lib/cart-recommendations";

describe("cart fragrance recommendations", () => {
  it("excludes products already in the cart and unpublished products", () => {
    const cartProduct = demoProducts.find((product) => product.slug === "oud-wood");
    const unpublished = demoProducts.find((product) => product.published);
    if (!cartProduct || !unpublished) throw new Error("Demo catalogue fixture is missing");
    const result = recommendCartProducts([
      { ...unpublished, id: "hidden-product", slug: "hidden-product", published: false },
      ...demoProducts,
    ], [cartProduct]);
    expect(result.some((product) => product.id === cartProduct.id)).toBe(false);
    expect(result.some((product) => product.id === "hidden-product")).toBe(false);
    expect(result).toHaveLength(4);
  });

  it("prioritizes same-brand fragrances when items are in the cart", () => {
    const cartProduct = demoProducts.find((product) => product.slug === "oud-wood");
    if (!cartProduct) throw new Error("Oud Wood fixture is missing");
    const result = recommendCartProducts(demoProducts, [cartProduct]);
    expect(result[0]?.brand_slug).toBe(cartProduct.brand_slug);
    expect(result.some((product) => product.id === cartProduct.id)).toBe(false);
  });

  it("uses newest fragrances as a sensible fallback when the cart is empty", () => {
    const result = recommendCartProducts(demoProducts, []);
    expect(result.map((product) => product.slug)).toEqual(
      [...demoProducts]
        .filter((product) => product.published)
        .sort((a, b) => Number(b.is_new) - Number(a.is_new) || b.created_at.localeCompare(a.created_at) || a.name.localeCompare(b.name))
        .slice(0, 4)
        .map((product) => product.slug),
    );
  });

  it("returns no results for a zero or negative limit", () => {
    expect(recommendCartProducts(demoProducts, [], 0)).toEqual([]);
    expect(recommendCartProducts(demoProducts, [], -2)).toEqual([]);
  });
});
