import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  defaultMerchandising,
  loadMerchandising,
  resetMerchandising,
  saveMerchandising,
} from "@/lib/demo-merchandising";

describe("local demo homepage merchandising", () => {
  beforeEach(() => {
    window.localStorage.clear();
  });

  it("uses enabled defaults when no settings have been saved", () => {
    expect(loadMerchandising()).toEqual(defaultMerchandising);
  });

  it("persists section toggles and manual product selections in this browser", () => {
    const settings = {
      showFeaturedBrands: false,
      showCuratedProducts: true,
      curatedProductIds: ["product-a", "product-b"],
      showNewArrivals: false,
      newArrivalProductIds: ["product-c"],
    };

    expect(saveMerchandising(settings)).toBe(true);
    expect(loadMerchandising()).toEqual(settings);
  });

  it("notifies the current page when merchandising settings are saved", () => {
    const listener = vi.fn();
    window.addEventListener("ss:merchandising", listener);

    saveMerchandising({ ...defaultMerchandising, showFeaturedBrands: false });

    expect(listener).toHaveBeenCalledTimes(1);
    window.removeEventListener("ss:merchandising", listener);
  });

  it("resets saved settings to defaults and notifies the current page", () => {
    saveMerchandising({ ...defaultMerchandising, showNewArrivals: false });
    const listener = vi.fn();
    window.addEventListener("ss:merchandising", listener);

    resetMerchandising();

    expect(loadMerchandising()).toEqual(defaultMerchandising);
    expect(window.localStorage.getItem("ss.demoMerchandising.v1")).toBeNull();
    expect(listener).toHaveBeenCalledTimes(1);
    window.removeEventListener("ss:merchandising", listener);
  });
});
