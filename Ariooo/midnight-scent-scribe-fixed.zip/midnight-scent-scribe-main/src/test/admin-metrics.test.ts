import { describe, expect, it } from "vitest";
import type { DemoProduct } from "@/lib/demo-catalog";
import { summarizeCatalog } from "@/lib/admin-metrics";

const product = (id: string, published: boolean, stocks: number[]): DemoProduct => ({
  id,
  slug: id,
  name: id,
  brand_slug: "test-brand",
  category_id: "test-category",
  category_ids: ["test-category"],
  image_url: "https://example.com/test.jpg",
  desc_en: "",
  desc_fa: "",
  published,
  is_new: false,
  created_at: "2026-01-01",
  volumes: stocks.map((stock, index) => ({ id: id + "-" + index, ml: index === 0 ? 50 : 100, price: 10, stock })),
});

describe("admin catalogue metrics", () => {
  it("summarizes products, publishing state, bottle sizes and stock alerts", () => {
    expect(summarizeCatalog([product("published", true, [5, 2, 0]), product("draft", false, [0])])).toEqual({
      products: 2,
      publishedProducts: 1,
      draftProducts: 1,
      totalVariants: 4,
      unitsInStock: 7,
      lowStockVariants: 1,
      outOfStockVariants: 2,
    });
  });

  it("returns zeroed metrics for an empty catalogue", () => {
    expect(summarizeCatalog([])).toEqual({
      products: 0,
      publishedProducts: 0,
      draftProducts: 0,
      totalVariants: 0,
      unitsInStock: 0,
      lowStockVariants: 0,
      outOfStockVariants: 0,
    });
  });
});
