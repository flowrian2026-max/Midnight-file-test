import { describe, it, expect, vi } from 'vitest';
import { demoProducts, demoBrands, demoCategories, demoImages, filterProducts, sortProducts, minPrice } from '@/lib/demo-catalog';
import { normalizeCart } from '@/lib/cart-rules';
import { saveCatalog, loadCatalog, resetCatalog, upsertDemoBrand, upsertDemoCategory, isCatalogEdited } from '@/lib/demo-store';

describe('Combined catalogue filters', () => {
 it('combines search, brand, category, price and stock', () => {
  expect(filterProducts(demoProducts,{q:'wood',brand:'tom-ford',cat:'woody',min:190,max:200,inStock:true}).map(p=>p.slug)).toEqual(['oud-wood']);
  expect(filterProducts(demoProducts,{q:'oud wood',brand:'dior'})).toEqual([]);
 });
 it('reset returns all published products', () => {expect(filterProducts(demoProducts,{})).toHaveLength(21);});
 it('filters shared products by category slug even when database category IDs are UUIDs', () => {
  const base = demoProducts.find((product) => product.slug === 'oud-wood');
  if (!base) throw new Error('category fixture absent');
  const shared = {...base, category_id:'db-category-uuid', category_ids:['db-category-uuid'], category_slugs:['woody']};
  expect(filterProducts([shared], {cat:'woody'})).toHaveLength(1);
  expect(filterProducts([shared], {cat:'floral'})).toHaveLength(0);
 });
 it('sorts prices, names and reliable demo dates', () => {
  expect(minPrice(sortProducts(demoProducts,'price-asc')[0] as typeof demoProducts[number])).toBe(135);
  expect(sortProducts(demoProducts,'price-desc')[0]?.slug).toBe('lost-cherry');
  expect(sortProducts(demoProducts,'name')[0]?.slug).toBe('allure-homme-sport');
  expect(sortProducts(demoProducts,'newest')[0]?.slug).toBe('lazy-sunday-morning');
 });
 it('excludes unpublished and fully unavailable products when requested', () => {
  const base = demoProducts[0]; if(!base) throw new Error('fixture absent');
  expect(filterProducts([{...base,published:false}],{})).toEqual([]);
  expect(filterProducts([{...base,volumes:base.volumes.map(v=>({...v,stock:0}))}],{inStock:true})).toEqual([]);
 });
 it('does not assign a free price to a product with no configured bottle sizes', () => {
  const base = demoProducts[0]; if (!base) throw new Error('fixture absent');
  const unconfigured = {...base, volumes: []};
  expect(minPrice(unconfigured)).toBe(Number.POSITIVE_INFINITY);
  expect(filterProducts([unconfigured], {min: 1})).toEqual([]);
  expect(sortProducts([unconfigured, base], 'price-asc')[1]?.id).toBe(unconfigured.id);
  expect(sortProducts([unconfigured, base], 'price-desc')[1]?.id).toBe(unconfigured.id);
  expect(sortProducts([base, unconfigured], 'price-desc')[0]?.id).toBe(base.id);
 });
});
describe('Demo catalogue integrity', () => {
 it('uses unique product IDs and slugs', () => {
  expect(new Set(demoProducts.map((p) => p.id)).size).toBe(demoProducts.length);
  expect(new Set(demoProducts.map((p) => p.slug)).size).toBe(demoProducts.length);
 });
 it('points every product to a known brand, category and unique bundled or remote image', () => {
  const brandSlugs = new Set(demoBrands.map((b) => b.slug));
  const categoryIds = new Set(demoCategories.map((category) => category.id));
  const resolvedImages: string[] = [];
  for (const product of demoProducts) {
   expect(brandSlugs.has(product.brand_slug), product.slug + ' brand').toBe(true);
   expect(categoryIds.has(product.category_id), product.slug + ' category').toBe(true);
   if (product.image_url.startsWith('asset:')) {
    const imageKey = product.image_url.slice('asset:'.length);
    const bundledImage = demoImages[imageKey];
    expect(bundledImage, product.slug + ' image asset').toBeTruthy();
    resolvedImages.push(bundledImage);
   } else {
    expect(product.image_url, product.slug + ' image URL').toMatch(/^https:\/\/images\.unsplash\.com\/photo-[^?]+\?auto=format&fit=crop&w=1000&q=80$/);
    resolvedImages.push(product.image_url);
   }
  }
  expect(new Set(resolvedImages).size, 'every seeded product should use a different image').toBe(demoProducts.length);
 });
});

describe('Cart quantities and variant calculations', () => {
 it('never exceeds known variant stock', () => {
  expect(normalizeCart([{productId:'p-oud-wood',volumeId:'v-oud-100',qty:99}],demoProducts)).toEqual([{productId:'p-oud-wood',volumeId:'v-oud-100',qty:2}]);
 });
 it('does not add an out-of-stock variant', () => {
  expect(normalizeCart([{productId:'p-tobacco-vanille',volumeId:'v-tv-100',qty:1}],demoProducts)).toEqual([]);
 });
 it('removes zero, invalid and unavailable entries', () => {
  expect(normalizeCart([{productId:'p-oud-wood',volumeId:'v-oud-50',qty:0},{productId:'missing',volumeId:'none',qty:1},{productId:'p-oud-wood',volumeId:'v-oud-50',qty:NaN}],demoProducts)).toEqual([]);
 });
 it('keeps variants distinct and computes concrete subtotal', () => {
  const items = normalizeCart([{productId:'p-oud-wood',volumeId:'v-oud-50',qty:2},{productId:'p-oud-wood',volumeId:'v-oud-100',qty:1}],demoProducts);
  const subtotal = items.reduce((sum,item)=>{const price = demoProducts.find(p=>p.id===item.productId)?.volumes.find(v=>v.id===item.volumeId)?.price ?? 0; return sum+price*item.qty;},0);
  expect(items).toHaveLength(2); expect(subtotal).toBe(675);
 });
});
describe('Local catalogue editing', () => {
 it('persists edited catalog in this browser and restores defaults', () => {
  resetCatalog(); const catalog = loadCatalog();
  saveCatalog({...catalog,brands:[...catalog.brands,{slug:'test-brand',name:'Test',blurbEn:'',blurbFa:''}]});
  expect(JSON.parse(localStorage.getItem('ss.demoCatalog.v2') ?? '{}').brands.at(-1).slug).toBe('test-brand');
  expect(loadCatalog().brands.at(-1)?.slug).toBe('test-brand');
  resetCatalog(); expect(loadCatalog().brands).toHaveLength(6); expect(localStorage.getItem('ss.demoCatalog.v2')).toBeNull();
 });
 it('renames a brand and keeps its products connected', () => {
  resetCatalog();
  const catalog = loadCatalog();
  const original = catalog.brands.find((b) => b.slug === 'tom-ford');
  if (!original) throw new Error('Tom Ford fixture absent');

  const affectedCount = catalog.products.filter((p) => p.brand_slug === original.slug).length;
  const next = upsertDemoBrand(catalog, { ...original, slug: 'tom-ford-private' }, original.slug);

  expect(next).not.toBeNull();
  expect(next?.brands).toHaveLength(catalog.brands.length);
  expect(next?.brands.some((b) => b.slug === original.slug)).toBe(false);
  expect(next?.products.filter((p) => p.brand_slug === 'tom-ford-private')).toHaveLength(affectedCount);
  expect(next?.products.some((p) => p.brand_slug === original.slug)).toBe(false);
 });
 it('refuses a brand slug already owned by another brand', () => {
  resetCatalog();
  const catalog = loadCatalog();
  const original = catalog.brands.find((b) => b.slug === 'tom-ford');
  const existing = catalog.brands.find((b) => b.slug === 'dior');
  if (!original || !existing) throw new Error('Brand fixtures absent');

  const next = upsertDemoBrand(catalog, { ...original, slug: existing.slug }, original.slug);

  expect(next).toBeNull();
  expect(loadCatalog().brands.find((b) => b.slug === 'dior')?.name).toBe(existing.name);
  expect(loadCatalog().brands.find((b) => b.slug === 'tom-ford')?.name).toBe(original.name);
 });
 it('rejects duplicate slugs when adding a brand', () => {
  resetCatalog();
  const catalog = loadCatalog();
  const existing = catalog.brands[0];
  if (!existing) throw new Error('Brand fixture absent');

  expect(upsertDemoBrand(catalog, { ...existing, slug: 'new-demo-brand' }, null)).not.toBeNull();
  expect(upsertDemoBrand(catalog, { ...existing }, null)).toBeNull();
 });

 it('renames a category and updates product category slugs', () => {
  resetCatalog();
  const catalog = loadCatalog();
  const original = catalog.categories.find((item) => item.slug === 'woody');
  if (!original) throw new Error('Woody category fixture absent');
  const affected = catalog.products.filter((product) =>
   (product.category_slugs ?? []).includes(original.slug) ||
   product.category_id === original.id ||
   (product.category_ids ?? []).includes(original.id),
  );
  const next = upsertDemoCategory(catalog, { ...original, slug: 'woody-scents' }, original.slug);

  expect(next).not.toBeNull();
  expect(next?.categories.some((item) => item.slug === original.slug)).toBe(false);
  expect(next?.categories.some((item) => item.slug === 'woody-scents')).toBe(true);
  expect(next?.products.filter((product) => (product.category_slugs ?? []).includes('woody-scents'))).toHaveLength(affected.length);
  expect(next?.products.some((product) => (product.category_slugs ?? []).includes(original.slug))).toBe(false);
 });

 it('renames categories for products linked only by stable category ID', () => {
  resetCatalog();
  const catalog = loadCatalog();
  const original = catalog.categories.find((item) => item.slug === 'woody');
  const product = catalog.products.find((item) => item.category_id === original?.id);
  if (!original || !product) throw new Error('Woody category fixture absent');

  const idOnlyProduct = {
   ...product,
   category_slugs: undefined,
   category_ids: [original.id],
  };
  const withIdOnlyProduct = {
   ...catalog,
   products: catalog.products.map((item) => item.id === product.id ? idOnlyProduct : item),
  };
  const next = upsertDemoCategory(withIdOnlyProduct, { ...original, slug: 'woody-scents' }, original.slug);
  const updated = next?.products.find((item) => item.id === product.id);

  expect(updated?.category_id).toBe(original.id);
  expect(updated?.category_ids).toContain(original.id);
  expect(updated?.category_slugs).toContain('woody-scents');
  expect(updated?.category_slugs).not.toContain('woody');
 });

 it('rejects duplicate category slugs and missing original categories', () => {
  resetCatalog();
  const catalog = loadCatalog();
  const original = catalog.categories.find((item) => item.slug === 'woody');
  const existing = catalog.categories.find((item) => item.slug === 'floral');
  if (!original || !existing) throw new Error('Category fixtures absent');

  expect(upsertDemoCategory(catalog, { ...original, slug: existing.slug }, original.slug)).toBeNull();
  expect(upsertDemoCategory(catalog, { ...original, slug: 'another-slug' }, 'missing-category')).toBeNull();
  expect(upsertDemoCategory(catalog, { ...original, slug: 'new-demo-category' }, null)).not.toBeNull();
 });

 it('reports when catalogue edits cannot be persisted', () => {
  resetCatalog();
  const catalog = loadCatalog();
  const next = {
   ...catalog,
   brands: [...catalog.brands, { slug: 'session-only-brand', name: 'Session only', blurbEn: '', blurbFa: '' }],
  };
  const setSpy = vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => {
   throw new Error('storage blocked');
  });
  try {
   expect(saveCatalog(next)).toBe(false);
  } finally {
   setSpy.mockRestore();
  }

  expect(loadCatalog().brands.at(-1)?.slug).toBe('session-only-brand');
 });
 it('keeps the local demo reset safe when browser storage is blocked', () => {
  resetCatalog();
  const removeSpy = vi.spyOn(Storage.prototype, 'removeItem').mockImplementation(() => {
   throw new Error('storage blocked');
  });
  try {
   expect(() => resetCatalog()).not.toThrow();
  } finally {
   removeSpy.mockRestore();
  }

  expect(loadCatalog().brands).toHaveLength(6);
  const getSpy = vi.spyOn(Storage.prototype, 'getItem').mockImplementation(() => {
   throw new Error('storage blocked');
  });
  try {
   expect(isCatalogEdited()).toBe(false);
  } finally {
   getSpy.mockRestore();
  }
 });

});