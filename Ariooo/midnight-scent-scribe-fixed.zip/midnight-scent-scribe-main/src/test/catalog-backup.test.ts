import { describe, expect, it } from "vitest";
import { demoBrands, demoCategories, demoProducts } from "@/lib/demo-catalog";
import { parseCatalogBackup, serializeCatalogBackup } from "@/lib/catalog-backup";

const demoCatalog = {
  brands: demoBrands,
  categories: demoCategories,
  products: demoProducts,
};

describe("Scent Scribe catalogue backups", () => {
  it("round-trips the full catalogue in the versioned backup format", () => {
    const serialized = serializeCatalogBackup(demoCatalog);
    const parsed = parseCatalogBackup(JSON.parse(serialized));
    expect(parsed).toEqual(JSON.parse(JSON.stringify(demoCatalog)));
  });

  it("rejects files that are not Scent Scribe backups", () => {
    expect(() => parseCatalogBackup({ products: [], brands: [], categories: [] }))
      .toThrow("This is not a Scent Scribe catalogue backup.");
  });

  it("rejects duplicate product slugs instead of restoring ambiguous routes", () => {
    const parsed = JSON.parse(serializeCatalogBackup(demoCatalog)) as {
      schema: string;
      version: number;
      exportedAt: string;
      catalog: typeof demoCatalog;
    };
    parsed.catalog.products.push({ ...parsed.catalog.products[0]!, id: "different-id" });
    expect(() => parseCatalogBackup(parsed)).toThrow("duplicate IDs or URL slugs");
  });

  it("rejects invalid prices and stock counts in bottle variants", () => {
    const parsed = JSON.parse(serializeCatalogBackup(demoCatalog)) as {
      schema: string;
      version: number;
      exportedAt: string;
      catalog: typeof demoCatalog;
    };
    const product = parsed.catalog.products[0];
    if (!product || !product.volumes[0]) throw new Error("Demo product fixture is missing");
    product.volumes[0].stock = -2;
    expect(() => parseCatalogBackup(parsed)).toThrow("invalid records");
  });
});
