import { describe, expect, it } from "vitest";
import { demoProducts } from "@/lib/demo-catalog";
import { normalizeCart } from "@/lib/cart-rules";

describe("cart normalization edge cases", () => {
  it("merges duplicate saved lines and caps their combined quantity at stock", () => {
    expect(normalizeCart([
      { productId: "p-oud-wood", volumeId: "v-oud-100", qty: 1 },
      { productId: "p-oud-wood", volumeId: "v-oud-100", qty: 1 },
      { productId: "p-oud-wood", volumeId: "v-oud-100", qty: 4 },
    ], demoProducts)).toEqual([
      { productId: "p-oud-wood", volumeId: "v-oud-100", qty: 2 },
    ]);
  });

  it("rounds fractional quantities down and ignores non-finite quantities", () => {
    expect(normalizeCart([
      { productId: "p-oud-wood", volumeId: "v-oud-50", qty: 1.8 },
      { productId: "p-oud-wood", volumeId: "v-oud-100", qty: Number.POSITIVE_INFINITY },
    ], demoProducts)).toEqual([
      { productId: "p-oud-wood", volumeId: "v-oud-50", qty: 1 },
    ]);
  });
});
