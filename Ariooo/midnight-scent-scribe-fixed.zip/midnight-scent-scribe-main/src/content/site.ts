// Swap any image here: replace the file in src/assets (same name) or change the import.
import hero from "@/assets/hero.jpg";
import lumiere from "@/assets/p-lumiere.jpg";
import nocturne from "@/assets/p-nocturne.jpg";
import riviere from "@/assets/p-riviere.jpg";
import solstice from "@/assets/p-solstice.jpg";
import floral from "@/assets/f-floral.jpg";
import amber from "@/assets/f-amber.jpg";
import woody from "@/assets/f-woody.jpg";
import spicy from "@/assets/f-spicy.jpg";
import citrus from "@/assets/f-citrus.jpg";
import flower from "@/assets/flower.jpg";
import darkFlowers from "@/assets/dark-flowers.jpg";
import amalfi from "@/assets/j-amalfi.jpg";
import ritual from "@/assets/j-ritual.jpg";
import memory from "@/assets/j-memory.jpg";

export const images = { hero, flower, darkFlowers };

export const families = [
  { name: "Floral", desc: "Romantic. Luminous. Timeless.", img: floral },
  { name: "Amber", desc: "Warm. Sensual. Addictive.", img: amber },
  { name: "Woody", desc: "Bold. Grounded. Enduring.", img: woody },
  { name: "Spicy", desc: "Vibrant. Evocative. Magnetic.", img: spicy },
  { name: "Citrus", desc: "Bright. Refined. Uplifting.", img: citrus },
];

export const products = [
  { name: "Lumière", price: 180, img: lumiere },
  { name: "Nocturne", price: 180, img: nocturne },
  { name: "Rivière", price: 180, img: riviere },
  { name: "Solstice", price: 180, img: solstice },
];

export const stories = [
  { title: "A Fragrant Summer on the Amalfi Coast", tag: "Travel", img: amalfi },
  { title: "The Ritual of Scent", tag: "Wellness", img: ritual },
  { title: "The Power of a Memory", tag: "Inspiration", img: memory },
];
