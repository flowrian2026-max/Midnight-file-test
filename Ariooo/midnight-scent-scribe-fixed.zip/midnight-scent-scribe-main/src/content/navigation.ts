export const navPaths = ['/shop', '/scent-families', '/our-story', '/journal'] as const;
export const footerPaths = [
  ['/shop', '/discovery-sets', '/gift-cards'],
  ['/our-story', '/sustainability', '/ingredients', '/journal'],
  ['/contact', '/shipping-returns', '/faq'],
] as const;
export const familySlugs = ['floral', 'amber', 'woody', 'spicy', 'citrus'] as const;
export const productSlugs = ['lumiere', 'nocturne', 'riviere', 'solstice'] as const;
export const storySlugs = ['amalfi-coast', 'ritual-of-scent', 'power-of-memory'] as const;
