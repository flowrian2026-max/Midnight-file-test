import { createFileRoute } from '@tanstack/react-router';
import { CartPage } from '@/components/site/commerce-pages';
import { pageHead } from '@/components/site/pages';
export const Route = createFileRoute('/cart')({head: () => pageHead('Your bag','Review your selection and send a no-payment order request. Shipping is confirmed separately.'), component: CartPage});