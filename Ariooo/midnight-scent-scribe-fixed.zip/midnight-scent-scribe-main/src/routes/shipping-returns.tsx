import { createFileRoute } from '@tanstack/react-router';
import { InfoPage, pageHead } from '@/components/site/pages';
export const Route = createFileRoute('/shipping-returns')({head: () => pageHead('Shipping & Returns', 'Current shipping and returns information for the Scent Scribe collection.'), component: Page});
function Page() {return <InfoPage kind="shipping-returns"/>;}
