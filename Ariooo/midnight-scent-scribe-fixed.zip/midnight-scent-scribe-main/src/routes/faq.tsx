import { createFileRoute } from '@tanstack/react-router';
import { FaqPage, pageHead } from '@/components/site/pages';
export const Route = createFileRoute('/faq')({head: () => pageHead('Frequently Asked Questions', 'Find answers about choosing perfume and Scent Scribe store availability.'), component: FaqPage});
