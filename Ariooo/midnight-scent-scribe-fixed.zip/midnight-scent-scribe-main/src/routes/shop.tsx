import { createFileRoute } from '@tanstack/react-router';
import { pageHead } from '@/components/site/pages';
import { StoreShop, type ShopFilters } from '@/components/site/store';
export const Route = createFileRoute('/shop')({
  validateSearch: (s: Record<string, unknown>): ShopFilters => Object.fromEntries(['q','brand','cat','min','max','stock','sort','gender','season'].flatMap(key => typeof s[key] === 'string' ? [[key,s[key]]] : [])),
  head: () => pageHead('Shop', 'Browse Scent Scribe fragrances by category.'),
  component: Page,
});
function Page() { const filters = Route.useSearch(); const navigate = Route.useNavigate(); return <StoreShop filters={filters} onChange={next => void navigate({search:next, replace:true})} />; }
