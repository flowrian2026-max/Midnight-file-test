import { createFileRoute, Link } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ArrowDown, ArrowLeft, ArrowUp, Check, ChevronDown, ChevronUp,
  ExternalLink, Eye, FileImage, Images, LayoutDashboard, Loader2,
  Package, Plus, RefreshCw, Save, Search, ShieldCheck, ShoppingBag, Tag, Truck, UserRound,
  Trash2, X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/components/site/language";

export const Route = createFileRoute("/_authenticated/operations")({
  head: () => ({
    meta: [
      { title: "Store operations — Scent Scribe" },
      { name: "description", content: "Manage orders, promotions, homepage content and media for Scent Scribe." },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: StoreOperationsPage,
});

type ModuleKey = "orders" | "promotions" | "homepage" | "media" | "shipping" | "customers";
type Row = Record<string, unknown> & { id: string };
type Field = {
  name: string; label: string; labelFa: string;
  type?: "text" | "number" | "textarea" | "select" | "checkbox";
  options?: string[]; required?: boolean; help?: string; helpFa?: string;
};
type Definition = {
  title: string; titleFa: string; description: string; descriptionFa: string;
  fields: Field[];
};
type OrderLine = {
  id: string; product_name: string; brand_name?: string; size_ml?: number;
  unit_price: number; quantity: number; line_total: number;
};
type Stats = { orders: number; pending: number; promotions: number; visible: number; media: number; shipping: number; customers: number };

const definitions: Record<ModuleKey, Definition> = {
  orders: {
    title: "Orders", titleFa: "سفارش‌ها",
    description: "Review customer orders, inspect line items and update fulfillment or payment status.",
    descriptionFa: "سفارش مشتری‌ها و جزئیات اقلام را ببین و وضعیت پردازش و پرداخت را مدیریت کن.",
    fields: [
      { name: "order_number", label: "Order number", labelFa: "شماره سفارش" },
      { name: "customer_name", label: "Customer", labelFa: "نام مشتری" },
      { name: "customer_email", label: "Email", labelFa: "ایمیل" },
      { name: "customer_phone", label: "Phone", labelFa: "تلفن" },
      { name: "total", label: "Total", labelFa: "مبلغ کل", type: "number" },
      { name: "created_at", label: "Created", labelFa: "تاریخ ثبت" },
      { name: "status", label: "Order status", labelFa: "وضعیت سفارش", type: "select", required: true, options: ["pending","confirmed","processing","shipped","completed","cancelled","refunded"] },
      { name: "payment_status", label: "Payment status", labelFa: "وضعیت پرداخت", type: "select", required: true, options: ["unpaid","paid","failed","refunded"] },
      { name: "shipping_address", label: "Shipping address", labelFa: "نشانی ارسال", type: "textarea" },
      { name: "customer_note", label: "Customer note", labelFa: "یادداشت مشتری", type: "textarea" },
    ],
  },
  customers: {
    title: "Customers", titleFa: "مشتری‌ها",
    description: "A read-only directory grouped from order requests, with contact details and order history totals.",
    descriptionFa: "فهرست فقط‌خواندنی مشتریان بر اساس درخواست‌های سفارش، همراه با اطلاعات تماس و خلاصه سابقه سفارش.",
    fields: [],
  },
  promotions: {
    title: "Promotions", titleFa: "تخفیف‌ها",
    description: "Create discount codes and control their value, limits and active dates. Checkout application is not connected yet.",
    descriptionFa: "کد تخفیف بساز و مقدار، محدودیت و بازهٔ اعتبارش را تنظیم کن. اعمال کد در تسویه‌حساب هنوز متصل نیست.",
    fields: [
      { name: "code", label: "Code", labelFa: "کد تخفیف", required: true, help: "Letters and numbers; customers will enter this code.", helpFa: "حروف و عدد؛ مشتری این کد را وارد می‌کند." },
      { name: "name", label: "Promotion name", labelFa: "نام کمپین", required: true },
      { name: "description", label: "Description", labelFa: "توضیحات", type: "textarea" },
      { name: "discount_type", label: "Discount type", labelFa: "نوع تخفیف", type: "select", options: ["percent","fixed"], required: true },
      { name: "discount_value", label: "Discount value", labelFa: "مقدار تخفیف", type: "number", required: true },
      { name: "minimum_order", label: "Minimum order", labelFa: "حداقل مبلغ سفارش", type: "number" },
      { name: "usage_limit", label: "Usage limit (blank = unlimited)", labelFa: "سقف استفاده (خالی = نامحدود)", type: "number" },
      { name: "starts_at", label: "Starts at (ISO date/time)", labelFa: "شروع اعتبار (ISO)" },
      { name: "ends_at", label: "Ends at (ISO date/time)", labelFa: "پایان اعتبار (ISO)" },
      { name: "is_active", label: "Active", labelFa: "فعال", type: "checkbox" },
      { name: "usage_count", label: "Uses so far", labelFa: "تعداد استفاده", type: "number", help: "Read-only until checkout is connected.", helpFa: "تا زمان اتصال تسویه‌حساب فقط‌خواندنی است." },
    ],
  },
  homepage: {
    title: "Homepage", titleFa: "صفحهٔ اصلی",
    description: "Manage bilingual editorial sections, visibility, ordering and display schedules.",
    descriptionFa: "سکشن‌های دوزبانهٔ صفحهٔ اصلی، نمایش، ترتیب و زمان‌بندی را مدیریت کن.",
    fields: [
      { name: "section_key", label: "Unique section key", labelFa: "شناسه یکتا", required: true },
      { name: "section_type", label: "Section type", labelFa: "نوع سکشن", required: true, help: "Examples: editorial, product-shelf, campaign.", helpFa: "مثال: editorial، product-shelf، campaign." },
      { name: "title_en", label: "Title (English)", labelFa: "عنوان انگلیسی" },
      { name: "title_fa", label: "Title (Persian)", labelFa: "عنوان فارسی" },
      { name: "body_en", label: "Body (English)", labelFa: "متن انگلیسی", type: "textarea" },
      { name: "body_fa", label: "Body (Persian)", labelFa: "متن فارسی", type: "textarea" },
      { name: "image_url", label: "Image URL / asset key", labelFa: "آدرس تصویر / کلید فایل", help: "HTTPS URL or a built-in key such as asset:lumiere.", helpFa: "آدرس HTTPS یا کلید داخلی مثل asset:lumiere." },
      { name: "link_url", label: "Link URL", labelFa: "لینک مقصد" },
      { name: "product_ids", label: "Product IDs (comma-separated)", labelFa: "شناسه محصولات (با کاما جدا شود)" },
      { name: "sort", label: "Display order", labelFa: "ترتیب نمایش", type: "number" },
      { name: "is_visible", label: "Visible", labelFa: "قابل نمایش", type: "checkbox" },
      { name: "starts_at", label: "Starts at (ISO date/time)", labelFa: "شروع نمایش (ISO)" },
      { name: "ends_at", label: "Ends at (ISO date/time)", labelFa: "پایان نمایش (ISO)" },
    ],
  },
  shipping: {
    title: "Shipping", titleFa: "روش‌های ارسال",
    description: "Configure delivery zones, flat rates, free-shipping thresholds and estimated delivery windows. Checkout use is a separate integration step.",
    descriptionFa: "محدوده‌های ارسال، هزینه ثابت، حداقل خرید برای ارسال رایگان و بازه تحویل را تنظیم کن. اتصال به Checkout مرحله جداگانه‌ای است.",
    fields: [
      { name: "name", label: "Method name", labelFa: "نام روش ارسال", required: true },
      { name: "name_fa", label: "Method name (Persian)", labelFa: "نام روش ارسال (فارسی)" },
      { name: "zone", label: "Delivery zone", labelFa: "محدوده ارسال", required: true },
      { name: "price", label: "Shipping price", labelFa: "هزینه ارسال", type: "number", required: true },
      { name: "free_shipping_threshold", label: "Free shipping above", labelFa: "ارسال رایگان از مبلغ", type: "number", help: "Leave blank to disable free shipping.", helpFa: "برای غیرفعال‌کردن ارسال رایگان خالی بگذار." },
      { name: "estimated_min_days", label: "Minimum delivery days", labelFa: "حداقل روز تحویل", type: "number" },
      { name: "estimated_max_days", label: "Maximum delivery days", labelFa: "حداکثر روز تحویل", type: "number" },
      { name: "sort", label: "Display order", labelFa: "ترتیب نمایش", type: "number" },
      { name: "is_active", label: "Active", labelFa: "فعال", type: "checkbox" },
    ],
  },
  media: {
    title: "Media library", titleFa: "کتابخانه رسانه",
    description: "Organise image, video and document URLs with bilingual alt text. Binary uploads need an object-storage binding.",
    descriptionFa: "آدرس تصاویر، ویدئوها و اسناد را با متن جایگزین دوزبانه سامان بده. آپلود فایل به اتصال فضای ذخیره‌سازی نیاز دارد.",
    fields: [
      { name: "title", label: "Asset title", labelFa: "نام فایل", required: true },
      { name: "asset_url", label: "HTTPS asset URL", labelFa: "آدرس HTTPS فایل", required: true },
      { name: "media_type", label: "Media type", labelFa: "نوع رسانه", type: "select", options: ["image","video","document"], required: true },
      { name: "alt_en", label: "Alt text (English)", labelFa: "متن جایگزین انگلیسی" },
      { name: "alt_fa", label: "Alt text (Persian)", labelFa: "متن جایگزین فارسی" },
      { name: "mime_type", label: "MIME type", labelFa: "نوع MIME" },
      { name: "byte_size", label: "File size in bytes", labelFa: "حجم فایل (بایت)", type: "number" },
      { name: "width", label: "Width", labelFa: "عرض", type: "number" },
      { name: "height", label: "Height", labelFa: "ارتفاع", type: "number" },
    ],
  },
};

const paths: Record<ModuleKey, string> = {
  orders: "/api/d1/admin/orders",
  promotions: "/api/d1/admin/promotions",
  homepage: "/api/d1/admin/homepage",
  media: "/api/d1/admin/media",
  shipping: "/api/d1/admin/shipping",
  customers: "/api/d1/admin/customers",
};
const moduleIcons = { orders: ShoppingBag, promotions: Tag, homepage: LayoutDashboard, media: Images, shipping: Truck, customers: UserRound };
const inputClass = "w-full rounded-xl border border-[#34304a] bg-[#11101b] px-3.5 py-3 text-sm text-[#f2f0fa] outline-none transition placeholder:text-[#77738b] focus:border-[#8387c3] focus:ring-2 focus:ring-[#8387c3]/15";
const asText = (value: unknown) => value === null || value === undefined ? "" : String(value);
const money = (value: unknown, currency: unknown) => {
  const amount = Number(value);
  if (!Number.isFinite(amount)) return "—";
  try { return new Intl.NumberFormat(undefined, { style: "currency", currency: asText(currency) || "EUR", maximumFractionDigits: 2 }).format(amount); }
  catch { return amount.toFixed(2) + " " + (asText(currency) || "EUR"); }
};
const dateLabel = (value: unknown, fa: boolean) => {
  if (!value) return "—";
  const date = new Date(String(value));
  if (Number.isNaN(date.getTime())) return asText(value);
  return new Intl.DateTimeFormat(fa ? "fa-IR" : "en-GB", { dateStyle: "medium", timeStyle: "short" }).format(date);
};
function toForm(key: ModuleKey, row?: Row): Record<string, unknown> {
  const source = row ?? {};
  const result: Record<string, unknown> = {};
  for (const field of definitions[key].fields) {
    if (field.name === "product_ids") {
      try { result[field.name] = JSON.parse(asText(source.product_ids_json || "[]")).join(", "); }
      catch { result[field.name] = ""; }
    } else if (field.type === "checkbox") result[field.name] = source[field.name] === true || source[field.name] === 1;
    else result[field.name] = source[field.name] ?? (field.type === "number" ? "" : field.type === "checkbox" ? false : field.type === "select" ? field.options?.[0] ?? "" : "");
  }
  if (row) result.id = row.id;
  if (key === "shipping" && !row) {
    result.zone = "Domestic";
    result.price = 0;
    result.estimated_min_days = 2;
    result.estimated_max_days = 5;
    result.sort = 0;
    result.is_active = true;
  }
  return result;
}
function payloadFor(key: ModuleKey, form: Record<string, unknown>): Record<string, unknown> {
  const payload = { ...form };
  if (key === "homepage") {
    const value = asText(payload.product_ids).trim();
    payload.product_ids = value ? value.split(",").map((id) => id.trim()).filter(Boolean) : [];
    delete payload.product_ids_json;
  }
  if (key === "promotions" || key === "homepage" || key === "media" || key === "shipping") {
    for (const field of definitions[key].fields) {
      if (field.type === "number" && asText(payload[field.name]).trim() !== "") payload[field.name] = Number(payload[field.name]);
      if (field.type === "number" && asText(payload[field.name]).trim() === "") {
        payload[field.name] = ["usage_limit","width","height","free_shipping_threshold"].includes(field.name) ? null : 0;
      }
    }
  }
  return payload;
}
const isEnabled = (value: unknown) => value === true || value === 1;

function matchesFilter(key: ModuleKey, row: Row, filter: string): boolean {
  if (filter === "all") return true;
  if (key === "orders") return filter === "unpaid" ? row.payment_status === "unpaid" : row.status === filter;
  if (key === "promotions" || key === "shipping") return filter === "active" ? isEnabled(row.is_active) : !isEnabled(row.is_active);
  if (key === "homepage") return filter === "visible" ? isEnabled(row.is_visible) : !isEnabled(row.is_visible);
  if (key === "customers") return true;
  return row.media_type === filter;
}

function StoreOperationsPage() {
  const { fa } = useLanguage();
  const [active, setActive] = useState<ModuleKey>("orders");
  const [rows, setRows] = useState<Row[]>([]);
  const [editing, setEditing] = useState<Record<string, unknown> | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [stats, setStats] = useState<Stats>({ orders: 0, pending: 0, promotions: 0, visible: 0, media: 0, shipping: 0, customers: 0 });

  const load = useCallback(async (key: ModuleKey, quiet = false) => {
    if (!quiet) setBusy(true);
    if (!quiet) setNotice("");
    try {
      const response = await fetch(paths[key], { cache: "no-store", credentials: "same-origin" });
      const body = await response.json().catch(() => ({})) as { ok?: boolean; items?: Row[]; code?: string; message?: string };
      if (!response.ok || !body.ok) throw new Error(body.message ?? (body.code === "UNAUTHENTICATED" ? "Please sign in again." : "Could not load this module. Check the D1 migration and administrator session."));
      const nextRows = body.items ?? [];
      setRows(nextRows);
      return nextRows;
    } catch (error) {
      setRows([]);
      setNotice(error instanceof Error ? error.message : "Could not load this module.");
      return [];
    } finally { if (!quiet) setBusy(false); }
  }, []);

  const refreshStats = useCallback(async () => {
    const results = await Promise.all((Object.keys(paths) as ModuleKey[]).map(async (key) => {
      try {
        const response = await fetch(paths[key], { cache: "no-store", credentials: "same-origin" });
        const body = await response.json() as { ok?: boolean; items?: Row[] };
        return response.ok && body.ok ? [key, body.items ?? []] as const : [key, []] as const;
      } catch { return [key, []] as const; }
    }));
    const data = Object.fromEntries(results) as Record<ModuleKey, Row[]>;
    setStats({
      orders: data.orders.length,
      pending: data.orders.filter((row) => row.status === "pending").length,
      promotions: data.promotions.filter((row) => Boolean(row.is_active)).length,
      visible: data.homepage.filter((row) => Boolean(row.is_visible)).length,
      media: data.media.length,
      shipping: data.shipping.filter((row) => Boolean(row.is_active)).length,
      customers: data.customers.length,
    });
  }, []);

  useEffect(() => {
    setEditing(null); setExpandedId(null); setQuery(""); setFilter("all");
    void load(active);
  }, [active, load]);

  useEffect(() => { void refreshStats(); }, [refreshStats]);

  const visibleRows = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase();
    return rows.filter((row) => {
      if (!matchesFilter(active, row, filter)) return false;
      if (!needle) return true;
      const searchable = active === "orders"
        ? [row.order_number,row.customer_name,row.customer_email,row.customer_phone,row.status,row.payment_status]
        : active === "promotions"
          ? [row.code,row.name,row.description]
          : active === "homepage"
            ? [row.section_key,row.section_type,row.title_en,row.title_fa,row.body_en,row.body_fa]
            : active === "shipping"
              ? [row.name,row.name_fa,row.zone]
              : active === "customers"
                ? [row.customer_name,row.customer_email,row.customer_phone]
                : [row.title,row.asset_url,row.media_type,row.alt_en,row.alt_fa];
      return searchable.some((value) => asText(value).toLocaleLowerCase().includes(needle));
    });
  }, [active, filter, query, rows]);

  const save = async () => {
    if (!editing) return;
    setBusy(true); setNotice("");
    try {
      const response = await fetch(paths[active], {
        method: "POST", credentials: "same-origin",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payloadFor(active, editing)),
      });
      const body = await response.json().catch(() => ({})) as { ok?: boolean; code?: string; message?: string };
      if (!response.ok || !body.ok) throw new Error(body.message ?? body.code ?? "Save failed.");
      setEditing(null);
      setNotice(fa ? "تغییرات با موفقیت در دیتابیس ذخیره شد." : "Changes saved to the database.");
      await load(active, true);
      await refreshStats();
    } catch (error) { setNotice(error instanceof Error ? error.message : "Save failed."); }
    finally { setBusy(false); }
  };

  const remove = async (row: Row) => {
    if (!window.confirm(fa ? "این مورد برای همیشه حذف شود؟" : "Permanently delete this record?")) return;
    setBusy(true); setNotice("");
    try {
      const response = await fetch(paths[active] + "/" + encodeURIComponent(row.id), { method: "DELETE", credentials: "same-origin" });
      const body = await response.json().catch(() => ({})) as { ok?: boolean; message?: string };
      if (!response.ok || !body.ok) throw new Error(body.message ?? "Delete failed.");
      setNotice(fa ? "رکورد حذف شد." : "Record deleted.");
      await load(active, true);
      await refreshStats();
    } catch (error) { setNotice(error instanceof Error ? error.message : "Delete failed."); }
    finally { setBusy(false); }
  };

  const moveHomepageSection = async (row: Row, direction: -1 | 1) => {
    if (active !== "homepage" || busy) return;
    const ordered = [...rows].sort((a, b) => Number(a.sort ?? 0) - Number(b.sort ?? 0) || asText(a.section_key).localeCompare(asText(b.section_key)));
    const index = ordered.findIndex((item) => item.id === row.id);
    const targetIndex = index + direction;
    if (index < 0 || targetIndex < 0 || targetIndex >= ordered.length) return;
    const current = ordered[index], target = ordered[targetIndex];
    const currentSort = Number(current.sort ?? index), targetSort = Number(target.sort ?? targetIndex);
    setBusy(true); setNotice("");
    try {
      const saveOrder = async (item: Row, sort: number) => {
        const payload = payloadFor("homepage", { ...toForm("homepage", item), sort });
        const response = await fetch(paths.homepage, { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
        const body = await response.json().catch(() => ({})) as { ok?: boolean; code?: string; message?: string };
        if (!response.ok || !body.ok) throw new Error(body.message ?? body.code ?? "Could not save section order.");
      };
      await saveOrder(current, targetSort);
      await saveOrder(target, currentSort);
      setNotice(fa ? "ترتیب سکشن‌ها ذخیره شد." : "Section order saved.");
      await load("homepage", true);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : "Could not save section order.");
      await load("homepage", true);
    } finally { setBusy(false); }
  };

  const current = definitions[active];
  const filterOptions = active === "orders"
    ? [["all", fa ? "همه سفارش‌ها" : "All orders"],["pending",fa ? "در انتظار" : "Pending"],["processing",fa ? "در حال پردازش" : "Processing"],["shipped",fa ? "ارسال‌شده" : "Shipped"],["completed",fa ? "تکمیل‌شده" : "Completed"],["unpaid",fa ? "پرداخت‌نشده" : "Unpaid"]]
    : active === "promotions"
      ? [["all",fa ? "همه" : "All"],["active",fa ? "فعال" : "Active"],["inactive",fa ? "غیرفعال" : "Inactive"]]
      : active === "homepage"
        ? [["all",fa ? "همه سکشن‌ها" : "All sections"],["visible",fa ? "نمایش‌داده‌شده" : "Visible"],["hidden",fa ? "مخفی" : "Hidden"]]
        : active === "shipping"
          ? [["all",fa ? "همه روش‌ها" : "All methods"],["active",fa ? "فعال" : "Active"],["inactive",fa ? "غیرفعال" : "Inactive"]]
          : active === "customers"
            ? [["all",fa ? "همه مشتری‌ها" : "All customers"]]
            : [["all",fa ? "همه فایل‌ها" : "All media"],["image","Images"],["video","Videos"],["document","Documents"]];

  const statCards = [
    { label: fa ? "کل سفارش‌ها" : "Total orders", value: stats.orders, detail: fa ? stats.pending + " سفارش در انتظار" : stats.pending + " awaiting action", icon: ShoppingBag },
    { label: fa ? "تخفیف‌های فعال" : "Active promotions", value: stats.promotions, detail: fa ? "کدهای فعال ثبت‌شده" : "Saved active codes", icon: Tag },
    { label: fa ? "سکشن‌های قابل نمایش" : "Visible sections", value: stats.visible, detail: fa ? "محتوای صفحه اصلی" : "Homepage content", icon: LayoutDashboard },
    { label: fa ? "فایل‌های رسانه" : "Media records", value: stats.media, detail: fa ? "آدرس‌های ثبت‌شده" : "Registered asset URLs", icon: Images },
    { label: fa ? "روش‌های ارسال فعال" : "Active shipping methods", value: stats.shipping, detail: fa ? "قوانین ثبت‌شده ارسال" : "Saved delivery rules", icon: Truck },
    { label: fa ? "مشتری‌ها" : "Customers", value: stats.customers, detail: fa ? "بر اساس سابقه سفارش" : "From order history", icon: UserRound },
  ];

  return (
    <main dir={fa ? "rtl" : "ltr"} className="ss-operations min-h-screen bg-[#0c0b14] text-[#f2f0fa]">
      <div className="pointer-events-none fixed inset-0 overflow-hidden" aria-hidden="true">
        <div className="absolute -top-48 start-1/3 h-[34rem] w-[34rem] rounded-full bg-[#514b86]/15 blur-[120px]" />
        <div className="absolute -bottom-56 end-0 h-[32rem] w-[32rem] rounded-full bg-[#6c456d]/10 blur-[120px]" />
      </div>
      <div className="relative mx-auto max-w-[1500px] px-4 py-5 sm:px-6 lg:px-8 lg:py-8">
        <header className="mb-7 flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl border border-[#8387c3]/35 bg-[#8387c3]/10 text-[#b7b9ef]"><ShieldCheck className="h-5 w-5" /></div>
            <div><p className="text-[10px] font-semibold uppercase tracking-[.28em] text-[#a9a7c7]">SCENT SCRIBE / CONTROL ROOM</p><p className="mt-1 text-xs text-[#85829d]">{fa ? "مدیریت امن فروشگاه" : "Private store workspace"}</p></div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button asChild variant="outline" className="border-white/15 bg-white/[.03] text-[#e8e6f4] hover:bg-white/[.08]"><Link to="/admin"><LayoutDashboard className="me-2 h-4 w-4" />{fa ? "داشبورد" : "Dashboard"}</Link></Button>
            <Button asChild variant="outline" className="border-white/15 bg-white/[.03] text-[#e8e6f4] hover:bg-white/[.08]"><Link to="/"><Eye className="me-2 h-4 w-4" />{fa ? "مشاهده سایت" : "View site"}<ExternalLink className="ms-2 h-3 w-3" /></Link></Button>
            <Button variant="outline" disabled={busy} onClick={() => { void load(active); void refreshStats(); }} className="border-white/15 bg-white/[.03] text-[#e8e6f4] hover:bg-white/[.08]"><RefreshCw className={`me-2 h-4 w-4 ${busy ? "animate-spin" : ""}`} />{fa ? "تازه‌سازی" : "Refresh"}</Button>
          </div>
        </header>

        <section className="relative mb-7 overflow-hidden rounded-[28px] border border-[#8387c3]/25 bg-gradient-to-br from-[#222039] via-[#171625] to-[#17111f] p-6 shadow-[0_24px_80px_rgba(0,0,0,.24)] sm:p-8">
          <div className="pointer-events-none absolute -end-12 -top-28 h-72 w-72 rounded-full bg-[#8387c3]/15 blur-[80px]" />
          <div className="relative flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div><p className="mb-3 text-[10px] font-semibold tracking-[.25em] text-[#a9abd9]">{fa ? "فضای عملیات" : "OPERATIONS WORKSPACE"}</p>
              <h1 className="font-serif text-4xl tracking-tight text-[#f3f0fa] sm:text-5xl">{fa ? "مرکز عملیات فروشگاه" : "Store operations"}</h1>
              <p className="mt-3 max-w-2xl text-sm leading-7 text-[#b3b0c8]">{fa ? "سفارش‌ها، کمپین‌ها، محتوای صفحهٔ اصلی و رسانه‌ها؛ همه در یک فضای یکپارچه." : "Orders, campaigns, homepage storytelling and media — organised in one calm workspace."}</p>
            </div>
            <div className="flex items-center gap-2 self-start rounded-full border border-[#8387c3]/30 bg-[#8387c3]/10 px-3 py-2 text-xs text-[#c4c5f2] md:self-auto"><span className="h-2 w-2 rounded-full bg-[#9fa2e6] shadow-[0_0_12px_#8387c3]" />{fa ? "اتصال پنل محافظت‌شده با D1" : "Protected D1 workspace"}</div>
          </div>
        </section>

        <section aria-label={fa ? "خلاصه مدیریت" : "Workspace summary"} className="mb-7 grid grid-cols-2 gap-3 xl:grid-cols-6">
          {statCards.map(({ label, value, detail, icon: Icon }) => <article key={label} className="rounded-2xl border border-white/10 bg-[#151420]/85 p-4 shadow-[0_10px_35px_rgba(0,0,0,.14)] sm:p-5"><div className="flex items-start justify-between gap-2"><p className="text-xs text-[#aaa7c1]">{label}</p><span className="flex h-9 w-9 items-center justify-center rounded-xl border border-[#8387c3]/20 bg-[#8387c3]/10 text-[#b7b9eb]"><Icon className="h-4 w-4" /></span></div><p className="mt-4 text-3xl font-semibold tabular-nums text-[#f4f1fb]">{value.toLocaleString(fa ? "fa-IR" : "en-US")}</p><p className="mt-1 text-[11px] text-[#85829d]">{detail}</p></article>)}
        </section>

        <section className="mb-5 grid grid-cols-2 gap-2 lg:grid-cols-4">
          {(Object.keys(definitions) as ModuleKey[]).map((key) => {
            const Icon = moduleIcons[key], selected = active === key;
            const count = key === "orders" ? stats.orders : key === "promotions" ? stats.promotions : key === "homepage" ? stats.visible : stats.media;
            return <button key={key} type="button" aria-pressed={selected} onClick={() => setActive(key)} className={`group flex min-h-[76px] items-center gap-3 rounded-2xl border px-4 py-3 text-start transition-all duration-200 ${selected ? "border-[#8387c3]/55 bg-[#8387c3]/15 shadow-[inset_0_0_0_1px_rgba(131,135,195,.12)]" : "border-white/10 bg-[#151420]/75 hover:border-[#8387c3]/30 hover:bg-[#1b1929]"}`}>
              <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl ${selected ? "bg-[#8387c3]/20 text-[#c7c8f4]" : "bg-white/[.04] text-[#9996b2] group-hover:text-[#c7c8f4]"}`}><Icon className="h-[18px] w-[18px]" /></span>
              <span className="min-w-0 flex-1"><span className="block truncate text-sm font-medium text-[#eae7f5]">{fa ? definitions[key].titleFa : definitions[key].title}</span><span className="mt-1 block text-[11px] text-[#85829d]">{count.toLocaleString(fa ? "fa-IR" : "en-US")} {fa ? "رکورد" : "records"}</span></span>
              {selected && <span className="h-1.5 w-1.5 rounded-full bg-[#aeb0ee]" />}
            </button>;
          })}
        </section>

        <section className="overflow-hidden rounded-[26px] border border-white/10 bg-[#151420]/95 shadow-[0_24px_80px_rgba(0,0,0,.2)]">
          <div className="flex flex-col gap-4 border-b border-white/10 p-5 sm:p-6 lg:flex-row lg:items-center lg:justify-between">
            <div><div className="flex items-center gap-2 text-[#aeb0e7]"><span className="h-px w-6 bg-[#8387c3]" /><p className="text-[10px] font-semibold uppercase tracking-[.2em]">{fa ? "مدیریت محتوا" : "MANAGE YOUR STORE"}</p></div><h2 className="mt-2 font-serif text-2xl text-[#f0edf8] sm:text-3xl">{fa ? current.titleFa : current.title}</h2><p className="mt-1 max-w-2xl text-xs leading-6 text-[#9a97b0]">{fa ? current.descriptionFa : current.description}</p></div>
            <div className="flex shrink-0 flex-wrap gap-2">
              {active !== "orders" && active !== "customers" && <Button onClick={() => setEditing(toForm(active))} disabled={busy} className="bg-[#8387c3] text-[#0a1123] hover:bg-[#a0a3d8]"><Plus className="me-2 h-4 w-4" />{fa ? "افزودن مورد" : "Add new"}</Button>}
              <Button variant="outline" disabled={busy} onClick={() => void load(active)} className="border-white/15 bg-white/[.03] text-[#e8e6f4] hover:bg-white/[.08]"><RefreshCw className={`me-2 h-4 w-4 ${busy ? "animate-spin" : ""}`} />{fa ? "بارگذاری دوباره" : "Reload"}</Button>
            </div>
          </div>

          {notice && <div role="status" className="mx-5 mt-5 flex items-start gap-3 rounded-xl border border-[#8387c3]/25 bg-[#8387c3]/10 px-4 py-3 text-sm text-[#d4d3ef] sm:mx-6"><Check className="mt-0.5 h-4 w-4 shrink-0 text-[#aeb0ee]" /><span>{notice}</span><button type="button" className="ms-auto text-[#aaa7c1] hover:text-white" onClick={() => setNotice("")} aria-label={fa ? "بستن پیام" : "Dismiss message"}><X className="h-4 w-4" /></button></div>}

          {editing && <form onSubmit={(event) => { event.preventDefault(); void save(); }} className="m-5 grid gap-4 rounded-2xl border border-[#8387c3]/25 bg-[#100f1a] p-4 sm:m-6 sm:grid-cols-2 sm:p-6">
            <div className="sm:col-span-2 flex items-center justify-between gap-3 border-b border-white/10 pb-4"><div><p className="text-[10px] font-semibold uppercase tracking-[.2em] text-[#aeb0e7]">{fa ? "فرم ویرایش" : "EDIT WORKSPACE"}</p><h3 className="mt-1 font-serif text-xl">{fa ? "اطلاعات رکورد" : "Record details"}</h3></div><button type="button" onClick={() => setEditing(null)} className="rounded-lg p-2 text-[#9996b2] hover:bg-white/5 hover:text-white" aria-label={fa ? "بستن فرم" : "Close form"}><X className="h-4 w-4" /></button></div>
            {current.fields.map((field) => {
              const value = editing[field.name];
              const label = fa ? field.labelFa : field.label;
              const help = fa ? field.helpFa : field.help;
              if (active === "orders" && !["status","payment_status"].includes(field.name)) return <div key={field.name} className="min-w-0"><span className="mb-2 block text-[11px] text-[#8f8ba6]">{label}</span><div className="break-words rounded-xl border border-white/5 bg-white/[.025] px-3 py-3 text-sm text-[#d0cde0]">{asText(value) || "—"}</div></div>;
              if (active === "promotions" && field.name === "usage_count") return <div key={field.name}><span className="mb-2 block text-[11px] text-[#8f8ba6]">{label}</span><div className="rounded-xl border border-white/5 bg-white/[.025] px-3 py-3 text-sm text-[#d0cde0]">{asText(value) || "0"}</div></div>;
              return <label key={field.name} className={field.type === "textarea" ? "sm:col-span-2" : ""}><span className="mb-2 block text-[11px] text-[#b3b0c8]">{label}{field.required ? " *" : ""}</span>
                {field.type === "textarea" ? <textarea className={inputClass} rows={3} required={field.required} value={asText(value)} onChange={(event) => setEditing({ ...editing, [field.name]: event.target.value })} />
                  : field.type === "select" ? <select className={inputClass} required={field.required} value={asText(value)} onChange={(event) => setEditing({ ...editing, [field.name]: event.target.value })}>{field.options?.map((option) => <option key={option} value={option}>{option}</option>)}</select>
                    : field.type === "checkbox" ? <span className="flex min-h-12 items-center gap-3 rounded-xl border border-white/10 bg-white/[.025] px-3"><input type="checkbox" className="h-4 w-4 accent-[#8387c3]" checked={Boolean(value)} onChange={(event) => setEditing({ ...editing, [field.name]: event.target.checked })} /><span className="text-sm text-[#d0cde0]">{fa ? "فعال باشد" : "Enabled"}</span></span>
                      : <input className={inputClass} type={field.type === "number" ? "number" : "text"} min={field.type === "number" ? 0 : undefined} step={field.name === "discount_value" || field.name === "minimum_order" ? "0.01" : "1"} required={field.required} value={asText(value)} onChange={(event) => setEditing({ ...editing, [field.name]: event.target.value })} />}
                {help && <span className="mt-1.5 block text-[11px] leading-5 text-[#77738b]">{help}</span>}
              </label>;
            })}
            <div className="flex flex-wrap gap-2 border-t border-white/10 pt-4 sm:col-span-2"><Button type="submit" disabled={busy} className="bg-[#8387c3] text-[#0a1123] hover:bg-[#a0a3d8]"><Save className="me-2 h-4 w-4" />{busy ? (fa ? "در حال ذخیره…" : "Saving…") : (fa ? "ذخیره تغییرات" : "Save changes")}</Button><Button type="button" variant="outline" disabled={busy} onClick={() => setEditing(null)} className="border-white/15 bg-white/[.03] text-[#e8e6f4] hover:bg-white/[.08]">{fa ? "انصراف" : "Cancel"}</Button></div>
          </form>}

          <div className="flex flex-col gap-3 border-b border-white/10 p-4 sm:flex-row sm:items-center sm:p-5">
            <div className="relative min-w-0 flex-1"><Search className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#77738b]" /><input value={query} onChange={(event) => setQuery(event.target.value)} className={inputClass + " ps-10"} placeholder={fa ? "جست‌وجو در این بخش…" : "Search this section…"} aria-label={fa ? "جست‌وجو" : "Search records"} /></div>
            <select value={filter} onChange={(event) => setFilter(event.target.value)} className={inputClass + " sm:w-auto sm:min-w-44"} aria-label={fa ? "فیلتر رکوردها" : "Filter records"}>{filterOptions.map(([value,label]) => <option key={value} value={value}>{label}</option>)}</select>
            <p className="whitespace-nowrap text-xs text-[#8e8aa5]">{visibleRows.length.toLocaleString(fa ? "fa-IR" : "en-US")} {fa ? "مورد" : "records"}</p>
          </div>

          <div className="divide-y divide-white/[.07]">
            {busy && rows.length === 0 ? <div className="flex items-center justify-center gap-3 p-12 text-sm text-[#9996b2]"><Loader2 className="h-4 w-4 animate-spin" />{fa ? "در حال دریافت اطلاعات…" : "Loading records…"}</div>
              : visibleRows.length === 0 ? <div className="flex flex-col items-center px-5 py-14 text-center"><span className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl border border-white/10 bg-white/[.03] text-[#9693b0]"><Package className="h-5 w-5" /></span><p className="font-medium text-[#d9d6e8]">{fa ? "موردی پیدا نشد" : "Nothing to show yet"}</p><p className="mt-2 max-w-sm text-xs leading-6 text-[#85829d]">{fa ? "با تغییر فیلتر یا جست‌وجو دوباره امتحان کن." : "Try another filter or search term, or add your first record."}</p></div>
              : visibleRows.map((row) => {
                const expanded = expandedId === row.id;
                const lines = Array.isArray(row.items) ? row.items as OrderLine[] : [];
                const title = active === "orders" ? asText(row.order_number) : active === "promotions" ? asText(row.code) : active === "homepage" ? asText(row.section_key) : active === "shipping" ? asText(row.name) : active === "customers" ? asText(row.customer_name) : asText(row.title);
                const subtitle = active === "orders"
                  ? [row.customer_name,row.customer_email].map(asText).filter(Boolean).join(" · ")
                  : active === "promotions" ? asText(row.name)
                    : active === "homepage" ? asText(row.title_fa || row.title_en || row.section_type)
                      : active === "shipping" ? asText(row.name_fa || row.zone)
                        : active === "customers" ? [row.customer_email,row.customer_phone].map(asText).filter(Boolean).join(" · ")
                          : asText(row.asset_url);
                const status = active === "orders" ? asText(row.status) : active === "promotions" || active === "shipping" ? (row.is_active ? "active" : "inactive") : active === "homepage" ? (row.is_visible ? "visible" : "hidden") : active === "customers" ? (fa ? "مشتری" : "customer") : asText(row.media_type);
                const statusColor = ["completed","active","visible","image"].includes(status) ? "border-emerald-300/20 bg-emerald-300/[.07] text-emerald-200" : ["pending","processing","video"].includes(status) ? "border-amber-200/20 bg-amber-200/[.06] text-amber-100" : ["cancelled","refunded","inactive","hidden"].includes(status) ? "border-rose-300/20 bg-rose-300/[.06] text-rose-200" : "border-[#8387c3]/25 bg-[#8387c3]/10 text-[#c2c3ec]";
                return <article key={row.id} className="px-4 py-4 transition-colors hover:bg-white/[.018] sm:px-5">
                  <div className="flex flex-wrap items-center gap-3">
                    {active === "media" && row.media_type === "image" && /^https:\/\//i.test(asText(row.asset_url)) ? <img src={asText(row.asset_url)} alt="" loading="lazy" className="h-14 w-14 rounded-xl border border-white/10 object-cover" /> : <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/[.035] text-[#a9a6c8]">{active === "orders" ? <ShoppingBag className="h-5 w-5" /> : active === "promotions" ? <Tag className="h-5 w-5" /> : active === "homepage" ? <LayoutDashboard className="h-5 w-5" /> : active === "customers" ? <UserRound className="h-5 w-5" /> : <FileImage className="h-5 w-5" />}</span>}
                    <div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h3 className="max-w-full truncate text-sm font-semibold text-[#efedf7]">{title || "—"}</h3><span className={`rounded-full border px-2.5 py-1 text-[10px] font-medium ${statusColor}`}>{status || "—"}</span></div><p className="mt-1 truncate text-xs text-[#aaa7c1]">{subtitle || "—"}</p>
                      <p className="mt-1 text-[11px] text-[#77738b]">{active === "orders" ? money(row.total,row.currency) + (row.promotion_code ? " · " + asText(row.promotion_code) + " (-" + money(row.discount_total,row.currency) + ")" : "") + " · " + asText(row.payment_status) + " · " + dateLabel(row.created_at,fa) : active === "promotions" ? (row.discount_type === "percent" ? asText(row.discount_value) + "%" : money(row.discount_value,"EUR")) + " · " + asText(row.usage_count) + (fa ? " بار استفاده" : " uses") : active === "homepage" ? (fa ? "ترتیب " : "Order ") + asText(row.sort)
                        : active === "shipping" ? money(row.price,"EUR") + " · " + asText(row.zone) + " · " + asText(row.estimated_min_days) + "–" + asText(row.estimated_max_days) + (fa ? " روز" : " days")
                        : active === "customers" ? asText(row.order_count) + (fa ? " سفارش · ارزش کل " : " orders · order value ") + money(row.order_value_total,row.currency) + " · " + dateLabel(row.last_order_at,fa)
                          : asText(row.mime_type) || asText(row.media_type)}</p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      {active === "homepage" && <><Button type="button" variant="ghost" size="icon" disabled={busy || rows.findIndex((item) => item.id === row.id) === 0} onClick={() => void moveHomepageSection(row,-1)} aria-label={fa ? "انتقال به بالا" : "Move up"} className="text-[#a6a3bd] hover:bg-white/10 hover:text-white"><ArrowUp className="h-4 w-4" /></Button><Button type="button" variant="ghost" size="icon" disabled={busy || rows.findIndex((item) => item.id === row.id) === rows.length - 1} onClick={() => void moveHomepageSection(row,1)} aria-label={fa ? "انتقال به پایین" : "Move down"} className="text-[#a6a3bd] hover:bg-white/10 hover:text-white"><ArrowDown className="h-4 w-4" /></Button></>}
                      {active === "orders" && <Button type="button" variant="ghost" size="sm" onClick={() => setExpandedId(expanded ? null : row.id)} className="text-[#b9b6d0] hover:bg-white/10 hover:text-white">{fa ? "جزئیات" : "Details"}{expanded ? <ChevronUp className="ms-1 h-4 w-4" /> : <ChevronDown className="ms-1 h-4 w-4" />}</Button>}
                      {active !== "customers" && <Button type="button" variant="outline" size="sm" disabled={busy} onClick={() => setEditing(toForm(active,row))} className="border-white/15 bg-white/[.03] text-[#e8e6f4] hover:bg-white/[.08]">{active === "orders" ? (fa ? "وضعیت" : "Update") : (fa ? "ویرایش" : "Edit")}</Button>}
                      {active !== "orders" && active !== "customers" && <Button type="button" variant="ghost" size="icon" disabled={busy} onClick={() => void remove(row)} aria-label={fa ? "حذف رکورد" : "Delete record"} className="text-[#9b91a9] hover:bg-rose-400/10 hover:text-rose-200"><Trash2 className="h-4 w-4" /></Button>}
                    </div>
                  </div>
                  {expanded && active === "orders" && <div className="mt-4 rounded-2xl border border-white/10 bg-[#100f1a] p-4 sm:ms-15">
                    <div className="mb-3 flex flex-wrap items-center justify-between gap-2"><p className="text-xs font-semibold uppercase tracking-[.16em] text-[#aaa7c1]">{fa ? "اقلام سفارش" : "ORDER ITEMS"}</p><p className="text-xs text-[#9996b2]">{lines.length} {fa ? "قلم" : "items"}</p></div>
                    {lines.length ? <div className="space-y-2">{lines.map((line) => <div key={line.id} className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[.06] pb-2 text-xs last:border-0"><div><p className="font-medium text-[#e8e6f4]">{line.product_name}</p><p className="mt-1 text-[#85829d]">{line.brand_name || "—"} · {line.size_ml || "—"} ml · {fa ? "تعداد" : "Qty"} {line.quantity}</p></div><p className="font-medium tabular-nums text-[#d1ceeb]">{money(line.line_total,row.currency)}</p></div>)}</div> : <p className="text-xs text-[#85829d]">{fa ? "جزئیات اقلام برای این سفارش ثبت نشده." : "No line items were stored for this order."}</p>}
                    <div className="mt-4 grid gap-3 border-t border-white/[.08] pt-3 text-xs sm:grid-cols-2 xl:grid-cols-4"><div><p className="text-[#85829d]">{fa ? "نشانی ارسال" : "Shipping address"}</p><p className="mt-1 leading-6 text-[#d0cde0]">{[row.shipping_address,row.shipping_city,row.shipping_postcode].map(asText).filter(Boolean).join(" · ") || "—"}</p></div><div><p className="text-[#85829d]">{fa ? "روش ارسال" : "Delivery method"}</p><p className="mt-1 leading-6 text-[#d0cde0]">{asText(fa ? row.shipping_method_name_fa || row.shipping_method_name : row.shipping_method_name) || (fa ? "هماهنگی بعدی" : "To be confirmed")}{row.shipping_zone ? " · " + asText(row.shipping_zone) : ""}{row.shipping_eta_min_days !== null && row.shipping_eta_min_days !== undefined ? " · " + asText(row.shipping_eta_min_days) + "–" + asText(row.shipping_eta_max_days) + (fa ? " روز" : " days") : ""} · {money(row.shipping_total,row.currency)}</p></div><div><p className="text-[#85829d]">{fa ? "تخفیف اعمال‌شده" : "Applied discount"}</p><p className="mt-1 leading-6 text-[#d0cde0]">{asText(row.promotion_code) || (fa ? "بدون کد" : "No code")} · {money(row.discount_total,row.currency)}</p></div><div><p className="text-[#85829d]">{fa ? "یادداشت مشتری" : "Customer note"}</p><p className="mt-1 leading-6 text-[#d0cde0]">{asText(row.customer_note) || "—"}</p></div></div>
                  </div>}
                </article>;
              })}
          </div>
        </section>

        <footer className="mt-5 flex flex-wrap items-start justify-between gap-3 text-[11px] leading-6 text-[#77738b]"><p>{active === "orders" ? (fa ? "درخواست‌های سبد به‌صورت pending و unpaid ذخیره می‌شوند. پیش از تأیید، موجودی و هزینه ارسال را بررسی کن؛ هیچ پرداختی دریافت نمی‌شود." : "Cart requests are saved as pending and unpaid. Confirm stock and shipping before approval; no payment is collected.") : active === "promotions" ? (fa ? "کدهای فعال هنگام ثبت درخواست سفارش اعتبارسنجی و اعمال می‌شوند؛ شمارنده استفاده فقط پس از ثبت موفق افزایش می‌یابد." : "Active codes are validated and applied to order requests; usage counts increase only after a request is saved.") : active === "homepage" ? (fa ? "سکشن‌های قابل نمایش از D1 در صفحهٔ اصلی خوانده می‌شوند؛ ترتیب و زمان‌بندی در همین پنل مدیریت می‌شود." : "Visible sections are read from D1 by the homepage; ordering and scheduling are managed here.") : active === "shipping" ? (fa ? "روش‌ها در D1 ذخیره و هنگام ثبت درخواست سفارش انتخاب می‌شوند؛ هزینه و آستانه ارسال رایگان سمت سرور محاسبه و جزئیات روش در سفارش ذخیره می‌شود." : "Methods are saved in D1 and selected during order requests; fees and free-shipping thresholds are calculated server-side and snapshotted on the order.") : active === "customers" ? (fa ? "این فهرست فقط‌خواندنی از سفارش‌های ثبت‌شده ساخته شده است؛ ارزش کل شامل درخواست‌های در انتظار نیز می‌شود." : "This read-only directory is derived from saved orders; order value includes pending requests as well.") : (fa ? "این بخش فعلاً فراداده و آدرس رسانه را نگه می‌دارد؛ فایل اصلی در فضای خارجی میزبانی می‌شود." : "This module stores media metadata and URLs; the actual file remains hosted externally.")}</p><Link to="/admin" className="inline-flex items-center gap-1 whitespace-nowrap text-[#b7b9eb] hover:text-white">{fa ? "بازگشت به داشبورد" : "Back to dashboard"}<ArrowLeft className="h-3.5 w-3.5" /></Link></footer>
      </div>
    </main>
  );
}
