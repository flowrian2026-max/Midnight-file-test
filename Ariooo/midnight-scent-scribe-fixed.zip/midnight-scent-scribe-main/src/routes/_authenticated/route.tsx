import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    try {
      const response = await fetch("/api/d1/admin/session", {
        cache: "no-store",
        credentials: "same-origin",
      });
      if (!response.ok) throw redirect({ to: "/auth" });
      const payload = await response.json() as { ok?: boolean; user?: { id: string; email: string } };
      if (!payload.ok || !payload.user) throw redirect({ to: "/auth" });
      return { user: payload.user };
    } catch (error) {
      if (error != null && typeof error === "object" && "to" in error) throw error;
      throw redirect({ to: "/auth" });
    }
  },
  component: () => <Outlet />,
});
