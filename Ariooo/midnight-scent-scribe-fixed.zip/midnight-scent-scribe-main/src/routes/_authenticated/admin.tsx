import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Activity, AlertTriangle, ArrowRight, Boxes, CheckCircle2, ChevronRight,
  CircleAlert, Database, ExternalLink, Eye, LayoutDashboard, LogOut, Package,
  Pencil, Plus, RefreshCw, Search, ShieldCheck, Sparkles, Store, Tags, Truck, UserRound, Warehouse,
} from "lucide-react";
import { useLanguage } from "@/components/site/language";
import { pageHead } from "@/components/site/pages";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { brandsQuery, categoriesQuery, productsQuery, resolveImg } from "@/lib/catalog";
import { isRemoteCatalogEnabled } from "@/lib/remote-catalog";
import { summarizeCatalog } from "@/lib/admin-metrics";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    ...pageHead("Store control room", "Private administration dashboard for Scent Scribe."),
    meta: [...pageHead("Store control room", "Private administration dashboard for Scent Scribe.").meta, { name: "robots", content: "noindex" }],
  }),
  component: AdminPage,
});

type StockFilter = "all" | "low" | "out";
const panel = "rounded-2xl border border-border/70 bg-card/70 shadow-sm";
const eyebrow = "text-[0.65rem] font-medium uppercase tracking-[0.18em] text-muted-foreground";
const numberFormat = new Intl.NumberFormat("en-US");
const money = (value: number) => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 2 }).format(value);

function AdminPage() {
  const { fa } = useLanguage();
  const remoteMode = isRemoteCatalogEnabled();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [stockFilter, setStockFilter] = useState<StockFilter>("all");
  const role = useQuery({
    queryKey: ["is-admin"],
    queryFn: async () => {
      const response = await fetch("/api/d1/admin/session", { cache: "no-store", credentials: "same-origin" });
      if (!response.ok) return false;
      const result = await response.json() as { ok?: boolean; user?: { id: string; email: string } };
      return result.ok === true && Boolean(result.user?.id);
    },
    retry: false,
  });
  const products = useQuery(productsQuery);
  const brands = useQuery(brandsQuery);
  const categories = useQuery(categoriesQuery);
  const productList = products.data ?? [];
  const brandList = brands.data ?? [];
  const categoryList = categories.data ?? [];
  const summary = summarizeCatalog(productList);

  const visibleProducts = useMemo(() => {
    const needle = search.trim().toLocaleLowerCase();
    return productList.filter((product) => {
      const brandName = brandList.find((brand) => brand.slug === product.brand_slug)?.name ?? "";
      const matchesSearch = !needle || [product.name, product.slug, brandName].some((value) => value.toLocaleLowerCase().includes(needle));
      const stock = product.volumes.reduce((total, volume) => total + volume.stock, 0);
      const low = product.volumes.some((volume) => volume.stock > 0 && volume.stock <= 2);
      const matchesStock = stockFilter === "all" || (stockFilter === "low" && low) || (stockFilter === "out" && stock === 0);
      return matchesSearch && matchesStock;
    });
  }, [brandList, productList, search, stockFilter]);

  const refresh = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: ["products"] }),
      queryClient.invalidateQueries({ queryKey: ["brands"] }),
      queryClient.invalidateQueries({ queryKey: ["categories"] }),
    ]);
  };
  const signOut = async () => {
    await fetch("/api/d1/admin/logout", { method: "POST", credentials: "same-origin" }).catch(() => undefined);
    await navigate({ to: "/auth" });
  };

  if (role.isLoading) return <section className="mx-auto max-w-7xl px-5 py-20"><div className={panel + " flex items-center gap-3 p-8"}><Activity className="h-5 w-5 animate-pulse text-primary" /><p>{fa ? "در حال بررسی دسترسی مدیریت…" : "Verifying administrator access…"}</p></div></section>;

  if (role.isError || role.data !== true) {
    return <section className="mx-auto max-w-2xl px-5 py-20"><div className={panel + " p-8 md:p-10"}>
      <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-full border border-primary/30 bg-primary/10 text-primary"><ShieldCheck className="h-6 w-6" /></div>
      <p className={eyebrow}>SCENT SCRIBE · PRIVATE AREA</p>
      <h1 className="mt-3 font-serif text-3xl md:text-4xl">{fa ? "دسترسی مدیریت" : "Administrator access"}</h1>
      <p className="mt-4 text-sm leading-7 text-muted-foreground">{role.isError
        ? (fa ? "دسترسی مدیر تأیید نشد. اتصال D1 و نشست مدیر را بررسی کنید." : "Administrator access could not be verified. Check the D1 database and admin session.")
        : (fa ? "این بخش فقط برای حساب‌هایی است که نقش مدیر آن‌ها در سرور تأیید شده باشد." : "This area is restricted to accounts whose administrator role is verified by the backend.")}</p>
      <div className="mt-7 flex flex-wrap gap-3"><Button onClick={() => void role.refetch()}>{fa ? "بررسی دوباره" : "Try again"}</Button><Button variant="outline" onClick={() => void signOut()}>{fa ? "خروج" : "Sign out"}</Button></div>
    </div></section>;
  }

  const navItems = [
    { label: fa ? "نمای کلی" : "Overview", icon: LayoutDashboard, active: true, to: "/admin" as const },
    { label: fa ? "محصولات و موجودی" : "Products & stock", icon: Package, active: false, to: "/demo-editor" as const },
    { label: fa ? "برندها" : "Brands", icon: Tags, active: false, to: "/demo-editor" as const },
    { label: fa ? "دسته‌بندی‌ها" : "Categories", icon: Boxes, active: false, to: "/demo-editor" as const },
  ];
  const statItems = [
    { label: fa ? "کل محصولات" : "Total products", value: summary.products, detail: fa ? "در کاتالوگ نمونه" : "In the demo catalogue", icon: Package, tone: "text-primary bg-primary/10 border-primary/20" },
    { label: fa ? "منتشرشده" : "Published", value: summary.publishedProducts, detail: fa ? summary.draftProducts + " پیش‌نویس" : summary.draftProducts + " drafts", icon: CheckCircle2, tone: "text-emerald-300 bg-emerald-400/10 border-emerald-400/20" },
    { label: fa ? (remoteMode ? "واحد موجود" : "موجودی نمایشی") : (remoteMode ? "Units in stock" : "Demo units in stock"), value: summary.unitsInStock, detail: fa ? summary.totalVariants + " سایز شیشه" : summary.totalVariants + " bottle sizes", icon: Warehouse, tone: "text-sky-300 bg-sky-400/10 border-sky-400/20" },
    { label: fa ? "هشدار موجودی" : "Stock alerts", value: summary.lowStockVariants + summary.outOfStockVariants, detail: fa ? summary.lowStockVariants + " کم‌موجود · " + summary.outOfStockVariants + " ناموجود" : summary.lowStockVariants + " low · " + summary.outOfStockVariants + " out", icon: AlertTriangle, tone: "text-amber-200 bg-amber-300/10 border-amber-300/20" },
  ];

  return <div dir={fa ? "rtl" : "ltr"} className="ss-admin-shell min-h-screen">
    <div className="ss-admin-container mx-auto max-w-[1500px] px-4 py-6 sm:px-6 lg:px-8 lg:py-10">
      <header className="ss-admin-header mb-8 flex flex-col gap-5 border-b border-border/70 pb-7 md:flex-row md:items-end md:justify-between">
        <div><div className="mb-4 flex items-center gap-2 text-primary"><Sparkles className="h-4 w-4" /><span className={eyebrow}>SCENT SCRIBE / CONTROL ROOM</span></div>
          <h1 className="font-serif text-4xl tracking-tight sm:text-5xl">{fa ? "مرکز مدیریت فروشگاه" : "Store control room"}</h1>
          <p className="mt-3 max-w-2xl text-sm leading-7 text-muted-foreground">{fa ? "کاتالوگ، برندها و وضعیت موجودی را از یک نمای واحد بررسی کنید." : "A single workspace to review your catalogue, brands and stock status."}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => void refresh()} disabled={products.isFetching || brands.isFetching}><RefreshCw className={`me-2 h-4 w-4 ${products.isFetching || brands.isFetching ? "animate-spin" : ""}`} />{fa ? "تازه‌سازی" : "Refresh"}</Button>
          <Button asChild variant="outline"><Link to="/studio"><Sparkles className="me-2 h-4 w-4" />{fa ? "کتابخانه الگوهای استودیو" : "Studio template lab"}</Link></Button>
          <Button asChild variant="outline"><Link to="/"><Store className="me-2 h-4 w-4" />{fa ? "مشاهده فروشگاه" : "View storefront"}<ExternalLink className="ms-2 h-3.5 w-3.5" /></Link></Button>
          <Button variant="ghost" onClick={() => void signOut()}><LogOut className="me-2 h-4 w-4" />{fa ? "خروج" : "Sign out"}</Button>
        </div>
      </header>


      <div className="ss-admin-marquee" aria-label={fa ? "رایحه، ظرافت، جزئیات" : "The art of scent, detail and discovery"}>
        <div className="ss-admin-marquee__track" aria-hidden="true">
          {[0, 1].map((copy) => <div className="ss-admin-marquee__group" key={copy}><span>{fa ? "هنر رایحه" : "THE ART OF SCENT"}</span><i>✳</i><span>{fa ? "ظرافت در جزئیات" : "DETAIL IS EVERYTHING"}</span><i>✳</i><span>{fa ? "انتخابی ماندگار" : "A LASTING SIGNATURE"}</span><i>✳</i><span>{fa ? "تجربه‌ای شخصی" : "A PERSONAL EXPERIENCE"}</span><i>✳</i></div>)}
        </div>
      </div>
      <div className="ss-admin-layout grid gap-6 lg:grid-cols-[220px_minmax(0,1fr)] xl:grid-cols-[240px_minmax(0,1fr)]">
        <aside className="space-y-5">
          <nav aria-label={fa ? "منوی مدیریت" : "Admin navigation"} className={"ss-admin-sidebar " + panel + " p-3"}>
            <p className={eyebrow + " px-3 pb-3 pt-2"}>{fa ? "فضای کار" : "Workspace"}</p>
            <div className="flex gap-2 overflow-x-auto lg:flex-col">{navItems.map(({ label, icon: Icon, active, to }) => <Link key={label} to={to} className={`flex min-w-max items-center gap-3 rounded-xl px-3 py-3 text-sm transition-colors ${active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted hover:text-foreground"}`}><Icon className="h-4 w-4 shrink-0" /><span>{label}</span>{!active && <ChevronRight className="ms-auto h-3.5 w-3.5 opacity-50" />}</Link>)}</div>
            <div className="my-4 border-t border-border/70" /><p className={eyebrow + " px-3 pb-2"}>{fa ? "عملیات فروشگاه" : "Store operations"}</p>
            <Link to="/operations" className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"><Warehouse className="h-4 w-4" /><span>{fa ? "سفارش‌ها" : "Orders"}</span><ChevronRight className="ms-auto h-3.5 w-3.5 opacity-50" /></Link>
            <Link to="/operations" className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"><Activity className="h-4 w-4" /><span>{fa ? "تخفیف و کمپین" : "Promotions"}</span><ChevronRight className="ms-auto h-3.5 w-3.5 opacity-50" /></Link>
            <Link to="/operations" className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"><Database className="h-4 w-4" /><span>{fa ? "صفحه اصلی و رسانه" : "Homepage & media"}</span><ChevronRight className="ms-auto h-3.5 w-3.5 opacity-50" /></Link>
            <Link to="/operations" className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"><Truck className="h-4 w-4" /><span>{fa ? "روش‌های ارسال" : "Shipping methods"}</span><ChevronRight className="ms-auto h-3.5 w-3.5 opacity-50" /></Link>
            <Link to="/operations" className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"><UserRound className="h-4 w-4" /><span>{fa ? "مشتری‌ها" : "Customers"}</span><ChevronRight className="ms-auto h-3.5 w-3.5 opacity-50" /></Link>
          </nav>
          <div className={panel + " p-5"}><div className="flex items-center gap-2 text-primary"><ShieldCheck className="h-4 w-4" /><span className={eyebrow}>{fa ? "دسترسی مدیر" : "Admin access"}</span></div><p className="mt-3 font-medium">{fa ? "حساب تأیید شد" : "Administrator verified"}</p><p className="mt-2 text-xs leading-6 text-muted-foreground">{fa ? "نقش مدیر از طریق نشست امن Cloudflare D1 بررسی شده است." : "Administrator role verified through the secure Cloudflare D1 session."}</p></div>
        </aside>

        <main className="min-w-0 space-y-6">
          <section className="ss-admin-hero relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/15 via-card to-card p-6 sm:p-8">
            <div className="pointer-events-none absolute -end-10 -top-24 h-60 w-60 rounded-full bg-primary/10 blur-3xl" />
            <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between"><div className="max-w-2xl"><p className={eyebrow}>{fa ? "مرور وضعیت" : "Store overview"}</p><h2 className="mt-3 font-serif text-2xl sm:text-3xl">{fa ? "نمای روزانه فروشگاه" : "Your daily store snapshot"}</h2><p className="mt-3 text-sm leading-7 text-muted-foreground">{remoteMode ? (fa ? "کاتالوگ و درخواست سفارش به D1 متصل‌اند؛ درخواست‌ها در انتظار بررسی می‌مانند و پرداخت/درآمد واقعی ثبت نمی‌شود." : "The shared catalogue and order requests use D1. Requests remain pending; no payment or sales revenue is recorded.") : (fa ? "این آمار از کاتالوگ نمایشی همین مرورگر خوانده می‌شود؛ فروش، سفارش یا درآمد واقعی نمایش داده نمی‌شود." : "These metrics come from this browser’s demo catalogue. No real sales, orders or revenue are reported.")}</p></div>
              <Button asChild className="shrink-0"><Link to="/demo-editor"><Plus className="me-2 h-4 w-4" />{fa ? "مدیریت کاتالوگ" : "Manage catalogue"}<ArrowRight className="ms-2 h-4 w-4" /></Link></Button>
            </div>
          </section>

          {(products.isError || brands.isError || categories.isError) && <div role="alert" className="flex items-start gap-3 rounded-xl border border-destructive/30 bg-destructive/5 p-4 text-sm"><CircleAlert className="mt-0.5 h-4 w-4 shrink-0 text-destructive" /><p>{fa ? "خواندن بخشی از کاتالوگ ناموفق بود. اتصال داده را بررسی و تازه‌سازی کنید." : "Part of the catalogue could not be loaded. Check the data source and refresh."}</p></div>}

          <section aria-label={fa ? "آمار کاتالوگ" : "Catalogue metrics"} className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {statItems.map(({ label, value, detail, icon: Icon, tone }) => <div key={label} className={"ss-admin-stat " + panel + " p-5"}><div className="flex items-start justify-between gap-3"><p className="text-sm text-muted-foreground">{label}</p><span className={`flex h-9 w-9 items-center justify-center rounded-xl border ${tone}`}><Icon className="h-4 w-4" /></span></div><p className="mt-4 text-3xl font-semibold tabular-nums">{numberFormat.format(value)}</p><p className="mt-2 text-xs text-muted-foreground">{detail}</p></div>)}
          </section>

          <div className="grid gap-6 xl:grid-cols-[minmax(0,1.65fr)_minmax(280px,0.85fr)]">
            <section className={"ss-admin-products " + panel + " min-w-0 overflow-hidden"}>
              <div className="flex flex-col gap-4 border-b border-border/70 p-5 sm:flex-row sm:items-end sm:justify-between"><div><p className={eyebrow}>{fa ? "کاتالوگ" : "Catalogue"}</p><h2 className="mt-2 font-serif text-2xl">{fa ? "محصولات" : "Products"}</h2><p className="mt-1 text-sm text-muted-foreground">{fa ? visibleProducts.length + " مورد از " + productList.length + " محصول" : visibleProducts.length + " of " + productList.length + " products"}</p></div><Button asChild size="sm"><Link to="/demo-editor"><Plus className="me-2 h-4 w-4" />{fa ? "افزودن / ویرایش" : "Add / edit"}</Link></Button></div>
              <div className="flex flex-col gap-3 border-b border-border/70 p-4 sm:flex-row"><div className="relative min-w-0 flex-1"><Search className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" /><Input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={fa ? "جست‌وجوی نام یا برند…" : "Search products or brands…"} className="ps-9" aria-label={fa ? "جست‌وجوی محصولات" : "Search products"} /></div>
                <div className="flex gap-1 rounded-xl border border-border/70 bg-background/50 p-1">{([["all", fa ? "همه" : "All"], ["low", fa ? "کم‌موجود" : "Low stock"], ["out", fa ? "ناموجود" : "Out of stock"]] as const).map(([value, label]) => <button key={value} type="button" aria-pressed={stockFilter === value} onClick={() => setStockFilter(value)} className={`rounded-lg px-3 py-2 text-xs transition-colors ${stockFilter === value ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>{label}</button>)}</div>
              </div>
              <Table><TableHeader><TableRow><TableHead>{fa ? "محصول" : "Product"}</TableHead><TableHead>{fa ? (remoteMode ? "قیمت" : "قیمت نمونه") : (remoteMode ? "Price" : "Demo price")}</TableHead><TableHead>{fa ? "موجودی" : "Stock"}</TableHead><TableHead>{fa ? "وضعیت" : "Status"}</TableHead><TableHead className="text-end">{fa ? "ویرایش" : "Edit"}</TableHead></TableRow></TableHeader><TableBody>
                {visibleProducts.map((product) => {
                  const brand = brandList.find((item) => item.slug === product.brand_slug);
                  const configuredVolumes = product.volumes.filter((volume) => !volume.id.startsWith("unconfigured-"));
                  const hasConfiguredVolumes = configuredVolumes.length > 0;
                  const stock = configuredVolumes.reduce((sum, volume) => sum + volume.stock, 0);
                  const low = configuredVolumes.some((volume) => volume.stock > 0 && volume.stock <= 2);
                  const lowestPrice = configuredVolumes.reduce((min, volume) => Math.min(min, volume.price), Number.POSITIVE_INFINITY);
                  const statusText = !product.published ? (fa ? "پیش‌نویس" : "Draft") : !hasConfiguredVolumes ? (fa ? "حجم تنظیم نشده" : "Sizes not set") : stock === 0 ? (fa ? "ناموجود" : "Out of stock") : low ? (fa ? "کم‌موجود" : "Low stock") : (fa ? "منتشرشده" : "Published");
                  const statusClass = !product.published ? "border-border text-muted-foreground" : !hasConfiguredVolumes || low ? "border-amber-300/30 bg-amber-300/5 text-amber-200" : stock === 0 ? "border-destructive/30 bg-destructive/5 text-destructive" : "border-emerald-300/20 bg-emerald-300/5 text-emerald-200";
                  const dotClass = !product.published ? "bg-muted-foreground" : !hasConfiguredVolumes || low ? "bg-amber-300" : stock === 0 ? "bg-destructive" : "bg-emerald-300";
                  return <TableRow key={product.id}><TableCell><div className="flex min-w-[175px] items-center gap-3"><img src={resolveImg(product.image_url)} alt="" className="h-12 w-10 rounded-lg border border-border/60 object-cover" loading="lazy" /><div className="min-w-0"><p className="max-w-48 truncate font-medium">{product.name}</p><p className="mt-1 max-w-48 truncate text-xs text-muted-foreground">{brand?.name ?? product.brand_slug}</p><p className="mt-1 text-[0.65rem] text-muted-foreground">{hasConfiguredVolumes ? (fa ? configuredVolumes.length + " سایز" : configuredVolumes.length + " sizes") : (fa ? "حجم تنظیم نشده" : "Sizes not set")}</p></div></div></TableCell><TableCell className="whitespace-nowrap text-xs">{Number.isFinite(lowestPrice) ? money(lowestPrice) : "—"}</TableCell><TableCell className="whitespace-nowrap"><span className={stock === 0 ? "text-destructive" : low ? "text-amber-300" : "text-foreground"}>{stock}</span><span className="ms-1 text-xs text-muted-foreground">{fa ? "عدد" : "units"}</span></TableCell><TableCell><span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[0.68rem] ${statusClass}`}><span className={`h-1.5 w-1.5 rounded-full ${dotClass}`} />{statusText}</span></TableCell><TableCell className="text-end"><Button asChild size="icon" variant="ghost" aria-label={fa ? "ویرایش " + product.name : "Edit " + product.name}><Link to="/demo-editor"><Pencil className="h-4 w-4" /></Link></Button></TableCell></TableRow>;
                })}
                {visibleProducts.length === 0 && <TableRow><TableCell colSpan={5} className="py-12 text-center text-muted-foreground">{fa ? "محصولی با این فیلتر پیدا نشد." : "No products match these filters."}</TableCell></TableRow>}
              </TableBody></Table>
              <div className="flex items-center justify-between gap-3 border-t border-border/70 p-4 text-xs text-muted-foreground"><span>{remoteMode ? (fa ? "کاتالوگ مشترک و درخواست سفارش فعال است؛ پرداخت آنلاین فعال نیست." : "Shared catalogue and pending order requests are enabled; online payment is not.") : (fa ? "آمار و قیمت‌ها نمایشی هستند." : "Stock and prices are illustrative demo data.")}</span><Link to="/demo-editor" className="inline-flex items-center gap-1 whitespace-nowrap text-primary hover:underline">{fa ? "کاتالوگ کامل" : "Full catalogue"}<ArrowRight className="h-3 w-3" /></Link></div>
            </section>

            <div className="space-y-6">
              <section className={"ss-admin-side-card " + panel + " p-5"}><div className="mb-5 flex items-end justify-between gap-3"><div><p className={eyebrow}>{fa ? "برندهای فروشگاه" : "Brand partners"}</p><h2 className="mt-2 font-serif text-2xl">{fa ? "برندها" : "Brands"}</h2></div><Button asChild size="sm" variant="outline"><Link to="/demo-editor">{fa ? "مدیریت" : "Manage"}</Link></Button></div>
                <div className="space-y-1">{brandList.map((brand) => {const count = productList.filter((product) => product.brand_slug === brand.slug).length;return <div key={brand.slug} className="flex items-center justify-between gap-3 rounded-xl px-2 py-3 hover:bg-muted/40"><div className="min-w-0"><p className="truncate text-sm font-medium">{brand.name}</p><p className="mt-1 text-xs text-muted-foreground">{count} {fa ? "محصول" : count === 1 ? "product" : "products"}</p></div><ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" /></div>;})}{brandList.length === 0 && <p className="py-4 text-sm text-muted-foreground">{fa ? "برندی ثبت نشده." : "No brands found."}</p>}</div>
                <div className="mt-4 flex items-center justify-between border-t border-border/70 pt-4 text-xs text-muted-foreground"><span>{categoryList.length} {fa ? "دسته‌بندی" : "categories"}</span><span className="inline-flex items-center gap-1"><Tags className="h-3.5 w-3.5" />{brandList.length} {fa ? "برند" : "brands"}</span></div>
              </section>
              <section className={panel + " p-5"}><div className="flex items-center gap-2 text-primary"><Database className="h-4 w-4" /><p className={eyebrow}>{fa ? "وضعیت داده" : "Data status"}</p></div><div className={"mt-4 flex items-center gap-2 " + (remoteMode ? "text-emerald-300" : "text-amber-200")}><CircleAlert className="h-4 w-4" /><span className="text-sm font-medium">{remoteMode ? (fa ? "کاتالوگ مشترک فعال" : "Shared catalogue active") : (fa ? "ذخیره‌سازی محلی" : "Local demo storage")}</span></div><p className="mt-3 text-sm leading-7 text-muted-foreground">{remoteMode ? (fa ? "محصولات، برندها و موجودی از Cloudflare D1 خوانده می‌شوند. درخواست‌های سبد به‌صورت pending/unpaid ذخیره می‌شوند و مدیر می‌تواند وضعیتشان را تغییر دهد؛ پرداخت آنلاین هنوز متصل نیست." : "Products, brands and stock use the shared Cloudflare D1 catalogue. Cart requests are saved as pending/unpaid and can be managed here; online payments are not connected.") : (fa ? "تغییرات کاتالوگ فقط در همین مرورگر ذخیره می‌شود و به دستگاه یا بازدیدکنندگان دیگر نمی‌رسد. مدیریت واقعی سفارش و پایگاه‌داده هنوز متصل نشده." : "Catalogue edits are saved in this browser only and do not sync to other devices or visitors. Shared product persistence and order management are not connected yet.")}</p><div className="mt-5 rounded-xl border border-border/70 bg-background/40 p-3 text-xs leading-6 text-muted-foreground">{remoteMode ? (fa ? "گام بعدی: اتصال آپلود واقعی رسانه با R2 و تکمیل تنظیمات فروشگاه؛ پرداخت آنلاین فعلاً خارج از محدوده است." : "Next milestone: enable real media uploads with R2 and complete store settings; online payments remain out of scope for now.") : (fa ? "قدم بعدی: اتصال دیتابیس Cloudflare D1، اعمال مهاجرت و آزمایش نشست مدیر و ذخیره مشترک." : "Next milestone: connect the catalogue to database tables protected by administrator-only access policies.")}</div></section>
              <section className={panel + " p-5"}><div className="flex items-center gap-2 text-primary"><Eye className="h-4 w-4" /><p className={eyebrow}>{fa ? "دسترسی سریع" : "Quick links"}</p></div><div className="mt-4 space-y-2"><Button asChild variant="outline" className="w-full justify-between"><Link to="/demo-editor">{fa ? "ویرایش محصولات و برندها" : "Edit products & brands"}<ArrowRight className="h-4 w-4" /></Link></Button><Button asChild variant="outline" className="w-full justify-between"><Link to="/shop">{fa ? "پیش‌نمایش فروشگاه" : "Preview the shop"}<ArrowRight className="h-4 w-4" /></Link></Button><div className="flex items-start gap-2 rounded-xl bg-muted/40 p-3 text-xs leading-6 text-muted-foreground"><Sparkles className="mt-1 h-3.5 w-3.5 shrink-0 text-primary" />{fa ? "هویت سرمه‌ای، آلویی و یاسی Scent Scribe حفظ شده." : "Scent Scribe’s midnight navy, plum and lavender identity stays intact."}</div></div></section>
            </div>
          </div>
        </main>
      </div>
    </div>
  </div>;
}
