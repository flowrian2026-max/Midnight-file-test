import { createFileRoute } from '@tanstack/react-router';
import { AboutPage } from '@/components/site/about-page';
import { pageHead } from '@/components/site/pages';

export const Route = createFileRoute('/our-story')({
  head: () => pageHead('About Scent Scribe', 'The story, philosophy and fragrance discoveries behind Scent Scribe.'),
  component: AboutPage,
});
