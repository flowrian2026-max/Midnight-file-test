import { createFileRoute } from '@tanstack/react-router';
import { InfoPage, pageHead } from '@/components/site/pages';
export const Route = createFileRoute('/contact')({head: () => pageHead('Contact Us', 'Current contact availability and information for Scent Scribe enquiries.'), component: Page});
function Page() {return <InfoPage kind="contact"/>;}
