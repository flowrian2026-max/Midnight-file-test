import { createFileRoute } from '@tanstack/react-router';
import { FamiliesPage, pageHead } from '@/components/site/pages';
export const Route = createFileRoute('/scent-families')({head: () => pageHead('Scent Families', 'Explore floral, amber, woody, spicy and citrus fragrance families.'), component: FamiliesPage});
