import { createFileRoute } from '@tanstack/react-router';
import { InfoPage, pageHead } from '@/components/site/pages';
export const Route = createFileRoute('/sustainability')({head: () => pageHead('Sustainability', 'Thoughtful fragrance care and transparent environmental information.'), component: Page});
function Page() {return <InfoPage kind="sustainability"/>;}
