import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Scent Scribe — The Private Fragrance Gallery" },
      { name: "description", content: "A private fragrance gallery by Scent Scribe." },
      { property: "og:title", content: "Scent Scribe" },
      { property: "og:description", content: "The Private Fragrance Gallery." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  useEffect(() => {
    // Serve the editorial experience directly. Wrapping it in another iframe
    // creates a nested iframe and interferes with the intro/hero viewport.
    window.location.replace("/scent-smoke/");
  }, []);

  return (
    <main
      aria-label="Opening Scent Scribe"
      className="min-h-screen w-full bg-[#080c18]"
    />
  );
}
