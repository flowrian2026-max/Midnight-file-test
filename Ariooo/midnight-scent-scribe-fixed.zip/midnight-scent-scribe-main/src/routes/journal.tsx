import { createFileRoute, Link } from '@tanstack/react-router';
import { ArrowRight } from 'lucide-react';
import { useLanguage } from '@/components/site/language';
import { pageHead } from '@/components/site/pages';
import { stories } from '@/content/site';
import { storySlugs } from '@/content/navigation';

export const Route = createFileRoute('/journal')({
  head: () => pageHead('The Scent Journal', 'Fragrance guides, scent notes, rituals and stories from Scent Scribe.'),
  component: JournalPage,
});

const editorial = [
  { en: { category: 'TRAVEL & SCENT', title: 'A Fragrant Summer on the Amalfi Coast', dek: 'Citrus peel, warm stone and sea air: finding a fragrance that carries the brightness of summer.', read: 'A scent can recall a landscape without trying to imitate it. Explore bright citrus openings, airy florals and the quiet depth of woods.' }, fa: { category: 'سفر و رایحه', title: 'تابستانی معطر در ساحل آمالفی', dek: 'پوست مرکبات، سنگ گرم و هوای دریا؛ انتخاب رایحه‌ای با حال‌وهوای تابستان.', read: 'یک رایحه می‌تواند منظره‌ای را به یاد بیاورد، بدون آنکه بخواهد آن را تقلید کند. نُت‌های مرکباتی، گل‌های لطیف و عمق آرام چوب‌ها را کشف کن.' } },
  { en: { category: 'RITUALS', title: 'The Ritual of Scent', dek: 'A slower way to wear perfume: notice the opening, let the heart unfold and revisit the dry-down.', read: 'Apply fragrance to clean skin, allow it to settle naturally and give the composition time before deciding how it feels.' }, fa: { category: 'آیین‌های شخصی', title: 'آیین رایحه', dek: 'آرام‌تر عطر بزن؛ به شروع توجه کن، به نُت‌های میانی فرصت بده و دوباره رایحه را تجربه کن.', read: 'عطر را روی پوست تمیز استفاده کن، اجازه بده طبیعی جا بیفتد و پیش از قضاوت به ترکیب زمان بده.' } },
  { en: { category: 'MEMORY & EMOTION', title: 'The Power of a Memory', dek: 'Why a familiar note can bring a person, a place or a moment back before words arrive.', read: 'Keep a small scent journal: record the first impression, how the fragrance changes and the memory it brings to mind.' }, fa: { category: 'خاطره و احساس', title: 'قدرت یک خاطره', dek: 'چرا یک بوی آشنا می‌تواند پیش از واژه‌ها، فرد یا لحظه‌ای را به یادمان بیاورد؟', read: 'دفتر کوچکی برای رایحه‌ها داشته باش: برداشت نخست، تغییر عطر و خاطره‌ای را که زنده می‌کند یادداشت کن.' } }
];

function JournalPage() {
  const { fa } = useLanguage();
  return <main>
    <section className="relative isolate overflow-hidden border-b border-foreground/10 bg-plum-black">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_78%_10%,rgba(131,135,195,.18),transparent_42%),linear-gradient(120deg,#0A1123,#1F1823)]"/>
      <div className="mx-auto max-w-7xl px-5 pb-14 pt-28 md:px-6 md:pb-20 md:pt-36">
        <p className="eyebrow mb-5 text-primary">{fa ? 'مجلهٔ رایحه' : 'THE SCENT JOURNAL'}</p>
        <h1 className="max-w-4xl text-5xl leading-[1.02] md:text-7xl">{fa ? 'داستان‌هایی که با رایحه آغاز می‌شوند.' : 'Stories that begin with a scent.'}</h1>
        <p className="mt-6 max-w-2xl text-base leading-8 text-muted-foreground md:text-lg">{fa ? 'راهنماهای عطر، خانواده‌های بویایی و یادداشت‌هایی دربارهٔ خاطره، سفر و آیین‌های روزانه.' : 'Fragrance guides, scent families and notes on memory, travel and everyday rituals.'}</p>
        <div className="mt-10 flex flex-wrap gap-3">{(fa ? ['راهنمای عطر','نت‌های بویایی','خاطره و احساس'] : ['FRAGRANCE GUIDES','SCENT NOTES','MEMORY & MOOD']).map((x) => <span key={x} className="border border-foreground/15 px-4 py-2 text-xs tracking-[.12em] text-muted-foreground">{x}</span>)}</div>
      </div>
    </section>
    <section className="mx-auto max-w-7xl px-5 py-14 md:px-6 md:py-20">
      <div className="mb-9 flex items-end justify-between gap-4"><div><p className="eyebrow mb-3 text-primary">{fa ? 'یادداشت‌های سردبیر' : 'EDITORIAL NOTES'}</p><h2 className="text-3xl md:text-4xl">{fa ? 'تازه از دنیای عطر' : 'From the world of fragrance'}</h2></div><span className="eyebrow text-muted-foreground">01 — 03</span></div>
      <div className="grid gap-10 md:grid-cols-3">
        {editorial.map((a,i) => <article key={a.en.title} className="group">
          <Link to="/stories/$slug" params={{slug: storySlugs[i] ?? 'amalfi-coast'}} className="block">
            <div className="relative overflow-hidden border border-foreground/10 bg-plum-black"><img src={stories[i].img} alt={a[fa ? 'fa' : 'en'].title} loading="lazy" className="aspect-[4/3] w-full object-cover transition-transform duration-700 group-hover:scale-105"/><span className="absolute start-4 top-4 bg-background/85 px-3 py-2 text-[10px] tracking-[.18em]">{a[fa ? 'fa' : 'en'].category}</span></div>
            <p className="eyebrow mt-5 text-primary">{a[fa ? 'fa' : 'en'].category}</p>
            <h3 className="mt-3 text-2xl leading-snug transition-colors group-hover:text-primary md:text-3xl">{a[fa ? 'fa' : 'en'].title}</h3>
          </Link>
          <p className="mt-4 leading-7 text-muted-foreground">{a[fa ? 'fa' : 'en'].dek}</p>
          <p className="mt-3 text-sm leading-6">{a[fa ? 'fa' : 'en'].read}</p>
          <Link to="/stories/$slug" params={{slug: storySlugs[i] ?? 'amalfi-coast'}} className="eyebrow mt-5 inline-flex items-center gap-2 border-b border-current pb-2">{fa ? 'ادامهٔ مطلب' : 'READ THE STORY'}<ArrowRight className="h-3 w-3 rtl:rotate-180"/></Link>
        </article>)}
      </div>
    </section>
    <section className="border-y border-foreground/10 bg-cream text-cream-foreground"><div className="mx-auto flex max-w-7xl flex-col gap-5 px-5 py-12 md:flex-row md:items-center md:justify-between md:px-6 md:py-16"><div><p className="eyebrow mb-2">{fa ? 'قدم بعدی' : 'YOUR NEXT DISCOVERY'}</p><h2 className="text-3xl md:text-4xl">{fa ? 'رایحه‌ای تازه پیدا کن.' : 'Find a new scent to love.'}</h2><p className="mt-3 max-w-xl leading-7">{fa ? 'مطالعه را به تجربه تبدیل کن و مجموعهٔ چندبرندی را ببین.' : 'Turn reading into discovery and explore the multi-brand collection.'}</p></div><Link to="/shop" className="eyebrow inline-flex items-center gap-3 self-start border border-cream-foreground/30 px-6 py-4 md:self-auto">{fa ? 'دیدن عطرها' : 'EXPLORE FRAGRANCES'}<ArrowRight className="h-4 w-4 rtl:rotate-180"/></Link></div></section>
  </main>;
}
