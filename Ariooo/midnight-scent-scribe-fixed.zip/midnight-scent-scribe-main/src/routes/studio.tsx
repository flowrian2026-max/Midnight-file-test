import { createFileRoute } from "@tanstack/react-router";
import { UniversalAdminWorkbench } from "@/admin-kit/UniversalAdminWorkbench";
import { pageHead } from "@/components/site/pages";

export const Route = createFileRoute("/studio")({
  head: () => ({
    ...pageHead(
      "ARIXEN Studio / Control",
      "Reusable business admin blueprints and local demo workspaces.",
    ),
    meta: [
      ...pageHead(
        "ARIXEN Studio / Control",
        "Reusable business admin blueprints and local demo workspaces.",
      ).meta,
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: StudioWorkbenchPage,
});

/**
 * Separate, non-production template lab. The included demo adapters are
 * browser-local only; this route must not be used for private customer data.
 */
function StudioWorkbenchPage() {
  return (
    <UniversalAdminWorkbench
      title="ARIXEN Studio / Control"
      subtitle="One refined admin foundation. A tailored workspace for every client."
      namespace="arixen-studio-template-lab"
      studioMode
    />
  );
}
