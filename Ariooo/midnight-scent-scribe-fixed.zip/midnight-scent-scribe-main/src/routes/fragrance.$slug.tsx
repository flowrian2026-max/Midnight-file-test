import { createFileRoute } from '@tanstack/react-router';
import { pageHead } from '@/components/site/pages';
import { StoreProduct } from '@/components/site/store';
export const Route = createFileRoute('/fragrance/$slug')({
 head: ({params}) => pageHead(`${params.slug.replace(/-/g, ' ')} fragrance`, `Explore ${params.slug} sizes and demonstration availability at Scent Scribe.`),
 component: Page,
});
function Page() {const {slug} = Route.useParams(); return <StoreProduct slug={slug}/>;}
