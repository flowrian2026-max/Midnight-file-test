import { createFileRoute } from '@tanstack/react-router';
import { DiscoveryPage, pageHead } from '@/components/site/pages';
export const Route = createFileRoute('/discovery-sets')({head: () => pageHead('Discovery Sets', 'A guide to discovering your fragrance preferences and sample set availability.'), component: DiscoveryPage});
