import { createFileRoute } from '@tanstack/react-router';
import { pageHead } from '@/components/site/pages';
import { StoreArticle } from '@/components/site/store';

const storyMeta: Record<string, { title: string; description: string }> = {
  'amalfi-coast': {
    title: 'A Fragrant Summer on the Amalfi Coast',
    description: 'Explore citrus, warm stone and sea-air inspiration for fragrance in the brighter months.',
  },
  'ritual-of-scent': {
    title: 'The Ritual of Scent',
    description: 'A considered guide to applying perfume, noticing its opening and giving a composition time to unfold.',
  },
  'power-of-memory': {
    title: 'The Power of a Memory',
    description: 'Discover how scent, context and personal memory shape the way a fragrance feels.',
  },
};

export const Route = createFileRoute('/stories/$slug')({
  head: ({ params }) => {
    const meta = storyMeta[params.slug];
    const title = meta?.title ?? params.slug.replace(/-/g, ' ');
    const description = meta?.description ?? `Read ${title} in the Scent Scribe journal.`;
    return pageHead(title, description);
  },
  component: Page,
});

function Page() {
  const { slug } = Route.useParams();
  return <StoreArticle slug={slug} />;
}
