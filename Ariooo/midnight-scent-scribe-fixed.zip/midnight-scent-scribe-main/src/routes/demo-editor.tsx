import { createFileRoute, Link } from '@tanstack/react-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { Save, X, Plus, Pencil, Settings2 } from 'lucide-react';
import { pageHead, PageIntro } from '@/components/site/pages';
import { useLanguage } from '@/components/site/language';
import { productsQuery, brandsQuery, categoriesQuery } from '@/lib/catalog';
import { loadCatalog, saveCatalog, resetCatalog, upsertDemoBrand, upsertDemoCategory } from '@/lib/demo-store';
import { isRemoteCatalogEnabled, saveRemoteProduct, saveRemoteBrand, saveRemoteCategory } from '@/lib/remote-catalog';
import { supabase } from '@/integrations/supabase/client';
import type { DemoProduct, DemoBrand, DemoCategory } from '@/lib/demo-catalog';
import { Button } from '@/components/ui/button';
import { UniversalAdminWorkbench } from '@/admin-kit/UniversalAdminWorkbench';
import { defaultMerchandising, loadMerchandising, saveMerchandising, resetMerchandising, type DemoMerchandising } from '@/lib/demo-merchandising';
export const Route = createFileRoute('/demo-editor')({
 head: () => ({meta:[...pageHead('Studio / Control — Admin workspace','Reusable luxury admin workspace for Scent Scribe catalogue management and future site templates.').meta,{name:'robots',content:'noindex,nofollow'}]}), component: Editor,
});
const input = 'w-full border border-input bg-background p-2 text-sm';
function Editor() {
 const {fa} = useLanguage(); const qc = useQueryClient(); const remoteMode = isRemoteCatalogEnabled();
 const products = useQuery({queryKey:['admin-editor-products'],queryFn:()=>remoteMode ? loadRemoteAdminProducts() : qc.fetchQuery(productsQuery)});
 const brands = useQuery(brandsQuery); const categories = useQuery(categoriesQuery);
 const [saving, setSaving] = useState(false);
 const [studioMode, setStudioMode] = useState(true);
 const remoteAdmin = useQuery({queryKey:['remote-editor-admin'],enabled:remoteMode,retry:false,queryFn:async()=>{const response=await fetch('/api/d1/admin/session',{cache:'no-store',credentials:'same-origin'});if(!response.ok)return false;const result=await response.json() as {ok?:boolean;user?:{id:string}};return result.ok===true && Boolean(result.user?.id);}});
 const [merchandising,setMerchandising] = useState<DemoMerchandising>(() => loadMerchandising());
 const [merchandisingStatus,setMerchandisingStatus] = useState('');
 const [product,setProduct] = useState<DemoProduct | null>(null); const [brand,setBrand] = useState<DemoBrand | null>(null); const [category,setCategory] = useState<DemoCategory | null>(null); const [brandOriginalSlug,setBrandOriginalSlug] = useState<string | null>(null); const [categoryOriginalSlug,setCategoryOriginalSlug] = useState<string | null>(null); const [status,setStatus] = useState('');
 if (studioMode && !remoteMode) return <UniversalAdminWorkbench onExit={() => setStudioMode(false)} />;
 const refresh = () => {void qc.invalidateQueries({queryKey:['products']}); void qc.invalidateQueries({queryKey:['admin-editor-products']}); void qc.invalidateQueries({queryKey:['brands']}); void qc.invalidateQueries({queryKey:['categories']});};
 const save = async () => {
  if(remoteMode) {
   if(remoteAdmin.data !== true) { setStatus(fa ? 'برای ذخیرهٔ مشترک باید با حساب مدیر وارد شوید.' : 'Sign in with a verified administrator account to save shared changes.'); return; }
   setSaving(true);
   try {
    if(product) {
     const slugOkay = /^[a-z0-9]+(-[a-z0-9]+)*$/.test(product.slug);
     const duplicate = (products.data ?? []).some(p => p.id !== product.id && p.slug === product.slug);
     const brandExists = (brands.data ?? []).some(b => b.slug === product.brand_slug);
     const selectedCategoryIds = product.category_ids ?? (product.category_id ? [product.category_id] : []);
     const validCategories = selectedCategoryIds.length > 0 && selectedCategoryIds.every(id => (categories.data ?? []).some(category => category.id === id));
     const validImage = product.image_url.startsWith('asset:') || /^https:\/\//.test(product.image_url);
     if(!product.name.trim() || !slugOkay || duplicate || !product.volumes.length || new Set(product.volumes.map(v => v.ml)).size !== product.volumes.length || product.volumes.some(v => !Number.isFinite(v.price) || v.price < 0 || !Number.isInteger(v.stock) || v.stock < 0 || !Number.isFinite(v.ml) || v.ml <= 0) || !brandExists || !validCategories || !validImage) {setStatus(fa ? 'نام، نشانی یکتا، برند، دسته، عکس و مقادیر حجم را بررسی کنید.' : 'Check the name, unique slug, brand, category, image and bottle-size values.'); return;}
     await saveRemoteProduct(product);
    }
    if(brand) {
     if(!brand.name.trim() || !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(brand.slug)) {setStatus(fa ? 'نام و نشانی برند معتبر نیست.' : 'Enter a valid brand name and slug.'); return;}
     if((brands.data ?? []).some(b=>b.slug===brand.slug && b.slug!==brandOriginalSlug)) {setStatus(fa ? 'این نشانی متعلق به برند دیگری است؛ نشانی یکتا وارد کنید.' : 'That slug belongs to another brand. Choose a unique slug.'); return;}
     await saveRemoteBrand(brand,brandOriginalSlug);
    }
    if(category) {
     if(!category.name_en.trim() || !category.name_fa.trim() || !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(category.slug) || !Number.isInteger(category.sort) || category.sort < 0) {setStatus(fa ? 'نام انگلیسی، نام فارسی، نشانی معتبر و ترتیب صفر یا بیشتر لازم است.' : 'Enter both category names, a valid slug and a non-negative sort order.'); return;}
     if((categories.data ?? []).some(c=>c.slug===category.slug && c.slug!==categoryOriginalSlug)) {setStatus(fa ? 'این نشانی متعلق به دسته‌بندی دیگری است.' : 'That slug belongs to another category. Choose a unique slug.'); return;}
     await saveRemoteCategory(category,categoryOriginalSlug);
    }
    setProduct(null); setBrand(null); setCategory(null); setBrandOriginalSlug(null); setCategoryOriginalSlug(null); refresh();
    setStatus(fa ? 'در کاتالوگ مشترک ذخیره شد.' : 'Saved to the shared catalogue.');
   } catch(error) {
    setStatus(error instanceof Error ? error.message : (fa ? 'ذخیره انجام نشد؛ اتصال و مجوزهای پنل را بررسی کنید.' : 'Save failed. Check the database connection and administrator permissions.'));
   } finally { setSaving(false); }
   return;
  }
  const catalog = loadCatalog();
  let persisted = false;
  if(product) {
   if(!product.name.trim() || !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(product.slug) || catalog.products.some(p => p.id !== product.id && p.slug === product.slug) || !product.volumes.length || product.volumes.some(v => !Number.isFinite(v.price) || v.price < 0 || !Number.isInteger(v.stock) || v.stock < 0 || !Number.isFinite(v.ml) || v.ml <= 0) || !catalog.brands.some(b => b.slug === product.brand_slug) || !(Array.isArray(product.category_ids) ? product.category_ids.length > 0 && product.category_ids.every(id => catalog.categories.some(c => c.id === id)) : catalog.categories.some(c => c.id === product.category_id)) || !(product.image_url.startsWith('asset:') || /^https:\/\//.test(product.image_url))) {setStatus(fa ? 'نام، نشانی یکتا، برند، دسته، عکس و مقادیر حجم را بررسی کنید.' : 'Check the name, unique slug, brand, category, image and size values.'); return;}
   persisted = saveCatalog({...catalog,products:catalog.products.some(p => p.id === product.id) ? catalog.products.map(p => p.id === product.id ? product : p) : [...catalog.products,product]});
  }
  if(brand) {
   if(!brand.name.trim() || !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(brand.slug)) {setStatus(fa ? 'نام و نشانی برند معتبر نیست.' : 'Enter a valid brand name and slug.'); return;}
   const updatedCatalog = upsertDemoBrand(catalog, brand, brandOriginalSlug);
   if(!updatedCatalog) {
    setStatus(fa ? 'این نشانی متعلق به برند دیگری است؛ نشانی یکتا وارد کنید.' : 'That slug belongs to another brand. Choose a unique slug.');
    return;
   }
   persisted = saveCatalog(updatedCatalog);
  }
  if(category) {
   if(!category.name_en.trim() || !category.name_fa.trim() || !/^[a-z0-9]+(-[a-z0-9]+)*$/.test(category.slug) || !Number.isInteger(category.sort) || category.sort < 0) {
    setStatus(fa ? 'نام انگلیسی، نام فارسی، نشانی معتبر و ترتیب صفر یا بیشتر لازم است.' : 'Enter both category names, a valid slug and a non-negative sort order.');
    return;
   }
   const updatedCatalog = upsertDemoCategory(catalog, category, categoryOriginalSlug);
   if(!updatedCatalog) {
    setStatus(fa ? 'این نشانی متعلق به دسته‌بندی دیگری است یا دسته‌بندی اصلی پیدا نشد.' : 'That slug belongs to another category, or the original category could not be found.');
    return;
   }
   persisted = saveCatalog(updatedCatalog);
  }
  setProduct(null); setBrand(null); setCategory(null); setBrandOriginalSlug(null); setCategoryOriginalSlug(null); refresh();
  setStatus(persisted
    ? (fa ? 'فقط در همین مرورگر ذخیره شد.' : 'Saved in this browser only.')
    : (fa ? 'تغییرات فعلاً فقط در حافظهٔ این نشست هستند؛ ذخیره‌سازی مرورگر در دسترس نیست.' : 'Changes are only in this session; browser storage is unavailable.'));
 };
 const newProduct = () => {const id = crypto.randomUUID(); const firstCategoryId = categories.data?.[0]?.id ?? ''; setProduct({id,slug:'',name:'',brand_slug:brands.data?.[0]?.slug ?? '',category_id:firstCategoryId,category_ids:firstCategoryId ? [firstCategoryId] : [],image_url:'asset:nocturne',desc_en:'',desc_fa:'',published:false,is_new:false,created_at:new Date().toISOString(),volumes:[{id:crypto.randomUUID(),ml:50,price:0,stock:0}],gender:undefined,concentration:undefined,seasons:[],notes:{top:'',heart:'',base:''},occasions:[],scent_character:[]}); setBrand(null); setCategory(null); setBrandOriginalSlug(null); setCategoryOriginalSlug(null); setStatus('');};
 if(remoteMode && (remoteAdmin.isLoading || remoteAdmin.data !== true)) return <section className="mx-auto max-w-xl px-5 py-20"><PageIntro title={fa ? 'پنل مدیریت فروشگاه' : 'Store administration'} text={fa ? 'حالت کاتالوگ مشترک فعال است؛ برای ویرایش باید حساب مدیر شما در سرور تأیید شود.' : 'Shared catalogue mode is enabled. Your administrator role must be verified by the server before editing.'}/><div className="border border-border p-5"><p className="text-sm leading-7 text-muted-foreground">{remoteAdmin.isError ? (fa ? 'نقش مدیر قابل بررسی نیست. اتصال دیتابیس و مهاجرت‌ها را کنترل کنید.' : 'Administrator role could not be checked. Verify the database connection and migrations.') : (fa ? 'برای ورود به پنل امن وارد حساب مدیر شوید.' : 'Sign in with the store administrator account to continue.')}</p><Button asChild className="mt-4"><Link to="/auth">{fa ? 'ورود مدیر' : 'Administrator sign in'}</Link></Button></div></section>;
 return <section className="admin-shell mx-auto max-w-6xl px-5 py-12"><div className="mb-6 flex flex-wrap items-center justify-between gap-3 border border-border p-4"><div><p className="text-sm font-medium">Studio / Control</p><p className="mt-1 text-xs text-muted-foreground">Reusable admin kit · classic fragrance editor</p></div><Button variant="outline" onClick={() => setStudioMode(true)}><Settings2 className="me-2 h-4 w-4"/>Universal admin workspace</Button></div><PageIntro title={remoteMode ? (fa ? 'پنل کاتالوگ مشترک' : 'Shared catalogue editor') : (fa ? 'ویرایش نمونهٔ محلی' : 'Local demo editor')} text={remoteMode ? (fa ? 'تغییرات پس از تأیید نقش مدیر در پایگاه دادهٔ مشترک ذخیره می‌شوند.' : 'Edits are saved to the shared database after administrator authorization.') : (fa ? 'این صفحه مدیریت امن فروشگاه نیست؛ تغییرات فقط در همین مرورگر ذخیره می‌شوند و برای کاربران دیگر نمایش داده نمی‌شوند.' : 'This is not secure store administration. Changes are saved only in this browser and are not shared with other visitors.')}/>
 <p role="status" className="mb-6 text-sm text-muted-foreground">{status}</p>
 {!remoteMode && <section className="mb-10 border-y py-6" aria-labelledby="homepage-merchandising">
  <div className="mb-4">
   <p className="eyebrow mb-2 text-primary">{fa ? 'چیدمان صفحهٔ اصلی' : 'Homepage merchandising'}</p>
   <h2 id="homepage-merchandising" className="text-2xl">{fa ? 'کنترل بخش‌های صفحهٔ اصلی' : 'Homepage sections'}</h2>
   <p className="mt-2 max-w-2xl text-sm leading-6 text-muted-foreground">{fa ? 'تنظیمات زیر فقط در همین مرورگر ذخیره می‌شوند و هنوز پنل مشترک یا پایگاه دادهٔ آنلاین نیستند.' : 'These settings are saved in this browser only. This is not shared administration or an online database.'}</p>
  </div>
  <p role="status" className="mb-4 text-sm text-muted-foreground">{merchandisingStatus}</p>
  <div className="space-y-3">
   <label className="flex items-start gap-3 border border-input p-3"><input className="mt-1" type="checkbox" checked={merchandising.showFeaturedBrands} onChange={e=>setMerchandising({...merchandising,showFeaturedBrands:e.target.checked})}/><span><strong className="block">{fa ? 'نمایش ردیف برندهای منتخب' : 'Show featured brands'}</strong><span className="text-sm text-muted-foreground">{fa ? 'نام برندها در بخش منتخب صفحهٔ اصلی.' : 'Display the featured brand links.'}</span></span></label>
   <label className="flex items-start gap-3 border border-input p-3"><input className="mt-1" type="checkbox" checked={merchandising.showCuratedProducts} onChange={e=>setMerchandising({...merchandising,showCuratedProducts:e.target.checked})}/><span><strong className="block">{fa ? 'نمایش محصولات منتخب' : 'Show curated products'}</strong><span className="text-sm text-muted-foreground">{fa ? 'اگر محصولی انتخاب نکنی، انتخاب خودکار چند برند نمایش داده می‌شود.' : 'If no products are selected below, the homepage uses its automatic multi-brand selection.'}</span></span></label>
   <label className="flex items-start gap-3 border border-input p-3"><input className="mt-1" type="checkbox" checked={merchandising.showNewArrivals} onChange={e=>setMerchandising({...merchandising,showNewArrivals:e.target.checked})}/><span><strong className="block">{fa ? 'نمایش تازه‌واردها' : 'Show new arrivals'}</strong><span className="text-sm text-muted-foreground">{fa ? 'در حالت خودکار، محصولات علامت‌خورده به‌عنوان تازه‌وارد نمایش داده می‌شوند.' : 'In automatic mode, products marked as new are shown.'}</span></span></label>
  </div>
  <div className="mt-6 grid gap-6 md:grid-cols-2">
   <fieldset className="min-w-0 space-y-2">
    <legend className="mb-2 font-medium">{fa ? 'انتخاب دستی محصولات منتخب (حداکثر ۴)' : 'Manually choose curated products (up to 4)'}</legend>
    <p className="mb-3 text-xs text-muted-foreground">{fa ? 'اگر هیچ موردی انتخاب نشود، حالت خودکار فعال است.' : 'Leave all unchecked to use automatic selection.'}</p>
    <div className="max-h-64 space-y-2 overflow-y-auto border border-input p-3">
     {products.data?.filter(p=>p.published).map(p=><label key={p.id} className="flex items-start gap-2 text-sm"><input className="mt-1" type="checkbox" checked={merchandising.curatedProductIds.includes(p.id)} disabled={!merchandising.curatedProductIds.includes(p.id) && merchandising.curatedProductIds.length>=4} onChange={e=>setMerchandising({...merchandising,curatedProductIds:e.target.checked?[...merchandising.curatedProductIds,p.id]:merchandising.curatedProductIds.filter(id=>id!==p.id)})}/><span>{p.name}<span className="block text-xs text-muted-foreground">{p.brand_slug}</span></span></label>)}
     {!products.data?.some(p=>p.published) && <p className="text-sm text-muted-foreground">{fa ? 'محصول منتشرشده‌ای وجود ندارد.' : 'No published products yet.'}</p>}
    </div>
   </fieldset>
   <fieldset className="min-w-0 space-y-2">
    <legend className="mb-2 font-medium">{fa ? 'انتخاب دستی تازه‌واردها (حداکثر ۴)' : 'Manually choose new arrivals (up to 4)'}</legend>
    <p className="mb-3 text-xs text-muted-foreground">{fa ? 'در صورت خالی بودن، محصولات علامت‌خورده به‌عنوان تازه‌وارد انتخاب می‌شوند.' : 'Leave all unchecked to use products marked as new.'}</p>
    <div className="max-h-64 space-y-2 overflow-y-auto border border-input p-3">
     {products.data?.filter(p=>p.published).map(p=><label key={p.id} className="flex items-start gap-2 text-sm"><input className="mt-1" type="checkbox" checked={merchandising.newArrivalProductIds.includes(p.id)} disabled={!merchandising.newArrivalProductIds.includes(p.id) && merchandising.newArrivalProductIds.length>=4} onChange={e=>setMerchandising({...merchandising,newArrivalProductIds:e.target.checked?[...merchandising.newArrivalProductIds,p.id]:merchandising.newArrivalProductIds.filter(id=>id!==p.id)})}/><span>{p.name}<span className="block text-xs text-muted-foreground">{p.brand_slug}</span></span></label>)}
    </div>
   </fieldset>
  </div>
  <div className="mt-5 flex flex-wrap gap-3">
   <Button type="button" onClick={()=>{const ok=saveMerchandising(merchandising);setMerchandisingStatus(ok?(fa?'تنظیمات صفحهٔ اصلی در همین مرورگر ذخیره شد.':'Homepage settings saved in this browser.'):(fa?'ذخیره‌سازی مرورگر در دسترس نیست.':'Browser storage is unavailable.'));}}>{fa ? 'ذخیرهٔ چیدمان' : 'Save homepage layout'}</Button>
   <Button type="button" variant="outline" onClick={()=>{resetMerchandising();setMerchandising(defaultMerchandising);setMerchandisingStatus(fa?'تنظیمات پیش‌فرض بازگردانده شد.':'Default homepage settings restored.');}}>{fa ? 'بازگردانی چیدمان' : 'Reset layout'}</Button>
  </div>
 </section>}
 {product || brand || category ? <form onSubmit={e => {e.preventDefault();void save();}} className="space-y-5 border-y py-6">
 {product && <>
 <label className="block">{fa ? 'نام' : 'Name'}<input aria-label="Product name" className={input} value={product.name} onChange={e=>setProduct({...product,name:e.target.value})}/></label>
 <label className="block">{fa ? 'نشانی' : 'Slug'}<input aria-label="Product slug" className={input} dir="ltr" value={product.slug} onChange={e=>setProduct({...product,slug:e.target.value})}/></label>
 <div className="grid gap-4 sm:grid-cols-2"><label>{fa ? 'برند' : 'Brand'}<select className={input} value={product.brand_slug} onChange={e=>setProduct({...product,brand_slug:e.target.value})}>{brands.data?.map(b=><option key={b.slug} value={b.slug}>{b.name}</option>)}</select></label></div>
 <fieldset className="space-y-2"><legend className="text-sm">{fa ? 'دسته‌بندی‌ها (چند انتخابی)' : 'Categories (select all that apply)'}</legend><p className="text-xs text-muted-foreground">{fa ? 'فقط با زدن تیک، محصول در آن دسته‌بندی نمایش داده می‌شود.' : 'The product appears in a category only when its box is checked.'}</p><div className="grid gap-2 sm:grid-cols-2">{categories.data?.map(c=><label key={c.id} className="flex items-center gap-2 border border-input p-3"><input type="checkbox" checked={(product.category_ids ?? [product.category_id]).includes(c.id)} onChange={ev=>{const current=product.category_ids ?? [product.category_id];const next=ev.target.checked?[...current,c.id]:current.filter(id=>id!==c.id);setProduct({...product,category_ids:next,category_id:next[0] ?? ''});}}/><span>{fa ? c.name_fa : c.name_en}</span></label>)}</div></fieldset>
 <label className="block">{fa ? 'عکس (لینک HTTPS یا asset:nocturne)' : 'Image (HTTPS URL or asset:nocturne)'}<input className={input} value={product.image_url} onChange={e=>setProduct({...product,image_url:e.target.value})}/></label>
 {(['desc_en','desc_fa'] as const).map(key=><label key={key} className="block">{key === 'desc_en' ? 'Description EN' : 'توضیح فارسی'}<textarea className={`${input} min-h-24`} value={product[key]} onChange={e=>setProduct({...product,[key]:e.target.value})}/></label>)}
 <div className="flex gap-6"><label><input type="checkbox" checked={product.published} onChange={e=>setProduct({...product,published:e.target.checked})}/> {fa ? 'نمایش در فروشگاه' : 'Published'}</label><label><input type="checkbox" checked={product.is_new} onChange={e=>setProduct({...product,is_new:e.target.checked})}/> {fa ? 'تازه' : 'New'}</label></div>
 <fieldset className="space-y-4 border-t pt-5"><legend className="text-lg">{fa ? 'مشخصات و دسته‌بندی عطر' : 'Fragrance attributes & merchandising'}</legend>
 <p className="text-sm text-muted-foreground">{fa ? 'فقط اطلاعات تأییدشده را انتخاب کنید؛ موارد نامشخص را خالی بگذارید.' : 'Only enter verified details. Leave unknown attributes blank.'}</p>
 <div className="grid gap-4 sm:grid-cols-2">
 <label>{fa ? 'گروه مصرف' : 'Audience'}<select className={input} value={product.gender ?? ''} onChange={e=>setProduct({...product,gender:(e.target.value || undefined) as DemoProduct['gender']})}><option value="">{fa ? 'مشخص نشده' : 'Not specified'}</option><option value="women">{fa ? 'زنانه' : 'Women'}</option><option value="men">{fa ? 'مردانه' : 'Men'}</option><option value="unisex">{fa ? 'یونیسکس' : 'Unisex'}</option></select></label>
 <label>{fa ? 'غلظت' : 'Concentration'}<select className={input} value={product.concentration ?? ''} onChange={e=>setProduct({...product,concentration:(e.target.value || undefined) as DemoProduct['concentration']})}><option value="">{fa ? 'مشخص نشده' : 'Not specified'}</option><option value="parfum">Parfum</option><option value="extrait">Extrait de Parfum</option><option value="edp">Eau de Parfum (EDP)</option><option value="edt">Eau de Toilette (EDT)</option><option value="edc">Eau de Cologne (EDC)</option></select></label>
 </div>
 {([['seasons',fa?'فصل‌ها':'Seasons',[['spring',fa?'بهار':'Spring'],['summer',fa?'تابستان':'Summer'],['autumn',fa?'پاییز':'Autumn'],['winter',fa?'زمستان':'Winter']]],['occasions',fa?'موقعیت استفاده':'Occasions',[['daily',fa?'روزمره':'Daily'],['work',fa?'محیط کار':'Work'],['evening',fa?'شب و مهمانی':'Evening'],['formal',fa?'رسمی':'Formal']]],['scent_character',fa?'ویژگی رایحه':'Scent character',[['fresh',fa?'تازه':'Fresh'],['sweet',fa?'شیرین':'Sweet'],['warm',fa?'گرم':'Warm'],['powdery',fa?'پودری':'Powdery'],['smoky',fa?'دودی':'Smoky'],['clean',fa?'تمیز':'Clean']]]] as const).map(([key,title,options])=><fieldset key={key}><legend className="mb-2 text-sm">{title}</legend><div className="flex flex-wrap gap-x-4 gap-y-2">{options.map(([value,label])=><label key={value} className="flex items-center gap-2 text-sm"><input type="checkbox" checked={(product[key] ?? []).includes(value)} onChange={e=>setProduct({...product,[key]:e.target.checked?[...(product[key] ?? []),value]:(product[key] ?? []).filter(x=>x!==value)})}/>{label}</label>)}</div></fieldset>)}
 <div className="grid gap-3 sm:grid-cols-3">{(['top','heart','base'] as const).map(key=><label key={key} className="block text-sm">{key==='top'?(fa?'نت آغازین':'Top notes'):key==='heart'?(fa?'نت میانی':'Heart notes'):(fa?'نت پایه':'Base notes')}<input className={input} value={product.notes?.[key] ?? ''} placeholder={fa?'فقط در صورت تأیید':'Only if verified'} onChange={e=>setProduct({...product,notes:{...product.notes,[key]:e.target.value}})}/></label>)}</div>
 </fieldset>
 <div className="space-y-4">{product.volumes.map((v,i)=><div key={v.id} className="grid grid-cols-3 gap-3">{(['ml','price','stock'] as const).map(key=><label key={key} className="text-sm">{key === 'ml' ? 'ml' : key === 'price' ? (fa ? 'قیمت نمایشی' : 'Demo price') : (fa ? 'موجودی نمایشی' : 'Demo stock')}<input aria-label={`${key} ${i+1}`} type="number" min={key==='ml' ? 1 : 0} step={key==='price' ? '0.01' : 1} className={input} value={v[key]} onChange={e=>setProduct({...product,volumes:product.volumes.map(x=>x.id===v.id ? {...x,[key]:Number(e.target.value)} : x)})}/></label>)}</div>)}<Button type="button" variant="outline" onClick={()=>setProduct({...product,volumes:[...product.volumes,{id:crypto.randomUUID(),ml:50,price:0,stock:0}]})}><Plus/>{fa ? 'افزودن حجم' : 'Add size'}</Button></div>
 </>}
 {category && <><label className="block">{fa ? 'نشانی دسته‌بندی' : 'Category slug'}<input aria-label="Category slug" className={input} dir="ltr" value={category.slug} onChange={e=>setCategory({...category,slug:e.target.value})}/></label><div className="grid gap-4 sm:grid-cols-2"><label className="block">{fa ? 'نام انگلیسی' : 'Name (English)'}<input aria-label="Category name English" className={input} value={category.name_en} onChange={e=>setCategory({...category,name_en:e.target.value})}/></label><label className="block">{fa ? 'نام فارسی' : 'Name (Persian)'}<input aria-label="Category name Persian" className={input} value={category.name_fa} onChange={e=>setCategory({...category,name_fa:e.target.value})}/></label></div><label className="block">{fa ? 'ترتیب نمایش' : 'Display order'}<input aria-label="Category display order" className={input} type="number" min="0" step="1" value={category.sort} onChange={e=>setCategory({...category,sort:Number(e.target.value)})}/></label></>}
 {brand && <><label className="block">{fa ? 'نام برند' : 'Brand name'}<input aria-label="Brand name" className={input} value={brand.name} onChange={e=>setBrand({...brand,name:e.target.value})}/></label><label className="block">Slug<input aria-label="Brand slug" className={input} value={brand.slug} onChange={e=>setBrand({...brand,slug:e.target.value})}/></label>{(['blurbEn','blurbFa'] as const).map(key=><label key={key} className="block">{key === 'blurbEn' ? 'Description EN' : 'توضیح فارسی'}<textarea className={input} value={brand[key]} onChange={e=>setBrand({...brand,[key]:e.target.value})}/></label>)}</>}
 <div className="flex gap-3"><Button type="submit" disabled={saving}>{saving ? '…' : <><Save/>{remoteMode ? (fa ? 'ذخیره در فروشگاه' : 'Save to store') : (fa ? 'ذخیرهٔ محلی' : 'Save locally')}</>}</Button><Button type="button" variant="ghost" onClick={()=>{setProduct(null);setBrand(null);setCategory(null);setBrandOriginalSlug(null);setCategoryOriginalSlug(null);}}><X/>{fa ? 'انصراف' : 'Cancel'}</Button></div>
 </form> : <><div className="mb-6 flex flex-wrap gap-3"><Button onClick={newProduct}><Plus/>{fa ? 'محصول نمایشی' : 'Demo product'}</Button><Button variant="outline" onClick={()=>{setProduct(null);setBrand({slug:'',name:'',blurbEn:'',blurbFa:''});setCategory(null);setBrandOriginalSlug(null);setCategoryOriginalSlug(null);setStatus('');}}><Plus/>{fa ? 'برند' : 'Brand'}</Button>{remoteMode && <Button variant="outline" onClick={()=>{setProduct(null);setBrand(null);setCategory({id:crypto.randomUUID(),slug:'',name_en:'',name_fa:'',sort:(categories.data?.length ?? 0)+1});setBrandOriginalSlug(null);setCategoryOriginalSlug(null);setStatus('');}}><Plus/>{fa ? 'دسته‌بندی' : 'Category'}</Button>}{!remoteMode && <Button variant="ghost" onClick={()=>{if(window.confirm(fa ? 'تغییرات محلی پاک شوند؟' : 'Reset local catalogue edits?')) {resetCatalog();refresh();setStatus(fa ? 'نمونهٔ اولیه بازگردانده شد.' : 'Demo defaults restored.');}}}>{fa ? 'بازگردانی نمونه' : 'Reset demo'}</Button>}</div><ul className="divide-y border-y">{products.data?.map(p=><li key={p.id} className="flex items-center justify-between gap-4 py-4"><span dir="ltr">{p.name}</span><Button aria-label={`Edit ${p.name}`} size="icon" variant="outline" onClick={()=>{setProduct({...structuredClone(p),category_ids:p.category_ids ?? [p.category_id]});setBrand(null);setCategory(null);setCategoryOriginalSlug(null);setStatus('');}}><Pencil className="h-4 w-4"/></Button></li>)}</ul>{remoteMode && <><h2 className="my-8 text-3xl">{fa ? 'دسته‌بندی‌ها' : 'Categories'}</h2><ul className="divide-y border-y">{categories.data?.map(c=><li key={c.id} className="flex items-center justify-between gap-4 py-3"><span>{fa ? c.name_fa : c.name_en}<span className="ms-2 text-xs text-muted-foreground" dir="ltr">{c.slug}</span></span><Button aria-label={`Edit category ${c.slug}`} size="icon" variant="outline" onClick={()=>{setProduct(null);setBrand(null);setCategory({...c});setBrandOriginalSlug(null);setCategoryOriginalSlug(c.slug);setStatus('');}}><Pencil className="h-4 w-4"/></Button></li>)}</ul></>}
  <h2 className="my-8 text-3xl">{fa ? 'برندها' : 'Brands'}</h2><ul className="divide-y">{brands.data?.map(b=><li key={b.slug} className="flex justify-between gap-4 py-3"><Link to="/brand/$slug" params={{slug:b.slug}}>{b.name}</Link><Button aria-label={`Edit ${b.name}`} size="icon" variant="outline" onClick={()=>{setProduct(null);setBrand({...b});setCategory(null);setBrandOriginalSlug(b.slug);setCategoryOriginalSlug(null);setStatus('');}}><Pencil className="h-4 w-4"/></Button></li>)}</ul></>}
 </section>;
}
