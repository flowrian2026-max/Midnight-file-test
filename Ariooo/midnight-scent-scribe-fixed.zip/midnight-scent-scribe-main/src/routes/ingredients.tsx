import { createFileRoute } from '@tanstack/react-router';
import { InfoPage, pageHead } from '@/components/site/pages';
export const Route = createFileRoute('/ingredients')({head: () => pageHead('Ingredients', 'Understand fragrance materials, notes and ingredient labels.'), component: Page});
function Page() {return <InfoPage kind="ingredients"/>;}
