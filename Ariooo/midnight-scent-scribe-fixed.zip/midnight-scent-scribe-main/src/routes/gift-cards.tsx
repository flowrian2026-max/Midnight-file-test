import { createFileRoute } from '@tanstack/react-router';
import { GiftPage, pageHead } from '@/components/site/pages';
export const Route = createFileRoute('/gift-cards')({head: () => pageHead('Gift Cards', 'Explore fragrance gifting and the current availability of Scent Scribe gift cards.'), component: GiftPage});
