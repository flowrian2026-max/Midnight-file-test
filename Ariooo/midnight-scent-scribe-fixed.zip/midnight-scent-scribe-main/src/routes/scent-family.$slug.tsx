import { createFileRoute, notFound } from '@tanstack/react-router';
import { FamilyPage, pageHead } from '@/components/site/pages';
import { familySlugs } from '@/content/navigation';
import { families } from '@/content/site';
export const Route = createFileRoute('/scent-family/$slug')({
 loader: ({params}) => {const index = familySlugs.findIndex(s => s === params.slug); const item = families[index]; if (!item) throw notFound(); return {title:item.name};},
 head: ({loaderData}) => pageHead(loaderData?.title ?? 'Unavailable', 'Explore ' + (loaderData?.title ?? 'Scent Family') + ' at Scent Scribe.'),
 component: Page,
});
function Page() {const {slug} = Route.useParams(); return <FamilyPage slug={slug}/>;}
