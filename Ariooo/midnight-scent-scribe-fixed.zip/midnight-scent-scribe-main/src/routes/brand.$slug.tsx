import { createFileRoute } from '@tanstack/react-router';
import { pageHead } from '@/components/site/pages';
import { BrandListing } from '@/components/site/commerce-pages';
export const Route = createFileRoute('/brand/$slug')({
  head: ({ params }) => pageHead(`${params.slug.replace(/-/g, ' ')} fragrances`, 'Explore brand fragrances in the Scent Scribe demonstration catalogue.'),
  component: Page,
});
function Page() { const { slug } = Route.useParams(); return <BrandListing slug={slug}/>; }