import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useLanguage } from "@/components/site/language";
import { pageHead } from "@/components/site/pages";

export const Route = createFileRoute("/auth")({
  head: () => pageHead("Administrator sign in", "Private Scent Scribe store administration."),
  component: AuthPage,
});

function AuthPage() {
  const { fa } = useLanguage();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [checking, setChecking] = useState(true);
  const [backendReady, setBackendReady] = useState(false);
  const [setupMode, setSetupMode] = useState(false);
  const [resetMode, setResetMode] = useState(false);
  const [setupToken, setSetupToken] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  useEffect(() => {
    let alive = true;
    fetch("/api/d1/health", { cache: "no-store" })
      .then((response) => {
        if (alive) setBackendReady(response.ok);
      })
      .catch(() => {
        if (alive) setBackendReady(false);
      })
      .finally(() => {
        if (alive) setChecking(false);
      });
    fetch("/api/d1/admin/session", { cache: "no-store", credentials: "same-origin" })
      .then((response) => {
        if (alive && response.ok) void navigate({ to: "/admin" });
      })
      .catch(() => undefined);
    return () => { alive = false; };
  }, [navigate]);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg("");
    try {
      if ((setupMode || resetMode) && password !== confirmPassword) {
        setMsg(fa ? "تکرار رمز عبور با رمز اصلی یکی نیست." : "The passwords do not match.");
        return;
      }
      if ((setupMode || resetMode) && setupToken.length < 32) {
        setMsg(fa ? "کلید راه‌اندازی باید حداقل ۳۲ نویسه داشته باشد." : "The setup secret must be at least 32 characters.");
        return;
      }
      const endpoint = setupMode ? "/api/d1/admin/setup" : resetMode ? "/api/d1/admin/reset-password" : "/api/d1/admin/login";
      const response = await fetch(endpoint, {
        method: "POST",
        headers: { "content-type": "application/json" },
        credentials: "same-origin",
        cache: "no-store",
        body: JSON.stringify(setupMode || resetMode
          ? { setupToken, email: email.trim(), password }
          : { email: email.trim(), password }),
      });
      const payload = await response.json().catch(() => ({})) as { code?: string; message?: string };
      if (!response.ok) {
        const messages: Record<string, { fa: string; en: string }> = {
          D1_NOT_CONFIGURED: { fa: "دیتابیس هنوز به سرور وصل نشده است.", en: "The database has not been connected to the server yet." },
          D1_SCHEMA_MISSING: { fa: "ساختار جدول‌های دیتابیس هنوز اعمال نشده است.", en: "The D1 schema migration has not been applied yet." },
          INVALID_CREDENTIALS: { fa: "ایمیل یا رمز عبور درست نیست.", en: "The email or password is incorrect." },
          RATE_LIMITED: { fa: "تلاش‌ها زیاد بوده؛ کمی بعد دوباره امتحان کن.", en: "Too many attempts. Try again later." },
          SETUP_DISABLED: { fa: "کلید راه‌اندازی مدیر در Cloudflare تنظیم نشده است.", en: "The administrator setup secret is not configured in Cloudflare." },
          SETUP_DENIED: { fa: "کلید راه‌اندازی اشتباه است.", en: "The setup secret is incorrect." },
          SETUP_ALREADY_COMPLETED: { fa: "حساب مدیر قبلاً ساخته شده است؛ از فرم ورود استفاده کن.", en: "An administrator already exists. Use the sign-in form." },
          ADMIN_NOT_FOUND: { fa: "مدیری با این ایمیل پیدا نشد.", en: "No administrator was found for this email." },
          INVALID_INPUT: { fa: "ایمیل یا رمز عبور معتبر نیست؛ رمز باید حداقل ۱۲ نویسه باشد.", en: "Enter a valid email and a password with at least 12 characters." },
        };
        const known = payload.code ? messages[payload.code] : undefined;
        setMsg(known ? (fa ? known.fa : known.en) : (payload.message ?? (fa ? "درخواست انجام نشد؛ اتصال دیتابیس را بررسی کن." : "The request failed. Check the database connection.")));
      } else if (setupMode) {
        setSetupMode(false);
        setSetupToken("");
        setPassword("");
        setConfirmPassword("");
        setMsg(fa ? "حساب مدیر ساخته شد؛ حالا با همان ایمیل و رمز وارد شو." : "Administrator account created. Sign in with that email and password.");
      } else if (resetMode) {
        setResetMode(false);
        setSetupToken("");
        setPassword("");
        setConfirmPassword("");
        setMsg(fa ? "رمز بازنشانی شد؛ حالا با رمز جدید وارد شو." : "Password reset. Sign in with your new password.");
      } else {
        await navigate({ to: "/admin" });
      }
    } catch {
      setMsg(fa ? "سرور مدیریت در دسترس نیست." : "The administration server is unavailable.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="mx-auto max-w-md px-5 py-16">
      <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground">SCENT SCRIBE · PRIVATE AREA</p>
      <h1 className="mt-3 font-serif text-4xl">{fa ? "ورود مدیر" : "Administrator sign in"}</h1>
      <p className="mt-3 text-sm leading-7 text-muted-foreground">
        {fa ? "ورود فقط برای حساب مدیر از طریق نشست امن سرور انجام می‌شود؛ ثبت‌نام عمومی وجود ندارد." : "Only an administrator account can sign in through a secure server session. Public registration is disabled."}
      </p>
      {!checking && !backendReady && (
        <p role="status" className="mt-6 border border-border bg-card px-4 py-3 text-sm leading-6 text-muted-foreground">
          {fa ? "دیتابیس D1 هنوز متصل نیست. تا اتصال دیتابیس و ساخت اولین مدیر، ورود فعال نخواهد شد." : "Cloudflare D1 is not connected yet. Sign-in will be available after the database and first administrator are configured."}
        </p>
      )}
      <form onSubmit={submit} className="mt-8 space-y-4">
        {(setupMode || resetMode) && <Input type="password" required minLength={32} autoComplete="off" aria-label={fa ? "کلید راه‌اندازی" : "Setup secret"} placeholder={fa ? "کلید خصوصی راه‌اندازی مدیر" : "Private administrator setup secret"} value={setupToken} onChange={(e) => setSetupToken(e.target.value)} dir="ltr" />}
        <Input type="email" required autoComplete="username" aria-label={fa ? "ایمیل" : "Email"} placeholder={fa ? "ایمیل" : "Email"} value={email} onChange={(e) => setEmail(e.target.value)} dir="ltr" />
        <Input type="password" required minLength={12} maxLength={200} autoComplete={setupMode ? "new-password" : "current-password"} aria-label={fa ? "رمز عبور" : "Password"} placeholder={fa ? "رمز عبور" : "Password"} value={password} onChange={(e) => setPassword(e.target.value)} dir="ltr" />
        {(setupMode || resetMode) && <Input type="password" required minLength={12} maxLength={200} autoComplete="new-password" aria-label={fa ? "تکرار رمز عبور" : "Confirm password"} placeholder={fa ? "تکرار رمز عبور" : "Confirm password"} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} dir="ltr" />}
        <Button type="submit" disabled={busy || checking || !backendReady} className="w-full">
          {busy ? "…" : setupMode ? (fa ? "ساخت اولین مدیر" : "Create first administrator") : resetMode ? (fa ? "بازنشانی رمز مدیر" : "Reset administrator password") : (fa ? "ورود" : "Sign in")}
        </Button>
      </form>
      <Button type="button" variant="outline" className="mt-3 w-full" disabled={busy} onClick={() => {setSetupMode(!setupMode);setResetMode(false);setMsg("");setSetupToken("");setPassword("");setConfirmPassword("");}}>
        {setupMode ? (fa ? "بازگشت به ورود" : "Back to sign in") : (fa ? "راه‌اندازی اولیه (فقط مدیر اول)" : "Initial setup (first admin only)")}
      </Button>
      {!setupMode && <Button type="button" variant="outline" className="mt-3 w-full" disabled={busy} onClick={() => {setResetMode(!resetMode);setMsg("");setSetupToken("");setPassword("");setConfirmPassword("");}}>
        {resetMode ? (fa ? "بازگشت به ورود" : "Back to sign in") : (fa ? "بازنشانی رمز مدیر" : "Reset administrator password")}
      </Button>}
      {msg && <p role="status" className="mt-4 text-sm text-muted-foreground">{msg}</p>}
      <p className="mt-6 text-xs leading-6 text-muted-foreground">
        {fa ? "اگر دیتابیس هنوز راه‌اندازی نشده، از مسیر تنظیمات Cloudflare و راهنمای D1 پروژه استفاده کن." : "If the database is not initialized yet, follow the project's Cloudflare D1 setup guide."}
      </p>
    </section>
  );
}
