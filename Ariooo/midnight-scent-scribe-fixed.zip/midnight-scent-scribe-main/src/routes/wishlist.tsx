import { createFileRoute } from '@tanstack/react-router';
import { WishlistPage } from '@/components/site/commerce-pages';
import { pageHead } from '@/components/site/pages';
export const Route = createFileRoute('/wishlist')({head: () => pageHead('Wishlist','Your saved fragrances in the Scent Scribe demonstration store.'), component: WishlistPage});