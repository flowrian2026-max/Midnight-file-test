type D1Result<T = Record<string, unknown>> = { results?: T[] };

type D1BoundStatement = {
  all<T = Record<string, unknown>>(): Promise<D1Result<T>>;
  first<T = Record<string, unknown>>(): Promise<T | null>;
  run(): Promise<unknown>;
};
type D1Statement = { bind(...values: unknown[]): D1BoundStatement };
type D1Database = {
  prepare(query: string): D1Statement;
  batch(statements: D1BoundStatement[]): Promise<unknown[]>;
};
type D1Env = { DB?: D1Database; ADMIN_SETUP_TOKEN?: string };

const SESSION_SECONDS = 60 * 60 * 12;
const PBKDF2_ITERATIONS = 100_000;
const COOKIE = "ss_admin_session";
const json = (data: unknown, status = 200, headers: HeadersInit = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-content-type-options": "nosniff",
      "referrer-policy": "no-referrer",
      ...headers,
    },
  });
const encoder = new TextEncoder();
const b64 = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes));
const fromB64 = (value: string) => Uint8Array.from(atob(value), (c) => c.charCodeAt(0));
const randomToken = (size = 32) => {
  const bytes = crypto.getRandomValues(new Uint8Array(size));
  return b64(bytes).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
};
async function sha256(value: string): Promise<string> {
  return b64(new Uint8Array(await crypto.subtle.digest("SHA-256", encoder.encode(value))));
}
async function passwordHash(password: string): Promise<string> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = new Uint8Array(await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt, iterations: PBKDF2_ITERATIONS }, key, 256,
  ));
  return `pbkdf2-sha256\u0024${PBKDF2_ITERATIONS}\u0024${b64(salt)}\u0024${b64(bits)}`;
}
async function verifyPassword(password: string, stored: string): Promise<boolean> {
  try {
    const [scheme, iterationText, saltText, hashText] = stored.split("$");
    const iterations = Number(iterationText);
    if (scheme !== "pbkdf2-sha256" || !Number.isInteger(iterations) || iterations < 100_000 || iterations > 1_000_000) return false;
    const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
    const candidate = new Uint8Array(await crypto.subtle.deriveBits(
      { name: "PBKDF2", hash: "SHA-256", salt: fromB64(saltText), iterations }, key, 256,
    ));
    const expected = fromB64(hashText);
    if (candidate.length !== expected.length) return false;
    let diff = 0;
    for (let i = 0; i < candidate.length; i++) diff |= candidate[i] ^ expected[i];
    return diff === 0;
  } catch { return false; }
}
function cookieValue(request: Request, name: string): string | null {
  const header = request.headers.get("cookie") ?? "";
  for (const item of header.split(";")) {
    const index = item.indexOf("=");
    if (index > 0 && item.slice(0, index).trim() === name) return item.slice(index + 1).trim();
  }
  return null;
}
const setCookie = (token: string, maxAge = SESSION_SECONDS) =>
  `${COOKIE}=${token}; Path=/api/d1/admin; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;
const clearCookie = () => `${COOKIE}=; Path=/api/d1/admin; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
async function readJson(request: Request): Promise<Record<string, unknown> | null> {
  const type = request.headers.get("content-type") ?? "";
  if (!type.toLowerCase().includes("application/json")) return null;
  const length = Number(request.headers.get("content-length") ?? "0");
  if (length > 16_384) return null;
  try {
    const value: unknown = await request.json();
    return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : null;
  } catch { return null; }
}
async function rateAllowed(db: D1Database, key: string, limit: number, windowSeconds: number): Promise<boolean> {
  const now = Math.floor(Date.now() / 1000);
  const row = await db.prepare("SELECT attempts, window_started_at, blocked_until FROM admin_rate_limits WHERE rate_key = ?")
    .bind(key).first<{ attempts: number; window_started_at: number; blocked_until: number }>();
  if (row?.blocked_until && row.blocked_until > now) return false;
  if (!row || now - row.window_started_at >= windowSeconds) {
    await db.prepare("INSERT INTO admin_rate_limits(rate_key, attempts, window_started_at, blocked_until) VALUES(?, 1, ?, 0) ON CONFLICT(rate_key) DO UPDATE SET attempts=1, window_started_at=excluded.window_started_at, blocked_until=0, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')")
      .bind(key, now).run();
    return true;
  }
  const attempts = row.attempts + 1;
  const blockedUntil = attempts >= limit ? now + windowSeconds : 0;
  await db.prepare("UPDATE admin_rate_limits SET attempts=?, blocked_until=?, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE rate_key=?")
    .bind(attempts, blockedUntil, key).run();
  return !blockedUntil;
}
async function adminSession(request: Request, db: D1Database) {
  const token = cookieValue(request, COOKIE);
  if (!token) return null;
  const tokenHash = await sha256(token);
  return db.prepare("SELECT u.id, u.email FROM admin_sessions s JOIN admin_users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at > strftime('%Y-%m-%dT%H:%M:%fZ','now') AND u.is_active=1")
    .bind(tokenHash).first<{ id: string; email: string }>();
}
const validEmail = (v: unknown): v is string => typeof v === "string" && v.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const validPassword = (v: unknown): v is string => typeof v === "string" && v.length >= 12 && v.length <= 200;

const validSlug = (v: unknown): v is string =>
  typeof v === "string" && v.length <= 120 && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(v);
const validStringArray = (v: unknown, maxItems = 24): v is string[] =>
  Array.isArray(v) && v.length <= maxItems && v.every((item) => typeof item === "string" && item.length <= 100);
const sameOrigin = (request: Request) => {
  const origin = request.headers.get("origin");
  return Boolean(origin) && origin === new URL(request.url).origin;
};
function productString(value: unknown, max: number, fallback = ""): string | null {
  if (value === undefined || value === null) return fallback;
  return typeof value === "string" && value.length <= max ? value.trim() : null;
}

export async function handleD1Api(request: Request, rawEnv: unknown): Promise<Response | null> {
  const url = new URL(request.url);
  if (!url.pathname.startsWith("/api/d1/")) return null;
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: { allow: "GET, POST, OPTIONS" } });
  const env = rawEnv as D1Env;
  if (!env?.DB) {
    // Temporary safe diagnostics: report binding names only, never binding values or secrets.
    const envObject = rawEnv && (typeof rawEnv === "object" || typeof rawEnv === "function")
      ? rawEnv as Record<string, unknown>
      : null;
    return json({
      ok: false,
      code: "D1_NOT_CONFIGURED",
      message: "The Cloudflare D1 binding named DB has not been configured.",
      diagnostic: {
        envType: rawEnv === null ? "null" : typeof rawEnv,
        hasDBProperty: Boolean(envObject && "DB" in envObject),
        bindingNames: envObject ? Object.keys(envObject).filter((key) => /^[A-Z][A-Z0-9_]{0,63}$/.test(key)).slice(0, 40) : [],
      },
    }, 503);
  }
  const db = env.DB;

  // Public, read-only homepage content. Only visible sections inside their schedule are exposed.
  if (url.pathname === "/api/d1/homepage") {
    if (request.method !== "GET") return json({ error: "Method not allowed" }, 405, { allow: "GET, OPTIONS" });
    try {
      const result = await db.prepare("SELECT id,section_key,section_type,title_en,title_fa,body_en,body_fa,image_url,link_url,product_ids_json,sort FROM homepage_sections WHERE is_visible=1 AND (starts_at IS NULL OR starts_at='' OR datetime(starts_at)<=datetime('now')) AND (ends_at IS NULL OR ends_at='' OR datetime(ends_at)>=datetime('now')) ORDER BY sort,section_key").bind().all();
      return json({ ok: true, items: result.results ?? [] });
    } catch {
      return json({ ok: false, code: "HOMEPAGE_QUERY_FAILED" }, 503);
    }
  }

  if (url.pathname === "/api/d1/health" || url.pathname === "/api/d1/catalog") {
    if (request.method !== "GET") return json({ error: "Method not allowed" }, 405, { allow: "GET, OPTIONS" });
    if (url.pathname.endsWith("/health")) {
      try {
        const result = await db.prepare("SELECT COUNT(*) AS found FROM sqlite_master WHERE type='table' AND name IN ('brands','categories','products','product_volumes','product_categories','admin_users','admin_sessions','admin_audit_log','admin_rate_limits','orders','order_items','promotions','homepage_sections','media_assets','shipping_methods')").bind().first<{ found: number }>();
        if (result?.found !== 15) return json({ ok: false, code: "D1_SCHEMA_MISSING" }, 503);
        return json({ ok: true, database: "D1", schema: "ready" });
      } catch { return json({ ok: false, code: "D1_QUERY_FAILED" }, 503); }
    }
    try {
      const [brands, categories, products, volumes, productCategories] = await Promise.all([
        db.prepare("SELECT id,slug,name,blurb_en,blurb_fa,sort FROM brands WHERE is_active=1 ORDER BY sort,name").bind().all(),
        db.prepare("SELECT id,slug,name_en,name_fa,sort FROM categories ORDER BY sort,name_en").bind().all(),
        db.prepare("SELECT p.id,p.slug,p.name,p.brand_id,b.slug AS brand_slug,p.category_id,c.slug AS category_slug,p.price,p.image_url,p.desc_en,p.desc_fa,p.is_new,p.published,p.gender,p.concentration,p.seasons_json,p.notes_json,p.occasions_json,p.scent_character_json,p.created_at,p.updated_at FROM products p LEFT JOIN brands b ON b.id=p.brand_id LEFT JOIN categories c ON c.id=p.category_id WHERE p.published=1 ORDER BY p.created_at DESC").bind().all(),
        db.prepare("SELECT v.id,v.product_id,v.ml,v.price,v.stock,v.sku FROM product_volumes v INNER JOIN products p ON p.id=v.product_id WHERE v.is_active=1 AND p.published=1 ORDER BY v.product_id,v.ml").bind().all(),
        db.prepare("SELECT pc.product_id,pc.category_id FROM product_categories pc INNER JOIN products p ON p.id=pc.product_id WHERE p.published=1").bind().all(),
      ]);
      return json({ ok: true, brands: brands.results ?? [], categories: categories.results ?? [], products: products.results ?? [], volumes: volumes.results ?? [], productCategories: productCategories.results ?? [] });
    } catch { return json({ ok: false, code: "CATALOG_QUERY_FAILED" }, 503); }
  }

  if (url.pathname === "/api/d1/shipping/methods") {
    if (request.method !== "GET") return json({ error: "Method not allowed" }, 405, { allow: "GET, OPTIONS" });
    try {
      const orderColumns = await db.prepare("PRAGMA table_info(orders)").bind().all<{ name: string }>();
      if (!(orderColumns.results ?? []).some((column) => column.name === "shipping_method_id")) {
        return json({ ok: false, code: "SHIPPING_MIGRATION_REQUIRED", message: "Apply the order shipping snapshot migration to enable delivery choices." }, 503);
      }
      const result = await db.prepare("SELECT id,name,name_fa,zone,price,free_shipping_threshold,estimated_min_days,estimated_max_days FROM shipping_methods WHERE is_active=1 ORDER BY sort,zone,name").bind().all();
      return json({ ok: true, items: result.results ?? [] });
    } catch {
      return json({ ok: false, code: "SHIPPING_NOT_CONFIGURED", message: "Shipping methods are not configured yet." }, 503);
    }
  }

  // Public request-order intake: no payment is collected and inventory is not reserved.
  if (url.pathname === "/api/d1/checkout/request") {
    if (request.method !== "POST") return json({ error: "Method not allowed" }, 405, { allow: "POST, OPTIONS" });
    if (!sameOrigin(request)) return json({ ok: false, code: "ORIGIN_REJECTED" }, 403);
    const ip = request.headers.get("CF-Connecting-IP") ?? "unknown";
    if (!(await rateAllowed(db, `order-request:${await sha256(ip)}`, 6, 900))) {
      return json({ ok: false, code: "RATE_LIMITED", message: "Too many order requests. Please try again later." }, 429);
    }
    const body = await readJson(request);
    if (!body || !Array.isArray(body.items) || body.items.length < 1 || body.items.length > 20) {
      return json({ ok: false, code: "INVALID_ORDER_REQUEST", message: "Your selection is empty or too large." }, 400);
    }
    const customerName = productString(body.customer_name, 120);
    const customerEmail = productString(body.customer_email, 254, "");
    const customerPhone = productString(body.customer_phone, 40);
    const shippingAddress = productString(body.shipping_address, 1000);
    const shippingCity = productString(body.shipping_city, 120);
    const shippingPostcode = productString(body.shipping_postcode, 40, "");
    const customerNote = productString(body.customer_note, 1000, "");
    if (!customerName || !customerName.length || !customerPhone || customerPhone.length < 6 ||
        !shippingAddress || !shippingAddress.length || !shippingCity || !shippingCity.length ||
        customerEmail === null || (customerEmail.length > 0 && !validEmail(customerEmail)) ||
        shippingPostcode === null || customerNote === null) {
      return json({ ok: false, code: "INVALID_CUSTOMER_DETAILS", message: "Enter your name, a valid phone number, city and shipping address. Email is optional." }, 400);
    }

    const requested = new Map<string, { productId: string; volumeId: string; quantity: number }>();
    for (const item of body.items) {
      if (!item || typeof item !== "object") return json({ ok: false, code: "INVALID_ORDER_ITEM" }, 400);
      const value = item as Record<string, unknown>;
      const productId = value.product_id;
      const volumeId = value.volume_id;
      const quantity = value.quantity;
      if (typeof productId !== "string" || !/^[A-Za-z0-9_-]{1,128}$/.test(productId) ||
          typeof volumeId !== "string" || !/^[A-Za-z0-9_-]{1,128}$/.test(volumeId) ||
          !Number.isSafeInteger(quantity) || Number(quantity) < 1 || Number(quantity) > 10) {
        return json({ ok: false, code: "INVALID_ORDER_ITEM" }, 400);
      }
      const key = productId + ":" + volumeId;
      const previous = requested.get(key);
      const nextQuantity = (previous?.quantity ?? 0) + Number(quantity);
      if (nextQuantity > 10) return json({ ok: false, code: "INVALID_ORDER_ITEM", message: "A maximum of 10 units per bottle size is allowed." }, 400);
      requested.set(key, { productId, volumeId, quantity: nextQuantity });
    }

    try {
      const lines: Array<{ productId: string; volumeId: string; productName: string; brandName: string; sizeMl: number; sku: string | null; unitPrice: number; quantity: number; lineTotal: number }> = [];
      for (const item of requested.values()) {
        const product = await db.prepare("SELECT p.id,p.name,b.name AS brand_name,v.id AS volume_id,v.ml,v.price,v.stock,v.sku FROM products p INNER JOIN brands b ON b.id=p.brand_id INNER JOIN product_volumes v ON v.product_id=p.id WHERE p.id=? AND v.id=? AND p.published=1 AND v.is_active=1")
          .bind(item.productId, item.volumeId)
          .first<{ id: string; name: string; brand_name: string; volume_id: string; ml: number; price: number; stock: number; sku: string | null }>();
        if (!product) return json({ ok: false, code: "PRODUCT_UNAVAILABLE", message: "One of the selected fragrances is no longer available. Refresh your cart and try again." }, 409);
        if (Number(product.stock) < item.quantity) return json({ ok: false, code: "STOCK_CHANGED", message: "The available stock changed for " + product.name + ". Refresh your cart before sending the request." }, 409);
        const unitPrice = Number(product.price);
        const sizeMl = Number(product.ml);
        if (!Number.isFinite(unitPrice) || unitPrice < 0 || !Number.isFinite(sizeMl) || sizeMl <= 0) {
          return json({ ok: false, code: "INVALID_CATALOG_PRICE", message: "A selected fragrance has incomplete catalogue pricing." }, 409);
        }
        lines.push({
          productId: product.id, volumeId: product.volume_id, productName: product.name,
          brandName: product.brand_name, sizeMl, sku: product.sku, unitPrice,
          quantity: item.quantity, lineTotal: Number((unitPrice * item.quantity).toFixed(2)),
        });
      }

      const subtotal = Number(lines.reduce((sum, line) => sum + line.lineTotal, 0).toFixed(2));
      const promotionCode = (productString(body.promotion_code, 64, "") ?? "").trim().toUpperCase();
      let promotion: { id: string; code: string; discount_type: string; discount_value: number; minimum_order: number; usage_limit: number | null; usage_count: number; is_active: number; has_started: number; has_not_ended: number } | null = null;
      let discountTotal = 0;
      if (promotionCode) {
        promotion = await db.prepare("SELECT id,code,discount_type,discount_value,minimum_order,usage_limit,usage_count,is_active,CASE WHEN starts_at IS NULL OR starts_at='' OR datetime(starts_at)<=datetime('now') THEN 1 ELSE 0 END AS has_started,CASE WHEN ends_at IS NULL OR ends_at='' OR datetime(ends_at)>=datetime('now') THEN 1 ELSE 0 END AS has_not_ended FROM promotions WHERE code=?")
          .bind(promotionCode)
          .first<typeof promotion>();
        if (!promotion || promotion.is_active !== 1 || promotion.has_started !== 1 || promotion.has_not_ended !== 1 ||
            (promotion.usage_limit !== null && promotion.usage_count >= promotion.usage_limit)) {
          return json({ ok: false, code: "PROMOTION_UNAVAILABLE", message: "This discount code is invalid, inactive, expired or has reached its usage limit." }, 400);
        }
        if (subtotal < Number(promotion.minimum_order ?? 0)) {
          return json({ ok: false, code: "PROMOTION_MINIMUM_NOT_MET", message: "Your selection does not meet the minimum order value for this code." }, 400);
        }
        const rawDiscount = promotion.discount_type === "percent"
          ? subtotal * Number(promotion.discount_value) / 100
          : Number(promotion.discount_value);
        discountTotal = Number(Math.min(subtotal, rawDiscount).toFixed(2));
      }

      const discountedSubtotal = Number((subtotal - discountTotal).toFixed(2));
      const shippingMethodId = productString(body.shipping_method_id, 128, "") ?? "";
      let shippingMethod: { id: string; name: string; name_fa: string; zone: string; price: number; free_shipping_threshold: number | null; estimated_min_days: number; estimated_max_days: number } | null = null;
      let activeShippingCount = 0;
      let hasShippingSnapshot = false;
      const orderColumns = await db.prepare("PRAGMA table_info(orders)").bind().all<{ name: string }>();
      hasShippingSnapshot = (orderColumns.results ?? []).some((column) => column.name === "shipping_method_id");
      try {
        const count = await db.prepare("SELECT COUNT(*) AS count FROM shipping_methods WHERE is_active=1").bind().first<{ count: number }>();
        activeShippingCount = Number(count?.count ?? 0);
      } catch {
        if (shippingMethodId) return json({ ok: false, code: "SHIPPING_NOT_READY", message: "Shipping configuration is not ready. Please send the request without a shipping choice." }, 503);
      }
      if (shippingMethodId && !hasShippingSnapshot) {
        return json({ ok: false, code: "SHIPPING_MIGRATION_REQUIRED", message: "Apply the order shipping snapshot migration before selecting a delivery method." }, 503);
      }
      if (hasShippingSnapshot && activeShippingCount > 0 && !shippingMethodId) {
        return json({ ok: false, code: "SHIPPING_METHOD_REQUIRED", message: "Choose a delivery method before sending your request." }, 400);
      }
      if (shippingMethodId) {
        shippingMethod = await db.prepare("SELECT id,name,name_fa,zone,price,free_shipping_threshold,estimated_min_days,estimated_max_days FROM shipping_methods WHERE id=? AND is_active=1")
          .bind(shippingMethodId)
          .first<typeof shippingMethod>();
        if (!shippingMethod) return json({ ok: false, code: "SHIPPING_METHOD_UNAVAILABLE", message: "That delivery method is no longer available. Refresh and choose another." }, 409);
      }
      const shippingTotal = shippingMethod
        ? shippingMethod.free_shipping_threshold !== null && discountedSubtotal >= Number(shippingMethod.free_shipping_threshold)
          ? 0
          : Number(shippingMethod.price)
        : 0;
      const total = Number((discountedSubtotal + shippingTotal).toFixed(2));
      const orderId = crypto.randomUUID();
      const orderNumber = "SS-" + new Date().toISOString().slice(0, 10).replace(/-/g, "") + "-" + crypto.randomUUID().slice(0, 6).toUpperCase();
      const statements: D1BoundStatement[] = [
        db.prepare("UPDATE promotions SET usage_count=usage_count+1,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=? AND ? IS NOT NULL AND is_active=1 AND (usage_limit IS NULL OR usage_count<usage_limit) AND (starts_at IS NULL OR starts_at='' OR datetime(starts_at)<=datetime('now')) AND (ends_at IS NULL OR ends_at='' OR datetime(ends_at)>=datetime('now'))")
          .bind(promotion?.id ?? "", promotion?.code ?? null),
        hasShippingSnapshot
          ? db.prepare("INSERT INTO orders(id,order_number,status,payment_status,customer_name,customer_email,customer_phone,shipping_address,shipping_city,shipping_postcode,customer_note,subtotal,discount_total,shipping_total,total,currency,promotion_code,shipping_method_id,shipping_method_name,shipping_method_name_fa,shipping_zone,shipping_eta_min_days,shipping_eta_max_days) SELECT ?,?,'pending','unpaid',?,?,?,?,?,?,?, ?,?,?,?,'EUR',?,?,?,?,?,?,? WHERE ? IS NULL OR changes()=1")
            .bind(orderId, orderNumber, customerName, customerEmail, customerPhone, shippingAddress, shippingCity, shippingPostcode, customerNote, subtotal, discountTotal, shippingTotal, total, promotion?.code ?? null, shippingMethod?.id ?? null, shippingMethod?.name ?? null, shippingMethod?.name_fa ?? null, shippingMethod?.zone ?? null, shippingMethod?.estimated_min_days ?? null, shippingMethod?.estimated_max_days ?? null, promotion?.code ?? null)
          : db.prepare("INSERT INTO orders(id,order_number,status,payment_status,customer_name,customer_email,customer_phone,shipping_address,shipping_city,shipping_postcode,customer_note,subtotal,discount_total,shipping_total,total,currency,promotion_code) SELECT ?,?,'pending','unpaid',?,?,?,?,?,?,?, ?,?,?,?,'EUR',? WHERE ? IS NULL OR changes()=1")
            .bind(orderId, orderNumber, customerName, customerEmail, customerPhone, shippingAddress, shippingCity, shippingPostcode, customerNote, subtotal, discountTotal, 0, discountedSubtotal, promotion?.code ?? null, promotion?.code ?? null),
      ];
      for (const line of lines) {
        statements.push(db.prepare("INSERT INTO order_items(id,order_id,product_id,volume_id,product_name,brand_name,size_ml,sku,unit_price,quantity,line_total) SELECT ?,?,?,?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM orders WHERE id=?)")
          .bind(crypto.randomUUID(), orderId, line.productId, line.volumeId, line.productName, line.brandName, line.sizeMl, line.sku, line.unitPrice, line.quantity, line.lineTotal, orderId));
      }
      const results = await db.batch(statements) as Array<{ meta?: { changes?: number } }>;
      if (promotion && results[1]?.meta?.changes !== 1) {
        return json({ ok: false, code: "PROMOTION_LIMIT_REACHED", message: "This discount code was just used up. Remove it and send your request again." }, 409);
      }
      if (results[1]?.meta?.changes !== 1) {
        return json({ ok: false, code: "ORDER_REQUEST_FAILED", message: "The order could not be saved. Please try again." }, 503);
      }
      return json({
        ok: true, order_number: orderNumber, status: "pending", payment_status: "unpaid",
        subtotal, discount_total: discountTotal, shipping_total: shippingTotal, total,
        promotion_code: promotion?.code ?? null,
        shipping_method: shippingMethod ? { name: shippingMethod.name, name_fa: shippingMethod.name_fa, zone: shippingMethod.zone, estimated_min_days: shippingMethod.estimated_min_days, estimated_max_days: shippingMethod.estimated_max_days } : null,
        currency: "EUR",
        message: "Your order request was received. Stock confirmation is still required. No payment was taken.",
      }, 201);
    } catch (error) {
      console.error("public_order_request_failed", error instanceof Error ? error.message : String(error));
      return json({ ok: false, code: "ORDER_REQUEST_FAILED", message: "We could not save the request. Please try again later." }, 503);
    }
  }

  if (url.pathname === "/api/d1/admin/setup") {
    if (request.method !== "POST") return json({ error: "Method not allowed" }, 405, { allow: "POST, OPTIONS" });
    if (!sameOrigin(request)) return json({ ok: false, code: "ORIGIN_REJECTED" }, 403);
    if (!env.ADMIN_SETUP_TOKEN || env.ADMIN_SETUP_TOKEN.length < 32) return json({ ok: false, code: "SETUP_DISABLED" }, 503);
    const ip = request.headers.get("CF-Connecting-IP") ?? "unknown";
    if (!(await rateAllowed(db, `setup:${await sha256(ip)}`, 5, 900))) return json({ ok: false, code: "RATE_LIMITED" }, 429);
    const body = await readJson(request);
    if (!body || typeof body.setupToken !== "string" || typeof body.email !== "string" || !validEmail(body.email) || !validPassword(body.password)) {
      return json({ ok: false, code: "INVALID_INPUT", message: "Provide a valid email and a password of at least 12 characters." }, 400);
    }
    if (body.setupToken !== env.ADMIN_SETUP_TOKEN) return json({ ok: false, code: "SETUP_DENIED" }, 403);
    try {
      const id = crypto.randomUUID();
      const insertResult = await db.prepare("INSERT INTO admin_users(id,email,password_hash) SELECT ?,?,? WHERE NOT EXISTS (SELECT 1 FROM admin_users)")
        .bind(id, body.email.trim().toLowerCase(), await passwordHash(body.password)).run() as { meta?: { changes?: number } };
      if (insertResult.meta?.changes !== 1) return json({ ok: false, code: "SETUP_ALREADY_COMPLETED" }, 409);
      await db.prepare("INSERT INTO admin_audit_log(id,user_id,action,entity_type) VALUES(?,?,?,'admin')").bind(crypto.randomUUID(), id, "initial_admin_created").run();
      return json({ ok: true, message: "Admin account created. You can now log in." }, 201);
    } catch (error) {
      const detail = error instanceof Error ? error.message : String(error);
      // Keep database internals out of the public response; log the reason for diagnosis.
      console.error("admin_setup_failed", detail);
      if (detail.includes("UNIQUE constraint failed: admin_users.email")) {
        return json({ ok: false, code: "SETUP_EMAIL_EXISTS", message: "An administrator with this email already exists. Try signing in." }, 409);
      }
      if (detail.includes("no such table: admin_users") || detail.includes("no such table: admin_audit_log")) {
        return json({ ok: false, code: "D1_SCHEMA_MISSING", message: "The administrator tables are missing from the connected D1 database." }, 503);
      }
      return json({ ok: false, code: "SETUP_FAILED", message: "Administrator setup failed on the server. Check the Worker logs for admin_setup_failed." }, 503);
    }
  }

  if (url.pathname === "/api/d1/admin/reset-password") {
    if (request.method !== "POST") return json({ error: "Method not allowed" }, 405, { allow: "POST, OPTIONS" });
    if (!sameOrigin(request)) return json({ ok: false, code: "ORIGIN_REJECTED" }, 403);
    if (!env.ADMIN_SETUP_TOKEN || env.ADMIN_SETUP_TOKEN.length < 32) return json({ ok: false, code: "SETUP_DISABLED" }, 503);
    const ip = request.headers.get("CF-Connecting-IP") ?? "unknown";
    if (!(await rateAllowed(db, `reset:${await sha256(ip)}`, 5, 900))) return json({ ok: false, code: "RATE_LIMITED" }, 429);
    const body = await readJson(request);
    if (!body || body.setupToken !== env.ADMIN_SETUP_TOKEN || typeof body.email !== "string" ||
        !validEmail(body.email) || !validPassword(body.password)) {
      return json({ ok: false, code: "INVALID_INPUT", message: "Provide the valid setup secret, administrator email, and a password of at least 12 characters." }, 400);
    }
    try {
      const user = await db.prepare("SELECT id,email FROM admin_users WHERE email=? COLLATE NOCASE AND is_active=1")
        .bind(body.email.trim()).first<{ id: string; email: string }>();
      if (!user) return json({ ok: false, code: "ADMIN_NOT_FOUND", message: "No active administrator exists for that email." }, 404);
      await db.prepare("UPDATE admin_users SET password_hash=? WHERE id=?")
        .bind(await passwordHash(body.password), user.id).run();
      await db.prepare("DELETE FROM admin_sessions WHERE user_id=?").bind(user.id).run();
      await db.prepare("INSERT INTO admin_audit_log(id,user_id,action,entity_type) VALUES(?,?,?,'admin')")
        .bind(crypto.randomUUID(), user.id, "admin_password_reset").run();
      return json({ ok: true, message: "Password reset. Sign in with your new password." });
    } catch (error) {
      console.error("admin_password_reset_failed", error instanceof Error ? error.message : String(error));
      return json({ ok: false, code: "RESET_FAILED", message: "Password reset failed on the server." }, 503);
    }
  }

  if (url.pathname === "/api/d1/admin/login") {
    if (request.method !== "POST") return json({ error: "Method not allowed" }, 405, { allow: "POST, OPTIONS" });
    if (!sameOrigin(request)) return json({ ok: false, code: "ORIGIN_REJECTED" }, 403);
    const ip = request.headers.get("CF-Connecting-IP") ?? "unknown";
    if (!(await rateAllowed(db, `login:${await sha256(ip)}`, 8, 900))) return json({ ok: false, code: "RATE_LIMITED" }, 429);
    const body = await readJson(request);
    if (!body || !validEmail(body.email) || typeof body.password !== "string" || body.password.length > 200) return json({ ok: false, code: "INVALID_CREDENTIALS" }, 401);
    try {
      const user = await db.prepare("SELECT id,email,password_hash FROM admin_users WHERE email=? COLLATE NOCASE AND is_active=1")
        .bind(body.email.trim()).first<{ id: string; email: string; password_hash: string }>();
      if (!user || !(await verifyPassword(body.password, user.password_hash))) return json({ ok: false, code: "INVALID_CREDENTIALS" }, 401);
      const token = randomToken();
      const expiresAt = new Date(Date.now() + SESSION_SECONDS * 1000).toISOString();
      await db.prepare("INSERT INTO admin_sessions(id,user_id,token_hash,expires_at) VALUES(?,?,?,?)")
        .bind(crypto.randomUUID(), user.id, await sha256(token), expiresAt).run();
      await db.prepare("INSERT INTO admin_audit_log(id,user_id,action,entity_type) VALUES(?,?,?,'admin')").bind(crypto.randomUUID(), user.id, "admin_login").run();
      return json({ ok: true, user: { id: user.id, email: user.email } }, 200, { "set-cookie": setCookie(token) });
    } catch { return json({ ok: false, code: "LOGIN_FAILED" }, 503); }
  }



  if (url.pathname === "/api/d1/admin/brands" || url.pathname === "/api/d1/admin/categories") {
    const isBrand = url.pathname.endsWith("/brands");
    if (request.method !== "GET" && request.method !== "POST") {
      return json({ error: "Method not allowed" }, 405, { allow: "GET, POST, OPTIONS" });
    }
    const user = await adminSession(request, db).catch(() => null);
    if (!user) return json({ ok: false, code: "UNAUTHENTICATED" }, 401);
    if (request.method === "GET") {
      try {
        const query = isBrand
          ? "SELECT id,slug,name,blurb_en,blurb_fa,sort,is_active FROM brands ORDER BY sort,name"
          : "SELECT id,slug,name_en,name_fa,sort FROM categories ORDER BY sort,name_en";
        const result = await db.prepare(query).bind().all();
        return json({ ok: true, items: result.results ?? [] });
      } catch { return json({ ok: false, code: "ADMIN_REFERENCE_QUERY_FAILED" }, 503); }
    }
    if (!sameOrigin(request)) return json({ ok: false, code: "ORIGIN_REJECTED" }, 403);
    const body = await readJson(request);
    if (!body) return json({ ok: false, code: "INVALID_JSON" }, 400);
    const slug = productString(body.slug, 120);
    const originalSlug = body.original_slug === undefined || body.original_slug === null || body.original_slug === ""
      ? null : productString(body.original_slug, 120);
    try {
      if (!validSlug(slug) || (body.original_slug !== undefined && body.original_slug !== null && body.original_slug !== "" && !validSlug(originalSlug))) {
        return json({ ok: false, code: "INVALID_SLUG" }, 400);
      }
      let statement: D1BoundStatement;
      let entityId: string;
      if (isBrand) {
        const name = productString(body.name, 160);
        const blurbEn = productString(body.blurb_en, 1000, "");
        const blurbFa = productString(body.blurb_fa, 1000, "");
        if (!name || !name.length || blurbEn === null || blurbFa === null) return json({ ok: false, code: "INVALID_BRAND" }, 400);
        const previous = originalSlug ? await db.prepare("SELECT id FROM brands WHERE slug=?").bind(originalSlug).first<{ id: string }>() : null;
        entityId = previous?.id ?? crypto.randomUUID();
        statement = previous
          ? db.prepare("UPDATE brands SET slug=?,name=?,blurb_en=?,blurb_fa=?,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?")
              .bind(slug, name, blurbEn, blurbFa, entityId)
          : db.prepare("INSERT INTO brands(id,slug,name,blurb_en,blurb_fa) VALUES(?,?,?,?,?)")
              .bind(entityId, slug, name, blurbEn, blurbFa);
      } else {
        const nameEn = productString(body.name_en, 160);
        const nameFa = productString(body.name_fa, 160);
        const sort = body.sort === undefined ? 0 : body.sort;
        if (!nameEn || !nameEn.length || !nameFa || !nameFa.length || typeof sort !== "number" || !Number.isSafeInteger(sort) || sort < 0 || sort > 100000) {
          return json({ ok: false, code: "INVALID_CATEGORY" }, 400);
        }
        const previous = originalSlug ? await db.prepare("SELECT id FROM categories WHERE slug=?").bind(originalSlug).first<{ id: string }>() : null;
        entityId = previous?.id ?? crypto.randomUUID();
        statement = previous
          ? db.prepare("UPDATE categories SET slug=?,name_en=?,name_fa=?,sort=? WHERE id=?")
              .bind(slug, nameEn, nameFa, sort, entityId)
          : db.prepare("INSERT INTO categories(id,slug,name_en,name_fa,sort) VALUES(?,?,?,?,?)")
              .bind(entityId, slug, nameEn, nameFa, sort);
      }
      await db.batch([
        statement,
        db.prepare("INSERT INTO admin_audit_log(id,user_id,action,entity_type,entity_id) VALUES(?,?,?,?,?)")
          .bind(crypto.randomUUID(), user.id, originalSlug ? "reference_updated" : "reference_created", isBrand ? "brand" : "category", entityId),
      ]);
      return json({ ok: true, id: entityId, message: isBrand ? "Brand saved." : "Category saved." });
    } catch {
      return json({ ok: false, code: "REFERENCE_SAVE_FAILED", message: "Could not save. Check for a duplicate slug." }, 409);
    }
  }

  if (url.pathname === "/api/d1/admin/products") {
    if (request.method !== "GET" && request.method !== "POST") {
      return json({ error: "Method not allowed" }, 405, { allow: "GET, POST, OPTIONS" });
    }
    const user = await adminSession(request, db).catch(() => null);
    if (!user) return json({ ok: false, code: "UNAUTHENTICATED" }, 401);
    if (request.method === "GET") {
      try {
        const [brands, categories, products, volumes, productCategories] = await Promise.all([
          db.prepare("SELECT id,slug,name,blurb_en,blurb_fa,sort,is_active FROM brands ORDER BY sort,name").bind().all(),
          db.prepare("SELECT id,slug,name_en,name_fa,sort FROM categories ORDER BY sort,name_en").bind().all(),
          db.prepare("SELECT id,slug,name,brand_id,category_id,price,image_url,desc_en,desc_fa,published,is_new,gender,concentration,seasons_json,notes_json,occasions_json,scent_character_json,created_at,updated_at FROM products ORDER BY updated_at DESC").bind().all(),
          db.prepare("SELECT id,product_id,ml,price,stock,sku,is_active FROM product_volumes ORDER BY product_id,ml").bind().all(),
          db.prepare("SELECT product_id,category_id FROM product_categories").bind().all(),
        ]);
        return json({ ok: true, brands: brands.results ?? [], categories: categories.results ?? [], products: products.results ?? [], volumes: volumes.results ?? [], productCategories: productCategories.results ?? [] });
      } catch { return json({ ok: false, code: "ADMIN_CATALOG_QUERY_FAILED" }, 503); }
    }

    if (!sameOrigin(request)) return json({ ok: false, code: "ORIGIN_REJECTED" }, 403);
    const body = await readJson(request);
    if (!body) return json({ ok: false, code: "INVALID_JSON" }, 400);
    const id = body.id === undefined || body.id === null || body.id === "" ? crypto.randomUUID()
      : typeof body.id === "string" && /^[A-Za-z0-9_-]{1,128}$/.test(body.id) ? body.id : null;
    const slug = productString(body.slug, 120);
    const name = productString(body.name, 180);
    const descEn = productString(body.desc_en, 12000, "");
    const descFa = productString(body.desc_fa, 12000, "");
    const imageUrl = productString(body.image_url, 2048, "");
    const brandSlug = body.brand_slug === undefined || body.brand_slug === null || body.brand_slug === "" ? null : productString(body.brand_slug, 120);
    const gender = body.gender === undefined || body.gender === null || body.gender === "" ? null : body.gender;
    const concentration = body.concentration === undefined || body.concentration === null || body.concentration === "" ? null : body.concentration;
    const seasons = body.seasons === undefined ? [] : body.seasons;
    const occasions = body.occasions === undefined ? [] : body.occasions;
    const scentCharacter = body.scent_character === undefined ? [] : body.scent_character;
    const rawNotes = body.notes === undefined || body.notes === null ? {} : body.notes;
    const rawVolumes = body.volumes === undefined ? [] : body.volumes;
    let price = body.price === undefined ? 0 : body.price;

    if (!id || !validSlug(slug) || !name || !name.length || descEn === null || descFa === null || imageUrl === null ||
        (imageUrl !== "" && !/^https:\/\//i.test(imageUrl) && !/^asset:[A-Za-z0-9_-]+$/.test(imageUrl)) ||
        (brandSlug !== null && (brandSlug === "" || !validSlug(brandSlug))) ||
        (gender !== null && !["women","men","unisex"].includes(String(gender))) ||
        (concentration !== null && !["parfum","edp","edt","edc","extrait"].includes(String(concentration))) ||
        !validStringArray(seasons, 8) || !validStringArray(occasions) || !validStringArray(scentCharacter) ||
        typeof rawNotes !== "object" || Array.isArray(rawNotes) || rawNotes === null ||
        !Array.isArray(rawVolumes) || rawVolumes.length > 50 ||
        typeof price !== "number" || !Number.isFinite(price) || price < 0 ||
        typeof body.published !== "boolean" || typeof body.is_new !== "boolean") {
      return json({ ok: false, code: "INVALID_PRODUCT", message: "Some product fields are invalid." }, 400);
    }
    const notes = rawNotes as Record<string, unknown>;
    for (const key of ["top", "heart", "base"]) {
      if (notes[key] !== undefined && (typeof notes[key] !== "string" || (notes[key] as string).length > 500)) {
        return json({ ok: false, code: "INVALID_NOTES" }, 400);
      }
    }
    const volumeRows: Array<{ id: string; ml: number; price: number; stock: number; sku: string | null }> = [];
    for (const volume of rawVolumes as unknown[]) {
      if (!volume || typeof volume !== "object" || Array.isArray(volume)) return json({ ok: false, code: "INVALID_VOLUME" }, 400);
      const v = volume as Record<string, unknown>;
      const ml = v.ml;
      const volumePrice = v.price;
      const stock = v.stock;
      const sku = v.sku === undefined || v.sku === null || v.sku === "" ? null : v.sku;
      if (typeof ml !== "number" || !Number.isFinite(ml) || ml <= 0 || ml > 5000 ||
          typeof volumePrice !== "number" || !Number.isFinite(volumePrice) || volumePrice < 0 ||
          typeof stock !== "number" || !Number.isSafeInteger(stock) || stock < 0 ||
          (sku !== null && (typeof sku !== "string" || sku.length > 80))) {
        return json({ ok: false, code: "INVALID_VOLUME" }, 400);
      }
      volumeRows.push({ id: crypto.randomUUID(), ml, price: volumePrice, stock, sku: sku as string | null });
    }

    try {
      let brandId: string | null = null;
      if (brandSlug) {
        const brand = await db.prepare("SELECT id FROM brands WHERE slug=? AND is_active=1").bind(brandSlug).first<{ id: string }>();
        if (!brand) return json({ ok: false, code: "UNKNOWN_BRAND" }, 400);
        brandId = brand.id;
      }
      const rawCategoryIds = body.category_ids === undefined ? (body.category_id ? [body.category_id] : []) : body.category_ids;
      if (!validStringArray(rawCategoryIds, 30) || rawCategoryIds.some((value) => value.length > 128)) {
        return json({ ok: false, code: "INVALID_CATEGORIES" }, 400);
      }
      const categoryIds = [...new Set(rawCategoryIds)];
      if (body.category_id !== undefined && body.category_id !== null && body.category_id !== "" && typeof body.category_id !== "string") {
        return json({ ok: false, code: "INVALID_CATEGORIES" }, 400);
      }
      if (typeof body.category_id === "string" && body.category_id && !categoryIds.includes(body.category_id)) categoryIds.unshift(body.category_id);
      let primaryCategoryId: string | null = categoryIds[0] ?? null;
      if (typeof body.category_id === "string" && body.category_id) primaryCategoryId = body.category_id;
      if (categoryIds.length) {
        const placeholders = categoryIds.map(() => "?").join(",");
        const found = await db.prepare("SELECT id FROM categories WHERE id IN (" + placeholders + ")").bind(...categoryIds).all<{ id: string }>();
        if ((found.results ?? []).length !== categoryIds.length) return json({ ok: false, code: "UNKNOWN_CATEGORY" }, 400);
      }
      if (price === 0 && volumeRows.length > 0) price = volumeRows[0].price;

      const statements: D1BoundStatement[] = [
        db.prepare("INSERT INTO products (id,slug,name,brand_id,category_id,price,image_url,desc_en,desc_fa,published,is_new,gender,concentration,seasons_json,notes_json,occasions_json,scent_character_json) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET slug=excluded.slug,name=excluded.name,brand_id=excluded.brand_id,category_id=excluded.category_id,price=excluded.price,image_url=excluded.image_url,desc_en=excluded.desc_en,desc_fa=excluded.desc_fa,published=excluded.published,is_new=excluded.is_new,gender=excluded.gender,concentration=excluded.concentration,seasons_json=excluded.seasons_json,notes_json=excluded.notes_json,occasions_json=excluded.occasions_json,scent_character_json=excluded.scent_character_json,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')")
          .bind(id, slug, name, brandId, primaryCategoryId, price, imageUrl || null, descEn, descFa, body.published ? 1 : 0, body.is_new ? 1 : 0, gender, concentration, JSON.stringify(seasons), JSON.stringify({ top: typeof notes.top === "string" ? notes.top : "", heart: typeof notes.heart === "string" ? notes.heart : "", base: typeof notes.base === "string" ? notes.base : "" }), JSON.stringify(occasions), JSON.stringify(scentCharacter)),
        db.prepare("DELETE FROM product_categories WHERE product_id=?").bind(id),
        db.prepare("UPDATE product_volumes SET is_active=0, updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE product_id=?").bind(id),
        db.prepare("INSERT INTO admin_audit_log(id,user_id,action,entity_type,entity_id) VALUES(?,?,?,'product',?)").bind(crypto.randomUUID(), user.id, "product_saved", id),
      ];
      for (const categoryId of categoryIds) statements.push(db.prepare("INSERT INTO product_categories(product_id,category_id) VALUES(?,?)").bind(id, categoryId));
      for (const volume of volumeRows) {
        statements.push(db.prepare("INSERT INTO product_volumes(id,product_id,ml,price,stock,sku,is_active) VALUES(?,?,?,?,?,?,1) ON CONFLICT(product_id,ml) DO UPDATE SET price=excluded.price,stock=excluded.stock,sku=excluded.sku,is_active=1,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')")
          .bind(volume.id, id, volume.ml, volume.price, volume.stock, volume.sku));
      }
      await db.batch(statements);
      return json({ ok: true, id, message: "Product saved." });
    } catch {
      return json({ ok: false, code: "PRODUCT_SAVE_FAILED", message: "Could not save the product. Check for duplicate slug or SKU." }, 409);
    }
  }


  if (url.pathname === "/api/d1/admin/customers") {
    if (request.method !== "GET") return json({ error: "Method not allowed" }, 405, { allow: "GET, OPTIONS" });
    const user = await adminSession(request, db).catch(() => null);
    if (!user) return json({ ok: false, code: "UNAUTHENTICATED" }, 401);
    try {
      const result = await db.prepare("SELECT MIN(id) AS id,MAX(customer_name) AS customer_name,lower(MAX(customer_email)) AS customer_email,MAX(customer_phone) AS customer_phone,COUNT(*) AS order_count,SUM(total) AS order_value_total,MAX(created_at) AS last_order_at,MAX(currency) AS currency FROM orders WHERE trim(customer_email)<>'' OR trim(customer_phone)<>'' GROUP BY CASE WHEN trim(customer_email)<>'' THEN lower(customer_email) ELSE customer_phone END ORDER BY last_order_at DESC LIMIT 500").bind().all();
      return json({ ok: true, items: result.results ?? [] });
    } catch {
      return json({ ok: false, code: "CUSTOMER_QUERY_FAILED", message: "Could not load customers from order history." }, 503);
    }
  }

  // Store operations: all management endpoints require an authenticated admin session.
  const storeCollection = url.pathname.match(/^\/api\/d1\/admin\/(orders|promotions|homepage|media|shipping)$/);
  const storeItem = url.pathname.match(/^\/api\/d1\/admin\/(promotions|homepage|media|shipping)\/([A-Za-z0-9_-]{1,128})$/);
  if (storeCollection || storeItem) {
    const resource = storeCollection?.[1] ?? storeItem?.[1] ?? "";
    const itemId = storeItem?.[2] ?? null;
    if (!["GET", "POST", "DELETE"].includes(request.method)) {
      return json({ error: "Method not allowed" }, 405, { allow: "GET, POST, DELETE, OPTIONS" });
    }
    const user = await adminSession(request, db).catch(() => null);
    if (!user) return json({ ok: false, code: "UNAUTHENTICATED" }, 401);
    if (request.method !== "GET" && !sameOrigin(request)) return json({ ok: false, code: "ORIGIN_REJECTED" }, 403);

    if (request.method === "DELETE") {
      if (!itemId || resource === "orders") return json({ ok: false, code: "DELETE_NOT_ALLOWED" }, 405);
      const table = resource === "promotions" ? "promotions" : resource === "homepage" ? "homepage_sections" : resource === "shipping" ? "shipping_methods" : "media_assets";
      try {
        await db.batch([
          db.prepare("DELETE FROM " + table + " WHERE id=?").bind(itemId),
          db.prepare("INSERT INTO admin_audit_log(id,user_id,action,entity_type,entity_id) VALUES(?,?,?,?,?)")
            .bind(crypto.randomUUID(), user.id, resource + "_deleted", resource, itemId),
        ]);
        return json({ ok: true });
      } catch {
        return json({ ok: false, code: "STORE_DELETE_FAILED" }, 503);
      }
    }

    if (request.method === "GET") {
      try {
        if (resource === "orders") {
          const result = await db.prepare("SELECT * FROM orders ORDER BY created_at DESC LIMIT 500").bind().all<Record<string, unknown>>();
          const orders = result.results ?? [];
          const items = orders.length
            ? await db.prepare("SELECT id,order_id,product_id,volume_id,product_name,brand_name,size_ml,sku,unit_price,quantity,line_total FROM order_items WHERE order_id IN (" + orders.map(() => "?").join(",") + ") ORDER BY product_name").bind(...orders.map((o) => String(o.id))).all<Record<string, unknown>>()
            : { results: [] as Record<string, unknown>[] };
          const byOrder = new Map<string, Record<string, unknown>[]>();
          for (const item of items.results ?? []) byOrder.set(String(item.order_id), [...(byOrder.get(String(item.order_id)) ?? []), item]);
          return json({ ok: true, items: orders.map((order) => ({ ...order, items: byOrder.get(String(order.id)) ?? [] })) });
        }
        if (resource === "promotions") {
          const result = await db.prepare("SELECT id,code,name,description,discount_type,discount_value,minimum_order,usage_limit,usage_count,starts_at,ends_at,is_active,created_at,updated_at FROM promotions ORDER BY created_at DESC").bind().all();
          return json({ ok: true, items: result.results ?? [] });
        }
        if (resource === "homepage") {
          const result = await db.prepare("SELECT id,section_key,section_type,title_en,title_fa,body_en,body_fa,image_url,link_url,product_ids_json,sort,is_visible,starts_at,ends_at,created_at,updated_at FROM homepage_sections ORDER BY sort,section_key").bind().all();
          return json({ ok: true, items: result.results ?? [] });
        }
        if (resource === "shipping") {
          const result = await db.prepare("SELECT id,name,name_fa,zone,price,free_shipping_threshold,estimated_min_days,estimated_max_days,is_active,sort,created_at,updated_at FROM shipping_methods ORDER BY sort,zone,name").bind().all();
          return json({ ok: true, items: result.results ?? [] });
        }
        const result = await db.prepare("SELECT id,title,asset_url,alt_en,alt_fa,media_type,mime_type,byte_size,width,height,created_at,updated_at FROM media_assets ORDER BY created_at DESC").bind().all();
        return json({ ok: true, items: result.results ?? [] });
      } catch {
        return json({ ok: false, code: "STORE_QUERY_FAILED", message: "Store operations tables are not ready. Apply the next D1 migration first." }, 503);
      }
    }

    const body = await readJson(request);
    if (!body) return json({ ok: false, code: "INVALID_JSON" }, 400);
    const id = typeof body.id === "string" && /^[A-Za-z0-9_-]{1,128}$/.test(body.id) ? body.id : crypto.randomUUID();
    try {
      if (resource === "orders") {
        if (typeof body.id !== "string" ||
            !["pending","confirmed","processing","shipped","completed","cancelled","refunded"].includes(String(body.status)) ||
            !["unpaid","paid","failed","refunded"].includes(String(body.payment_status))) {
          return json({ ok: false, code: "INVALID_ORDER_UPDATE" }, 400);
        }
        const result = await db.prepare("UPDATE orders SET status=?,payment_status=?,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now') WHERE id=?")
          .bind(body.status, body.payment_status, body.id).run() as { meta?: { changes?: number } };
        if (result.meta?.changes !== 1) return json({ ok: false, code: "ORDER_NOT_FOUND" }, 404);
        await db.prepare("INSERT INTO admin_audit_log(id,user_id,action,entity_type,entity_id) VALUES(?,?,?,'order',?)")
          .bind(crypto.randomUUID(), user.id, "order_status_updated", body.id).run();
        return json({ ok: true, id: body.id });
      }

      if (resource === "promotions") {
        const code = productString(body.code, 64);
        const name = productString(body.name, 160);
        const description = productString(body.description, 2000, "");
        const type = body.discount_type;
        const value = body.discount_value;
        const minimum = body.minimum_order === undefined ? 0 : body.minimum_order;
        const usageLimit = body.usage_limit === undefined || body.usage_limit === null || body.usage_limit === "" ? null : body.usage_limit;
        if (!code || !/^[A-Za-z0-9_-]{2,64}$/.test(code) || !name || !name.length || description === null ||
            !["percent","fixed"].includes(String(type)) || typeof value !== "number" || !Number.isFinite(value) || value <= 0 ||
            (type === "percent" && value > 100) || typeof minimum !== "number" || !Number.isFinite(minimum) || minimum < 0 ||
            (usageLimit !== null && (typeof usageLimit !== "number" || !Number.isSafeInteger(usageLimit) || usageLimit < 0)) ||
            (body.is_active !== undefined && typeof body.is_active !== "boolean")) return json({ ok: false, code: "INVALID_PROMOTION" }, 400);
        const starts = productString(body.starts_at, 40, "");
        const ends = productString(body.ends_at, 40, "");
        if (starts === null || ends === null) return json({ ok: false, code: "INVALID_PROMOTION_DATES" }, 400);
        await db.prepare("INSERT INTO promotions(id,code,name,description,discount_type,discount_value,minimum_order,usage_limit,starts_at,ends_at,is_active) VALUES(?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET code=excluded.code,name=excluded.name,description=excluded.description,discount_type=excluded.discount_type,discount_value=excluded.discount_value,minimum_order=excluded.minimum_order,usage_limit=excluded.usage_limit,starts_at=excluded.starts_at,ends_at=excluded.ends_at,is_active=excluded.is_active,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')")
          .bind(id, code.toUpperCase(), name, description, type, value, minimum, usageLimit, starts || null, ends || null, body.is_active === false ? 0 : 1).run();
      } else if (resource === "homepage") {
        const key = productString(body.section_key, 120);
        const type = productString(body.section_type, 40, "editorial");
        const titleEn = productString(body.title_en, 240, "");
        const titleFa = productString(body.title_fa, 240, "");
        const bodyEn = productString(body.body_en, 4000, "");
        const bodyFa = productString(body.body_fa, 4000, "");
        const image = productString(body.image_url, 2048, "");
        const link = productString(body.link_url, 2048, "");
        const rawProducts = body.product_ids === undefined ? [] : body.product_ids;
        const sort = body.sort === undefined ? 0 : body.sort;
        if (!key || !validSlug(key) || type === null || !type || titleEn === null || titleFa === null || bodyEn === null || bodyFa === null ||
            image === null || link === null || (image && !/^https:\/\//i.test(image) && !/^asset:[A-Za-z0-9_-]+$/.test(image)) ||
            (link && !/^https:\/\//i.test(link) && !link.startsWith("/")) || !validStringArray(rawProducts, 50) ||
            typeof sort !== "number" || !Number.isSafeInteger(sort) || sort < 0 || sort > 100000 ||
            (body.is_visible !== undefined && typeof body.is_visible !== "boolean")) return json({ ok: false, code: "INVALID_HOMEPAGE_SECTION" }, 400);
        const starts = productString(body.starts_at, 40, "");
        const ends = productString(body.ends_at, 40, "");
        if (starts === null || ends === null) return json({ ok: false, code: "INVALID_HOMEPAGE_DATES" }, 400);
        await db.prepare("INSERT INTO homepage_sections(id,section_key,section_type,title_en,title_fa,body_en,body_fa,image_url,link_url,product_ids_json,sort,is_visible,starts_at,ends_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET section_key=excluded.section_key,section_type=excluded.section_type,title_en=excluded.title_en,title_fa=excluded.title_fa,body_en=excluded.body_en,body_fa=excluded.body_fa,image_url=excluded.image_url,link_url=excluded.link_url,product_ids_json=excluded.product_ids_json,sort=excluded.sort,is_visible=excluded.is_visible,starts_at=excluded.starts_at,ends_at=excluded.ends_at,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')")
          .bind(id, key, type, titleEn, titleFa, bodyEn, bodyFa, image || null, link || null, JSON.stringify(rawProducts), sort, body.is_visible === false ? 0 : 1, starts || null, ends || null).run();
      } else if (resource === "shipping") {
        const name = productString(body.name, 160);
        const nameFa = productString(body.name_fa, 160, "");
        const zone = productString(body.zone, 120, "Domestic");
        const price = body.price;
        const threshold = body.free_shipping_threshold === undefined || body.free_shipping_threshold === null || body.free_shipping_threshold === "" ? null : body.free_shipping_threshold;
        const minDays = body.estimated_min_days === undefined ? 2 : body.estimated_min_days;
        const maxDays = body.estimated_max_days === undefined ? 5 : body.estimated_max_days;
        const sort = body.sort === undefined ? 0 : body.sort;
        if (!name || !name.length || nameFa === null || !zone || !zone.length ||
            typeof price !== "number" || !Number.isFinite(price) || price < 0 ||
            (threshold !== null && (typeof threshold !== "number" || !Number.isFinite(threshold) || threshold < 0)) ||
            !Number.isSafeInteger(minDays) || minDays < 0 || minDays > 60 ||
            !Number.isSafeInteger(maxDays) || maxDays < minDays || maxDays > 60 ||
            !Number.isSafeInteger(sort) || sort < 0 || sort > 100000 ||
            (body.is_active !== undefined && typeof body.is_active !== "boolean")) {
          return json({ ok: false, code: "INVALID_SHIPPING_METHOD" }, 400);
        }
        await db.prepare("INSERT INTO shipping_methods(id,name,name_fa,zone,price,free_shipping_threshold,estimated_min_days,estimated_max_days,is_active,sort) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,name_fa=excluded.name_fa,zone=excluded.zone,price=excluded.price,free_shipping_threshold=excluded.free_shipping_threshold,estimated_min_days=excluded.estimated_min_days,estimated_max_days=excluded.estimated_max_days,is_active=excluded.is_active,sort=excluded.sort,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')")
          .bind(id, name, nameFa, zone, price, threshold, minDays, maxDays, body.is_active === false ? 0 : 1, sort).run();
      } else {
        const title = productString(body.title, 240, "");
        const assetUrl = productString(body.asset_url, 2048);
        const altEn = productString(body.alt_en, 500, "");
        const altFa = productString(body.alt_fa, 500, "");
        const mediaType = body.media_type ?? "image";
        const mime = productString(body.mime_type, 120, "");
        const size = body.byte_size === undefined ? 0 : body.byte_size;
        const width = body.width === undefined || body.width === null || body.width === "" ? null : body.width;
        const height = body.height === undefined || body.height === null || body.height === "" ? null : body.height;
        if (title === null || !assetUrl || !/^https:\/\//i.test(assetUrl) || altEn === null || altFa === null ||
            !["image","video","document"].includes(String(mediaType)) || mime === null ||
            typeof size !== "number" || !Number.isSafeInteger(size) || size < 0 ||
            (width !== null && (typeof width !== "number" || !Number.isSafeInteger(width) || width <= 0)) ||
            (height !== null && (typeof height !== "number" || !Number.isSafeInteger(height) || height <= 0))) return json({ ok: false, code: "INVALID_MEDIA_ASSET" }, 400);
        await db.prepare("INSERT INTO media_assets(id,title,asset_url,alt_en,alt_fa,media_type,mime_type,byte_size,width,height) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET title=excluded.title,asset_url=excluded.asset_url,alt_en=excluded.alt_en,alt_fa=excluded.alt_fa,media_type=excluded.media_type,mime_type=excluded.mime_type,byte_size=excluded.byte_size,width=excluded.width,height=excluded.height,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')")
          .bind(id, title, assetUrl, altEn, altFa, mediaType, mime, size, width, height).run();
      }
      await db.prepare("INSERT INTO admin_audit_log(id,user_id,action,entity_type,entity_id) VALUES(?,?,?,?,?)")
        .bind(crypto.randomUUID(), user.id, itemId ? resource + "_updated" : resource + "_saved", resource, id).run();
      return json({ ok: true, id });
    } catch (error) {
      console.error("store_operation_save_failed", resource, error instanceof Error ? error.message : String(error));
      return json({ ok: false, code: "STORE_SAVE_FAILED", message: "Could not save this record. Check unique codes, keys, and field values." }, 409);
    }
  }

  if (url.pathname === "/api/d1/admin/session") {
    if (request.method !== "GET") return json({ error: "Method not allowed" }, 405, { allow: "GET, OPTIONS" });
    try {
      const user = await adminSession(request, db);
      return user ? json({ ok: true, user }) : json({ ok: false, code: "UNAUTHENTICATED" }, 401);
    } catch { return json({ ok: false, code: "SESSION_CHECK_FAILED" }, 503); }
  }

  if (url.pathname === "/api/d1/admin/logout") {
    if (request.method !== "POST") return json({ error: "Method not allowed" }, 405, { allow: "POST, OPTIONS" });
    if (!sameOrigin(request)) return json({ ok: false, code: "ORIGIN_REJECTED" }, 403);
    try {
      const token = cookieValue(request, COOKIE);
      if (token) await db.prepare("DELETE FROM admin_sessions WHERE token_hash=?").bind(await sha256(token)).run();
      return json({ ok: true }, 200, { "set-cookie": clearCookie() });
    } catch { return json({ ok: false, code: "LOGOUT_FAILED" }, 503, { "set-cookie": clearCookie() }); }
  }

  return json({ error: "Not found" }, 404);
}
