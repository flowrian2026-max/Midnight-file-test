import type { DemoBrand, DemoCategory, DemoProduct, DemoVolume } from "./demo-catalog";
import type { DemoCatalog } from "./demo-store";

const BACKUP_SCHEMA = "scent-scribe-catalog-backup";
const BACKUP_VERSION = 1;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function nonEmptyString(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0;
}
function uniqueBy<T>(items: T[], key: (item: T) => string): boolean {
  const values = items.map(key);
  return new Set(values).size === values.length;
}
function isBrand(value: unknown): value is DemoBrand {
  return isRecord(value) &&
    nonEmptyString(value.slug) &&
    nonEmptyString(value.name) &&
    typeof value.blurbEn === "string" &&
    typeof value.blurbFa === "string";
}
function isCategory(value: unknown): value is DemoCategory {
  return isRecord(value) &&
    nonEmptyString(value.id) &&
    nonEmptyString(value.slug) &&
    nonEmptyString(value.name_en) &&
    nonEmptyString(value.name_fa) &&
    typeof value.sort === "number" &&
    Number.isFinite(value.sort);
}
function isVolume(value: unknown): value is DemoVolume {
  return isRecord(value) &&
    nonEmptyString(value.id) &&
    Number.isInteger(value.ml) && Number(value.ml) > 0 &&
    typeof value.price === "number" && Number.isFinite(value.price) && value.price >= 0 &&
    Number.isInteger(value.stock) && Number(value.stock) >= 0;
}
function isStringArray(value: unknown): boolean {
  return Array.isArray(value) && value.every((item) => typeof item === "string");
}
function isProduct(value: unknown): value is DemoProduct {
  if (!isRecord(value)) return false;
  const requiredStrings = [
    "id", "slug", "name", "brand_slug", "category_id", "image_url",
    "desc_en", "desc_fa", "created_at",
  ];
  if (!requiredStrings.every((key) => typeof value[key] === "string")) return false;
  if (!nonEmptyString(value.id) || !nonEmptyString(value.slug) || !nonEmptyString(value.name) || !nonEmptyString(value.brand_slug)) return false;
  if (typeof value.published !== "boolean" || typeof value.is_new !== "boolean") return false;
  if (!Array.isArray(value.volumes) || !value.volumes.every(isVolume)) return false;
  for (const key of ["category_ids", "category_slugs", "seasons", "occasions", "scent_character"]) {
    if (value[key] !== undefined && !isStringArray(value[key])) return false;
  }
  if (value.notes !== undefined) {
    if (!isRecord(value.notes)) return false;
    for (const key of ["top", "heart", "base"]) {
      if (value.notes[key] !== undefined && typeof value.notes[key] !== "string") return false;
    }
  }
  if (value.gender !== undefined && !["women", "men", "unisex"].includes(String(value.gender))) return false;
  if (value.concentration !== undefined && !["parfum", "edp", "edt", "edc", "extrait"].includes(String(value.concentration))) return false;
  return true;
}

export function serializeCatalogBackup(catalog: DemoCatalog): string {
  return JSON.stringify({
    schema: BACKUP_SCHEMA,
    version: BACKUP_VERSION,
    exportedAt: new Date().toISOString(),
    catalog,
  }, null, 2);
}

export function parseCatalogBackup(input: unknown): DemoCatalog {
  if (!isRecord(input) || input.schema !== BACKUP_SCHEMA) {
    throw new Error("This is not a Scent Scribe catalogue backup.");
  }
  if (input.version !== BACKUP_VERSION) {
    throw new Error("This backup version is not supported by this release.");
  }
  const value = input.catalog;
  if (!isRecord(value) ||
      !Array.isArray(value.brands) ||
      !Array.isArray(value.categories) ||
      !Array.isArray(value.products)) {
    throw new Error("The backup is missing its brands, categories or products.");
  }

  const brands = value.brands;
  const categories = value.categories;
  const products = value.products;
  if (!brands.every(isBrand) || !categories.every(isCategory) || !products.every(isProduct)) {
    throw new Error("The backup contains invalid records. Nothing was restored.");
  }
  if (!uniqueBy(brands, (brand) => brand.slug) ||
      !uniqueBy(categories, (category) => category.id) ||
      !uniqueBy(categories, (category) => category.slug) ||
      !uniqueBy(products, (product) => product.id) ||
      !uniqueBy(products, (product) => product.slug)) {
    throw new Error("The backup contains duplicate IDs or URL slugs. Nothing was restored.");
  }
  const brandSlugs = new Set(brands.map((brand) => brand.slug));
  if (!products.every((product) => brandSlugs.has(product.brand_slug))) {
    throw new Error("A product refers to a missing brand. Nothing was restored.");
  }

  return { brands, categories, products } as DemoCatalog;
}
