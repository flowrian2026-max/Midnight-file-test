import type { DemoProduct } from './demo-catalog';
export interface CartEntry { productId:string; volumeId:string; qty:number }
export function normalizeCart(entries: CartEntry[], products: DemoProduct[]): CartEntry[] {
  const result: CartEntry[] = [];
  for (const entry of entries) {
    const product = products.find(p => p.id === entry?.productId && p.published);
    const volume = product?.volumes.find(v => v.id === entry.volumeId);
    if (!volume || volume.stock <= 0 || !Number.isFinite(entry.qty) || entry.qty <= 0) continue;
    const existing = result.find(e => e.productId === entry.productId && e.volumeId === entry.volumeId);
    const qty = Math.min(volume.stock, Math.floor(entry.qty));
    if (qty <= 0) continue;
    if (existing) existing.qty = Math.min(volume.stock,existing.qty+qty);
    else result.push({productId:entry.productId,volumeId:entry.volumeId,qty});
  }
  return result;
}