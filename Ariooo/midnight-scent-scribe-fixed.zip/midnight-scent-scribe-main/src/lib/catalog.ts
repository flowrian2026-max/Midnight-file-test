import { queryOptions } from "@tanstack/react-query";
import { demoImages, demoArticles } from "./demo-catalog";
import { loadCatalog } from "./demo-store";
import { isRemoteCatalogEnabled, loadRemoteBrands, loadRemoteCategories, loadRemoteProducts } from "./remote-catalog";

// Built-in photos can be referenced as "asset:<key>"; anything else is used as a URL.
export const assetImages: Record<string, string> = demoImages;
export function resolveImg(v?: string | null) {
  if (!v) return demoImages["lumiere"];
  if (v.startsWith("asset:")) return assetImages[v.slice(6)] ?? demoImages["lumiere"];
  return v;
}

// Catalogue data is local demo data (see src/lib/demo-catalog.ts). The queries
// keep their async shape so loading states stay exercised across the app.
const tick = () => new Promise((r) => setTimeout(r, 120));

export const categoriesQuery = queryOptions({
  queryKey: ["categories"],
  queryFn: async () => {
    await tick();
    if (isRemoteCatalogEnabled()) {
      try { return await loadRemoteCategories(); }
      catch { /* Keep the showcase usable until D1 is provisioned. */ }
    }
    return [...loadCatalog().categories].sort((a, b) => a.sort - b.sort);
  },
});

export const productsQuery = queryOptions({
  queryKey: ["products"],
  queryFn: async () => {
    await tick();
    if (isRemoteCatalogEnabled()) {
      try { return await loadRemoteProducts(); }
      catch { /* Keep the showcase usable until D1 is provisioned. */ }
    }
    return loadCatalog().products;
  },
});

export const brandsQuery = queryOptions({
  queryKey: ["brands"],
  queryFn: async () => {
    await tick();
    if (isRemoteCatalogEnabled()) {
      try { return await loadRemoteBrands(); }
      catch { /* Keep the showcase usable until D1 is provisioned. */ }
    }
    return loadCatalog().brands;
  },
});

export const articlesQuery = queryOptions({
  queryKey: ["articles"],
  queryFn: async () => {
    await tick();
    return [...demoArticles].sort((a, b) => b.created_at.localeCompare(a.created_at));
  },
});
