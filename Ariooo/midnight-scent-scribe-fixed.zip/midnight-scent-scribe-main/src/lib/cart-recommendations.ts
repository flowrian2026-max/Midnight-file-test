import type { DemoProduct } from "./demo-catalog";

/**
 * Rank published fragrances for the cart cross-sell area.
 * Matching brand, category and scent character outrank new arrivals.
 */
export function recommendCartProducts(
  products: DemoProduct[],
  cartProducts: DemoProduct[],
  limit = 4,
): DemoProduct[] {
  const excluded = new Set(cartProducts.map((product) => product.id));
  const cart = cartProducts.filter((product) => product.published);
  const characterOverlap = (left: DemoProduct, right: DemoProduct): number => {
    const rightCharacters = new Set(right.scent_character ?? []);
    return (left.scent_character ?? []).filter((character) => rightCharacters.has(character)).length;
  };
  const categoryOverlap = (left: DemoProduct, right: DemoProduct): boolean => {
    const leftIds = new Set(left.category_ids ?? [left.category_id].filter(Boolean));
    const rightIds = right.category_ids ?? [right.category_id].filter(Boolean);
    return rightIds.some((id) => leftIds.has(id)) ||
      (right.category_slugs ?? []).some((slug) => (left.category_slugs ?? []).includes(slug));
  };
  const score = (candidate: DemoProduct): number => {
    const affinity = cart.reduce((total, item) => {
      let points = 0;
      if (candidate.brand_slug === item.brand_slug) points += 5;
      if (categoryOverlap(candidate, item)) points += 2;
      points += characterOverlap(candidate, item) * 1.5;
      return total + points;
    }, 0);
    return affinity + (candidate.is_new ? 0.75 : 0);
  };

  return products
    .filter((product) => product.published && !excluded.has(product.id))
    .sort((left, right) => {
      const difference = score(right) - score(left);
      if (difference !== 0) return difference;
      const dateOrder = right.created_at.localeCompare(left.created_at);
      return dateOrder || left.name.localeCompare(right.name);
    })
    .slice(0, Math.max(0, Math.trunc(limit)));
}
