// DEMO CATALOGUE — local demonstration data only.
// No server or database is connected to this project. Every product, price,
// stock level and description below is placeholder demo content for showing
// the storefront; it does NOT represent real availability from any brand.
import lumiere from "@/assets/p-lumiere.jpg";
import nocturne from "@/assets/p-nocturne.jpg";
import riviere from "@/assets/p-riviere.jpg";
import solstice from "@/assets/p-solstice.jpg";
import floral from "@/assets/f-floral.jpg";
import amber from "@/assets/f-amber.jpg";
import woody from "@/assets/f-woody.jpg";
import spicy from "@/assets/f-spicy.jpg";
import citrus from "@/assets/f-citrus.jpg";

export const demoImages: Record<string, string> = {
  lumiere, nocturne, riviere, solstice, floral, amber, woody, spicy, citrus,
};

export interface DemoBrand {
  slug: string;
  name: string;
  blurbEn: string;
  blurbFa: string;
}
export interface DemoCategory {
  id: string;
  slug: string;
  name_en: string;
  name_fa: string;
  sort: number;
}
export interface DemoVolume {
  id: string;
  ml: number;
  price: number;
  stock: number; // 0 = out of stock
}
export interface DemoProduct {
  id: string;
  slug: string;
  name: string;
  brand_slug: string;
  /** Legacy primary category; kept for compatibility with older local demo data. */
  category_id: string;
  /** Every category selected by the editor. */
  category_ids?: string[];
  /** Stable category slugs for storefront filtering when database IDs are UUIDs. */
  category_slugs?: string[];
  image_url: string;
  desc_en: string;
  desc_fa: string;
  published: boolean;
  is_new: boolean;
  /** Optional merchandising attributes; leave empty until verified by the store editor. */
  gender?: "women" | "men" | "unisex";
  concentration?: "parfum" | "edp" | "edt" | "edc" | "extrait";
  seasons?: string[];
  notes?: { top?: string; heart?: string; base?: string };
  occasions?: string[];
  scent_character?: string[];
  created_at: string;
  volumes: DemoVolume[];
}

export const demoBrands: DemoBrand[] = [
  { slug: "tom-ford", name: "Tom Ford", blurbEn: "Private blends with an opulent, nocturnal signature.", blurbFa: "ترکیب‌های خصوصی با امضایی اشرافی و شبانه." },
  { slug: "dior", name: "Dior", blurbEn: "Parisian couture translated into scent.", blurbFa: "کوتور پاریسی در قالب رایحه." },
  { slug: "chanel", name: "Chanel", blurbEn: "Timeless compositions with a modern pulse.", blurbFa: "ترکیب‌های بی‌زمان با نبضی مدرن." },
  { slug: "ysl", name: "Yves Saint Laurent", blurbEn: "Bold, sensual and unapologetically expressive.", blurbFa: "جسور، حسی و بی‌پرده بیانگر." },
  { slug: "maison-margiela", name: "Maison Margiela", blurbEn: "Memories bottled as a familiar moment.", blurbFa: "خاطره‌ها در قالب لحظه‌ای آشنا." },
  { slug: "guerlain", name: "Guerlain", blurbEn: "A French perfumery heritage with a signature warmth, since 1828.", blurbFa: "میراث عطرسازی فرانسوی با گرمایی شاخص از سال ۱۸۲۸." },
];

export const demoCategories: DemoCategory[] = [
  { id: "cat-floral", slug: "floral", name_en: "Floral", name_fa: "گلی", sort: 1 },
  { id: "cat-amber", slug: "amber", name_en: "Amber", name_fa: "گرم و شیرین", sort: 2 },
  { id: "cat-woody", slug: "woody", name_en: "Woody", name_fa: "چوبی", sort: 3 },
  { id: "cat-spicy", slug: "spicy", name_en: "Spicy", name_fa: "تند", sort: 4 },
  { id: "cat-citrus", slug: "citrus", name_en: "Citrus", name_fa: "مرکباتی", sort: 5 },
];

const v = (id: string, ml: number, price: number, stock: number): DemoVolume => ({ id, ml, price, stock });
const img = (key: string) => `asset:${key}`;
// Unsplash-hosted editorial images are demo imagery, not verified brand packshots.
const remoteImg = (photoId: string) => `https://images.unsplash.com/${photoId}?auto=format&fit=crop&w=1000&q=80`;

export const demoProducts: DemoProduct[] = [
  {
    id: "p-oud-wood", slug: "oud-wood", name: "Oud Wood", brand_slug: "tom-ford", category_id: "cat-woody",
    gender: "unisex", concentration: "edp", seasons: ["autumn","winter"],
    notes: {"top":"cardamom","heart":"rosewood","base":"oud"}, occasions: ["evening","formal"], scent_character: ["woody","amber"],
    image_url: img("nocturne"), published: true, is_new: true, created_at: "2026-09-20",
    desc_en: "Rare oud wood, sandalwood and rosewood wrapped in warm cardamom and amber.\n\nA private blend that feels like smoke over dark timber — composed, modern and quietly commanding.",
    desc_fa: "چوب عود کمیاب، چوب صندل و رزوود در آغوش هل گرم و کهربا.\n\nترکیبی خصوصی که مانند دودی روی چوب تیره حس می‌شود؛ آرام، مدرن و فرمان‌دهنده.",
    volumes: [v("v-oud-50", 50, 195, 6), v("v-oud-100", 100, 285, 2)],
  },
  {
    id: "p-tobacco-vanille", slug: "tobacco-vanille", name: "Tobacco Vanille", brand_slug: "tom-ford", category_id: "cat-amber",
    gender: "unisex", concentration: "edp", seasons: ["autumn","winter"],
    notes: {"top":"tobacco leaf","heart":"cocoa","base":"vanilla"}, occasions: ["evening","formal"], scent_character: ["amber","spicy"],
    image_url: remoteImg("photo-1737920459846-2d0318700658"), published: true, is_new: false, created_at: "2026-05-02",
    desc_en: "Sweet tobacco leaf, tonka bean and vanilla softened by cocoa and dried fruit.\n\nAn enveloping, plush warmth for evenings when the room should feel golden.",
    desc_fa: "برگ تنباکوی شیرین، لوبیای تونکا و وانیل که با کاکائو و میوهٔ خشک ملایم شده‌اند.\n\nگرمایی فراگیر و نرم برای شب‌هایی که اتاق باید طلایی حس شود.",
    volumes: [v("v-tv-50", 50, 210, 4), v("v-tv-100", 100, 320, 0)],
  },
  {
    id: "p-lost-cherry", slug: "lost-cherry", name: "Lost Cherry", brand_slug: "tom-ford", category_id: "cat-floral",
    gender: "women", concentration: "edp", seasons: ["autumn","winter"],
    notes: {"top":"black cherry","heart":"rose","base":"tonka bean"}, occasions: ["date night","evening"], scent_character: ["fruity","floral"],
    image_url: img("solstice"), published: true, is_new: true, created_at: "2026-09-28",
    desc_en: "Candied cherry liqueur over almond and Turkish rose, with tonka in the base.\n\nPlayful and decadent — a fragrance that opens like dessert and settles like velvet.",
    desc_fa: "لیکور گیلاس آب‌نباتی روی بادام و رز ترکی، با تونکا در پایه.\n\nشاد و اشرافی؛ رایحه‌ای که مانند دسر باز می‌شود و مانند مخمل می‌نشیند.",
    volumes: [v("v-lc-50", 50, 230, 3)],
  },
  {
    id: "p-sauvage", slug: "sauvage", name: "Sauvage", brand_slug: "dior", category_id: "cat-woody",
    gender: "men", concentration: "edp", seasons: ["spring","summer"],
    notes: {"top":"bergamot","heart":"pepper","base":"ambroxan"}, occasions: ["daily","office"], scent_character: ["woody","citrus"],
    image_url: img("riviere"), published: true, is_new: false, created_at: "2026-03-14",
    desc_en: "Bergamot freshness meeting ambroxan, pepper and a clean woody base.\n\nWide-open, mineral and effortless — the everyday signature of a modern wardrobe.",
    desc_fa: "تازگی ترنج در دیدار با آمبروکسان، فلفل و پایه‌ای چوبی و شفاف.\n\nباز، مینرال و بی‌تکلف؛ امضای روزمرهٔ یک کمد لباس مدرن.",
    volumes: [v("v-sauv-60", 60, 165, 8), v("v-sauv-100", 100, 215, 5)],
  },
  {
    id: "p-miss-dior", slug: "miss-dior", name: "Miss Dior", brand_slug: "dior", category_id: "cat-floral",
    gender: "women", concentration: "edp", seasons: ["spring","summer"],
    notes: {"top":"peony","heart":"rose","base":"musk"}, occasions: ["daily","date night"], scent_character: ["floral","powdery"],
    image_url: img("lumiere"), published: true, is_new: false, created_at: "2026-02-20",
    desc_en: "Grasse rose and peony over a luminous, powdery musk trail.\n\nA floral that feels like a silk ribbon — soft, precise and unmistakably Parisian.",
    desc_fa: "رز گراس و گل صدتومانی روی ردپایی درخشان و پودری از مشک.\n\nگلی که مانند روبان ابریشمی حس می‌شود؛ نرم، دقیق و بی‌شک پاریسی.",
    volumes: [v("v-md-50", 50, 170, 7), v("v-md-100", 100, 220, 3)],
  },
  {
    id: "p-bleu", slug: "bleu-de-chanel", name: "Bleu de Chanel", brand_slug: "chanel", category_id: "cat-woody",
    gender: "men", concentration: "edp", seasons: ["autumn","spring"],
    notes: {"top":"grapefruit","heart":"ginger","base":"cedar"}, occasions: ["office","evening"], scent_character: ["woody","citrus"],
    image_url: remoteImg("photo-1654524437221-2903a6cdb371"), published: true, is_new: false, created_at: "2026-01-30",
    desc_en: "Grapefruit and ginger over cedar, sandalwood and a whisper of incense.\n\nPoised and nocturnal — a woody aromatic with unusual depth.",
    desc_fa: "گریپ‌فروت و زنجبیل روی سدر، صندل و زمزمه‌ای از کندر.\n\nموقر و شبانه؛ آروماتیکی چوبی با عمقی نامتعارف.",
    volumes: [v("v-bleu-50", 50, 150, 9), v("v-bleu-100", 100, 195, 4)],
  },
  {
    id: "p-no5", slug: "no-5", name: "N°5", brand_slug: "chanel", category_id: "cat-floral",
    gender: "women", concentration: "parfum", seasons: ["autumn","winter","spring"],
    notes: {"top":"aldehydes","heart":"jasmine","base":"sandalwood"}, occasions: ["formal","evening"], scent_character: ["floral","powdery"],
    image_url: remoteImg("photo-1643696206555-4f725bc50c30"), published: true, is_new: false, created_at: "2025-12-01",
    desc_en: "The legendary bouquet of May rose and jasmine over aldehydes and soft woods.\n\nA century-old conversation between flowers and light, still utterly modern.",
    desc_fa: "دسته‌گل افسانه‌ای رز می و یاس روی آلدئیدها و چوب‌های نرم.\n\nگفت‌وگویی صدساله میان گل و نور که هنوز کاملاً مدرن است.",
    volumes: [v("v-n5-60", 60, 175, 2), v("v-n5-100", 100, 240, 1)],
  },
  {
    id: "p-libre", slug: "libre", name: "Libre", brand_slug: "ysl", category_id: "cat-floral",
    gender: "women", concentration: "edp", seasons: ["spring","autumn"],
    notes: {"top":"lavender","heart":"orange blossom","base":"musk"}, occasions: ["office","daily"], scent_character: ["floral","aromatic"],
    image_url: remoteImg("photo-1680503504076-e5c61901c36d"), published: true, is_new: false, created_at: "2026-04-11",
    desc_en: "Lavender drawn out of convention and set against orange blossom and musk.\n\nFresh and floral with a masculine-feminine tension that refuses categories.",
    desc_fa: "اسطوخودوس بیرون از قواعد، در کنار شکوفهٔ نارنج و مشک.\n\nتازه و گلی با کشمکشی مردانه-زنانه که دسته‌بندی نمی‌پذیرد.",
    volumes: [v("v-lib-50", 50, 155, 6), v("v-lib-90", 90, 205, 0)],
  },
  {
    id: "p-black-opium", slug: "black-opium", name: "Black Opium", brand_slug: "ysl", category_id: "cat-spicy",
    gender: "women", concentration: "edp", seasons: ["autumn","winter"],
    notes: {"top":"pink pepper","heart":"coffee","base":"vanilla"}, occasions: ["evening","date night"], scent_character: ["spicy","gourmand"],
    image_url: remoteImg("photo-1709551264890-9a1453f19a1c"), published: true, is_new: false, created_at: "2026-02-05",
    desc_en: "Black coffee accord, pink pepper and vanilla over white flowers.\n\nAddictive and electric — a night out in a bottle.",
    desc_fa: "آکورد قهوهٔ سیاه، فلفل صورتی و وانیل روی گل‌های سفید.\n\nاعتیادآور و پرهیجان؛ یک شب بیرون در یک بطری.",
    volumes: [v("v-bo-50", 50, 145, 5), v("v-bo-90", 90, 190, 2)],
  },
  {
    id: "p-jazz-club", slug: "jazz-club", name: "Replica — Jazz Club", brand_slug: "maison-margiela", category_id: "cat-spicy",
    gender: "men", concentration: "edt", seasons: ["autumn","winter"],
    notes: {"top":"pink pepper","heart":"rum","base":"tobacco"}, occasions: ["evening","casual"], scent_character: ["woody","spicy"],
    image_url: remoteImg("photo-1721190171118-c5c0921ea6c0"), published: true, is_new: true, created_at: "2026-09-05",
    desc_en: "Rum absolute, pink pepper and vetiver over tobacco leaf.\n\nA smoky booth, a saxophone, a glass on the table — memory in perfume form.",
    desc_fa: "عصارهٔ رام، فلفل صورتی و وتیور روی برگ تنباکو.\n\nاتاقی دودی، ساکسوفونی، جامی روی میز؛ خاطره در قالب عطر.",
    volumes: [v("v-jc-100", 100, 165, 4)],
  },
  {
    id: "p-fireplace", slug: "by-the-fireplace", name: "Replica — By the Fireplace", brand_slug: "maison-margiela", category_id: "cat-amber",
    gender: "unisex", concentration: "edt", seasons: ["autumn","winter"],
    notes: {"top":"clove","heart":"chestnut","base":"smoky woods"}, occasions: ["casual","evening"], scent_character: ["amber","woody"],
    image_url: remoteImg("photo-1654524438960-ab0a67b4e22f"), published: true, is_new: false, created_at: "2026-06-18",
    desc_en: "Chestnut cream, clove and cashmeran over glowing embers.\n\nCocooning and sweet-smoky — winter distilled into a soft amber.",
    desc_fa: "کرم شاه‌بلوط، میخک و کشمیران روی اخگرهای سرخ.\n\nدربرگیرنده و شیرین-دودی؛ زمستان تقطیرشده در کهربایی نرم.",
    volumes: [v("v-bf-100", 100, 160, 5)],
  },
  {
    id: "p-shalimar", slug: "shalimar", name: "Shalimar", brand_slug: "guerlain", category_id: "cat-amber",
    gender: "women", concentration: "edp", seasons: ["autumn","winter"],
    notes: {"top":"bergamot","heart":"iris","base":"vanilla"}, occasions: ["formal","evening"], scent_character: ["amber","powdery"],
    image_url: remoteImg("photo-1723391962166-6d9bb8a3d3e7"), published: true, is_new: false, created_at: "2025-11-10",
    desc_en: "Bergamot brightness descending into iris, tonka and vanilla — the original oriental.\n\nA warm, powdery legend with almost two centuries of admirers.",
    desc_fa: "روشنی ترنج که به زنبق، تونکا و وانیل می‌رسد — شرقیِ اصیل.\n\nافسانه‌ای گرم و پودری با تقریباً دو قرن ستایشگر.",
    volumes: [v("v-sha-90", 90, 150, 3)],
  },

  {
    id: "p-jadore", slug: "jadore", name: "J’adore", brand_slug: "dior", category_id: "cat-floral",
    gender: "women", concentration: "edp", seasons: ["spring","summer"], notes: { top: "pear", heart: "jasmine", base: "soft woods" },
    occasions: ["daily","formal"], scent_character: ["floral","fruity"],
    image_url: remoteImg("photo-1654524438549-10892fe4aec4"), published: true, is_new: true, created_at: "2026-10-03",
    desc_en: "A luminous floral bouquet imagined around jasmine, rose and ripe fruit.\n\nElegant and radiant, made for a polished daytime mood.",
    desc_fa: "دسته‌گلی درخشان با الهام از یاس، رز و میوه‌های رسیده.\n\nظریف و نورانی؛ مناسب حال‌وهوای روزهای آراسته.",
    volumes: [v("v-jadore-50", 50, 175, 6), v("v-jadore-100", 100, 235, 3)],
  },
  {
    id: "p-homme-intense", slug: "dior-homme-intense", name: "Dior Homme Intense", brand_slug: "dior", category_id: "cat-woody",
    gender: "men", concentration: "edp", seasons: ["autumn","winter"], notes: { top: "lavender", heart: "iris", base: "cedar" },
    occasions: ["evening","formal"], scent_character: ["woody","powdery"],
    image_url: remoteImg("photo-1666621630026-862eea07236c"), published: true, is_new: false, created_at: "2026-07-22",
    desc_en: "A smooth iris accord layered with warm woods and a soft amber-like depth.\n\nTailored, intimate and especially suited to cooler evenings.",
    desc_fa: "آکوردی نرم از زنبق در کنار چوب‌های گرم و عمقی کهربایی.\n\nخوش‌دوخت و صمیمی؛ مناسب شب‌های خنک.",
    volumes: [v("v-dhi-50", 50, 180, 4), v("v-dhi-100", 100, 250, 2)],
  },
  {
    id: "p-chance-tendre", slug: "chance-eau-tendre", name: "Chance Eau Tendre", brand_slug: "chanel", category_id: "cat-floral",
    gender: "women", concentration: "edt", seasons: ["spring","summer"], notes: { top: "grapefruit", heart: "jasmine", base: "white musk" },
    occasions: ["daily","office"], scent_character: ["floral","citrus"],
    image_url: remoteImg("photo-1714218723982-95803a4b23d1"), published: true, is_new: true, created_at: "2026-10-06",
    desc_en: "Grapefruit brightness and airy florals settle into a clean musk trail.\n\nFresh, graceful and easy to wear from morning onward.",
    desc_fa: "درخشش گریپ‌فروت و گل‌های سبک که به ردپایی تمیز از مشک می‌رسند.\n\nتازه و باوقار؛ مناسب از ابتدای روز.",
    volumes: [v("v-cet-50", 50, 160, 5), v("v-cet-100", 100, 220, 2)],
  },
  {
    id: "p-chanel-allure-homme", slug: "allure-homme-sport", name: "Allure Homme Sport", brand_slug: "chanel", category_id: "cat-citrus",
    gender: "men", concentration: "edt", seasons: ["spring","summer"], notes: { top: "orange", heart: "pepper", base: "tonka" },
    occasions: ["daily","casual"], scent_character: ["citrus","woody"],
    image_url: remoteImg("photo-1709100198813-b43c16cfee95"), published: true, is_new: false, created_at: "2026-08-14",
    desc_en: "Bright citrus meets peppery freshness and a smooth tonka finish.\n\nAn energetic, clean profile for everyday wear.",
    desc_fa: "مرکبات درخشان در کنار تازگی فلفلی و پایانی نرم از تونکا.\n\nرایحه‌ای پرانرژی و تمیز برای استفاده روزمره.",
    volumes: [v("v-ahs-50", 50, 155, 7), v("v-ahs-100", 100, 215, 4)],
  },
  {
    id: "p-ysl-y", slug: "ysl-y-edp", name: "Y Eau de Parfum", brand_slug: "ysl", category_id: "cat-woody",
    gender: "men", concentration: "edp", seasons: ["spring","autumn"], notes: { top: "apple", heart: "sage", base: "cedar" },
    occasions: ["office","daily"], scent_character: ["woody","aromatic","fruity"],
    image_url: remoteImg("photo-1654524436650-bc9533447496"), published: true, is_new: true, created_at: "2026-10-01",
    desc_en: "Crisp apple and aromatic sage over a modern woody base.\n\nConfident and versatile, balancing freshness with depth.",
    desc_fa: "سیب ترد و مریم‌گلی آروماتیک روی پایه‌ای چوبی و مدرن.\n\nبااعتمادبه‌نفس و منعطف؛ متعادل میان تازگی و عمق.",
    volumes: [v("v-ysly-60", 60, 150, 6), v("v-ysly-100", 100, 205, 3)],
  },
  {
    id: "p-mon-paris", slug: "mon-paris", name: "Mon Paris", brand_slug: "ysl", category_id: "cat-floral",
    gender: "women", concentration: "edp", seasons: ["spring","autumn"], notes: { top: "strawberry", heart: "datura flower", base: "patchouli" },
    occasions: ["date night","evening"], scent_character: ["fruity","floral"],
    image_url: remoteImg("photo-1609749282774-5883a366cdd1"), published: true, is_new: false, created_at: "2026-08-02",
    desc_en: "Juicy red-fruit facets meet white florals and a softly earthy base.\n\nRomantic, playful and designed for a memorable evening.",
    desc_fa: "میوه‌های قرمز آبدار در کنار گل‌های سفید و پایه‌ای خاکی و ملایم.\n\nرمانتیک و بازیگوش؛ برای شبی به‌یادماندنی.",
    volumes: [v("v-mp-50", 50, 145, 4), v("v-mp-90", 90, 195, 2)],
  },
  {
    id: "p-lazy-sunday", slug: "lazy-sunday-morning", name: "Replica — Lazy Sunday Morning", brand_slug: "maison-margiela", category_id: "cat-floral",
    gender: "unisex", concentration: "edt", seasons: ["spring","summer"], notes: { top: "pear", heart: "lily of the valley", base: "white musk" },
    occasions: ["daily","casual"], scent_character: ["floral","powdery"],
    image_url: remoteImg("photo-1718466044521-d38654f3ba0a"), published: true, is_new: true, created_at: "2026-10-08",
    desc_en: "Soft white florals and clean musk evoke sunlit linen and a quiet morning.\n\nAiry, understated and comforting rather than loud.",
    desc_fa: "گل‌های سفید لطیف و مشک تمیز، یادآور ملحفه‌های روشن و صبحی آرام.\n\nسبک و بی‌تکلف؛ آرامش‌بخش به‌جای پرهیاهو.",
    volumes: [v("v-lsm-100", 100, 160, 5)],
  },
  {
    id: "p-mandarine-basilic", slug: "aqua-allegoria-mandarine-basilic", name: "Aqua Allegoria Mandarine Basilic", brand_slug: "guerlain", category_id: "cat-citrus",
    gender: "unisex", concentration: "edt", seasons: ["spring","summer"], notes: { top: "mandarin", heart: "basil", base: "green tea" },
    occasions: ["daily","casual"], scent_character: ["citrus","green","aromatic"],
    image_url: remoteImg("photo-1775807175033-91fb7d61be65"), published: true, is_new: true, created_at: "2026-09-29",
    desc_en: "Juicy mandarin and aromatic basil create a bright, green-citrus impression.\n\nA breezy daytime scent with a crisp, cheerful character.",
    desc_fa: "نارنگی آبدار و ریحان معطر، حسی روشن و سبز-مرکباتی می‌سازند.\n\nرایحه‌ای سبک برای روز با شخصیتی شاداب و سرزنده.",
    volumes: [v("v-mb-75", 75, 135, 6), v("v-mb-125", 125, 185, 3)],
  },
  {
    id: "p-lhomme-ideal", slug: "lhomme-ideal-edp", name: "L’Homme Idéal Eau de Parfum", brand_slug: "guerlain", category_id: "cat-amber",
    gender: "men", concentration: "edp", seasons: ["autumn","winter"], notes: { top: "almond", heart: "cherry", base: "leather" },
    occasions: ["evening","formal"], scent_character: ["amber","woody","gourmand"],
    image_url: img("amber"), published: true, is_new: false, created_at: "2026-07-11",
    desc_en: "A playful almond-and-cherry accord over woods and a supple leather impression.\n\nWarm, polished and a little unexpected.",
    desc_fa: "آکوردی دلنشین از بادام و گیلاس روی چوب‌ها و حسی از چرم نرم.\n\nگرم و آراسته، با اندکی غافلگیری.",
    volumes: [v("v-lhi-50", 50, 145, 4), v("v-lhi-100", 100, 195, 2)],
  },
];

// ---- Pure catalogue helpers (unit-tested) ----
export type SortKey = "newest" | "price-asc" | "price-desc" | "name";
export interface CatalogFilters {
  q?: string | undefined;
  brand?: string | undefined;
  cat?: string | undefined;
  min?: number | undefined;
  max?: number | undefined;
  inStock?: boolean | undefined;
  gender?: string | undefined;
  season?: string | undefined;
}

export interface DemoArticle {
  id: string;
  slug: string;
  title_en: string;
  title_fa: string;
  tag_en: string;
  tag_fa: string;
  image_url: string;
  body_en: string;
  body_fa: string;
  published: boolean;
  created_at: string;
}

export const demoArticles: DemoArticle[] = [
  {
    id: "a-amalfi", slug: "amalfi-coast", tag_en: "Travel", tag_fa: "سفر",
    title_en: "A Fragrant Summer on the Amalfi Coast", title_fa: "تابستانی معطر در ساحل آمالفی",
    image_url: "asset:citrus", published: true, created_at: "2026-08-01",
    body_en: "Along the coast, scent belongs as much to the landscape as to a bottle: citrus peel, warm stone and air from the sea.\n\nA citrus fragrance can echo that brightness without trying to reproduce a place literally. Bergamot and lemon suggest freshness, while woods can lend a quieter finish.\n\nWhen choosing a scent for warmer days, try a little first. Heat changes how quickly a fragrance unfolds, and the same perfume can feel different outdoors.",
    body_fa: "در کنار ساحل، رایحه به اندازهٔ یک بطری عطر به منظره تعلق دارد: پوست مرکبات، سنگ گرم و هوای دریا.\n\nیک عطر مرکباتی می‌تواند آن روشنایی را بازتاب دهد، بدون آنکه یک مکان را عیناً بازسازی کند. ترنج و لیمو تازگی می‌آورند و چوب‌ها پایانی آرام‌تر می‌سازند.\n\nبرای روزهای گرم، ابتدا مقدار کمی از عطر را امتحان کنید. گرما سرعت بازشدن رایحه را تغییر می‌دهد و همان عطر در فضای باز ممکن است متفاوت احساس شود.",
  },
  {
    id: "a-ritual", slug: "ritual-of-scent", tag_en: "Wellness", tag_fa: "آرامش",
    title_en: "The Ritual of Scent", title_fa: "آیین رایحه",
    image_url: "asset:floral", published: true, created_at: "2026-07-15",
    body_en: "A daily fragrance ritual can be a small pause: choosing, applying and noticing how the scent develops.\n\nTry fragrance on clean skin and let it dry naturally rather than rubbing the application points together. Give the opening time to settle before deciding how it feels.\n\nThere is no single correct scent for every day. Your surroundings, comfort and preference matter more than a rigid rule about when to wear a perfume.",
    body_fa: "آیین روزانهٔ عطر می‌تواند مکثی کوچک باشد: انتخاب‌کردن، استفاده‌کردن و توجه به تغییر رایحه.\n\nعطر را روی پوست تمیز امتحان کنید و اجازه دهید طبیعی خشک شود؛ محل استفاده را به هم نمالید. قبل از قضاوت، به نُت‌های آغازین فرصت بدهید آرام بگیرند.\n\nبرای همهٔ روزها یک رایحهٔ درست وجود ندارد. محیط، راحتی و سلیقهٔ شما از قواعد سخت دربارهٔ زمان استفاده از عطر مهم‌ترند.",
  },
  {
    id: "a-memory", slug: "power-of-memory", tag_en: "Inspiration", tag_fa: "الهام",
    title_en: "The Power of a Memory", title_fa: "قدرت یک خاطره",
    image_url: "asset:amber", published: true, created_at: "2026-06-20",
    body_en: "A familiar smell can bring a person or a place to mind before we have found the words to describe it.\n\nThe scent itself is only part of that experience. Context matters: a garden after rain, a favourite room, or a fragrance worn during an important moment.\n\nKeep a small scent journal. Record what you notice first, how the fragrance changes and what it reminds you of. Over time, these impressions can reveal your own preferences.",
    body_fa: "یک بوی آشنا می‌تواند پیش از آنکه واژه‌ای برای توصیفش پیدا کنیم، فرد یا مکانی را به یادمان بیاورد.\n\nخود رایحه فقط بخشی از تجربه است. زمینه هم اهمیت دارد: باغی بعد از باران، اتاقی محبوب یا عطری که در لحظه‌ای مهم استفاده شده است.\n\nدفتر کوچکی برای رایحه‌ها داشته باشید. برداشت نخست، تغییر عطر و چیزی را که به یادتان می‌آورد بنویسید. این یادداشت‌ها به مرور سلیقهٔ شخصی شما را روشن‌تر می‌کنند.",
  },
];

export function minPrice(p: DemoProduct): number {
  return p.volumes.length ? Math.min(...p.volumes.map((x) => x.price)) : Number.POSITIVE_INFINITY;
}
export function totalStock(p: DemoProduct): number {
  return p.volumes.reduce((s, x) => s + x.stock, 0);
}

export function filterProducts(list: DemoProduct[], f: CatalogFilters): DemoProduct[] {
  const q = (f.q ?? "").trim().toLowerCase();
  const searchableText = (p: DemoProduct) => [
    p.name,
    p.brand_slug.replace(/-/g, " "),
    p.category_id.replace(/^cat-/, "").replace(/-/g, " "),
    ...(p.category_ids ?? []).map((id) => id.replace(/^cat-/, "").replace(/-/g, " ")),
    ...(p.category_slugs ?? []).map((slug) => slug.replace(/-/g, " ")),
    p.desc_en,
    p.desc_fa,
    p.gender,
    p.concentration,
    ...(p.seasons ?? []),
    ...Object.values(p.notes ?? {}),
    ...(p.occasions ?? []),
    ...(p.scent_character ?? []),
    ...p.volumes.map((volume) => `${volume.ml} ml`),
  ].filter(Boolean).join(" ").toLowerCase();

  return list.filter((p) => {
    if (!p.published) return false;
    if (q && !searchableText(p).includes(q)) return false;
    if (f.brand && p.brand_slug !== f.brand) return false;
    if (f.gender && p.gender !== f.gender) return false;
    if (f.season && !(p.seasons ?? []).includes(f.season)) return false;
    if (f.cat && !(p.category_slugs?.includes(f.cat) || p.category_ids?.includes(`cat-${f.cat}`) || p.category_id === `cat-${f.cat}`)) return false;
    // Do not treat an unconfigured product as a zero-priced fragrance in price filters.
    if ((f.min !== undefined || f.max !== undefined) && p.volumes.length === 0) return false;
    const price = minPrice(p);
    if (f.min !== undefined && !Number.isNaN(f.min) && price < f.min) return false;
    if (f.max !== undefined && !Number.isNaN(f.max) && price > f.max) return false;
    if (f.inStock && totalStock(p) === 0) return false;
    return true;
  });
}

export function sortProducts(list: DemoProduct[], key: SortKey): DemoProduct[] {
  const out = [...list];
  if (key === "price-asc" || key === "price-desc") {
    out.sort((a, b) => {
      const priceA = minPrice(a);
      const priceB = minPrice(b);
      const aUnpriced = !Number.isFinite(priceA);
      const bUnpriced = !Number.isFinite(priceB);
      // Keep products without configured bottle sizes at the end for both price directions.
      if (aUnpriced !== bUnpriced) return aUnpriced ? 1 : -1;
      if (aUnpriced && bUnpriced) return b.created_at.localeCompare(a.created_at);
      return key === "price-asc" ? priceA - priceB : priceB - priceA;
    });
  } else if (key === "name") {
    out.sort((a, b) => a.name.localeCompare(b.name));
  } else {
    out.sort((a, b) => b.created_at.localeCompare(a.created_at));
  }
  return out;
}
