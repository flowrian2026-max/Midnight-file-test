import type { DemoProduct } from "@/lib/demo-catalog";

export interface CatalogSummary {
  products: number;
  publishedProducts: number;
  draftProducts: number;
  totalVariants: number;
  unitsInStock: number;
  lowStockVariants: number;
  outOfStockVariants: number;
}

export function summarizeCatalog(products: DemoProduct[]): CatalogSummary {
  const variants = products.flatMap((product) => product.volumes).filter((variant) => !variant.id.startsWith("unconfigured-"));
  return {
    products: products.length,
    publishedProducts: products.filter((product) => product.published).length,
    draftProducts: products.filter((product) => !product.published).length,
    totalVariants: variants.length,
    unitsInStock: variants.reduce((total, variant) => total + Math.max(0, variant.stock), 0),
    lowStockVariants: variants.filter((variant) => variant.stock > 0 && variant.stock <= 2).length,
    outOfStockVariants: variants.filter((variant) => variant.stock === 0).length,
  };
}
