import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { productsQuery } from "./catalog";
import { loadCatalog } from "./demo-store";
import type { DemoProduct, DemoVolume } from "./demo-catalog";
import { normalizeCart } from './cart-rules';

// Cart & wishlist live in localStorage (demo only — no accounts, no server).
export interface CartItem {
  productId: string;
  volumeId: string;
  qty: number;
}
export interface ResolvedCartItem extends CartItem {
  product: DemoProduct;
  volume: DemoVolume;
  lineTotal: number;
}

const CART_KEY = "ss.cart.v1";
const WISH_KEY = "ss.wishlist.v1";

function read<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function write(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // storage unavailable
  }
}

interface CommerceContextValue {
  items: ResolvedCartItem[];
  count: number;
  subtotal: number;
  addToCart: (productId: string, volumeId: string, qty?: number) => void;
  setQty: (productId: string, volumeId: string, qty: number) => void;
  removeFromCart: (productId: string, volumeId: string) => void;
  clearCart: () => void;
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  inWishlist: (productId: string) => boolean;
}

const CommerceContext = createContext<CommerceContextValue | null>(null);

export function CommerceProvider({ children }: { children: ReactNode }) {
  const productsQueryResult = useQuery(productsQuery);
  const catalogProducts = productsQueryResult.data ?? loadCatalog().products;
  const [rawItems, setRawItems] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const cart = read<unknown>(CART_KEY, []); const wishes = read<unknown>(WISH_KEY, []);
    setRawItems(Array.isArray(cart) ? normalizeCart(cart, catalogProducts) : []);
    setWishlist(Array.isArray(wishes) ? wishes.filter((v):v is string => typeof v === 'string') : []);
    setReady(true);
    const refresh = () => {
      const entries = read<unknown>(CART_KEY,[]); const saved = read<unknown>(WISH_KEY,[]);
      setRawItems(Array.isArray(entries) ? normalizeCart(entries, catalogProducts) : []);
      setWishlist(Array.isArray(saved) ? saved.filter((v):v is string => typeof v === 'string') : []);
    };
    const catalogChanged = () => setRawItems(prev => normalizeCart(prev, catalogProducts));
    window.addEventListener('storage',refresh); window.addEventListener('ss:catalog',catalogChanged);
    return () => {window.removeEventListener('storage',refresh); window.removeEventListener('ss:catalog',catalogChanged);};
  }, [catalogProducts]);

  useEffect(() => {
    if (ready) write(CART_KEY, rawItems);
  }, [rawItems, ready]);
  useEffect(() => {
    if (ready) write(WISH_KEY, wishlist);
  }, [wishlist, ready]);

  const items = useMemo<ResolvedCartItem[]>(() => {
    const products = catalogProducts;
    const out: ResolvedCartItem[] = [];
    for (const it of normalizeCart(rawItems, products)) {
      const product = products.find((p) => p.id === it.productId);
      const volume = product?.volumes.find((v) => v.id === it.volumeId);
      if (!product || !volume) continue;
      const qty = it.qty;
      out.push({ ...it, qty, product, volume, lineTotal: volume.price * qty });
    }
    return out;
  }, [rawItems, catalogProducts]);

  const addToCart = useCallback((productId: string, volumeId: string, qty = 1) => {
    setRawItems((prev) => {
      const existing = prev.find((i) => i.productId === productId && i.volumeId === volumeId);
      const next = existing ? prev.map((i) => (i === existing ? { ...i, qty: i.qty + qty } : i)) : [...prev, { productId, volumeId, qty }];
      return normalizeCart(next, catalogProducts);
    });
  }, [catalogProducts]);

  const setQty = useCallback((productId: string, volumeId: string, qty: number) => {
    setRawItems((prev) =>
      normalizeCart(prev
        .map((i) => (i.productId === productId && i.volumeId === volumeId ? { ...i, qty } : i))
        .filter((i) => i.qty > 0), catalogProducts),
    );
  }, [catalogProducts]);

  const removeFromCart = useCallback((productId: string, volumeId: string) => {
    setRawItems((prev) => prev.filter((i) => !(i.productId === productId && i.volumeId === volumeId)));
  }, []);

  const clearCart = useCallback(() => setRawItems([]), []);

  const toggleWishlist = useCallback((productId: string) => {
    setWishlist((prev) => (prev.includes(productId) ? prev.filter((x) => x !== productId) : [...prev, productId]));
  }, []);

  const value: CommerceContextValue = {
    items,
    count: items.reduce((s, i) => s + i.qty, 0),
    subtotal: items.reduce((s, i) => s + i.lineTotal, 0),
    addToCart,
    setQty,
    removeFromCart,
    clearCart,
    wishlist,
    toggleWishlist,
    inWishlist: (id) => wishlist.includes(id),
  };

  return <CommerceContext.Provider value={value}>{children}</CommerceContext.Provider>;
}

export function useCommerce() {
  const ctx = useContext(CommerceContext);
  if (!ctx) throw new Error("useCommerce must be used inside CommerceProvider");
  return ctx;
}
