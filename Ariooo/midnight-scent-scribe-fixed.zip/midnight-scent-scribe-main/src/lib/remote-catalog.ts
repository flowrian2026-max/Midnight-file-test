import type { DemoBrand, DemoCategory, DemoProduct, DemoVolume } from "@/lib/demo-catalog";

type UnknownRow = Record<string, unknown>;
type D1Catalog = {
  ok: boolean;
  brands: UnknownRow[];
  categories: UnknownRow[];
  products: UnknownRow[];
  volumes: UnknownRow[];
  productCategories?: UnknownRow[];
};
type D1AdminCatalog = D1Catalog;
type ProductCategoryRow = { product_id: string; category_id: string };

// Production uses the shared D1 API by default. The local catalogue is only a
// fallback while D1 is not configured; editors never treat local storage as a shared save.
export const isRemoteCatalogEnabled = () =>
  import.meta.env.PROD || import.meta.env.VITE_USE_D1_CATALOG === "true" || import.meta.env.VITE_USE_REMOTE_CATALOG === "true";

async function requestJson<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(path, {
    cache: "no-store",
    credentials: "same-origin",
    ...init,
    headers: { ...(init.headers ?? {}), ...(init.body ? { "content-type": "application/json" } : {}) },
  });
  const payload = await response.json().catch(() => ({})) as { code?: string; message?: string };
  if (!response.ok) {
    const messages: Record<string, string> = {
      D1_NOT_CONFIGURED: "Cloudflare D1 is not connected.",
      UNAUTHENTICATED: "Sign in with an administrator account first.",
      ORIGIN_REJECTED: "The server rejected this request origin.",
      INVALID_PRODUCT: "Some product fields are invalid.",
      UNKNOWN_BRAND: "Choose a brand that exists in the database.",
      UNKNOWN_CATEGORY: "Choose a category that exists in the database.",
      PRODUCT_SAVE_FAILED: "Could not save the product. Check duplicate slug or SKU.",
      REFERENCE_SAVE_FAILED: "Could not save the reference. Check for a duplicate slug.",
      RATE_LIMITED: "Too many attempts. Try again later.",
    };
    throw new Error(payload.message ?? (payload.code ? messages[payload.code] : undefined) ?? `Request failed (${response.status}).`);
  }
  return payload as T;
}

async function fetchCatalog(): Promise<D1Catalog> {
  return requestJson<D1Catalog>("/api/d1/catalog");
}

function parseJson<T>(value: unknown, fallback: T): T {
  if (typeof value !== "string") return (value as T) ?? fallback;
  try { return JSON.parse(value) as T; } catch { return fallback; }
}
const boolValue = (value: unknown) => value === true || value === 1 || value === "1";
function mapBrand(row: UnknownRow): DemoBrand {
  return {
    slug: String(row.slug ?? ""),
    name: String(row.name ?? ""),
    blurbEn: String(row.blurb_en ?? ""),
    blurbFa: String(row.blurb_fa ?? ""),
  };
}
function mapCategory(row: UnknownRow): DemoCategory {
  return {
    id: String(row.id ?? ""),
    slug: String(row.slug ?? ""),
    name_en: String(row.name_en ?? ""),
    name_fa: String(row.name_fa ?? ""),
    sort: Number(row.sort ?? 0),
  };
}
function mapProductRows(data: D1Catalog | D1AdminCatalog): DemoProduct[] {
  const brands = data.brands.map(mapBrand);
  const brandSlugById = new Map(data.brands.map((brand) => [String(brand.id), String(brand.slug)]));
  const categoryById = new Map(data.categories.map((category) => [String(category.id), String(category.slug)]));
  const categoriesByProduct = new Map<string, string[]>();
  for (const link of (data.productCategories ?? []) as ProductCategoryRow[]) {
    categoriesByProduct.set(link.product_id, [...(categoriesByProduct.get(link.product_id) ?? []), link.category_id]);
  }
  const volumesByProduct = new Map<string, DemoVolume[]>();
  for (const row of data.volumes) {
    if (row.is_active !== undefined && !boolValue(row.is_active)) continue;
    const productId = String(row.product_id ?? "");
    const volume: DemoVolume = {
      id: String(row.id ?? ""),
      ml: Number(row.ml ?? 0),
      price: Number(row.price ?? 0),
      stock: Number(row.stock ?? 0),
    };
    volumesByProduct.set(productId, [...(volumesByProduct.get(productId) ?? []), volume]);
  }
  void brands;
  return data.products.map((row) => {
    const id = String(row.id ?? "");
    const linkedCategoryIds = categoriesByProduct.get(id) ?? [];
    const fallbackCategoryId = row.category_id ? String(row.category_id) : "";
    const categoryIds = linkedCategoryIds.length ? [...new Set(linkedCategoryIds)] : fallbackCategoryId ? [fallbackCategoryId] : [];
    const notesRaw = parseJson<unknown>(row.notes_json ?? row.notes, {});
    const notes = notesRaw && typeof notesRaw === "object" && !Array.isArray(notesRaw)
      ? notesRaw as { top?: string; heart?: string; base?: string } : {};
    return {
      id,
      slug: String(row.slug ?? ""),
      name: String(row.name ?? ""),
      brand_slug: String(row.brand_slug ?? brandSlugById.get(String(row.brand_id ?? "")) ?? ""),
      category_id: fallbackCategoryId || categoryIds[0] || "",
      category_ids: categoryIds,
      category_slugs: categoryIds.map((categoryId) => categoryById.get(categoryId)).filter((slug): slug is string => Boolean(slug)),
      image_url: String(row.image_url ?? "asset:lumiere"),
      desc_en: String(row.desc_en ?? ""),
      desc_fa: String(row.desc_fa ?? ""),
      published: boolValue(row.published),
      is_new: boolValue(row.is_new),
      gender: row.gender === "women" || row.gender === "men" || row.gender === "unisex" ? row.gender : undefined,
      concentration: ["parfum", "edp", "edt", "edc", "extrait"].includes(String(row.concentration ?? ""))
        ? row.concentration as DemoProduct["concentration"] : undefined,
      seasons: parseJson<string[]>(row.seasons_json ?? row.seasons, []),
      notes,
      occasions: parseJson<string[]>(row.occasions_json ?? row.occasions, []),
      scent_character: parseJson<string[]>(row.scent_character_json ?? row.scent_character, []),
      created_at: String(row.created_at ?? new Date(0).toISOString()),
      volumes: volumesByProduct.get(id) ?? [],
    };
  });
}

export async function loadRemoteBrands(): Promise<DemoBrand[]> {
  const data = await fetchCatalog();
  return data.brands.map(mapBrand);
}
export async function loadRemoteCategories(): Promise<DemoCategory[]> {
  const data = await fetchCatalog();
  return data.categories.map(mapCategory);
}
export async function loadRemoteProducts(): Promise<DemoProduct[]> {
  const data = await fetchCatalog();
  return mapProductRows(data);
}
export async function loadRemoteAdminProducts(): Promise<DemoProduct[]> {
  const data = await requestJson<D1AdminCatalog>("/api/d1/admin/products");
  return mapProductRows(data);
}

export async function saveRemoteProduct(product: DemoProduct): Promise<void> {
  await requestJson("/api/d1/admin/products", {
    method: "POST",
    body: JSON.stringify({
      id: product.id,
      slug: product.slug.trim(),
      name: product.name.trim(),
      brand_slug: product.brand_slug,
      category_id: product.category_id || null,
      category_ids: product.category_ids ?? (product.category_id ? [product.category_id] : []),
      price: product.volumes[0]?.price ?? 0,
      image_url: product.image_url,
      desc_en: product.desc_en,
      desc_fa: product.desc_fa,
      published: product.published,
      is_new: product.is_new,
      gender: product.gender ?? null,
      concentration: product.concentration ?? null,
      seasons: product.seasons ?? [],
      notes: product.notes ?? {},
      occasions: product.occasions ?? [],
      scent_character: product.scent_character ?? [],
      volumes: product.volumes.map((volume) => ({
        ml: volume.ml,
        price: volume.price,
        stock: volume.stock,
      })),
    }),
  });
}
export async function saveRemoteBrand(brand: DemoBrand, originalSlug: string | null): Promise<void> {
  await requestJson("/api/d1/admin/brands", {
    method: "POST",
    body: JSON.stringify({
      slug: brand.slug.trim(),
      name: brand.name.trim(),
      blurb_en: brand.blurbEn,
      blurb_fa: brand.blurbFa,
      original_slug: originalSlug,
    }),
  });
}
export async function saveRemoteCategory(category: DemoCategory, originalSlug: string | null): Promise<void> {
  await requestJson("/api/d1/admin/categories", {
    method: "POST",
    body: JSON.stringify({
      slug: category.slug.trim(),
      name_en: category.name_en.trim(),
      name_fa: category.name_fa.trim(),
      sort: Math.max(0, Math.trunc(category.sort)),
      original_slug: originalSlug,
    }),
  });
}
