// Local-only homepage merchandising settings for the Scent Scribe demo.
// These settings affect this browser only; they are not shared administration.
export interface DemoMerchandising {
  showFeaturedBrands: boolean;
  showCuratedProducts: boolean;
  curatedProductIds: string[];
  showNewArrivals: boolean;
  newArrivalProductIds: string[];
}

export const defaultMerchandising: DemoMerchandising = {
  showFeaturedBrands: true,
  showCuratedProducts: true,
  curatedProductIds: [],
  showNewArrivals: true,
  newArrivalProductIds: [],
};

const KEY = "ss.demoMerchandising.v1";

export function loadMerchandising(): DemoMerchandising {
  if (typeof window === "undefined") return defaultMerchandising;
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return defaultMerchandising;
    const value = JSON.parse(raw) as Partial<DemoMerchandising>;
    return {
      showFeaturedBrands: typeof value.showFeaturedBrands === "boolean" ? value.showFeaturedBrands : defaultMerchandising.showFeaturedBrands,
      showCuratedProducts: typeof value.showCuratedProducts === "boolean" ? value.showCuratedProducts : defaultMerchandising.showCuratedProducts,
      curatedProductIds: Array.isArray(value.curatedProductIds) ? value.curatedProductIds.filter((id): id is string => typeof id === "string") : defaultMerchandising.curatedProductIds,
      showNewArrivals: typeof value.showNewArrivals === "boolean" ? value.showNewArrivals : defaultMerchandising.showNewArrivals,
      newArrivalProductIds: Array.isArray(value.newArrivalProductIds) ? value.newArrivalProductIds.filter((id): id is string => typeof id === "string") : defaultMerchandising.newArrivalProductIds,
    };
  } catch {
    return defaultMerchandising;
  }
}

export function saveMerchandising(settings: DemoMerchandising): boolean {
  if (typeof window === "undefined") return false;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(settings));
    window.dispatchEvent(new Event("ss:merchandising"));
    return true;
  } catch {
    return false;
  }
}

export function resetMerchandising(): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(KEY);
  } catch {
    // Keep defaults available for the current render if storage is blocked.
  }
  window.dispatchEvent(new Event("ss:merchandising"));
}
