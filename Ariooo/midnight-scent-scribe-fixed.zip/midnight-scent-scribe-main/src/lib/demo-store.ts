// Local demo catalogue store.
// No backend is connected: the catalogue lives in this browser's localStorage,
// seeded from the demo data in demo-catalog.ts. Edits made in /admin affect
// THIS BROWSER ONLY and are never shared with other visitors or users.
import { demoBrands, demoCategories, demoProducts, type DemoBrand, type DemoCategory, type DemoProduct } from "./demo-catalog";

const KEY = "ss.demoCatalog.v2";
  
// Upgrade untouched seeded images without overwriting a product image chosen in the editor.
const legacyDefaultImageBySlug: Record<string, string> = {
  "oud-wood": "asset:nocturne",
  "tobacco-vanille": "asset:amber",
  "lost-cherry": "asset:solstice",
  "sauvage": "asset:riviere",
  "miss-dior": "asset:floral",
  "bleu-de-chanel": "asset:nocturne",
  "no-5": "asset:lumiere",
  "libre": "asset:floral",
  "black-opium": "asset:spicy",
  "jazz-club": "asset:nocturne",
  "by-the-fireplace": "asset:amber",
  "shalimar": "asset:lumiere",
  "jadore": "asset:solstice",
  "dior-homme-intense": "asset:nocturne",
  "chance-eau-tendre": "asset:floral",
  "allure-homme-sport": "asset:riviere",
  "ysl-y-edp": "asset:riviere",
  "mon-paris": "asset:solstice",
  "lazy-sunday-morning": "asset:lumiere",
  "aqua-allegoria-mandarine-basilic": "asset:citrus",
  "lhomme-ideal-edp": "asset:amber",
};

export interface DemoCatalog {
  brands: DemoBrand[];
  categories: DemoCategory[];
  products: DemoProduct[];
}

function seed(): DemoCatalog {
  return { brands: demoBrands, categories: demoCategories, products: demoProducts };
}

let cache: DemoCatalog | undefined;

export function loadCatalog(): DemoCatalog {
  if (cache) return cache;
  if (typeof window === "undefined") return seed();
  try {
    const raw = window.localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<DemoCatalog>;
      if (Array.isArray(parsed.products) && Array.isArray(parsed.brands) && Array.isArray(parsed.categories)) {
        const seededImages = new Map(demoProducts.map((product) => [product.slug, product.image_url]));
        let migratedImages = false;
        const products = parsed.products.map((p) => {
          const product = p as DemoProduct;
          const normalized: DemoProduct = {
            ...product,
            category_ids: Array.isArray(product.category_ids)
              ? product.category_ids
              : [product.category_id].filter(Boolean),
          };
          const legacyImage = legacyDefaultImageBySlug[normalized.slug];
          const currentSeedImage = seededImages.get(normalized.slug);
          if (legacyImage && currentSeedImage && normalized.image_url === legacyImage && currentSeedImage !== legacyImage) {
            migratedImages = true;
            return { ...normalized, image_url: currentSeedImage };
          }
          return normalized;
        });
        cache = { ...(parsed as DemoCatalog), products };
        if (migratedImages) {
          try {
            window.localStorage.setItem(KEY, JSON.stringify(cache));
          } catch {
            // Keep the migrated in-memory catalogue if browser storage is read-only.
          }
        }
        return cache;
      }
    }
  } catch {
    // corrupt storage -> fall through to seed
  }
  cache = seed();
  return cache;
}

// Create a brand or rename an existing one without orphaning its products.
// Returns null when the source brand is missing or the requested slug belongs to another brand.
export function upsertDemoBrand(
  catalog: DemoCatalog,
  brand: DemoBrand,
  originalSlug: string | null,
): DemoCatalog | null {
  if (originalSlug !== null && !catalog.brands.some((item) => item.slug === originalSlug)) {
    return null;
  }
  if (catalog.brands.some((item) => item.slug === brand.slug && item.slug !== originalSlug)) {
    return null;
  }

  if (originalSlug === null) {
    return { ...catalog, brands: [...catalog.brands, brand] };
  }

  return {
    ...catalog,
    brands: catalog.brands.map((item) => (item.slug === originalSlug ? brand : item)),
    products: originalSlug === brand.slug
      ? catalog.products
      : catalog.products.map((product) =>
          product.brand_slug === originalSlug
            ? { ...product, brand_slug: brand.slug }
            : product,
        ),
  };
}

// Create a category or rename an existing one without leaving stale category slugs on products.
// Returns null when the source category is missing or the requested slug belongs to another category.
export function upsertDemoCategory(
  catalog: DemoCatalog,
  category: DemoCategory,
  originalSlug: string | null,
): DemoCatalog | null {
  const originalCategory = originalSlug === null
    ? undefined
    : catalog.categories.find((item) => item.slug === originalSlug);

  if (originalSlug !== null && !originalCategory) {
    return null;
  }
  if (catalog.categories.some((item) => item.slug === category.slug && item.slug !== originalSlug)) {
    return null;
  }

  if (originalSlug === null) {
    return { ...catalog, categories: [...catalog.categories, category] };
  }

  if (!originalCategory) return null;

  return {
    ...catalog,
    categories: catalog.categories.map((item) => (item.slug === originalSlug ? category : item)),
    products: originalSlug === category.slug
      ? catalog.products
      : catalog.products.map((product) => {
          const slugs = product.category_slugs ?? [];
          const linkedBySlug = slugs.includes(originalSlug);
          const linkedById =
            product.category_id === originalCategory.id ||
            (product.category_ids ?? []).includes(originalCategory.id);

          if (!linkedBySlug && !linkedById) return product;

          const nextSlugs = linkedBySlug
            ? slugs.map((slug) => slug === originalSlug ? category.slug : slug)
            : [...slugs, category.slug];

          return { ...product, category_slugs: [...new Set(nextSlugs)] };
        }),
  };
}

export function saveCatalog(next: DemoCatalog): boolean {
  cache = next;
  if (typeof window === "undefined") return false;

  let persisted = false;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(next));
    persisted = true;
  } catch {
    // Keep the current in-memory copy, but report that it will not survive a reload.
  }
  window.dispatchEvent(new Event("ss:catalog"));
  return persisted;
}

export function resetCatalog(): void {
  cache = seed();
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(KEY);
  } catch {
    // Reset the in-memory demo even if storage is blocked.
  }
  window.dispatchEvent(new Event("ss:catalog"));
}

export function isCatalogEdited(): boolean {
  if (typeof window === "undefined") return false;
  try {
    return window.localStorage.getItem(KEY) !== null;
  } catch {
    return false;
  }
}
