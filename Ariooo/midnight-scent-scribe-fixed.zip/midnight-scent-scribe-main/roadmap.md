# Linked pages
- [x] Add bilingual shared navigation and independent destination pages.
- [x] Replace homepage and footer placeholder links with actual routes.
- [x] Verify navigation, direct page access, and mobile Persian layout.

# Public demonstration
- [x] Replace the homepage scroll opening with a cinematic, accessible three-chapter fragrance story and verify desktop/mobile/RTL.
- [x] Repair incomplete storefront and journal routes.
- [x] Complete search, filters, variants, brand pages, cart and wishlist.
- [x] Connect homepage to the same local demo catalog; preserve design.
- [x] Audit auth/admin and add an explicitly local demo editor without changing server permissions.
- [x] Run catalog/commerce tests and desktop/mobile bilingual browser flows.
- [x] Document persistence, security limits and free public-demo publishing steps in DEMO-READINESS.md.
- [ ] Shared admin/auth verification: blocked until a functioning existing backend is available; do not activate Cloud.
- [ ] Real checkout/payment: excluded by user; no payments or orders.
