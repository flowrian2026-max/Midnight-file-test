-- Atomic, server-checked write functions for the shared admin editor.
-- These functions are deliberately unusable by anonymous visitors and require
-- the currently signed-in user to hold the admin role.

-- Limit role checks to the caller's own identity; a client must not be able
-- to probe the administrator status of arbitrary user IDs.
create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select _user_id = auth.uid()
    and exists (
      select 1
      from public.user_roles
      where user_id = auth.uid() and role = _role
    );
$$;
--> statement-breakpoint

create or replace function public.admin_save_product(p_product jsonb)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
  v_brand_id uuid;
  v_category_id uuid;
  v_category_text text;
  v_volume jsonb;
begin
  if auth.uid() is null or not public.has_role(auth.uid(), 'admin') then
    raise exception 'Administrator role required' using errcode = '42501';
  end if;

  if coalesce(trim(p_product->>'name'), '') = ''
     or coalesce(trim(p_product->>'slug'), '') !~ '^[a-z0-9]+(-[a-z0-9]+)*$'
     or jsonb_typeof(coalesce(p_product->'volumes', '[]'::jsonb)) <> 'array'
     or jsonb_array_length(coalesce(p_product->'volumes', '[]'::jsonb)) = 0 then
    raise exception 'Product name, slug and at least one bottle size are required' using errcode = '22023';
  end if;

  v_id := coalesce(nullif(p_product->>'id', '')::uuid, gen_random_uuid());

  select id into v_brand_id
  from public.brands
  where slug = p_product->>'brand_slug' and is_active = true;

  if v_brand_id is null then
    raise exception 'Choose an active brand before saving this product' using errcode = '22023';
  end if;

  select value into v_category_text
  from jsonb_array_elements_text(coalesce(p_product->'category_ids', '[]'::jsonb))
  limit 1;

  v_category_id := coalesce(
    nullif(v_category_text, '')::uuid,
    nullif(p_product->>'category_id', '')::uuid
  );

  insert into public.products (
    id, slug, name, brand_id, category_id, price, image_url,
    desc_en, desc_fa, published, is_new, gender, concentration,
    seasons, notes, occasions, scent_character, updated_at
  ) values (
    v_id,
    trim(p_product->>'slug'),
    trim(p_product->>'name'),
    v_brand_id,
    v_category_id,
    greatest(0, coalesce((p_product->'volumes'->0->>'price')::numeric, 0)),
    nullif(p_product->>'image_url', ''),
    coalesce(p_product->>'desc_en', ''),
    coalesce(p_product->>'desc_fa', ''),
    coalesce((p_product->>'published')::boolean, false),
    coalesce((p_product->>'is_new')::boolean, false),
    nullif(p_product->>'gender', ''),
    nullif(p_product->>'concentration', ''),
    array(select jsonb_array_elements_text(coalesce(p_product->'seasons', '[]'::jsonb))),
    coalesce(p_product->'notes', '{}'::jsonb),
    array(select jsonb_array_elements_text(coalesce(p_product->'occasions', '[]'::jsonb))),
    array(select jsonb_array_elements_text(coalesce(p_product->'scent_character', '[]'::jsonb))),
    now()
  )
  on conflict (id) do update set
    slug = excluded.slug,
    name = excluded.name,
    brand_id = excluded.brand_id,
    category_id = excluded.category_id,
    price = excluded.price,
    image_url = excluded.image_url,
    desc_en = excluded.desc_en,
    desc_fa = excluded.desc_fa,
    published = excluded.published,
    is_new = excluded.is_new,
    gender = excluded.gender,
    concentration = excluded.concentration,
    seasons = excluded.seasons,
    notes = excluded.notes,
    occasions = excluded.occasions,
    scent_character = excluded.scent_character,
    updated_at = now();

  -- Reject duplicate sizes at the database boundary even if a client
  -- bypasses the editor's duplicate-size validation.
  if (
    select count(*) <> count(distinct (value->>'ml')::numeric)
    from jsonb_array_elements(p_product->'volumes')
  ) then
    raise exception 'Bottle sizes must be unique for a product' using errcode = '22023';
  end if;

  -- Validate every size before changing the existing volume rows.
  for v_volume in select value from jsonb_array_elements(p_product->'volumes')
  loop
    if coalesce((v_volume->>'ml')::numeric, 0) <= 0
       or coalesce((v_volume->>'price')::numeric, -1) < 0
       or coalesce((v_volume->>'stock')::integer, -1) < 0
       or (v_volume->>'ml')::numeric > 99999 then
      raise exception 'Bottle size, price or stock is invalid' using errcode = '22023';
    end if;
  end loop;

  -- Keep stable volume IDs for unchanged sizes so saved carts do not break
  -- whenever an administrator edits a product's price, copy or stock.
  delete from public.product_volumes
  where product_id = v_id
    and ml not in (
      select (value->>'ml')::numeric
      from jsonb_array_elements(p_product->'volumes')
    );

  for v_volume in select value from jsonb_array_elements(p_product->'volumes')
  loop
    insert into public.product_volumes (product_id, ml, price, stock, is_active, updated_at)
    values (
      v_id,
      (v_volume->>'ml')::numeric,
      (v_volume->>'price')::numeric,
      (v_volume->>'stock')::integer,
      true,
      now()
    )
    on conflict (product_id, ml) do update set
      price = excluded.price,
      stock = excluded.stock,
      is_active = true,
      updated_at = now();
  end loop;

  delete from public.product_categories where product_id = v_id;
  for v_category_text in
    select distinct value
    from jsonb_array_elements_text(coalesce(p_product->'category_ids', '[]'::jsonb))
  loop
    insert into public.product_categories(product_id, category_id)
    values (v_id, v_category_text::uuid)
    on conflict do nothing;
  end loop;

  if v_category_id is not null then
    insert into public.product_categories(product_id, category_id)
    values (v_id, v_category_id)
    on conflict do nothing;
  end if;

  return v_id;
end;
$$;
--> statement-breakpoint

create or replace function public.admin_save_brand(p_brand jsonb, p_original_slug text default null)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
  v_slug text;
  v_name text;
begin
  if auth.uid() is null or not public.has_role(auth.uid(), 'admin') then
    raise exception 'Administrator role required' using errcode = '42501';
  end if;

  v_slug := trim(coalesce(p_brand->>'slug', ''));
  v_name := trim(coalesce(p_brand->>'name', ''));

  if v_slug !~ '^[a-z0-9]+(-[a-z0-9]+)*$' or v_name = '' then
    raise exception 'A valid brand name and slug are required' using errcode = '22023';
  end if;

  if p_original_slug is not null then
    update public.brands
    set slug = v_slug,
        name = v_name,
        blurb_en = coalesce(p_brand->>'blurb_en', ''),
        blurb_fa = coalesce(p_brand->>'blurb_fa', ''),
        updated_at = now()
    where slug = p_original_slug
    returning id into v_id;

    if v_id is null then
      raise exception 'The brand being edited no longer exists' using errcode = 'P0002';
    end if;
  else
    insert into public.brands(slug, name, blurb_en, blurb_fa)
    values (v_slug, v_name, coalesce(p_brand->>'blurb_en', ''), coalesce(p_brand->>'blurb_fa', ''))
    returning id into v_id;
  end if;

  return v_id;
end;
$$;
--> statement-breakpoint

create or replace function public.admin_save_category(p_category jsonb, p_original_slug text default null)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id uuid;
  v_slug text;
  v_name_en text;
  v_name_fa text;
  v_sort integer;
begin
  if auth.uid() is null or not public.has_role(auth.uid(), 'admin') then
    raise exception 'Administrator role required' using errcode = '42501';
  end if;

  v_slug := trim(coalesce(p_category->>'slug', ''));
  v_name_en := trim(coalesce(p_category->>'name_en', ''));
  v_name_fa := trim(coalesce(p_category->>'name_fa', ''));
  v_sort := greatest(0, coalesce(nullif(p_category->>'sort', '')::integer, 0));

  if v_slug !~ '^[a-z0-9]+(-[a-z0-9]+)*$'
     or v_name_en = ''
     or v_name_fa = '' then
    raise exception 'Valid category slug and both language names are required' using errcode = '22023';
  end if;

  if p_original_slug is not null then
    update public.categories
    set slug = v_slug, name_en = v_name_en, name_fa = v_name_fa, sort = v_sort
    where slug = p_original_slug
    returning id into v_id;

    if v_id is null then
      raise exception 'The category being edited no longer exists' using errcode = 'P0002';
    end if;
  else
    insert into public.categories(slug, name_en, name_fa, sort)
    values (v_slug, v_name_en, v_name_fa, v_sort)
    returning id into v_id;
  end if;

  return v_id;
end;
$$;
--> statement-breakpoint

revoke all on function public.admin_save_product(jsonb) from public, anon;
--> statement-breakpoint
revoke all on function public.admin_save_brand(jsonb, text) from public, anon;
--> statement-breakpoint
revoke all on function public.admin_save_category(jsonb, text) from public, anon;
--> statement-breakpoint
grant execute on function public.admin_save_product(jsonb) to authenticated;
--> statement-breakpoint
grant execute on function public.admin_save_brand(jsonb, text) to authenticated;
--> statement-breakpoint
grant execute on function public.admin_save_category(jsonb, text) to authenticated;
--> statement-breakpoint
