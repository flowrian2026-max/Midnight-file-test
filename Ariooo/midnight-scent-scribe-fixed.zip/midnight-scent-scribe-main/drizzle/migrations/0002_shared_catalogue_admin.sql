-- Shared catalogue schema for Scent Scribe administration.
-- Safe to apply after 0000_store_catalog_admin.sql and
-- 0001_secure_admin_bootstrap.sql. This migration does not enable payments
-- or invent live inventory for the placeholder/demo products.

create table if not exists public.brands (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  blurb_en text not null default '',
  blurb_fa text not null default '',
  sort integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint brands_slug_format check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$')
);
--> statement-breakpoint

alter table public.products
  add column if not exists brand_id uuid references public.brands(id) on delete set null,
  add column if not exists is_new boolean not null default false,
  add column if not exists gender text,
  add column if not exists concentration text,
  add column if not exists seasons text[] not null default '{}',
  add column if not exists notes jsonb not null default '{}'::jsonb,
  add column if not exists occasions text[] not null default '{}',
  add column if not exists scent_character text[] not null default '{}',
  add column if not exists updated_at timestamptz not null default now();
--> statement-breakpoint

-- Only expose published products attached to a currently active brand.
-- Administrators can still inspect unpublished/unassigned products in the editor.
drop policy if exists "public read published" on public.products;
--> statement-breakpoint
create policy "public read published"
  on public.products for select
  using (
    public.has_role(auth.uid(), 'admin')
    or (
      published
      and brand_id is not null
      and exists (
        select 1
        from public.brands b
        where b.id = products.brand_id and b.is_active = true
      )
    )
  );
--> statement-breakpoint

alter table public.products
  drop constraint if exists products_gender_check,
  add constraint products_gender_check
    check (gender is null or gender in ('women', 'men', 'unisex'));
--> statement-breakpoint

alter table public.products
  drop constraint if exists products_concentration_check,
  add constraint products_concentration_check
    check (concentration is null or concentration in ('parfum', 'edp', 'edt', 'edc', 'extrait'));
--> statement-breakpoint

create table if not exists public.product_volumes (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  ml numeric(7,2) not null,
  price numeric(12,2) not null,
  stock integer not null default 0,
  sku text unique,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint product_volumes_ml_positive check (ml > 0),
  constraint product_volumes_price_nonnegative check (price >= 0),
  constraint product_volumes_stock_nonnegative check (stock >= 0),
  constraint product_volumes_product_ml_unique unique (product_id, ml)
);
--> statement-breakpoint

create table if not exists public.product_categories (
  product_id uuid not null references public.products(id) on delete cascade,
  category_id uuid not null references public.categories(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (product_id, category_id)
);
--> statement-breakpoint

create index if not exists products_brand_id_idx on public.products(brand_id);
--> statement-breakpoint
create index if not exists products_published_created_idx on public.products(published, created_at desc);
--> statement-breakpoint
create index if not exists product_volumes_product_active_idx on public.product_volumes(product_id, is_active);
--> statement-breakpoint
create index if not exists product_categories_category_idx on public.product_categories(category_id);
--> statement-breakpoint

-- Preserve existing single-category relationships in the new many-to-many table.
insert into public.product_categories(product_id, category_id)
select id, category_id
from public.products
where category_id is not null
on conflict (product_id, category_id) do nothing;
--> statement-breakpoint

-- The brand directory can be prepared without claiming any demo product is
-- genuine stock. Product-brand links must be assigned after catalogue review.
insert into public.brands(slug, name, blurb_en, blurb_fa, sort)
values
  ('tom-ford', 'Tom Ford', 'Private blends with an opulent, nocturnal signature.', 'ترکیب‌هایی با امضایی اشرافی و شبانه.', 1),
  ('dior', 'Dior', 'Parisian couture translated into scent.', 'کوتور پاریسی در قالب رایحه.', 2),
  ('chanel', 'Chanel', 'Timeless compositions with a modern pulse.', 'ترکیب‌های بی‌زمان با نبضی مدرن.', 3),
  ('ysl', 'Yves Saint Laurent', 'Bold, sensual and expressive.', 'جسور، حسی و بیانگر.', 4),
  ('maison-margiela', 'Maison Margiela', 'Memories bottled as a familiar moment.', 'خاطره‌ها در قالب لحظه‌ای آشنا.', 5),
  ('guerlain', 'Guerlain', 'A French perfumery heritage with signature warmth.', 'میراث عطرسازی فرانسوی با گرمایی شاخص.', 6)
on conflict (slug) do nothing;
--> statement-breakpoint

alter table public.brands enable row level security;
--> statement-breakpoint
alter table public.product_volumes enable row level security;
--> statement-breakpoint
alter table public.product_categories enable row level security;
--> statement-breakpoint

drop policy if exists "public read active brands" on public.brands;
--> statement-breakpoint
create policy "public read active brands"
  on public.brands for select
  using (is_active or public.has_role(auth.uid(), 'admin'));
--> statement-breakpoint

drop policy if exists "admin write brands" on public.brands;
--> statement-breakpoint
create policy "admin write brands"
  on public.brands for all to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));
--> statement-breakpoint

drop policy if exists "public read published product volumes" on public.product_volumes;
--> statement-breakpoint
create policy "public read published product volumes"
  on public.product_volumes for select
  using (
    exists (
      select 1 from public.products p
      where p.id = product_volumes.product_id
        and (p.published or public.has_role(auth.uid(), 'admin'))
    )
  );
--> statement-breakpoint

drop policy if exists "admin write product volumes" on public.product_volumes;
--> statement-breakpoint
create policy "admin write product volumes"
  on public.product_volumes for all to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));
--> statement-breakpoint

drop policy if exists "public read published product categories" on public.product_categories;
--> statement-breakpoint
create policy "public read published product categories"
  on public.product_categories for select
  using (
    exists (
      select 1 from public.products p
      where p.id = product_categories.product_id
        and (p.published or public.has_role(auth.uid(), 'admin'))
    )
  );
--> statement-breakpoint

drop policy if exists "admin write product categories" on public.product_categories;
--> statement-breakpoint
create policy "admin write product categories"
  on public.product_categories for all to authenticated
  using (public.has_role(auth.uid(), 'admin'))
  with check (public.has_role(auth.uid(), 'admin'));
--> statement-breakpoint

grant select on public.brands, public.product_volumes, public.product_categories to anon, authenticated;
--> statement-breakpoint
grant insert, update, delete on public.brands, public.product_volumes, public.product_categories to authenticated;
--> statement-breakpoint
revoke insert, update, delete, truncate, references, trigger
  on table public.brands, public.product_volumes, public.product_categories from anon;
--> statement-breakpoint

-- The original four rows are generic design placeholders, not verified products.
-- Keep them out of the public storefront until an admin reviews and republishes them.
update public.products
set published = false, updated_at = now()
where slug in ('lumiere', 'nocturne', 'riviere', 'solstice');
--> statement-breakpoint
