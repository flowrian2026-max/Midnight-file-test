-- Scent Scribe security hardening.
-- The original bootstrap migration promoted the first auth user to admin.
-- Never assign administrator privileges based on signup order: public signup
-- can be abused to claim the store before its owner.
--
-- This migration is safe to apply whether or not the original trigger exists.
-- It intentionally does NOT create an administrator. Assign the intended owner
-- through a trusted Supabase SQL editor/service-role process after verifying
-- the owner's auth.users UUID. Never expose a service-role key to the browser.

drop trigger if exists on_auth_user_created_admin on auth.users;
--> statement-breakpoint
drop function if exists public.assign_first_admin();
--> statement-breakpoint

-- Keep user_roles writes unavailable to browser-authenticated users.
-- Existing policy allows authenticated users to read only their own role rows.
revoke insert, update, delete, truncate, references, trigger
  on table public.user_roles from anon, authenticated;
--> statement-breakpoint
