create type public.app_role as enum ('admin','user');
create table public.user_roles (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete cascade not null, role app_role not null, unique(user_id, role));
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "own roles readable" on public.user_roles for select to authenticated using (user_id = auth.uid());

create or replace function public.has_role(_user_id uuid, _role app_role) returns boolean language sql stable security definer set search_path = public as $$ select exists (select 1 from public.user_roles where user_id=_user_id and role=_role) $$;

create or replace function public.assign_first_admin() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.user_roles where role='admin') then
    insert into public.user_roles(user_id, role) values (new.id, 'admin');
  end if;
  return new;
end $$;
create trigger on_auth_user_created_admin after insert on auth.users for each row execute function public.assign_first_admin();

create table public.categories (id uuid primary key default gen_random_uuid(), slug text unique not null, name_en text not null, name_fa text not null, sort int not null default 0, created_at timestamptz not null default now());
create table public.products (id uuid primary key default gen_random_uuid(), slug text unique not null, name text not null, category_id uuid references public.categories(id) on delete set null, price numeric not null default 0, image_url text, desc_en text not null default '', desc_fa text not null default '', published boolean not null default true, created_at timestamptz not null default now());
create table public.articles (id uuid primary key default gen_random_uuid(), slug text unique not null, title_en text not null, title_fa text not null, tag_en text not null default '', tag_fa text not null default '', body_en text not null default '', body_fa text not null default '', image_url text, published boolean not null default true, created_at timestamptz not null default now());

grant select on public.categories, public.products, public.articles to anon, authenticated;
grant insert, update, delete on public.categories, public.products, public.articles to authenticated;
grant all on public.categories, public.products, public.articles to service_role;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.articles enable row level security;
create policy "public read" on public.categories for select using (true);
create policy "admin write" on public.categories for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "public read published" on public.products for select using (published or public.has_role(auth.uid(),'admin'));
create policy "admin write" on public.products for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "public read published" on public.articles for select using (published or public.has_role(auth.uid(),'admin'));
create policy "admin write" on public.articles for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

insert into public.categories (slug,name_en,name_fa,sort) values ('floral','Floral','گلی',1),('amber','Amber','عنبری',2),('woody','Woody','چوبی',3),('spicy','Spicy','ادویه‌ای',4),('citrus','Citrus','مرکباتی',5);
insert into public.products (slug,name,category_id,price,image_url) values
 ('lumiere','Lumière',(select id from public.categories where slug='floral'),180,'asset:lumiere'),
 ('nocturne','Nocturne',(select id from public.categories where slug='amber'),180,'asset:nocturne'),
 ('riviere','Rivière',(select id from public.categories where slug='citrus'),180,'asset:riviere'),
 ('solstice','Solstice',(select id from public.categories where slug='woody'),180,'asset:solstice');
insert into public.articles (slug,title_en,title_fa,tag_en,tag_fa,image_url,body_en,body_fa) values
 ('amalfi-coast','A Fragrant Summer on the Amalfi Coast','تابستانی معطر در ساحل آمالفی','Travel','سفر','asset:amalfi',
  $$Along the coast, scent belongs as much to the landscape as to a bottle: citrus peel, warm stone and air from the sea.

A citrus fragrance can echo that brightness without trying to reproduce a place literally. Bergamot and lemon suggest freshness, while woods can lend a quieter finish.

When choosing a scent for warmer days, try a little first. Heat changes how quickly a fragrance unfolds, and the same perfume can feel different outdoors.$$,
  $$در کنار ساحل، رایحه به اندازهٔ یک بطری عطر به منظره تعلق دارد: پوست مرکبات، سنگ گرم و هوای دریا.

یک عطر مرکباتی می‌تواند آن روشنایی را بازتاب دهد، بدون آنکه یک مکان را عیناً بازسازی کند. ترنج و لیمو تازگی می‌آورند و چوب‌ها پایانی آرام‌تر می‌سازند.

برای روزهای گرم، ابتدا مقدار کمی از عطر را امتحان کنید. گرما سرعت بازشدن رایحه را تغییر می‌دهد و همان عطر در فضای باز ممکن است متفاوت احساس شود.$$),
 ('ritual-of-scent','The Ritual of Scent','آیین رایحه','Wellness','آرامش','asset:ritual',
  $$A daily fragrance ritual can be a small pause: choosing, applying and noticing how the scent develops.

Try fragrance on clean skin and let it dry naturally rather than rubbing the application points together. Give the opening time to settle before deciding how it feels.

There is no single correct scent for every day. Your surroundings, comfort and preference matter more than a rigid rule about when to wear a perfume.$$,
  $$آیین روزانهٔ عطر می‌تواند مکثی کوچک باشد: انتخاب‌کردن، استفاده‌کردن و توجه به تغییر رایحه.

عطر را روی پوست تمیز امتحان کنید و اجازه دهید طبیعی خشک شود؛ محل استفاده را به هم نمالید. قبل از قضاوت، به نُت‌های آغازین فرصت بدهید آرام بگیرند.

برای همهٔ روزها یک رایحهٔ درست وجود ندارد. محیط، راحتی و سلیقهٔ شما از قواعد سخت دربارهٔ زمان استفاده از عطر مهم‌ترند.$$),
 ('power-of-memory','The Power of a Memory','قدرت یک خاطره','Inspiration','الهام','asset:memory',
  $$A familiar smell can bring a person or a place to mind before we have found the words to describe it.

The scent itself is only part of that experience. Context matters: a garden after rain, a favourite room, or a fragrance worn during an important moment.

Keep a small scent journal. Record what you notice first, how the fragrance changes and what it reminds you of. Over time, these impressions can reveal your own preferences.$$,
  $$یک بوی آشنا می‌تواند پیش از آنکه واژه‌ای برای توصیفش پیدا کنیم، فرد یا مکانی را به یادمان بیاورد.

خود رایحه فقط بخشی از تجربه است. زمینه هم اهمیت دارد: باغی بعد از باران، اتاقی محبوب یا عطری که در لحظه‌ای مهم استفاده شده است.

دفتر کوچکی برای رایحه‌ها داشته باشید. برداشت نخست، تغییر عطر و چیزی را که به یادتان می‌آورد بنویسید. این یادداشت‌ها به مرور سلیقهٔ شخصی شما را روشن‌تر می‌کنند.$$);