# Scent Scribe public demonstration

## Data and persistence
- The storefront, brand pages, product variants and editor use the same local demonstration catalogue. Descriptions, prices and stock are illustrative examples, not actual availability from any brand. The 21 seeded product cards now use a distinct mix of bundled and Unsplash-hosted editorial images; these images are visual placeholders, not verified photographs of the named branded products or their packaging. Remote images require an internet connection.
- Catalogue edits, cart and wishlist survive refresh in the same browser when storage is available. They are not shared between browsers, devices or users. Clearing browser data removes them.
- `/demo-editor` is intentionally public and edits only the visitor’s own copy. It is not secure shared administration.
- No payments, orders, email subscriptions, uploads or paid services are enabled. Existing authentication configuration has not been replaced.

## Administration and outstanding security blocker
The existing migration `drizzle/migrations/0000_store_catalog_admin.sql` defines `public.assign_first_admin()` and trigger `on_auth_user_created_admin`. It promotes the first auth user whenever no admin exists. If the migration is deployed and public signup is enabled, an untrusted visitor can win the first-user race (or become admin after all admin assignments are removed).

Public signup was removed from the app UI, but this is **not** a server-side fix. Hosted auth settings and deployed policies are unverified. Do not publish working shared administration until the existing backend owner:
1. Disables public signup at the existing auth service.
2. Reviews existing users and admin role rows for unauthorized assignments.
3. Removes the `on_auth_user_created_admin` trigger and `assign_first_admin()` function through a reviewed migration.
4. Assigns the intended owner explicitly through a trusted, privileged process, never a browser request.
5. Verifies authenticated role reads, anonymous write denial, non-admin write denial and owner CRUD against the actual server catalogue.

No database migration or permission change has been applied to the hosted database in this task. The `/admin` dashboard remains a read-only overview. `/demo-editor` remains browser-local by default; code now contains a feature-flagged shared-catalog adapter and administrator-checked product/brand/category save calls, but they are **not active or verified** while the hosted database is disabled and migrations are unapplied. Do not set `VITE_USE_REMOTE_CATALOG=true` until the full activation checklist in `docs/shared-backend-setup.md` is complete. Authenticated administration cannot be claimed verified without a working service and a real session.

## Publishing this free demonstration
1. Review the demo-label wording and confirm illustrative prices/photos are acceptable for a demonstration, not commercial selling.
2. Resolve the existing backend signup/first-admin risk before exposing a working auth service; the browser-only storefront itself does not require Cloud activation.
3. In Lovable, use **Publish**, review the publication dialog for current account limits/costs, and choose the existing free `lovable.app` address. No custom domain, paid integration, payment provider or Cloud activation is needed for the local demo.
4. After publishing/updating, open the public address in a fresh browser and retest shop → product → bag, saved fragrances, Persian, direct brand/story links and local editor persistence. A preview check does not prove the published version has updated.

This task does not publish automatically. Eligibility and remaining free publishing quota have not been checked; do not accept an upgrade if the free option is unavailable.

## Verification results
- 37 automated assertions passed: catalogue filter combinations, reset, price/name/date sorting, published/in-stock filtering, variant stock clamping, unavailable variants, removal/invalid entries, subtotal, local catalogue persistence and route matching.
- Chromium desktop (1280×1800) exercised homepage → Tom Ford → shop → combined filters → variant selection → cart → wishlist. Cart changed from $285 to $570, stopped at the known stock of two, persisted after refresh and returned to $285 after decrement. Remove emptied the bag.
- Wishlist survived refresh and removal returned the empty state. The unavailable Tobacco Vanille 100 ml selection disabled adding. Empty brand results and journal detail rendered.
- Local editor saved an actual product name and price change, which appeared on the product page and survived refresh. A separate fresh browser still displayed the original product, proving edits are not shared.
- Persian switching, RTL, mobile 390×844 product/shop, mobile menu navigation and auth page were checked. Product and shop had no horizontal overflow. Screenshots were reviewed. No page runtime errors were captured in that flow.
- Preview compilation reported `build OK`. Cloud and paid integrations were not activated. Palette tokens, existing imagery and fonts were preserved.
- Sign-in success, authenticated admin role checks, hosted signup configuration, database policies and published-site behavior remain **unverified**. Loading/error UI exists, but deliberate catalogue-fetch failure injection has not been tested.