// @lovable.dev/vite-tanstack-config supplies the React, TanStack Start, Tailwind,
// aliases and error-reporting plugins. Outside the Lovable sandbox we must
// explicitly enable Nitro so Cloudflare builds emit a runnable Worker bundle.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";

const isLovableSandbox =
  process.env.LOVABLE_SANDBOX === "1" ||
  Boolean(process.env.DEV_SERVER__PROJECT_PATH);

export default defineConfig({
  tanstackStart: {
    // Keep the SSR error wrapper as the server entry.
    server: { entry: "server" },
  },
  ...(isLovableSandbox
    ? {}
    : {
        nitro: {
          preset: "cloudflare-module",
          output: {
            dir: "dist",
            serverDir: "dist/server",
            publicDir: "dist/client",
          },
          cloudflare: {
            nodeCompat: true,
            deployConfig: true,
          },
        },
      }),
});
