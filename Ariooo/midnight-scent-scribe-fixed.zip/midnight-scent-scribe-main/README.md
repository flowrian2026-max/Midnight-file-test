# Scent Scribe

## Cloudflare Workers deployment

This repository deploys the TanStack Start app to the `midnight-scent-scribe` Cloudflare Worker.

In Cloudflare Workers Builds, use:
- **Build command:** `npm run build`
- **Deploy command:** `npx wrangler deploy` (the default)

The Wrangler configuration is in `wrangler.jsonc`. Pushes to `main` should trigger a new build when this repository is connected to Workers Builds.

**Production bindings are source-controlled:** keep the `DB` D1 binding in `wrangler.jsonc` and deploy from the connected GitHub build so the active Worker version uses the repository configuration.

## Development

```sh
npm install
npm run dev
```
