/* Scroll-driven 3D bottle for the editorial hero.
   Zero dependencies: a tiny GLB reader plus one WebGL draw call (single mesh, single texture).
   ScrollEditorial owns the scroll maths and writes CSS variables on the scene element;
   this renderer only reads them (--bottle-turn, --bottle-enter, --bottle-pointer-rotate-x/y).
   If anything fails (no WebGL, lost context, bad file) the caller keeps the CSS bottle. */

export type GlbMesh = {
  positions: Float32Array;
  normals: Float32Array;
  uvs: Float32Array;
  indices: Uint16Array;
  image: Blob;
};

export type BottleGL = { wake: () => void; destroy: () => void };

type Accessor = { bufferView: number; componentType: number; count: number; type: string };
type BufferView = { byteOffset?: number; byteLength: number };
type GltfJson = {
  accessors: Accessor[];
  bufferViews: BufferView[];
  images: { bufferView: number; mimeType: string }[];
  meshes: { primitives: { attributes: Record<string, number>; indices: number }[] }[];
};

const COMPONENTS: Record<string, number> = { SCALAR: 1, VEC2: 2, VEC3: 3 };

export function parseGlb(buffer: ArrayBuffer): GlbMesh {
  const view = new DataView(buffer);
  if (view.getUint32(0, true) !== 0x46546c67) throw new Error("Not a GLB file");
  let offset = 12;
  let json: GltfJson | null = null;
  let bin: ArrayBuffer | null = null;
  while (offset + 8 <= buffer.byteLength) {
    const length = view.getUint32(offset, true);
    const type = view.getUint32(offset + 4, true);
    const start = offset + 8;
    if (type === 0x4e4f534a) json = JSON.parse(new TextDecoder().decode(new Uint8Array(buffer, start, length))) as GltfJson;
    else if (type === 0x004e4942) bin = buffer.slice(start, start + length);
    offset = start + length;
  }
  if (!json || !bin) throw new Error("GLB is missing its JSON or BIN chunk");
  const data = bin;
  const gltf = json;
  const primitive = gltf.meshes[0].primitives[0];
  const slice = (accessor: Accessor) => {
    const bv = gltf.bufferViews[accessor.bufferView];
    const start = bv.byteOffset ?? 0;
    return data.slice(start, start + bv.byteLength);
  };
  const floats = (index: number) => {
    const accessor = gltf.accessors[index];
    if (accessor.componentType !== 5126) throw new Error("Expected float vertex data");
    return new Float32Array(slice(accessor), 0, accessor.count * COMPONENTS[accessor.type]);
  };
  const indexAccessor = gltf.accessors[primitive.indices];
  if (indexAccessor.componentType !== 5123) throw new Error("Expected 16-bit indices");
  const imageView = gltf.bufferViews[gltf.images[0].bufferView];
  const imageStart = imageView.byteOffset ?? 0;
  return {
    positions: floats(primitive.attributes.POSITION),
    normals: floats(primitive.attributes.NORMAL),
    uvs: floats(primitive.attributes.TEXCOORD_0),
    indices: new Uint16Array(slice(indexAccessor), 0, indexAccessor.count),
    image: new Blob([data.slice(imageStart, imageStart + imageView.byteLength)], { type: gltf.images[0].mimeType }),
  };
}

const VERTEX = `
attribute vec3 aPos;
attribute vec3 aNor;
attribute vec2 aUv;
uniform mat4 uModelView;
uniform mat4 uProj;
uniform mat3 uNormalMat;
varying vec3 vNor;
varying vec3 vView;
varying vec2 vUv;
void main() {
  vec4 mv = uModelView * vec4(aPos, 1.0);
  vView = -mv.xyz;
  vNor = uNormalMat * aNor;
  vUv = aUv;
  gl_Position = uProj * mv;
}`;

// Palette-only lighting: periwinkle rim and fill, lavender specular. Same maths as the offline preview.
const FRAGMENT = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uTex;
varying vec3 vNor;
varying vec3 vView;
varying vec2 vUv;
const vec3 PERI = vec3(0.514, 0.529, 0.765);
const vec3 LAV = vec3(0.815, 0.821, 0.911);
void main() {
  vec3 albedo = texture2D(uTex, vUv).rgb;
  vec3 n = normalize(vNor);
  vec3 v = normalize(vView);
  if (dot(n, v) < 0.0) n = -n;
  float ndv = clamp(dot(n, v), 0.0, 1.0);
  vec3 l1 = normalize(vec3(0.55, 0.75, 0.65));
  vec3 l2 = normalize(vec3(-0.7, 0.1, 0.5));
  float d1 = max(dot(n, l1), 0.0);
  float d2 = max(dot(n, l2), 0.0);
  float spec = pow(max(dot(n, normalize(l1 + v)), 0.0), 70.0);
  float lum = dot(albedo, vec3(0.2126, 0.7152, 0.0722));
  float labelMask = 1.0 - clamp((lum - 0.70) / 0.20, 0.0, 1.0);
  float rim = pow(1.0 - ndv, 2.6);
  vec3 col = albedo * (0.32 + 0.80 * d1 + 0.22 * d2) + rim * PERI * 0.55 + spec * labelMask * 0.55 * LAV;
  gl_FragColor = vec4(col, 1.0);
}`;

function compile(gl: WebGLRenderingContext, type: number, source: string) {
  const shader = gl.createShader(type);
  if (!shader) throw new Error("Could not create shader");
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    const log = gl.getShaderInfoLog(shader);
    gl.deleteShader(shader);
    throw new Error("Shader compile failed: " + log);
  }
  return shader;
}

function perspective(fovY: number, aspect: number, near: number, far: number) {
  const f = 1 / Math.tan(fovY / 2);
  const nf = 1 / (near - far);
  return new Float32Array([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0]);
}

export async function createBottleGL(canvas: HTMLCanvasElement, scene: HTMLElement, url: string, onLost: () => void): Promise<BottleGL> {
  const response = await fetch(url);
  if (!response.ok) throw new Error("Bottle model not found");
  const mesh = parseGlb(await response.arrayBuffer());

  const gl = canvas.getContext("webgl", { alpha: true, antialias: true, premultipliedAlpha: true, powerPreference: "low-power" });
  if (!gl) throw new Error("WebGL is not available");

  const program = gl.createProgram();
  if (!program) throw new Error("Could not create program");
  gl.attachShader(program, compile(gl, gl.VERTEX_SHADER, VERTEX));
  gl.attachShader(program, compile(gl, gl.FRAGMENT_SHADER, FRAGMENT));
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error("Program link failed: " + gl.getProgramInfoLog(program));
  gl.useProgram(program);

  const attribute = (name: string, data: Float32Array, size: number) => {
    const buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    const location = gl.getAttribLocation(program, name);
    gl.enableVertexAttribArray(location);
    gl.vertexAttribPointer(location, size, gl.FLOAT, false, 0, 0);
    return buffer;
  };
  const buffers = [attribute("aPos", mesh.positions, 3), attribute("aNor", mesh.normals, 3), attribute("aUv", mesh.uvs, 2)];
  const indexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, mesh.indices, gl.STATIC_DRAW);

  const textureUrl = URL.createObjectURL(mesh.image);
  const image = new Image();
  image.src = textureUrl;
  await image.decode();
  URL.revokeObjectURL(textureUrl);
  const texture = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
  gl.generateMipmap(gl.TEXTURE_2D);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
  const anisotropy = gl.getExtension("EXT_texture_filter_anisotropic");
  if (anisotropy) gl.texParameterf(gl.TEXTURE_2D, anisotropy.TEXTURE_MAX_ANISOTROPY_EXT, 4);

  const uModelView = gl.getUniformLocation(program, "uModelView");
  const uProj = gl.getUniformLocation(program, "uProj");
  const uNormalMat = gl.getUniformLocation(program, "uNormalMat");
  gl.uniform1i(gl.getUniformLocation(program, "uTex"), 0);
  gl.enable(gl.DEPTH_TEST);
  gl.clearColor(0, 0, 0, 0);

  const FOV = (24 * Math.PI) / 180;
  const readVar = (name: string) => {
    const value = parseFloat(scene.style.getPropertyValue(name));
    return Number.isFinite(value) ? value : 0;
  };

  let width = 0;
  let height = 0;
  const resize = () => {
    const cssWidth = canvas.clientWidth;
    const cssHeight = canvas.clientHeight;
    if (!cssWidth || !cssHeight) return;
    const mobile = window.matchMedia("(max-width: 767px)").matches;
    const dpr = Math.min(window.devicePixelRatio || 1, mobile ? 1.5 : 2);
    width = Math.round(cssWidth * dpr);
    height = Math.round(cssHeight * dpr);
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    gl.viewport(0, 0, width, height);
  };
  const resizeObserver = new ResizeObserver(resize);
  resizeObserver.observe(canvas);
  resize();

  let onScreen = true;
  const intersection = new IntersectionObserver((entries) => {
    onScreen = entries.some((entry) => entry.isIntersecting);
    if (onScreen) wake();
  });
  intersection.observe(scene);

  let turn = 0;
  let tiltX = 0;
  let tiltY = 0;
  let primed = false;
  let last = 0;
  let raf = 0;
  let running = false;
  let destroyed = false;

  const draw = (now: number) => {
    const dt = Math.min(0.05, last ? (now - last) / 1000 : 0.016);
    last = now;
    const k = 1 - Math.exp(-dt * 10);
    const targetTurn = readVar("--bottle-turn") + readVar("--bottle-pointer-rotate-y") * 0.8;
    const targetTilt = 0.1 - (readVar("--bottle-pointer-rotate-x") * Math.PI) / 180 * 0.6;
    if (!primed) { turn = targetTurn; tiltX = targetTilt; primed = true; }
    turn += (targetTurn - turn) * k;
    tiltX += (targetTilt - tiltX) * k;
    tiltY = turn * (Math.PI / 180);
    const bob = Math.sin((now / 1000) * 0.84) * 0.012;

    const aspect = width / height;
    const distance = Math.max(0.56, 0.36 / aspect) / Math.tan(FOV / 2);
    const cy = Math.cos(tiltY), sy = Math.sin(tiltY), cx = Math.cos(tiltX), sx = Math.sin(tiltX);
    // R = Rx * Ry, column-major
    const r00 = cy, r01 = 0, r02 = sy;
    const r10 = sx * sy, r11 = cx, r12 = -sx * cy;
    const r20 = -cx * sy, r21 = sx, r22 = cx * cy;
    const modelView = new Float32Array([
      r00, r10, r20, 0,
      r01, r11, r21, 0,
      r02, r12, r22, 0,
      0, bob * cx, bob * sx - distance, 1,
    ]);
    const normalMat = new Float32Array([r00, r10, r20, r01, r11, r21, r02, r12, r22]);

    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.uniformMatrix4fv(uProj, false, perspective(FOV, aspect, 0.1, 20));
    gl.uniformMatrix4fv(uModelView, false, modelView);
    gl.uniformMatrix3fv(uNormalMat, false, normalMat);
    gl.drawElements(gl.TRIANGLES, mesh.indices.length, gl.UNSIGNED_SHORT, 0);
  };

  const frame = (now: number) => {
    raf = 0;
    if (destroyed) return;
    // Idle while the bottle is not entering, off screen, or the tab is hidden; wake() restarts the loop.
    if (readVar("--bottle-enter") < 0.01 || !onScreen || document.hidden) { running = false; last = 0; return; }
    if (width && height) draw(now);
    raf = requestAnimationFrame(frame);
  };
  function wake() {
    if (running || destroyed) return;
    running = true;
    raf = requestAnimationFrame(frame);
  }

  const onVisibility = () => { if (!document.hidden) wake(); };
  const onContextLost = (event: Event) => { event.preventDefault(); destroy(); onLost(); };
  document.addEventListener("visibilitychange", onVisibility);
  canvas.addEventListener("webglcontextlost", onContextLost);

  function destroy() {
    if (destroyed) return;
    destroyed = true;
    cancelAnimationFrame(raf);
    resizeObserver.disconnect();
    intersection.disconnect();
    document.removeEventListener("visibilitychange", onVisibility);
    canvas.removeEventListener("webglcontextlost", onContextLost);
    buffers.forEach((buffer) => gl.deleteBuffer(buffer));
    gl.deleteBuffer(indexBuffer);
    gl.deleteTexture(texture);
    gl.deleteProgram(program);
  }

  return { wake, destroy };
}
