import { useEffect, useRef, useState, type CSSProperties } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "./language";
import { images, families } from "@/content/site";
import bottle from "@/assets/editorial-bottle.png";
import "./perfume-bottle-3d.css";
import type { BottleGL } from "./bottle-gl";

const chapters = ["The encounter", "The composition", "The fragrance edit"];
const chaptersFa = ["اولین دیدار", "ترکیب رایحه", "منتخب عطرها"];

// One setting controls the perfume colour independently from the glass and cap.
const bottleLiquidColor = "#766bb5";

// Real 3D bottle (lean GLB, re-skinned to the Scent Scribe label and palette). The CSS bottle stays as the fallback.
const bottleModelUrl = "/models/scent-scribe-bottle.glb";

// Motion writes only compositor variables; React changes only at chapter boundaries.
export function ScrollEditorial() {
  const { fa, t } = useLanguage();
  const scene = useRef<HTMLElement>(null);
  const [chapter, setChapter] = useState(0);
  const [reduced, setReduced] = useState(false);
  const [glReady, setGlReady] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const glRef = useRef<BottleGL | null>(null);

  useEffect(() => {
    const node = scene.current;
    if (!node) return;
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    let frame = 0;
    const update = () => {
      frame = 0;
      if (preference.matches) return;
      const range = Math.max(1, node.offsetHeight - window.innerHeight);
      const progress = Math.max(0, Math.min(1, -node.getBoundingClientRect().top / range));
      const beat = progress < 0.3 ? 0 : progress < 0.67 ? 1 : 2;
      node.style.setProperty("--journey", String(progress));
      // The hero is a clean ocean scene; the bottle swims into frame as the second chapter begins.
      const enterRaw = Math.max(0, Math.min(1, (progress - 0.2) / 0.18));
      const enter = enterRaw * enterRaw * (3 - 2 * enterRaw);
      node.style.setProperty("--bottle-enter", enter.toFixed(3));
      glRef.current?.wake();
      // Turn the bottle through the story instead of treating the artwork as a flat card.
      // Scroll-driven 3D turn: enters side-on (-78deg), swings to a three-quarter front view as it arrives,
      // then keeps rotating slowly through the remaining chapters (about -16deg to +38deg).
      const settle = Math.max(0, progress - 0.38) / 0.62;
      node.style.setProperty("--bottle-turn", (-78 + enter * 62 + settle * 54).toFixed(2) + "deg");
      const bottleFrame = node.querySelector<HTMLElement>(".ss-editorial-bottle-frame");
      if (bottleFrame) {
        // A measured camera drift: keep the bottle intact and grounded in the scene.
        const mobile = window.matchMedia("(max-width: 767px)").matches;
        const wave = Math.sin(progress * Math.PI);
        const driftX = -progress * (mobile ? 7 : 22);
        const lift = -progress * (mobile ? 8 : 16);
        const depth = progress * (mobile ? 10 : 26);
        const tilt = Math.sin(progress * Math.PI * 2) * (mobile ? 0.65 : 1.25);
        const roll = Math.sin(progress * Math.PI * 2) * (mobile ? 0.12 : 0.28);
        const scale = (0.965 + enter * 0.035) * (1 + progress * (mobile ? 0.012 : 0.028) + wave * (mobile ? 0.004 : 0.008));
        const rise = (1 - enter) * (mobile ? 28 : 56);
        bottleFrame.style.visibility = enter < 0.01 ? "hidden" : "visible";
        bottleFrame.style.transform = "translate3d(" + driftX.toFixed(1) + "px, " + (lift + rise).toFixed(1) + "px, " + depth.toFixed(1) + "px) rotateY(calc(var(--pointer-rotate-y, 0deg) + " + tilt.toFixed(2) + "deg)) rotateX(var(--pointer-rotate-x, 0deg)) rotateZ(" + roll.toFixed(2) + "deg) scale(" + scale.toFixed(3) + ")";
      }
      setChapter((previous) => previous === beat ? previous : beat);
    };
    const schedule = () => { if (!frame) frame = requestAnimationFrame(update); };
    const syncPreference = () => { setReduced(preference.matches); schedule(); };
    syncPreference();
    preference.addEventListener("change", syncPreference);
    window.addEventListener("scroll", schedule, { passive: true });
    window.addEventListener("resize", schedule);
    return () => {
      cancelAnimationFrame(frame);
      preference.removeEventListener("change", syncPreference);
      window.removeEventListener("scroll", schedule);
      window.removeEventListener("resize", schedule);
    };
  }, []);

  // Load the 3D bottle after first paint, never for reduced-motion or data-saver visitors.
  useEffect(() => {
    const canvas = canvasRef.current;
    const node = scene.current;
    if (!canvas || !node) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const connection = (navigator as Navigator & { connection?: { saveData?: boolean } }).connection;
    if (connection?.saveData) return;
    let cancelled = false;
    const timer = window.setTimeout(() => {
      import("./bottle-gl")
        .then(({ createBottleGL }) => createBottleGL(canvas, node, bottleModelUrl, () => { glRef.current = null; setGlReady(false); }))
        .then((created) => {
          if (cancelled) { created.destroy(); return; }
          glRef.current = created;
          setGlReady(true);
          created.wake();
        })
        .catch(() => { /* WebGL or the model is unavailable: the CSS bottle stays */ });
    }, 1800);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
      glRef.current?.destroy();
      glRef.current = null;
    };
  }, []);

  const goToChapter = (index: number) => {
    const node = scene.current;
    if (!node) return;
    if (reduced) {
      node.querySelectorAll("article")[index]?.scrollIntoView({ block: "start" });
      return;
    }
    const progress = [0, 0.44, 0.82][index] ?? 0;
    window.scrollTo({ top: window.scrollY + node.getBoundingClientRect().top + progress * (node.offsetHeight - window.innerHeight), behavior: "smooth" });
  };

  const handlePointerMove = (event: React.PointerEvent<HTMLElement>) => {
    if (reduced || event.pointerType === "touch") return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    const node = scene.current;
    if (!node) return;
    node.style.setProperty("--pointer-x", x.toFixed(3));
    node.style.setProperty("--pointer-y", y.toFixed(3));
    node.style.setProperty("--parallax-x", (-x * 22).toFixed(1) + "px");
    node.style.setProperty("--parallax-y", (-y * 14).toFixed(1) + "px");
    node.style.setProperty("--pointer-rotate-y", (x * 10).toFixed(2) + "deg");
    node.style.setProperty("--pointer-rotate-x", (y * -7).toFixed(2) + "deg");
    node.style.setProperty("--bottle-pointer-rotate-y", (x * 7).toFixed(2) + "deg");
    node.style.setProperty("--bottle-pointer-rotate-x", (y * -4).toFixed(2) + "deg");
  };
  const resetPointer = () => {
    const node = scene.current;
    if (!node) return;
    node.style.setProperty("--pointer-x", "0");
    node.style.setProperty("--pointer-y", "0");
    node.style.setProperty("--parallax-x", "0px");
    node.style.setProperty("--parallax-y", "0px");
    node.style.setProperty("--pointer-rotate-y", "0deg");
    node.style.setProperty("--pointer-rotate-x", "0deg");
    node.style.setProperty("--bottle-pointer-rotate-y", "0deg");
    node.style.setProperty("--bottle-pointer-rotate-x", "0deg");
  };

  return (
    <section ref={scene} onPointerMove={handlePointerMove} onPointerLeave={resetPointer} className="ss-editorial-scene" data-chapter={chapter} data-static={reduced} data-gl={glReady} aria-label={fa ? "سفر در دنیای رایحه" : "A journey through fragrance"}>
      <div className="ss-editorial-stage">
        <div className="ss-editorial-world" aria-hidden="true">
          <video className="ss-editorial-landscape" src="/scent-hero-v2.mp4" poster={images.hero} muted playsInline autoPlay={!reduced} loop preload={reduced ? "none" : "metadata"} ref={(video) => { if (video && reduced) video.pause(); }} />
          <div className="ss-editorial-veil" />
          <span className="ss-editorial-type">{chapter === 1 ? "ESSENCE" : "SCENT"}</span>
          <div className="ss-editorial-atmosphere" />
          <div className="ss-editorial-bottle-frame">
            <canvas ref={canvasRef} className="ss-editorial-bottle-gl" aria-hidden="true" />
            <div className="ss-editorial-bottle3d" style={{ "--ss-bottle-liquid": bottleLiquidColor } as CSSProperties}>
              <div className="ss-bottle3d__model">
                <div className="ss-bottle3d__cap"><span className="ss-bottle3d__cap-ribs" /></div>
                <div className="ss-bottle3d__neck" />
                <div className="ss-bottle3d__body">
                  <div className="ss-bottle3d__body-back" />
                  <div className="ss-bottle3d__side ss-bottle3d__side--left" />
                  <div className="ss-bottle3d__side ss-bottle3d__side--right" />
                  <div className="ss-bottle3d__top" />
                  <div className="ss-bottle3d__bottom" />
                  <div className="ss-bottle3d__body-front">
                    <span className="ss-bottle3d__liquid" />
                    <span className="ss-bottle3d__highlight ss-bottle3d__highlight--left" />
                    <span className="ss-bottle3d__highlight ss-bottle3d__highlight--right" />
                    <div className="ss-bottle3d__label"><strong>SCENT<br />SCRIBE</strong><span>EAU DE PARFUM</span></div>
                  </div>
                </div>
                <span className="ss-bottle3d__base" />
              </div>
            </div>
            <img className="ss-editorial-bottle ss-editorial-bottle--fallback" src={bottle} alt="" width="300" height="563" />
            <span className="ss-editorial-specular" />
          </div>
        </div>

        <div className="ss-editorial-heading"><span>{fa ? "بوتیک مستقل عطر" : "INDEPENDENT FRAGRANCE BOUTIQUE"}</span><span dir="ltr">SCENT SCRIBE / VOL. 01</span></div>
        <div className="ss-editorial-chapters">
          <article className="ss-editorial-chapter" data-active={chapter === 0} inert={!reduced && chapter !== 0} aria-hidden={!reduced && chapter !== 0}>
            <p className="ss-editorial-kicker">01 / {fa ? "هنر انتخاب رایحه" : "THE ART OF FINDING YOUR SCENT"}</p>
            <h1 dir="ltr">Scent<br /><em>Scribe.</em></h1>
            <p className="ss-editorial-description">{t.heroTitle.join(" ")}<br />{t.heroSub}</p>
            <Button asChild variant="outline" className="ss-editorial-link"><Link to="/shop">{t.discover}<ArrowUpRight className="h-4 w-4 rtl:-rotate-90" /></Link></Button>
          </article>
          <article className="ss-editorial-chapter" data-active={chapter === 1} inert={!reduced && chapter !== 1} aria-hidden={!reduced && chapter !== 1}>
            <p className="ss-editorial-kicker">02 / {fa ? "لایه‌های رایحه" : "THE COMPOSITION"}</p>
            <h2>{fa ? "از اولین نُت،" : "From the first note,"}<br /><em>{fa ? "تا آخرین خاطره." : "to the last memory."}</em></h2>
            <p className="ss-editorial-description">{fa ? "کهربای گرم. گلبرگ‌های لطیف. عمق چوب‌ها. خانواده‌های رایحه را کشف کن و انتخاب خودت را پیدا کن." : "Golden amber. Soft petals. The depth of woods. Explore the fragrance families and find what moves you."}</p>
            <ul className="ss-editorial-notes">{[0, 1, 2].map((i) => <li key={i}><span>0{i + 1}</span>{t.families[i]?.[0]}</li>)}</ul>
            <Button asChild variant="outline" className="ss-editorial-link"><Link to="/scent-families">{t.famTitle}<ArrowUpRight className="h-4 w-4" /></Link></Button>
            <p className="ss-editorial-caption">{fa ? "تصویر هنری نمایشی؛ نه تصویر رسمی محصولات برندها." : "Illustrative campaign bottle. Not official brand photography."}</p>
          </article>
          <article className="ss-editorial-chapter" data-active={chapter === 2} inert={!reduced && chapter !== 2} aria-hidden={!reduced && chapter !== 2}>
            <p className="ss-editorial-kicker">03 / {fa ? "منتخب خانه‌های عطر" : "THE FRAGRANCE EDIT"}</p>
            <h2 dir={fa ? "rtl" : "ltr"}>{fa ? "نگاهی به" : "A study in"}<br /><em>{fa ? "تام فورد." : "Tom Ford."}</em></h2>
            <p className="ss-editorial-description">{fa ? "انتخابی از مجموعهٔ نمایشی تام فورد؛ در کنار دیور، شنل، ایو سن لوران و دیگر خانه‌های عطر." : "Discover our Tom Ford demonstration edit, alongside Dior, Chanel, Yves Saint Laurent and more fragrance houses."}</p>
            <Button asChild variant="outline" className="ss-editorial-link"><Link to="/brand/$slug" params={{ slug: "tom-ford" }}>{fa ? "منتخب تام فورد" : "The Tom Ford edit"}<ArrowUpRight className="h-4 w-4" /></Link></Button>
            <p className="ss-editorial-caption">{fa ? "تصویر هنری نمایشی؛ نه تصویر رسمی محصولات برندها." : "Demonstration campaign artwork. Not official brand photography."}</p>
          </article>
        </div>

        <nav className="ss-editorial-index" aria-label={fa ? "فصل‌های رایحه" : "Fragrance chapters"}>
          {chapters.map((label, i) => <Button key={label} variant="ghost" onClick={() => goToChapter(i)} aria-current={chapter === i ? "step" : undefined} className="ss-editorial-index-link"><span>0{i + 1}</span><span>{fa ? chaptersFa[i] : label}</span><i /></Button>)}
          <Button asChild variant="ghost" className="ss-editorial-index-shop"><Link to="/shop">{fa ? "فروشگاه" : "Shop the boutique"}<ArrowUpRight className="h-4 w-4" /></Link></Button>
        </nav>
        <span className="ss-editorial-scroll" aria-hidden="true"><ArrowDown className="h-4 w-4" />{fa ? "دنیای رایحه" : "A WORLD OF SCENT"}</span>
      </div>
    </section>
  );
}
